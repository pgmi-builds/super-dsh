# OMP Python REPL port implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Track steps with checkboxes. Repository acceptance and release gates override skill commit steps: no commits, tags, pushes or publishing before acceptance, report and user release.

**Goal:** Replace Better's Jupyter/ZMQ substrate with the pinned OMP Python runner, retaining tool calls, session state and honest best-effort checkpoints without consumer pip installs.

**Architecture:** Node owns one Python child per session and serializes user and internal execution over OMP's NDJSON protocol. Unmodified upstream resources have provenance and licenses; Better owns initialization, binding callbacks, namespace filtering, checkpoints, output mapping and lifecycle. Checkpoints preserve an admitted object graph and expose incomplete coverage without replaying user code.

**Tech Stack:** Node child_process, TypeScript, Python stdlib, vendored dill 0.4.1, Vitest, Cordis/DSH native composition.

**Spec:** `docs/specs/omp-python-repl-port/spec.md`. User approved BOTH phases on 2026-10-12.

## Global constraints

- `runner.py` is copied byte for byte from commit `fa5ff4a3a977a28b93d025f4cf50f046e019f18c`; expected SHA256 `e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974`.
- Copy required MIT notices and original source provenance; no OMP package import or Bun runtime. Use packaged `.py` resources, compiled JS at runtime.
- Vendor dill 0.4.1 Python sources unchanged with BSD-3-Clause notices; no consumer pip install. Python interpreter remains required, supported baseline >=3.9 subject to pinned runner verification.
- Preserve `ReplRuntime` public seam and lossless JSON/tool-error/cancellation contracts. No upstream checkout edits.
- Internal cells serialize with user cells and cannot pollute visible output/user namespace lists. No unowned listener or callback admission after cell completion.
- Checkpoints exclude runner/Better/tool bindings and OS resources, commit atomically, retain previous valid generation after failure/cap, validate manifest/environment/integrity before load, and report skipped state and latest successful turn.
- Do not automatically retry/replay the death-observing cell or assert it did not execute if it began. Reset clears memory and disk.
- Use existing checkout on `codex/omp-python-repl-port`; preserve unrelated working changes. LSP/AST inspection evidence is `/tmp/omp-lsp-ast.json` plus protocol research evidence.
- Test versions synchronize using root `version:release`; next round `0.3.0-s`. No npm publish, Git commit/tag/push or production actions.
- Acceptance requires current launcher tarballs at PC4999 and dev3 independent test installation, actual model-visible tool use, report under `docs/test-reports/`, and running browser review URL.

## Task 1: Replace execution substrate and deliver resources
