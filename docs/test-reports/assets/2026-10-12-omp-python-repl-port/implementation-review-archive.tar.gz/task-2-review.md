# Task 2 independent review

## Spec Compliance

- ❌ Issues found: save/restore admission differs for overridden startup bindings; dependency pruning misses statically inspectable callbacks; unsuccessful writes do not keep disk usage bounded. See Important findings below.
- ⚠️ Consumer tarball PC4999/dev3 acceptance and the broader Better suite remain controller gates, intentionally outside this Task2 review. They are not reasons for this verdict.

## Strengths

- `better-dsh/src/omp-python/better_snapshot.py:124` and `:134` contain the pinned, instance-local dill namespace adapter. Real fresh-process assertions at `better-dsh/test/omp-checkpoints.spec.ts:14` and `:31` verify aliases/cycles, closures and LIVE function/class globals after rebinding, rather than checking only initial restored values.
- `better-dsh/src/omp-python/better_snapshot.py:96` guards nested resources and captured owned bindings; `better-dsh/test/omp-checkpoint-safety.spec.ts:20` exercises captured proxies versus recreated current tools and transitive ordinary-function/class dependencies.
- `better-dsh/src/omp-python/better_snapshot.py:258` uses one atomic manifest pointer. `:285` and `:302` validate environment and integrity before decode. The cap, timeout, caught-interrupt, corrupt-checkpoint and reset cases are concrete behavior tests (`better-dsh/test/omp-checkpoint-safety.spec.ts:59`, `:76`, `:115`).
- `better-dsh/src/runtime.ts:231` serializes whole principal operations, and `better-dsh/test/omp-checkpoint-safety.spec.ts:172` checks query/set/reset ordering behind an active cell. `better-dsh/src/runtime.ts:168` derives defaults from official ProfileContext while preserving explicit configuration; the actual Cordis fixture at `better-dsh/test/omp-checkpoint-safety.spec.ts:186` checks default and disable.
- `better-dsh/test/omp-checkpoint-safety.spec.ts:90` verifies side effects occur once, user output survives, and successful recovery does not deny partial execution or request blind replay.

## Issues

### Critical

- None found.

### Important

1. **Saved startup-name overrides make the entire checkpoint unrestorable.** `better-dsh/src/omp-python/better_snapshot.py:291` rejects every name returned by `reserved_names()`, whereas save selects `better_support.user_namespace()` (`better-dsh/src/omp-python/better_support.py:390`), which intentionally admits user replacements by checking both name and original-object identity. The original runner installs `display` at `better-dsh/src/omp-python/runner.py:1784`, and initialization remembers that binding. Thus `display = 42; valuable = [1, 2]` is admitted and reported as successfully saved, but the next fresh restore rejects the complete payload with `ValueError: invalid checkpoint namespace names`, losing even `valuable`. A focused helper probe reproduced exactly that result. Align admission and restoration rules: preserve legal user replacements, or explicitly omit/report disallowed replacements at save time so the remaining graph can restore. Add a real fresh-runner regression.

2. **Dependency pruning admits broken nested callbacks without reporting them.** `better-dsh/src/omp-python/better_snapshot.py:162` through `:178` only follows selected containers and user-instance `__dict__`; it ignores `functools.partial` contents and slot values. With an omitted `bad` whose reducer raises, both `wrapped = functools.partial(lambda: bad)` and a user slotted instance with `slot.callback = lambda: bad` are saved and restored as admitted names. Both raise `NameError` after restore; only `bad` is in omissions. This is a statically inspectable dependency, not the documented dynamic-eval limitation. Focused probe: save returned names `[Bad, Slotted, functools, slot, wrapped]`, omission `{bad: "TypeError: bad"}`; restore returned count 5; both callbacks raised `NameError: name 'bad' is not defined`. Traverse these supported structures (including inherited slot descriptors) or conservatively omit an unsupported root with an explicit inspection reason; add fresh-process tests for both cases and transitive dependents.

3. **Repeated failed commits accumulate unbounded checkpoint artifacts.** `better-dsh/src/omp-python/better_snapshot.py:253` and `:255` create payload/temp files, but cleanup runs only after successful replacement (`:263`); exception handlers at `:269` and `:271` do not remove files created by the failed attempt. Deadline exhaustion after writes and pointer-write failures therefore leave up to a full capped payload plus manifest temp each time. A focused fault-injection probe saved one valid generation, injected three `os.replace` failures, and observed growth from two files to eight while every save reported failure. The report acknowledges cleanup only on later success/reset, which does not meet failure-path boundedness when failures persist. Preserve the current and retained valid generations, clean this attempt's uncommitted files in a finally path, and scavenge recognized abandoned files before subsequent writes to handle killed writers. Add failure/deadline/crash-orphan coverage, not only the successful-commit bound at `better-dsh/test/omp-checkpoint-safety.spec.ts:136`.

### Minor

- `better-dsh/src/runtime.ts:637`: the respawn-failure return occurs before the started/unstarted wording at `:644`, so a cell that performs an external side effect, exits, and cannot respawn gets no partial-execution/no-replay explanation. Reuse the execution-status wording in this return as well, and exercise a failing-respawn branch. The ordinary successful-respawn path is correctly tested.

## Verification and scope

- Read the supplied Task1→Task2 working diff once in sequential chunks, task brief, global context, and the implementation report when it appeared. No Git/index/HEAD/source changes or subagents; only this report was written in the checkout.
- Read existing evidence: `/tmp/omp-task2-red.log` (4 expected failures), `/tmp/omp-task2-final94-suite.log` (94/94, 13 files), `/tmp/omp-task2-final-python39.log` (19/19), `/tmp/omp-task2-final-typecheck.log` (host/client successful), and `/tmp/omp-task2-resource-guard.log` (positive guard and altered-fixture rejection). No warning/error noise in final supplied logs. Did not rerun suites.
- Ran two short, isolated Python commands with temporary checkpoint directories and bytecode writes disabled: the first checked unsupported dependency containers and injected pointer-swap failures; the second checked save/restore name-rule mismatch and compared vendored bytes. The detailed observed outcomes are recorded in findings 1–3. Temporary directories were automatically removed.
- Independently hashed the retained dill wheel and compared all 14 runtime source files plus the BSD license byte-for-byte to that artifact and to `dill-provenance.json`; all matched. This uses the previously obtained immutable artifact, not an unverified implementer assertion.
- Focused surrounding-seam checks: runtime run/restore/counter/disposal context was read because review hunks cut those methods; bridge internal-cell deadline dispatch was checked for timeout semantics; `better_support.user_namespace`, initialization, and binding installation were checked for save/restore ownership consistency; original runner `display` installation was located for the concrete startup-name finding; the unchanged controller-authored `omp-checkpoints.spec.ts` was read to verify the omitted-from-diff graph/counter requirements. No broad branch crawl.

## Assessment

**Task quality: Needs fixes.** The implementation has strong real-process coverage and correctly contains pinned serializer adaptation, but the three reproduced failure cases undermine honest best-effort recovery and bounded storage. Resolve those cases and run focused regressions before the Task2 gate passes.
