# Task 1 review — OMP execution substrate

Date: 2026-10-12. Reviewed working tree, without commits or production access.

**Spec compliance: changes required.** The execution substrate and delivery resources largely match Task 1, but the compiler compatibility helper, native-reset input protection, and cancellation of subprocess work need correction.

**Code quality: changes required.** The isolated support module and transport are substantially simpler than the retired substrate. Three reproduced behavioral defects below prevent approval. Namespace pollution is a smaller additional correction.

## Findings

### R1 — P1: install the helper required by the pinned compiler

Location: `better-dsh/src/omp-python/better_support.py:193` (initialization at lines 57–67).

The pinned runner's `_ShadowCallSiteTransformer` rewrites `tool.read(one_argument)` to `__omp_with_call_site__(site_id, callable, argument)` even when speculation is unused. That helper normally comes from the omitted OMP prelude. Better initializes bindings but never installs a replacement. A valid namespace binding named `tool` with function `read` therefore fails before contacting the host.

Focused actual bridge probe: execute `await tool.read({"path":"x"})`, spec `{ "tool": { "functions": ["read"] } }`, and a handler returning 42. Result was `status: error`, `NameError: name '__omp_with_call_site__' is not defined`; host invocation count was **0**. Existing `tools.echo` fanout coverage does not exercise this compiler path. The same rewritten shape can occur in ordinary user code defining its own `tool` object.

Remediation: supply a Better-owned compatible forwarding helper with the compiler's exact calling convention, account for its ownership/filtering and reset behavior, and leave runner bytes unchanged. Add a focused valid `tool.read` binding regression, including correct result and exactly one host invocation.

### R2 — P1: cancellation can return while subprocess work continues

Location: `better-dsh/src/kernel.ts:210`–214; signal target at line 272 and force-timer clearing at line 264.

Abort/timeout sends SIGINT only to the runner leader. When the leader responds with `done`, `settle()` clears the force timer and the owned process-group cleanup never runs. A subprocess launched by the interrupted cell can therefore keep running after cancellation is returned, performing side effects concurrently with later cells. Group cleanup on eventual bridge disposal does not satisfy cancellation of current subprocess work. This also affects newly exposed OMP shell/pip subprocess helpers, which do not have a cancellation cleanup `finally` around their subprocess operations.

Focused actual bridge probe ran `import subprocess, time; p = subprocess.Popen(["sleep", "20"]); print(p.pid, flush=True); time.sleep(20)` (as separate source lines), with a 500 ms execution timeout. The bridge returned `outcome: forced`, `failure.kind: timeout`, but `process.kill(childPid, 0)` succeeded and `bridge.isRunning` was still true. The review probe then explicitly disposed its bridge to clean up the owned group.

A second, narrower probe used the **foreground native shell** cell `!echo $$; sleep 20`, eliminating ambiguity about intentionally detached user work. It also returned timeout while the printed shell PID remained alive. This finding targets foreground work owned by the cancelled operation, not a blanket requirement to kill every intentionally persistent background process in the session. The immutable OMP helper itself lacks interruption cleanup; no old-Jupyter comparative runtime probe was performed, so this is not asserted as a newly introduced generic `Popen` regression. It is an uncovered gap in the requested Task 1 abort/timeout mapping, subprocess cleanup, and bounded termination contract when adapting native OMP shell execution.

Remediation: define and implement cleanup for owned subprocess work on the responsive-cancellation path, before admitting the next cell. Preserve the existing PID-survival contract for ordinary interrupted Python cells; do not simply destroy every runner on every abort. Add a focused subprocess cancellation regression checking the subprocess is no longer executing when cancellation returns. Account for descendants that ignore the first signal.

### R3 — P2: native reset removes input protection in the same cell

Location: `better-dsh/src/omp-python/better_support.py:174` and 193 (initialize only before the submitted program).

The immutable `%reset` implementation restores the original builtins dictionary. OMP executes the final expression separately from the preceding body, so a final `input()` after reset uses the original blocking input function, not Better's unsupported-input guard. Reinitializing on the next operation is too late: control stdin is already being consumed by user input.

Focused actual bridge probe: `%reset\ninput("question")` returned a 500 ms timeout, printed `question`, and exhausted its cancellation grace, destroying the runner. The immediately following `42` returned `worker-exit: Python is not running`. Normal `input()` is already tested, but this documented open question is a real reproducible protocol/lifecycle failure, not just a missing test.

Remediation: reinstate Better's input protection immediately when native reset occurs through a Better-owned adaptation, or reject the unsupported same-cell usage explicitly before execution. Preserve the immutable runner and supported reset semantics. Add a regression asserting an actionable immediate error and a usable subsequent cell. Persistent checkpoint clearing remains Task 2 and is not part of this finding.

### R4 — P2, smaller scope: omit the synthetic execution filename from user state

Location: `better-dsh/src/omp-python/better_support.py:193` and 204–208.

Passing `filename='<better-cell>'` invokes the runner's `_prepare_file_source`, which writes `ns['__file__']`. The ownership snapshot is captured before that occurs and `user_namespace()` does not exclude the synthetic value. A fresh runner executing only `42`, followed by `queryVar(null)`, returned `['__file__']`. This exposes adapter-created state as a user variable and hands it to the forthcoming snapshot filtering seam.

Remediation: track/filter the adapter-owned filename identity/value or avoid creating it for ordinary cells, while preserving a genuine user-defined value according to the ownership policy. Verify an otherwise empty REPL has no adapter-created variable in its names query.

## Verified and accepted aspects

- Read Task 1 brief, global context, implementation report, working diff, specification, local AGENTS, and the pinned protocol research. Inspected the actual owned source and only relevant runner/runtime/build/output call sites outside the diff.
- Source and built runner SHA-256 both equal `e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974`. No immutable runner change is requested. Provenance and full MIT notice are shipped by the resource-copy mechanism.
- Better uses actual `transform_cell` and `_exec_source_async`; typed final completion, None suppression, top-level await, and compiler error handling are connected to the existing runtime seam. The former standalone AST executor is removed.
- POSIX callbacks have dedicated pipes, unique callback and run identities, concurrent dispatch within a cell, revocation on cell completion/cancellation, and stale reply checks. Internal execution shares the bridge queue and hides its output from user results.
- Startup is a bounded real initialization cell. Process exit now initiates disposal and settlement follows close/drain handling. The reported additional SIGINT confirm window and startup-disposal guard are present in reviewed source.
- Interpreter probe is stdlib-only and requires >=3.9. Managed compatibility environments no longer install Jupyter or dill packages. Runtime resource URLs resolve relative to emitted modules; recursive copying includes support/provenance/notices. Installed tarball and target-machine proof remains the parent's later delivery gate.
- Windows authenticated loopback callbacks, proxy bypass, and listener closure are implemented. Windows execution was unavailable; the explicitly reported leader-only Windows descendant termination is an accepted scoped limitation for this review, not a claim of parity or an extra blocker.

## Evidence and boundaries

Existing reported RED/GREEN/typecheck/build evidence was considered; no broad suite was rerun. Review-only probes directly imported `kernel.ts` and `python.ts` through the installed `tsx` runner, started isolated `python3` children, and disposed every bridge in `finally`. They exercise the reviewed transport/support code, not a stale `lib/` copy. One attempted Node transform-types invocation was unsupported and did not launch a Python child; the probes then used installed tsx successfully.

Task 2 snapshot implementation, vendored dill probe, full runtime transaction serialization/cold-start races, checkpoint reset semantics, and final PC4999/dev3 delivery acceptance remain explicitly pending and are **not** grounds for this Task 1 rejection. No Git finalization, source edits, production reads/actions, or extra subagents were used. Only this requested review report was written.
