# Task 1 implementation report — OMP execution substrate

Date: 2026-10-12 (Asia/Hong_Kong). Scope: Task 1 only. No commit, tag, push, publish, production home access or production process mutation.

## Delivered

- Unchanged pinned `runner.py`, full OMP MIT license and JSON provenance in `better-dsh/src/omp-python/`. Runner SHA-256 is `e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974`, confirmed identical in source and `lib/omp-python/runner.py` after build.
- Better-owned `better_support.py` owns module-qualified initialization, bindings, typed rejection, completion encoding, variable query/set and filtering. The OMP Agent prelude is neither executed nor shipped.
- Actual native OMP execution: Better calls the unchanged runner's `transform_cell`, wraps only the transformed final AST expression to carry the existing typed JSON envelope, and invokes the unchanged runner's `_exec_source_async`. OMP still owns source transformations, compilation, top-level await, execution and errors. This is not the retired standalone AST executor. No runner monkey patch or source edit.
- Node per-child NDJSON transport, startup initialization cell, queue serialization, request ID output correlation, stdout/stderr/error/display mapping, signal-based interruption, bounded teardown and POSIX owned process-group sweep. No Jupyter connection file, ZMQ transport or kernel bridge Python process.
- POSIX callbacks use dedicated inherited fd 3/4; requests correlate to active run and unique callback ID, fan out concurrently, and are revoked at cell end/cancel. Windows avoids nonportable extra fd inheritance: scoped authenticated loopback HTTP, standard-library Python client, explicit proxy bypass and close-owned listener.
- Python >=3.9 interpreter probe; configured stdlib-only venv accepted. Managed compatibility venv creation remains but installs no kernel packages and fallback uses `--without-pip`. `kernel:venv` is an explicit environment preparation command; no install hook/download.
- Build resource copy recursively ships Python resources/notices/provenance and excludes pycache/pyc. Child/probe use `PYTHONDONTWRITEBYTECODE=1`. Removed `kernel-transport.ts` and `kernel-bridge.py`.
- Product code outside Task1's owned files was not changed. Root independently owns README/eval-description/plan/docs.

## Actual RED and GREEN

1. Added stdlib-only venv runtime test and actual OMP magic/shell/reset test before implementation. Ran `npm --prefix better-dsh test -- test/runtime.spec.ts test/kernel-env.spec.ts`.
   - RED: 2 expected failures / 17 passes. Standard-library venv failed with missing ipykernel; magic failed with SyntaxError under old AST executor. Evidence: `/tmp/omp-task1-red.log`.
2. After port: runtime suite 16/16 passed (`/tmp/omp-task1-green-runtime.log`). Includes persistence, typed dict completion, docstrings/multiline strings, None suppression, top-level await, top-level return rejection, error mutation retention, stdlib-only environment, magic/shell and helpers after `%reset`.
3. Final execution set: `runtime.spec.ts`, `kernel-env.spec.ts`, `bindings.spec.ts`, `parallel.spec.ts`, `run-cell.spec.ts`, `interrupt-race.spec.ts`, `omp-execution.spec.ts`: 48/48 passed, 7 files. Evidence: `/tmp/omp-task1-final-execution.log`.
4. After process-exit/close ordering correction: `interrupt-race.spec.ts` + `omp-execution.spec.ts`: 9/9 passed. Evidence: `/tmp/omp-task1-final-cancellation.log`.
5. Selected non-snapshot lifecycle cases (`disposes the kernel|aborts an in-flight|times out`): 3 passed, snapshot case intentionally not run. Evidence: `/tmp/omp-task1-final-lifecycle.log`.
6. Host and client typechecks passed after fixing the test callback's return type. Evidence: `/tmp/omp-task1-final-typecheck.log`.
7. Better build succeeded; resource copy ran and source/lib original runner hashes matched. Evidence: `/tmp/omp-task1-build.log`. This build preceded the final startup-disposal guard and final test type annotation; root must rebuild final delivery after Task2.
8. Post-tests process inventory showed no Task1 OMP runner children. One existing production ipykernel was observed and left untouched; production was not part of these tests.

New integration cases include gather fanout with peak host concurrency 3, stale detached callback denied before host invocation, native subprocess stdout through runner capture, unsupported interactive input, and SIGINT-resistant child killed/reaped before cancellation returns.

The old same-tick-abort regression expected `race_marker` to exist after an aborted assignment. Changed its verification to `print("alive")`: the actual contract is interpreter survival; cancelled code need not execute. The other cold/queued/busy-loop checks continue to require PID stability. Existing snapshot-sensitive session test remains failed pending Task2, intentionally not represented as passing.

## LSP / AST and source evidence

Read actual existing runtime, bootstrap, Python cells, kernel, environment, binding/parallel/cancellation/lifecycle tests; read all pinned runner dispatch/transform/compile/execution/signal ranges and protocol report. Actual earlier LSP/TypeScript AST results are `/tmp/omp-lsp-ast.json`; pinned Python actual LSP and AST results and runtime probes are referenced in `/tmp/omp-python-protocol-research.md`. These established runtime bridge call sites and the actual OMP transformation/execution API before implementation. No capability gap is claimed.

## Task2 handoff / limitations

- `snapshotState` returns an explicit `failed` pending-Task2 result; `restoreState` returns explicit degraded pending-Task2 result. No snapshot success claim. `buildSnapshotCell` / `buildRestoreCell` already produce module-qualified `better_snapshot.save/restore` calls. Task2 should wire them through the existing private internal-cell parser and extend outcome shapes as needed.
- `KernelEnv.dill: true` currently means packaged snapshot capability selected; Task2 must actually vendor dill 0.4.1 and probe/import it as planned. No external dill installation is performed.
- Runtime still requires Task2's whole per-principal transaction queue to prevent duplicate cold children and run/snapshot/query/set/reset/dispose interleaving; bridge-level execute serialization alone cannot solve those runtime-level races.
- `user_namespace` excludes original runner identities and current injected binding names. Task2 must reject aliases and nested references to binding/callback/event-loop/OS resources, not merely filtered top-level globals. Per-variable serialization alone is insufficient for shared globals/aliases; use the final snapshot research.
- Native `%reset` preserves module-qualified helper availability but clears user globals; a later operation reinitializes Better input handling and bindings. Task2 must clear persistent checkpoint on native magic reset and define same-cell rebinding/reset behavior.
- `input()` is actionable unsupported during normal cells. Direct `sys.stdin.read()` remains an unsupported protocol hazard; cancellation remains bounded. A native `%reset` followed by `input()` in the same submitted cell can bypass the next-operation initialization; reviewer should decide whether the Better adaptation must reinstate its input binding immediately after reset.
- Text-only `ReplRuntime` has no image field; rich displays choose text/plain/markdown/html or JSON, and nontext-only bundles produce an explicit MIME placeholder. No image support claim. Native shell helper retains upstream's explicit truncation notice; Node does not silently tail/truncate user stream data.
- POSIX cancellation escalates to group kill and waits for close before settlement. Exit callback marks dead and starts disposal; it no longer resolves merely on `exit`. A second SIGINT after `interruptConfirmMs` covers the runner's `started`-before-signal-handler window and is cleared on every terminal path.
- Actual Windows execution was unavailable. HTTP callback portability is implemented but unverified there; Windows descendant group cleanup remains leader-only (`child.kill`), whereas POSIX sweeps the whole owned group. This concrete portability gap needs reviewer disposition before claiming equivalent Windows lifecycle behavior.
- Resource module path is based on the compiled module's `import.meta.url` next to `omp-python/`. Build verified copies, but installed tarball/PC4999/dev3 behavior remains root's later acceptance responsibility.

## Files owned

`better-dsh/src/{kernel.ts,kernel-env.ts,bootstrap.ts,python.ts}`, new `better-dsh/src/omp-python/{runner.py,better_support.py,OMP-LICENSE,provenance.json}`, deleted `better-dsh/src/{kernel-transport.ts,kernel-bridge.py}`, `better-dsh/scripts/{copy-kernel-bridge.mjs,kernel-provision.mjs}`, `better-dsh/package.json` description/keyword only; tests `runtime.spec.ts`, `kernel-env.spec.ts`, `interrupt-race.spec.ts`, new `omp-execution.spec.ts`.

## Review fix round 1 — R1, R3, R4 addressed; R2 pending root lifecycle ruling

Read the final independent review at `task-1-review.md`. Added four focused actual runtime regressions before production changes: native `tool.read` including typed rejection, same-cell `%reset` + input, same-cell reset + read binding, and empty namespace names after `42`. RED: all four failed as reported (`/tmp/omp-task1-fix1-red.log`).

Better-owned fixes, runner unchanged:

- Added async `with_call_site(site_id, action, args)`, installed as runner-required `__omp_with_call_site__`; forwards and awaits callable result without claiming OMP speculative identity/cache support. Native runner's compiler instrumentation remains active.
- Added an AST adapter for the transformed native reset call. It calls the original magic then immediately restores Better initialization and current bindings through module functions and a per-cell ContextVar. It does not replace the runner magic function. Input and native tool.read work correctly in the same cell after reset.
- Uses runner's default cell filename instead of synthetic `<better-cell>`, avoiding `_prepare_file_source` injecting `__file__`. No blanket ban on genuine user `__file__` values was added.
- Provenance describes the additional deliberate adaptations.

GREEN: full `omp-execution.spec.ts` 9/9 (`/tmp/omp-task1-fix1-green.log`), scoped runtime + bindings + execution suites 33/33 (`/tmp/omp-task1-fix1-regression.log`), host typecheck passed (`/tmp/omp-task1-fix1-typecheck.log`). Actual Python AST inspection emitted adapter/function structure to `/tmp/omp-task1-fix1-ast.json`; actual pyright LSP definitions/references for new helper and ResetAdapter are `/tmp/omp-task1-fix1-lsp.log`.

R2 requires cancellation-time foreground descendant cleanup, including children that ignore SIGINT, while preserving ordinary interrupted runner PID. This is not fixed by the earlier exit/close ordering change. Root has been given scoped implementation options and owns the pending ruling; no lifecycle change or R2 success is claimed here. Windows leader-only teardown is explicitly accepted as scoped limitation by the independent review; still no Windows behavior parity claim.

## Review fix round 1 — R2 responsive cancellation and immutable build guard

Root ruled that responsive cancellation should clean descendants NEW to the current cell, preserving prior persistent children and ordinary runner PID. Added actual native `!echo $$; sleep 20` and SIGINT/SIGTERM-ignoring Python `Popen` timeout regressions. RED: both showed live child PID after timeout (`/tmp/omp-task1-r2-red.log`).

Better support snapshots a process-tree baseline at cell entry. Linux enumerates children of every thread via `/proc/<pid>/task/*/children` and stores `/proc/<pid>/stat` birth identities, avoiding PID-reuse signaling. POSIX fallback uses bounded `ps` probes. On KeyboardInterrupt it temporarily ignores host confirm SIGINT, discovers new descendants, signals TERM, escalates to KILL after 25 ms, waits/reaps direct children and verifies no recorded child is executing. Loop budget is 100 ms; host interrupt grace remains the hard outer bound. New descendants found during cleanup are added while known identities remain tracked across reparenting. Earlier persistent children are excluded. Any baseline/inspection/cleanup failure exits the runner with 130; Node then sweeps the owned group and preserves pending timeout/abort outcome instead of admitting another user cell on an unproven runner. Windows still has the accepted leader-only limitation; intentionally escaped/double-forked work is outside this process-tree proof.

GREEN: both cancellation cases passed (`/tmp/omp-task1-r2-green.log`). Extended the ignored-signal test to assert a child from a prior successful cell survives this cancellation and the runner retains its PID; the test then explicitly terminates/waits its own persistent child. Final full OMP execution + interrupt-race suites: 15/15 passed (`/tmp/omp-task1-fix1-final.log`), host typecheck passed (`/tmp/omp-task1-fix1-final-typecheck.log`).

Build copier now hashes original runner bytes against provenance BEFORE creating/copying lib resources, rejecting any mismatch. Excludes bytecode and tests from resource copies. Actual negative test used a throwaway fixture with deliberately mismatched source, leaving original vendor untouched; it failed before copying. Actual real copy succeeded with the pinned SHA (`/tmp/omp-task1-resource-guard.log`).

This supersedes earlier reported same-cell reset and filename limitations. Snapshot and final tarball/target acceptance remain Task2/root responsibilities. An additional caught-KeyboardInterrupt edge was reported to root for disposition: if user code itself catches SIGINT and returns normally, this exception-based cleanup hook would not run. A temporary Better-owned signal wrapper tracking the interrupt and restoring the runner handler would close that edge without changing runner source; no additional implementation is claimed at this report checkpoint.

## Final caught-interrupt correction (approved root scope)

Root approved the remaining realistic edge. Added a regression where user code catches the timeout's KeyboardInterrupt and returns normally while its newly created child ignores TERM. RED showed the child remained live (`/tmp/omp-task1-caught-red.log`). Better now temporarily wraps SIGINT only during its own run: records receipt, delegates the previous runner handler unchanged, and runs descendant cleanup in finalization whenever a signal was observed (or KeyboardInterrupt propagated). It then restores the previous handler. Cleanup temporarily ignores confirm SIGINT and still retires the runner on any uncertainty. No runner function/source or subprocess monkeypatch is used.

GREEN: full OMP execution + interrupt-race suites 16/16 (`/tmp/omp-task1-caught-green.log`), including prior persistent child and ordinary runner PID preservation. Resource copier reverified pinned immutable SHA and refreshed packaged support/provenance (`/tmp/omp-task1-fix1-final-resources.log`). This supersedes the previously pending caught-KeyboardInterrupt edge. No further Task1 product edits are planned before reviewer recheck.

## Python 3.13+ docstring semantic test correction (test only)

Investigated the full-suite docstring failure with systematic-debugging. Minimal original source, parsed AST literal and `ast.unparse` output all retain the same string contents; actual Python 3.14.8 and `/usr/bin/python3` 3.14.4 nevertheless strip its common indentation when compiling original source, AST, or unparsed source. Actual Python3.11.17 retains it. Evidence: `/tmp/omp-docstring-{python314,python3144,python311}.log`; focused pre-correction runtime failure3.14/pass3.11: `/tmp/omp-docstring-runtime{314,311}.log`. This is native interpreter behavior, not an adapter product defect. Official Python3.13 release notes confirm the compiler change: https://docs.python.org/3.13/whatsnew/3.13.html#other-language-changes .

Root authorized a test-only correction. `test/runtime.spec.ts` now compares the adapter's docstring result to the same `KERNEL_PYTHON` compiling the untouched original program in an independent namespace. This preserves the meaningful native-source oracle without imposing pre3.13 semantics. Updated the same file's obsolete ipykernel suite comment; no product source changed.

Focused docstring and ordinary multiline literal tests both passed on actual `/usr/bin/python3`3.14.4 (2/2; `/tmp/omp-docstring-fixed314.log`) and isolated Python3.9.25 (2/2; `/tmp/omp-docstring-fixed39.log`). Task2 source files were not edited or otherwise mutated during this investigation.
