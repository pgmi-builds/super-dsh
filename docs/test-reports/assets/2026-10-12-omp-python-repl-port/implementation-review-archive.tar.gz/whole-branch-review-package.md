# Whole-branch working-tree review

No commits per repository release gate. HEAD is task baseline. Includes task-owned working changes and new files; excludes initial unrelated docs/README and unrelated specs/reports/settings. Original copied runner and dill source/license bytes recorded as immutable resources with hashes below; own source full diff included.

Base: cac344e5aea4f53c40439b0f63d1db29c86eaacc

- better-dsh/README.md: 12696 current bytes; sha256 34c18fe5b844e52255394fde6edb85e8f3e3859d2ea1e14a68faa6547891b217
- better-dsh/cordis.patch.yml: 5269 current bytes; sha256 2b09cd77a2437ff4e8a467c765771d95439be1a10159c5af93b8f7c4d485fac3
- better-dsh/eval-description.md: 3029 current bytes; sha256 7966bacfc69e7e82c2a378812ca3f560ebcef4a66bc25191668dec4e878297dc
- better-dsh/package-lock.json: 120721 current bytes; sha256 d0176351599736e915caf8d569610e7720f2516654cbaa10f595664cc66dfb22
- better-dsh/package.json: 12661 current bytes; sha256 621dc41f1316971ac1a6b8668c7263ae0c26989d73c89ee755eec0c4e9217949
- better-dsh/scripts/copy-kernel-bridge.mjs: 1387 current bytes; sha256 8e3d6a846234d068480e137ddff3d14674309c229c1c495e766b42fb38c76570
- better-dsh/scripts/kernel-provision.mjs: 415 current bytes; sha256 9abeca6db13f167fe58a6a0c2205824985ee0abdb4437e62455ea4c38ae7e3d4
- better-dsh/src/bootstrap.ts: 169 current bytes; sha256 5d0f38f7cb55bd57018c1b45eb086b6f801beae114f717c0ad800986a1d94b46
- better-dsh/src/index.ts: 58639 current bytes; sha256 a29e2e1da9eca0f32c0527f1ac533885e0185e1854b618edfd4efde183c78ddc
- better-dsh/src/kernel-bridge.py: 0 current bytes; sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- better-dsh/src/kernel-env.ts: 3400 current bytes; sha256 6bc1cace90a31b63076596939396bdd057cd9a98752857c3882c1ba5a865fb42
- better-dsh/src/kernel-transport.ts: 0 current bytes; sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- better-dsh/src/kernel.ts: 19283 current bytes; sha256 d4d7d52eef6b8208c781b311a4141db7c7dcc326b503d91bd94a954455e4bcb0
- better-dsh/src/omp-python/DILL-LICENSE: 1790 current bytes; sha256 f669d63bebf765baaa0b20d8b0c1193296a7e0ea0c22c50a308b74d76ab3939c
- better-dsh/src/omp-python/OMP-LICENSE: 1144 current bytes; sha256 16c45f9d667442781f03fa198914cc39abcaa48ec5ed8f644643e554ca2fbf63
- better-dsh/src/omp-python/better_snapshot.py: 17470 current bytes; sha256 c2b9ff92211e9940f7c4cf7bd3415c202528e5db6cdf39a313e215d02a154c42
- better-dsh/src/omp-python/better_support.py: 16723 current bytes; sha256 57c283f15e83fc3d600612dc81cb33e0f349883176399fb89a07f0d4229d23c2
- better-dsh/src/omp-python/dill-provenance.json: 2272 current bytes; sha256 824dcd24d5539a55a5d01cf3a7c2bdae26a6bc0678e65aab18c10f8f14ef7ea2
- better-dsh/src/omp-python/provenance.json: 1266 current bytes; sha256 abf07547705c5b7e3164ef82e4a7004e9e90a1da4f642dd80b6bc7e5250231a0
- better-dsh/src/omp-python/runner.py: 90278 current bytes; sha256 e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974
- better-dsh/src/omp-python/vendor/dill/__diff.py: 7146 current bytes; sha256 ed70aa5887a54d648b8e278e22edd7b6bd6652e8bd6019a5b4fefeb6fb6b1be4
- better-dsh/src/omp-python/vendor/dill/__info__.py: 10756 current bytes; sha256 106836361f383613e762ad49da3e8400f8b105bde9b15c58fb9ac05b3afca6b9
- better-dsh/src/omp-python/vendor/dill/__init__.py: 3798 current bytes; sha256 63cbac9f3a5fb1c949c53e93bd16066ab117916117a6bbf8942d992746c63366
- better-dsh/src/omp-python/vendor/dill/_dill.py: 91730 current bytes; sha256 35d695c86cce6f94b9eda6d83747855dca20a1c1d0ad306452bbbb72ac367f03
- better-dsh/src/omp-python/vendor/dill/_objects.py: 20015 current bytes; sha256 fd773b3aa9d97ac0e62819ad91b92b041303cc7dd3205cbfbed311b5cee5b122
- better-dsh/src/omp-python/vendor/dill/_shims.py: 6635 current bytes; sha256 92421aee6b961c7a7db88b6935f7ea99b8413b830428f21d7b21ce2b1c76545e
- better-dsh/src/omp-python/vendor/dill/detect.py: 11207 current bytes; sha256 55b0b234c68856e762a8cd672e61b04bec975ba33d0a47696e455aac09a726a5
- better-dsh/src/omp-python/vendor/dill/logger.py: 11143 current bytes; sha256 675c2053c05b48011604aa2e71844762b16154baaaa934e2f811dc7ec79b8bcf
- better-dsh/src/omp-python/vendor/dill/objtypes.py: 736 current bytes; sha256 de10c49d14b4e34995c80de7309a74b1e222030f5269fc5bbaf1b9b45bed85f1
- better-dsh/src/omp-python/vendor/dill/pointers.py: 4467 current bytes; sha256 cde5fc5ea94b0485bdbcbf971ff7abf475169889e56df5a362dbdae7a7939b0c
- better-dsh/src/omp-python/vendor/dill/session.py: 23541 current bytes; sha256 f3c0c914842b03cef7dcff952a46c2ab47759722737244180ab1b170f79229e1
- better-dsh/src/omp-python/vendor/dill/settings.py: 630 current bytes; sha256 0d1169d900bcc6ca4f67949bdde201e9a6cfa75c0db8136d0848d9f032d8fb1e
- better-dsh/src/omp-python/vendor/dill/source.py: 45710 current bytes; sha256 1ac9987fa6c43cb33dae2bf3d4473b1b613eb44800a1723de428aca9d7101860
- better-dsh/src/omp-python/vendor/dill/temp.py: 8027 current bytes; sha256 785c8c8192094545607518b66b8236b597798371d25059df9b92b72d5d99f779
- better-dsh/src/output.ts: 4021 current bytes; sha256 b1748e636833e86a6ece9465506f13a829f4555d03938640a8ac97e93892d228
- better-dsh/src/python.ts: 1936 current bytes; sha256 ba2e80c3a3d708cf0862611657d1c1caf97fab78e0c17fb8f63467eade211ce9
- better-dsh/src/runtime.ts: 36984 current bytes; sha256 43a82bcf4f668a4ca56be21f925f0c514bcc359744fc81592d713af6b7c36cc7
- better-dsh/test/helpers.ts: 11661 current bytes; sha256 19685d6ff1d985ddebaaab5c9880b191007b3fcccede29db676863d5cd65d463
- better-dsh/test/interrupt-race.spec.ts: 7027 current bytes; sha256 6afd51d74831ee0ff848c0574eba647cf34593b84bbb3e40272f0e78b7b0fa73
- better-dsh/test/kernel-env.spec.ts: 1919 current bytes; sha256 ce4cafc9d2f0072eb09be5c56b13010e4ee570cb8e1be5de3afa7d4c1b020354
- better-dsh/test/lifecycle.spec.ts: 4199 current bytes; sha256 8e8b6684e59ffaf6d5d285b2ba9d81a0db84e6883573e5fb90218ee31cc228a4
- better-dsh/test/omp-checkpoint-review.spec.ts: 8563 current bytes; sha256 0bc35a3ceac557881018a21fe15cd75c8d0dd306905cef8d3e7dc9924c888739
- better-dsh/test/omp-checkpoint-safety.spec.ts: 12064 current bytes; sha256 4636de0c85195a27a7458e5ee8fc251c3dcefae957b21bd76574fbabe7ab18c3
- better-dsh/test/omp-checkpoints.spec.ts: 4695 current bytes; sha256 64c635e458ef4a69d042493d0f3f86bd22dd02e87c8448836fa90492140a0b6f
- better-dsh/test/omp-execution.spec.ts: 9317 current bytes; sha256 a53e5763333ae1d85ceca34d30a7f314b7ad2d7b79ba35b9ba60a24970b1f672
- better-dsh/test/presentation.spec.ts: 16360 current bytes; sha256 f9c00f2270bdea8d455664f6b92b4287cef539be9d217c5642e4960d94624c7e
- better-dsh/test/runtime.spec.ts: 8243 current bytes; sha256 5bbb6b6d5ca4c95037b71200fbce0195e904d5e6e17e2aec4300729f3ce2d7a0
- better-dsh/test/session-keys.spec.ts: 11737 current bytes; sha256 808112040e2ff94ffe48e1d3609e39c0584b2f16b25a6f444ebd58021f1f8367
- better-dsh/test/snapshot-restore.spec.ts: 5532 current bytes; sha256 5b4bb3e31ea17f2c47d3f7d7ccc3bc5dc6ed328aa81aa526ba4180a87bd0719b
- better-dsh/test/snapshot-revive.spec.ts: 6777 current bytes; sha256 fa4bdef7a2bda7764c628d850dffd3da62be2f5f0fcc9ff5cfa12a0fc696b21d
- docs/package-catalog.json: 129486 current bytes; sha256 ed695696f963a2ce4cd7705bad0299a00bad7409b0983edf7f4b32a2cbece5ed
- docs/specs/omp-python-repl-port/runtime-guide.md: 4930 current bytes; sha256 1317e54334f7dfcb7a5aa597e88d2e42158103c4facc0f9ac8d041bff7bb6cfa
- docs/specs/omp-python-repl-port/spec.md: 9868 current bytes; sha256 1ca7d56277cecc3d281a81f3f0d8c13c2b9e616f11593a848879ead070c2d00f
- docs/superpowers/plans/2026-10-12-omp-python-repl-port.md: 10624 current bytes; sha256 0019eff71c6707ee8989586f8035ba479a1d7717d031bbb8bf613667a97deb1a
- docs/test-reports/2026-10-12-omp-python-repl-port.md: 14082 current bytes; sha256 5fb5051b9215ef767ca8199de4d6434316d9e1908c3299ee2c7d675af8e41d92
- package-lock.json: 223 current bytes; sha256 b365bbc890c535106d959b1357d59ecc15c43fb4afbc5a35cd8bfed0203a757c
- package.json: 902 current bytes; sha256 3ff38a1671d1a6346562b5321e6c98194c018f2059e76e02cc8ed6ab4f306bfb
- super-dsh/package-lock.json: 113667 current bytes; sha256 20bf35bf504bea4d073f38ec7feb0639dd6789226d2acb9415594814b95975d0
- super-dsh/package.json: 6040 current bytes; sha256 cfb0e4c0c0667897a4f385577a81fa3e5e3e63d4ce77a0d781f2b72084e6caab

```diff
--- baseline/better-dsh/README.md
+++ current/better-dsh/README.md
@@ -1,212 +1,85 @@
-> Part of [Super D](../README.md). This is the independently installable `better-dsh` package. Super Dash embeds the same local build and registers it as a separate native Plugin Manager row, with its own enable/disable switch; both packages share version 0.3.0-a. Active source is this directory, with shared specifications and references under root `docs/`.
+> Part of [Super D](../README.md). `better-dsh` is an independently installable native DSH bundle. Super Dash installs it through the native Plugin Manager; both packages use synchronized versions and independent enable/disable controls. Canonical shared specifications are in root `docs/`.
 
-# Better Dsh — Dashr
+# Better Dash — Dashr
 
-DASHR is a persistent-kernel REPL for the DeepSeek Harness (dsh): a
-**stateful `ctx.replRuntime` provider** (one persistent IPython kernel
-subprocess **per session**, the run's `principal`, held in a map inside the
-one service instance per mount). Each `run()` is one cell on the calling
-session's kernel; variables, imports, and definitions assigned in run N
-survive into run N+1 — *state codification* (blueprint §1.1 channel ②),
-deliberately NOT the per-run isolation a one-shot execution backend
-provides — and two sessions sharing one service instance never see each
-other's variables.
+Better provides a stateful `ctx.replRuntime` and the model-facing `eval` tool. Each DSH session has its own persistent Python child: variables, imports and definitions survive across cells, while sessions remain isolated. `DashrRuntime` owns the children and their lifecycle; the presentation layer exposes the Python SDK and bridges calls to the current session's host tools.
 
-Naming (v0.1.5 layer model): the runtime class is **`DashrRuntime`** — the
-standing-mount-layer component (one instance per mount holding the
-cross-session kernel map), and therefore the de facto daemon while the
-profile-level `DashrDaemon` concept stays an empty shell; the session layer
-is the ipykernel subprocess itself, a pure interpreter with no harness
-awareness.
-
-The presentation half — the `eval` transport tool, the Python SDK renderer,
-and the tool→binding bridge — lives in the SAME package (merged in v0.1.8;
-the pre-merge `dsh-rlm-mode`/`dashr-presentation` sibling split is gone).
-The runtime registers the service key `replRuntime` through its own vendored
-Service Definition (see `src/vendored/repl-runtime.ts`), so it carries **zero
-dsh runtime package dependencies**: only `@deepseek-ai/cordis` (peer),
-`schemastery`, and `zeromq`.
-
-## Package positioning
-
-- npm name: `better-dsh` (unscoped; formerly `@pgmi-builds/better-dsh`, which
-  now stays published only as a deprecated pointer to this name).
-- A standard Cordis plugin (`Context` + schemastery `Config`, every tunable
-  configurable from `cordis.yml`, no hardcoded tunables).
-- "Registrations are effects": the kernel lifecycle (lazy spawn on a key's
-  first `run()`, teardown on that session's `agent/disposed`, optional
-  snapshot at either teardown) is effect-owned, so plugin disposal tears
-  every subprocess down.
-- Published surface: `lib/` only (`files: ["lib"]`, `main`/`types`/`exports`
-  pointing at `lib/index.js` / `lib/index.d.ts`) — the build emits beside the
-  manifest (`outDir: 'lib'`; the tsdown default `dist/` left the exports map
-  dangling, fixed in M2B). The root also re-exports the vendored Service
-  Definition's public contract (`ReplRuntime` plus the `CodeRun*` /
-  `CodeBinding*` / `CodeJsonValue` types) so consumers depend on the
-  published shape instead of reaching into sources. The declaration keeps
-  dependency imports external (`dts: { resolve: false }`): bundled copies
-  would create duplicate type identities in a consumer's program.
+The execution path is Node → JSON lines → an unchanged, pinned OMP Python runner → Python. Better adapts the host interfaces and packages the runner resources with compiled JavaScript. No OMP package, Bun, IPython, Jupyter or ZeroMQ is required by this path. Host modules remain optional peers and keep their runtime identity; Better's own JavaScript dependencies are bundled at build time.
 
 ## Native Web policies
 
-The bundle owns native DSH Web policies as independently toggleable components.
-`dashr-web-trust` accepts authenticated serving Host/Origin values while retaining
-native cookie authentication. The native WebServer and HMR remain in place;
-Better contributes WebTrust, mobile behavior and its password page through the
-public WebServer interfaces. Listener address and port follow native CLI policy.
-Automatic credential onboarding is disabled; users can still configure models.
+The bundle owns independently toggleable WebTrust, mobile behavior, password-page and onboarding contributions through native DSH interfaces. Native WebServer/HMR and CLI listener policy remain in place. `dashr-welcome-notice` shadows the native welcome entry and calls its public completion callback; disabling that component restores the native welcome item.
 
-`dashr-welcome-notice` shadows only the native `welcome-notice` onboarding entry
-at a higher precedence and calls the shell's public completion callback every
-time it mounts, including new chats and explicitly reopened notices. It renders
-no dialog and writes no native acknowledgement state. Disabling the component
-withdraws its client contribution and restores the native welcome item; other
-onboarding steps retain their own behavior.
+Super Dash installs Better as a separate native bundle. `../dev-webmcp` is a development-only test bundle and is not shipped in either product tarball.
 
-```yaml
-- id: dashr-welcome-notice
-  disabled: true
-```
-
-Super Dash installs Better through the native Plugin Manager as a separate
-bundle. Better Dash remains independently installable. `../dev-webmcp` is an
-unshipped development-only bundle owned by this repository.
-
-## Install
+## Install and interpreter
 
 ```sh
 npm install better-dsh
 ```
 
-The runtime OWNS its kernel environment. With `python` left at the
-`python3` sentinel (or absent), it provisions a managed venv under the
-package (`.venv-kernel`) on first use, installing `ipykernel` + `dill`
-(CPython 3.11) — no `/tmp` symlink, no blind trust in a host `python3`.
-An explicit `python` (or `DASHR_KERNEL_PYTHON`) is verified instead. For
-development and tests, pre-create the venv:
+The runtime requires Python >=3.9. Configure `python` (or the bundle's `DASHR_KERNEL_PYTHON` hint) to select one. The default `python3` compatibility path prepares a managed environment using uv or system Python, without kernel package installs. uv may download the selected interpreter when it is absent; an explicit interpreter path uses your existing installation. Better probes the interpreter and ships the runner, checkpoint helper and dill0.4.1 sources; it does not run pip to install kernel packages. Python is not bundled by this change. A missing or unsupported interpreter produces an actionable error.
 
-```sh
-npm run kernel:venv        # uv venv .venv-kernel --python 3.11 + ipykernel + dill
-```
-
-Tests pick the kernel interpreter from `DASHR_TEST_PYTHON`, falling back to
-`./.venv-kernel/bin/python`, then `python3` — see `test/helpers.ts`.
+The original OMP runner's source commit/hash and MIT license, and dill's source hashes/version and BSD-3-Clause license, accompany the packaged resources. Better's integration code is separate from these original files. OMP-specific Agent helpers are not exposed as DSH features.
 
 ## Configuration
 
-Every field of the plugin `Config` (schemastery defaults shown):
+Runtime fields remain configurable through the ordinary Cordis row. The implementation's schema is authoritative; the principal controls are:
 
 | Field | Default | Meaning |
 | --- | --- | --- |
-| `python` | `python3` | Explicit interpreter with `ipykernel`; the bare `python3` sentinel (or absent) selects a managed venv under `kernelEnvDir`. |
-| `startupTimeoutMs` | `30000` | Budget for kernel spawn → ready, in milliseconds. |
-| `runTimeoutMs` | `120000` | Wall budget per run; expiry interrupts the kernel then force-settles. |
-| `interruptGraceMs` | `2000` | Grace between a timeout/abort interrupt and the force-settle. |
-| `interruptConfirmMs` | `250` | Confirm window between the control-channel interrupt and the SIGALRM escalation (must be `< interruptGraceMs`); see "Interrupts" below. |
-| `disposeTimeoutMs` | `5000` | Budget for graceful kernel teardown (shutdown_request → SIGKILL). |
-| `snapshotTimeoutMs` | `30000` | Budget for internal snapshot/restore cells (dill dump/load). |
-| `maxOutputBytes` | `67108864` | Hard cap for serialized log-array, completion-value, and failure-message payloads. |
-| `snapshotDir` | *(unset)* | Base directory for per-session namespace snapshots (`<dir>/<principal>/state.dill` + `manifest.json`); none when absent. |
-| `snapshotSizeCapBytes` | `268435456` | Serialized-size cap for a turn-end snapshot; over-cap snapshots are skipped (one-time model warning). |
-| `username` | `dashr` | Jupyter username stamped on wire messages. |
-| `kernelEnvDir` | *(unset)* | Managed venv directory (defaults to `<package>/.venv-kernel`). |
-| `kernelPythonVersion` | *(unset)* | Preferred CPython version for a managed venv (default `3.11`). |
-| `kernelAutoInstall` | `true` | Provision the managed venv (`ipykernel` + `dill`) on first use. |
+| `python` | `python3` | Interpreter selection; no Jupyter installation requirement. |
+| `startupTimeoutMs` | `30000` | Budget for child startup and initialization. |
+| `runTimeoutMs` | `120000` | Wall budget per user cell. |
+| `interruptGraceMs` | `2000` | Grace after an interrupt before terminating an unresponsive child. |
+| `interruptConfirmMs` | `250` | Delay before confirming an interrupt that has not finished the cell. |
+| `disposeTimeoutMs` | `5000` | Bound on graceful child teardown before forced cleanup. |
+| `snapshotTimeoutMs` | `30000` | Budget for internal save/restore operations. |
+| `maxOutputBytes` | `67108864` | Cap for serialized logs, completion and error output; overflow is reported. |
+| `snapshotDir` | native profile checkpoint directory | Explicit directory overrides the native profile default; `""` disables persistence and retains only live process state. Standalone runtimes must explicitly configure persistence. |
+| `snapshotSizeCapBytes` | `268435456` | Checkpoint payload cap; failed or over-cap saves preserve the previous committed generation. |
+| `kernelEnvDir` | `<package>/.venv-kernel` | Managed environment location used by the `python3` compatibility selection. |
+| `kernelPythonVersion` | `3.11` | Interpreter version requested from uv for a new managed environment. |
+| `kernelAutoInstall` | `true` | Allow creation of the managed environment on first use. |
+| `username` | `dashr` | Retained compatibility field. |
 
-## Persistent-state semantics
+## Cells and recovery
 
-- **Cell semantics**: each `run({ program })` is one cell on the calling
-  session's kernel namespace (`user_ns`) — a pure IPython REPL. Top-level
-  `await` works; a top-level `return` is a SyntaxError, exactly as in a
-  native IPython cell. The completion value is the LAST expression's value
-  (REPL displayhook-style): a statement-ending cell or a `None` final
-  expression yields no `value` field, and a non-JSON value comes back as its
-  repr text.
-- **Session keying** (M3-A): one kernel per distinct `request.principal`
-  (the presentation bridge passes the calling agent's session id); runs
-  without a principal share one default key, preserving M1 semantics. The
-  service instance count is unchanged — one per mount — the keying is a
-  `Map<principal, kernel>` inside the provider.
-- **Kernel lifetime**: lazy start on a key's first `run()`; teardown when
-  that session's agent is disposed (the dsh `agent/disposed` event, payload
-  `{ agent: { id } }`, listened through the untyped cordis event service to
-  keep this package's zero-dsh-dependency rule) and on plugin disposal
-  (`shutdown_request`, then SIGKILL after `disposeTimeoutMs`). A kernel that
-  dies unexpectedly is never reused in-process: it respawns onto its nearest
-  replayable snapshot (or a fresh empty kernel when none exists) and the run
-  that observed the death gets an explicit `worker-exit` naming what was lost.
-- **Turn-end snapshots** (M3-B): with `snapshotDir` configured, every
-  successful run is followed by a size-capped snapshot cell that dumps the
-  user namespace to `<snapshotDir>/<principal>/state.dill` + `manifest.json`
-  (`turn`, `pythonVersion`, `venvPath` = the kernel's own `sys.executable`,
-  `skills`, `names`, `sizeBytes`). A namespace whose serialized size exceeds
-  `snapshotSizeCapBytes` is skipped — estimated BEFORE any dill IO by a
-  bounded walk that reads numpy/pandas in-memory footprints, then confirmed
-  against the actual `.part` dump — and the model is warned once through the
-  run's own logs. Skipped snapshots never replace the previous good one.
-- **Restore-on-first-boot** (M3-B): a key's first kernel boot restores its
-  on-disk snapshot before running user code. The kernel validates the
-  manifest itself (python version, interpreter identity, skills); a
-  non-replayable snapshot degrades to an EMPTY namespace and the first run
-  tells the model so. Variable state and the append-only transcript are NOT
-  transactionally consistent (blueprint §8.3): the snapshot is a point-in-time
-  namespace capture that can lag the transcript, and a degraded restore never
-  fabricates variables the transcript once saw.
-- **Interrupts** (M3-A hardened): aborts/timeouts escalate in two phases —
-  the zmq control `interrupt_request` first, then SIGALRM only after
-  `interruptConfirmMs` if the cell has still not settled. The kernel-side
-  bootstrap installs a busy guard that only raises `KeyboardInterrupt` while
-  a dashr cell is actually executing, so a signal landing on an idle or
-  booting kernel is swallowed instead of terminating the process (the M1
-  same-tick dual send killed idle kernels deterministically — 10/10
-  same-tick, 8/10 at +1-2ms, 40/40 during cold boot; see
-  `test/interrupt-race.spec.ts`). The hard-abort contract is intact: a busy
-  `while True: pass` still breaks inside the grace (blueprint §10.4).
-- **Concurrency**: the bridge serializes cells per kernel (`executeCell`
-  awaits the previous cell), so concurrent `run()` calls on one session
-  queue rather than interleave; see `test/parallel.spec.ts`. Runs on
-  DIFFERENT principals execute on their own kernels concurrently.
-- **What snapshots do NOT carry**: nothing outside the kernel namespace is
-  ever in scope — the v0.1.8b removal deleted the Continual Harness
-  (`refine()`, `harnessDir`) entirely, so the snapshot/restore cycle's only
-  persistence channel is the kernel namespace itself (blueprint §8.4).
-  Anything a cell stores in ordinary variables follows the snapshot rules
-  above as before.
+One `eval` call runs one Python cell. Top-level `await` works and top-level `return` is invalid. The final expression supplies the completion value; a final `None` or statement produces no value. Non-JSON completions return repr text. Printed stdout/stderr become logs. Tools use `await tool.<name>({...})` and failures raise `ToolCallError`.
+
+Operations for one session serialize, including initialization, user cells, checkpointing, variable access and reset. Different sessions can execute concurrently; one cell can fan out independent asynchronous host tool calls.
+
+Completed cells attempt a checkpoint, including cells that raise after changing state. The helper saves an admitted user object graph, preserving shared references among retained values. Serialization failures, resource exclusions and partial coverage are reported to the model. A complete generation is committed atomically; a failed attempt before commit retains the previous valid checkpoint. If interruption prevents confirmation of the commit, Better reports that uncertainty.
+
+On a fresh child, Better validates and attempts restoration once before admitting user code. The notice identifies the saved cell and any omissions. A damaged or incompatible checkpoint starts empty and reports why. Runner plumbing, tool bindings and OS resources are excluded. Current tools are recreated from the host; files, sockets, subprocesses, threads, locks, connections, environment mutations and external side effects are not restored as a Python process.
+
+A dying or interrupted cell may already have performed side effects. Better never automatically retries it or blindly replays historical cells. Read the recovery notice and inspect real state before deciding which work to repeat. `reset: true` clears the session's memory and disk checkpoints.
+
+For the full boundary and source provenance contract, see [the runtime guide](docs/specs/omp-python-repl-port/runtime-guide.md) and [spec](docs/specs/omp-python-repl-port/spec.md).
 
 ## Testing
 
 ```sh
-npm install
-npm run kernel:venv     # once; or export DASHR_TEST_PYTHON=/path/to/python
-npm run typecheck       # tsc --noEmit
-npm test                # vitest --run (fileParallelism: false)
+npm run typecheck
+DASHR_TEST_PYTHON=python3 npm test
 ```
 
-Teardown discipline: every test context is disposed through
-`onTestFinished`, and CI must assert no orphan kernels remain:
-
-```sh
-pgrep -cf -- '-[m] ipykernel_launcher' || echo no-orphans
-```
-
-(The `-[m]` trick prevents `pgrep` from matching itself; 208 orphaned
-kernels once exhausted machine memory while every unit test stayed green —
-blueprint §10.8/§10.9.)
+Tests create real Python children and dispose their contexts. Stdlib-only interpreter coverage verifies that external kernel packages are unnecessary. Consumer acceptance additionally requires the root dual-tarball launcher and dev3 installed behavior; source tests and process liveness alone are insufficient.
 
 ---
 
 # Presentation half (eval transport, SDK, bindings)
 
 The DASHR agent-plane presentation (blueprint §7.4): the plugin half that
 presents the persistent-kernel runtime to the model as **cells on one
-persistent IPython kernel**. It contributes:
+persistent Python runner**. It contributes:
 
 - **`eval`** — the cell transport tool: one call = one cell on the calling
   session's kernel (the `ctx.replRuntime` service). Variables, imports, and
   definitions survive across calls. Nested tool calls ride the host
   registry's native scheduling pipeline as `await tool.name({...})` inside
   the cell — one positional arguments object per call, keyword arguments
   rejected. Every registry-visible tool is bound as a member; the
   `send_message` bridge callable joins them in the same catalog block.
 - **`dashr:tool-catalog`** — a generated Python SDK prompt section: one
   `async def name(args) -> Output` per visible tool (flat `tool.*` shape)
@@ -297,28 +170,25 @@
 
 | Field | Default | Meaning |
 | --- | --- | --- |
 | `maxParallelSubCalls` | `10` | Cap on one cell's overlapping sub-calls (native scheduler contract; `1` = strictly serial). |
 | *(runtime keys)* | — | The runtime slice (`python`, `snapshotDir`, timeouts, caps, kernel-env knobs) is documented in the Configuration table above. |
 
 ## Tests
 
 ```sh
 npm install
-npm run kernel:venv     # once; or export DASHR_TEST_PYTHON=/path/to/python
+export DASHR_TEST_PYTHON=python3  # or an explicit supported interpreter
 npm run typecheck
 npm test                # vitest --run
 ```
 
-The suite needs a Python interpreter with `ipykernel` (+ `dill` for the
-snapshot tiers) for the real-kernel specs; it resolves one from
-`DASHR_TEST_PYTHON`, then `./.venv-kernel/bin/python`, then `python3` —
-see `test/helpers.ts`.
+The suite needs a supported Python interpreter; the runner and checkpoint serializer are supplied by Better. `DASHR_TEST_PYTHON` selects the test interpreter.
 
 ## Relationship to upstream
 
 Structure mirrors `@deepseek-ai/dsh-agent-tool-presentation` and the Code
 Mode half of `@deepseek-ai/dsh-tools` (0.1.1-rc.2), re-pointed at the
 vendored `replRuntime` Service Definition. See the module docs in
 `src/index.ts` for the deliberate deltas (`eval` vs `run_code`, ordinary
 scoped registration, guard-based collapse, mirrored `tools/code-dispatch-log`
 waterfall).
```

```diff
--- baseline/better-dsh/cordis.patch.yml
+++ current/better-dsh/cordis.patch.yml
@@ -7,22 +7,23 @@
 #
 # `dashr-repl` (core): the `eval` tool and persistent-kernel REPL runtime land
 # in the global scope layer, so every agent in every preset sees them
 # (`agent → preset → global`). One process-global runtime keys one kernel per
 # Session/Agent, torn down on `agent/disposed` — the promotion of the v0.1.5
 # DashrDaemon shell. The tool is an ordinary registration: upstream's `code`
 # preset still applies its own `tools:code-only` rule (a direct `eval` call in
 # a PTC session resolves to UNKNOWN_TOOL). DASHR ships no PTC mode, so that
 # rule never bites here.
 #
-# `python` is only a hint: the runtime OWNS the kernel environment. An
-# explicit interpreter (DASHR_KERNEL_PYTHON) is verified; the bare
+# An explicit DASHR_KERNEL_PYTHON interpreter is verified. The default
+# python3 compatibility path may prepare a managed Python environment;
+# the packaged OMP runner needs no Jupyter or kernel package installation.
 - insert:
     - id: dashr-repl
       name: 'better-dsh'
       config:
         python: !!js process.env.DASHR_KERNEL_PYTHON ?? 'python3'
 
     # URL-aware I/O + hashline + devices. Gates ride THIS row's config
     # (schema defaults: both ON — opt-out), no longer the core row's.
     - id: dashr-url-schemes
       name: 'better-dsh/url-schemes'
```

```diff
--- baseline/better-dsh/eval-description.md
+++ current/better-dsh/eval-description.md
@@ -1,33 +1,37 @@
 Run one Python cell on a session-persistent scripting pad. One `eval` call = one cell; the pad's state persists across calls and turns — variables, imports, and definitions from earlier cells stay alive.
 
-Work incrementally: imports → define → test → use, each its own cell. Re-run setup only after `reset` or a crash.
+Work incrementally: imports → define → test → use, each its own cell. The pad uses an OMP-backed Python interpreter; Python must be available on the host. Better supplies its runner and checkpoint serializer without installing Jupyter or Python packages.
+
+After a restart, read the recovery notice before relying on earlier variables. Checkpoints restore Python scratchpad values on a best-effort basis; notices identify the last saved cell and any omitted values. Open files, sockets, subprocesses, locks and other live resources must be recreated. A checkpoint does not restore files, undo tool calls or recover the entire Python process.
+
+An interrupted or dying cell may already have changed variables, files or external systems. It is never automatically retried. Inspect the reported checkpoint and actual external state before deciding what to run again. A failed checkpoint leaves the previous valid checkpoint available; a failed restore starts with empty state and reports the reason.
 
 ## Arguments
 
 - `cell` (required): one Python program body. Top-level `await` works; top-level `return` is a SyntaxError — the cell runs in module scope (REPL semantics, not a function body).
 - `description` (required): a short summary of what the cell does — shown as the call's title in the UI.
 - `timeout` (optional): wall-clock budget in seconds; the cell is interrupted (then force-stopped) when exceeded. Omit for the runtime default.
-- `reset` (optional): restart the pad EMPTY first — earlier state is discarded.
+- `reset` (optional): restart the pad EMPTY first and delete its checkpoints — earlier state is discarded.
 
 ## Direct calls vs cells
 
 Payload-shaped work (one long read, one edit, one command) → direct tool call. Logic-shaped work (loops, conditions, fan-out, composing many tool results into one step) → an `eval` cell. Only what the cell prints or returns comes back — curate it.
 
 Delegation: `agent` is the unified agent-spawn entry; `subagent` is its native alias — both delegate through the same runtime, so call either.
 
 ## Calling tools from a cell
 
 Every session tool is callable from a cell as `await tool.<name>(args)` with ONE positional argument: `args` is the tool's parameter object written as a Python dict literal, same field names (`true`/`false`/`null` become `True`/`False`/`None`). A failed call raises `ToolCallError` with `.toolName` naming the tool. Tool names that are not plain identifiers (e.g. contain hyphens) have no `tool.<name>` member — call those as direct tool calls.
 
 ```python
-print(await tool.read({"path": "docs/README.md", "limit": 5}))
+print(await tool.read({"file_path": "docs/README.md", "limit": 5}))
 
 r = await tool.bash({"command": "ls -la src/", "description": "List source directory"})
 print(r["stdout"]["text"])
 
 import asyncio
 matches, files = await asyncio.gather(
     tool.grep({"pattern": "TODO", "path": "src"}),
     tool.glob({"pattern": "**/*.ts", "path": "src"}),
 )
 ```
```

```diff
--- baseline/better-dsh/package-lock.json
+++ current/better-dsh/package-lock.json
@@ -1,19 +1,19 @@
 {
   "name": "better-dsh",
-  "version": "0.3.0-r",
+  "version": "0.3.0-s",
   "lockfileVersion": 3,
   "requires": true,
   "packages": {
     "": {
       "name": "better-dsh",
-      "version": "0.3.0-r",
+      "version": "0.3.0-s",
       "license": "MIT",
       "devDependencies": {
         "@ast-grep/wasm": "^0.45.3",
         "@lumis-sh/wasm-bash": "^0.26.6",
         "@lumis-sh/wasm-c": "^0.26.3",
         "@lumis-sh/wasm-cpp": "^0.26.2",
         "@lumis-sh/wasm-css": "^0.26.4",
         "@lumis-sh/wasm-go": "^0.26.3",
         "@lumis-sh/wasm-html": "^0.26.4",
         "@lumis-sh/wasm-javascript": "^0.26.4",
```

```diff
--- baseline/better-dsh/package.json
+++ current/better-dsh/package.json
@@ -1,14 +1,14 @@
 {
   "name": "better-dsh",
-  "version": "0.3.0-r",
-  "description": "Make your dsh ready for serious coding tasks. (Tools x Schemas)^REPL. `skill://`, `ctx://`, `agent://`, `dvc://`, `dsh://`, IPython REPL, Context as Variables, cross compactions recallable, full context revive. `hash-edit`, `dvc://browser`, subagent as function, workflow as function.",
+  "version": "0.3.0-s",
+  "description": "Make your dsh ready for serious coding tasks. (Tools x Schemas)^REPL. `skill://`, `ctx://`, `agent://`, `dvc://`, `dsh://`, Python REPL, Context as Variables, cross compactions recallable, full context revive. `hash-edit`, `dvc://browser`, subagent as function, workflow as function.",
   "type": "module",
   "main": "lib/index.js",
   "types": "lib/index.d.ts",
   "exports": {
     ".": {
       "types": "./lib/index.d.ts",
       "default": "./lib/index.js"
     },
     "./py-sdk": {
       "types": "./lib/py-sdk.d.ts",
@@ -394,20 +394,20 @@
   "repository": {
     "type": "git",
     "url": "git+https://github.com/pgmi-builds/super-dsh.git",
     "directory": "better-dsh"
   },
   "keywords": [
     "dsh",
     "deepseek-harness",
     "repl",
     "eval",
-    "ipython",
+    "python",
     "kernel",
     "agent",
     "plugin"
   ],
   "homepage": "https://github.com/pgmi-builds/super-dsh/tree/master/better-dsh",
   "bugs": {
     "url": "https://github.com/pgmi-builds/super-dsh/issues"
   }
 }
```

```diff
--- baseline/better-dsh/scripts/copy-kernel-bridge.mjs
+++ current/better-dsh/scripts/copy-kernel-bridge.mjs
@@ -1,23 +1,19 @@
 #!/usr/bin/env node
-/**
- * Ship the Python kernel bridge beside the built entry.
- *
- * `tsdown` clears `lib/` on every build and only emits JavaScript, so the
- * stdio<->ZMQ bridge (`src/kernel-bridge.py`) is copied in afterwards:
- * `lib/kernel-bridge.py` is what `kernel-transport.ts` resolves through
- * `new URL('./kernel-bridge.py', import.meta.url)`. `files: ["lib", …]` then
- * carries it into the tarball with no extra manifest entry.
- *
- * Zero dependencies: `node:fs` only, like the rest of the build scripts.
- */
-import { copyFileSync, existsSync, mkdirSync, statSync } from 'node:fs'
-import { dirname, join } from 'node:path'
-import { fileURLToPath } from 'node:url'
-
-const here = dirname(fileURLToPath(import.meta.url))
-const source = join(here, '..', 'src', 'kernel-bridge.py')
-const target = join(here, '..', 'lib', 'kernel-bridge.py')
-
-if (!existsSync(join(here, '..', 'lib'))) mkdirSync(join(here, '..', 'lib'), { recursive: true })
-copyFileSync(source, target)
-console.log(`copy-kernel-bridge: ${statSync(target).size} bytes -> lib/kernel-bridge.py`)
+/** Verify and ship immutable runner plus Better resources after tsdown. */
+import { createHash } from 'node:crypto'
+import { cpSync, mkdirSync, readFileSync, rmSync } from 'node:fs'
+const source = new URL('../src/omp-python/', import.meta.url)
+const provenance = JSON.parse(readFileSync(new URL('provenance.json', source), 'utf8'))
+const expected = provenance.files['runner.py'].sha256
+const actual = createHash('sha256').update(readFileSync(new URL('runner.py', source))).digest('hex')
+if (actual !== expected) throw new Error(`Immutable OMP runner hash mismatch: expected ${expected}, found ${actual}`)
+const dillProvenance = JSON.parse(readFileSync(new URL('dill-provenance.json', source), 'utf8'))
+for (const [path, metadata] of Object.entries(dillProvenance.files)) {
+  const hash = createHash('sha256').update(readFileSync(new URL(path, source))).digest('hex')
+  if (hash !== metadata.sha256) throw new Error(`Immutable dill source hash mismatch: ${path}`)
+}
+const target = new URL('../lib/omp-python/', import.meta.url)
+rmSync(target, { recursive: true, force: true })
+mkdirSync(target, { recursive: true })
+cpSync(source, target, { recursive: true, filter: path => !path.includes('__pycache__') && !path.endsWith('.pyc') && !path.split(/[\\/]/).includes('tests') })
+console.log(`copy-kernel-bridge: verified runner ${actual}; packaged omp-python resources`)
```

```diff
--- baseline/better-dsh/scripts/kernel-provision.mjs
+++ current/better-dsh/scripts/kernel-provision.mjs
@@ -1,35 +1,5 @@
 #!/usr/bin/env node
-/**
- * Best-effort kernel provisioning entry — the single code path behind BOTH
- * `postinstall` and `npm run kernel:venv`.
- *
- * Fail-open by design (2026-09-03 ruling): any failure logs a remedy hint and
- * exits 0. The installation must NEVER fail because the kernel could not be
- * provisioned here — the daemon spin-up check (primary path) and first-use
- * lazy provisioning (final fallback) complete the three-trigger ladder.
- */
-import { access } from 'node:fs/promises'
-
-const libUrl = new URL('../lib/kernel-env.js', import.meta.url)
-
-try {
-  await access(libUrl)
-} catch {
-  // Dev checkout before the first build, or a pruned install: nothing to call.
-  console.log('[dashr] kernel-env build output not present yet — skipping install-time pre-provision (the daemon spin-up check will provision on start)')
-  process.exit(0)
-}
-
-const { resolveKernelEnv } = await import(libUrl)
-
-try {
-  const env = await resolveKernelEnv({
-    autoInstall: true,
-    log: (level, message) => console[level === 'warn' ? 'warn' : 'log'](`[dashr] ${message}`),
-  })
-  console.log(`[dashr] kernel ready: python ${env.version} at ${env.python}${env.dill ? '' : ' (dill missing — snapshots disabled)'}`)
-} catch (error) {
-  console.warn(`[dashr] kernel pre-provision failed (non-blocking): ${error instanceof Error ? error.message : String(error)}`)
-  console.warn('[dashr] remedies: run "npm run kernel:venv" in the dashr package; or rely on the daemon spin-up check / first-use auto-install; or set python to a prepared interpreter')
-  process.exit(0)
-}
+/** Explicit compatibility command: prepare only a stdlib Python environment, never pip packages. */
+const { resolveKernelEnv } = await import(new URL('../lib/kernel-env.js', import.meta.url).href)
+const env = await resolveKernelEnv({ log: (level, message) => console[level === 'warn' ? 'warn' : 'log'](message) })
+console.log(`Better Python REPL ready: Python ${env.version} at ${env.python}`)
```

```diff
--- baseline/better-dsh/src/bootstrap.ts
+++ current/better-dsh/src/bootstrap.ts
@@ -1,357 +1,2 @@
-/**
- * Python-side bootstrap executed once as an internal cell right after kernel
- * startup. Seeds the user namespace with the host-request comm bridge
- * (`dashr.host` target, the PA `host_request()` pattern), the binding-proxy
- * factories, the typed rejection classes, and the lossless-JSON completion
- * encoder. Names are `_dashr`/`__dashr` prefixed (any case) so they are
- * excluded from namespace snapshots and never leak into user state.
- * @module dashr/bootstrap
- */
-
-/** Comm target the kernel-side shim opens for typed host requests. */
-export const HOST_COMM_TARGET = 'dashr.host'
-
-/**
- * The bootstrap source. Kept dependency-free apart from `ast`, `asyncio`,
- * `json`, and `comm` (present by construction — it IS the kernel).
- */
-export const KERNEL_BOOTSTRAP = `
-import ast as _dashr_ast
-import json as _dashr_json
-
-
-def _dashr_install_control_comm_handlers():
-    # Host replies arrive as comm_msg on the CONTROL channel while the shell
-    # channel is busy executing our cell; teach the kernel to route them.
-    try:
-        from IPython import get_ipython
-    except Exception:
-        return
-    shell = get_ipython()
-    kernel = getattr(shell, 'kernel', None)
-    comm_manager = getattr(kernel, 'comm_manager', None)
-    control_handlers = getattr(kernel, 'control_handlers', None)
-    if comm_manager is None or not isinstance(control_handlers, dict):
-        return
-    control_handlers.setdefault('comm_msg', comm_manager.comm_msg)
-    control_handlers.setdefault('comm_close', comm_manager.comm_close)
-
-
-def _dashr_install_interrupt():
-    # ipykernel's async-cell SIGINT handling only schedules a callback on the
-    # kernel event loop, and a non-yielding cell ('while True: pass') blocks
-    # that very loop, so the control-channel interrupt can never break it.
-    # SIGALRM is untouched by ipykernel: raising KeyboardInterrupt from its
-    # handler breaks any cell, and the host sends it (after a confirm window,
-    # see the bridge) on timeout/abort. Best effort — where SIGALRM is
-    # unavailable the control-channel interrupt is all there is.
-    #
-    # The busy guard is load-bearing (M3-A, blueprint §5 "SIGALRM-at-idle 双重
-    # 窗口"): a KeyboardInterrupt raised OUTSIDE cell execution — while the
-    # kernel boots, idles between cells, or unwinds a finished one — escapes
-    # the shell's containment and terminates the process cleanly, which used
-    # to kill the kernel deterministically (10/10 same-tick aborts, 40/40
-    # during cold boot; dev/m2a-report.md §5.1). The handler therefore only
-    # raises while a dashr cell is actually executing, tracked by the
-    # module-level _dashr_state dict below and set/cleared by the run/snapshot
-    # cell scaffolds around their whole body. A stray SIGALRM outside that
-    # window is swallowed — the host's force-settle already resolves the run,
-    # and the kernel lives. The dict (not a bare flag) is captured by the
-    # handler closure, so user code rebinding the NAME cannot disarm the
-    # guard; mutating the dict itself stays possible and accepted — this shim
-    # is a capability seam, not a security boundary.
-    try:
-        import signal as _dashr_signal
-
-        def _dashr_on_sigalrm(_signum, _frame):
-            if not _dashr_state['executing']:
-                return
-            raise KeyboardInterrupt
-
-        _dashr_signal.signal(_dashr_signal.SIGALRM, _dashr_on_sigalrm)
-    except (ImportError, AttributeError, OSError, ValueError):
-        pass
-
-
-# The dashr busy-guard flag (see _dashr_install_interrupt): True for the whole
-# duration of a run or snapshot cell — the only window in which a SIGALRM may
-# raise KeyboardInterrupt. Lives at module (user-namespace) level so the cell
-# scaffolds can flip it; excluded from snapshots by the _dashr prefix rule.
-_dashr_state = {'executing': False}
-
-
-_dashr_install_interrupt()
-
-
-class _DashrRejected(Exception):
-    def __init__(self, message):
-        Exception.__init__(self, message)
-
-
-def _dashr_host_request(payload):
-    from comm import create_comm
-    import asyncio
-    _dashr_install_control_comm_handlers()
-    loop = asyncio.get_running_loop()
-    future = loop.create_future()
-    # primary=True publishes comm_open so the host learns this comm_id; the
-    # request itself travels as the first comm_msg.
-    comm = create_comm(target_name=${JSON.stringify(HOST_COMM_TARGET)})
-
-    def _resolve(action):
-        def _apply():
-            if future.done():
-                return
-            action()
-            comm.close()
-        # Replies arrive on the kernel's control channel, which may run off
-        # the event-loop thread; only call_soon_threadsafe may touch the
-        # future from there.
-        loop.call_soon_threadsafe(_apply)
-
-    def _on_msg(msg):
-        content = msg.get('content', {})
-        reply = content.get('data', {}) if isinstance(content, dict) else {}
-        if not isinstance(reply, dict) or future.done():
-            return
-        status = reply.get('status')
-        if status == 'ok':
-            _resolve(lambda: future.set_result(reply.get('result')))
-        elif status == 'error':
-            _resolve(lambda: future.set_exception(_DashrRejected(reply.get('error') or 'host request failed')))
-
-    comm.on_msg(_on_msg)
-    comm.send(dict(payload))
-    return future
-
-
-def _dashr_make_error_class(name, member_property):
-    def _init(self, message, member=None):
-        Exception.__init__(self, message)
-        if member is not None:
-            setattr(self, member_property, member)
-    return type(name, (Exception,), {'__init__': _init})
-
-
-def _dashr_make_proxy(global_name, function_name, error_class_name, member_property):
-    async def _dashr_proxy(*args, **kwargs):
-        if kwargs:
-            raise TypeError('dashr binding calls do not accept keyword arguments')
-        if len(args) == 1:
-            call_args = args[0]
-        elif len(args) == 0:
-            call_args = None
-        else:
-            call_args = list(args)
-        payload = {
-            'type': 'binding.call',
-            'global': global_name,
-            'name': function_name,
-            'args': call_args,
-        }
-        try:
-            return await _dashr_host_request(payload)
-        except _DashrRejected as rejected:
-            cls = globals().get(error_class_name) if error_class_name else None
-            if cls is None:
-                raise
-            raise cls(str(rejected), function_name) from None
-    return _dashr_proxy
-
-
-def _dashr_make_holder(global_name, error_class_name, member_property, members):
-    # Attribute misses travel to the host instead of raising AttributeError
-    # here: the host owns the namespace, so IT rejects an unknown member as an
-    # unknown binding rather than the kernel inventing a local error class.
-    class _DashrBindingHolder:
-        def __dir__(self):
-            # F9 (v0.2.0-a): introspection tells the truth — dir(tool) lists
-            # exactly the bound names. A custom __dir__ fully replaces the
-            # default object.__dir__, so no dunder noise leaks in.
-            return list(members)
-
-        def __getattr__(self, function_name):
-            return _dashr_make_proxy(
-                global_name,
-                function_name,
-                error_class_name,
-                member_property,
-            )
-
-    return _DashrBindingHolder()
-
-
-def _dashr_make_callable(global_name, function_name, error_class_name, member_property):
-    # A BARE callable global (the flat per-tool bindings AND the bridge
-    # tools: 'callable: true' on the namespace) instead of an object
-    # holder. The one-object form is the single convention: every callable
-    # takes exactly one positional arguments object (e.g.
-    # agent_message({'receiver': 'child', ...})), and keyword / multi-positional forms are
-    # rejected HERE, at the Python call boundary, so the introspectable
-    # signature tells the truth and a TypeError names the binding global
-    # (read(...) got an unexpected keyword argument ...). The wire envelope
-    # keeps the historical {'args': [...], 'kwargs': {}} shape so the host's
-    # parseReplCall / flatToolArgs / flatBridgeToolArgs validation layers stay
-    # authoritative and unchanged. The single functions-entry name is
-    # transport-only: the program never sees it, and a typed rejection
-    # carries the GLOBAL name as its member (for a flat tool binding the
-    # global IS the tool name the program knows). __name__/__qualname__ are
-    # pinned to the global name so introspection shows the binding's name,
-    # not the factory-local _dashr_callable.
-    async def _dashr_callable(args=None, /):
-        payload = {
-            'type': 'binding.call',
-            'global': global_name,
-            'name': function_name,
-            'args': {'args': [] if args is None else [args], 'kwargs': {}},
-        }
-        try:
-            return await _dashr_host_request(payload)
-        except _DashrRejected as rejected:
-            cls = globals().get(error_class_name) if error_class_name else None
-            if cls is None:
-                raise
-            raise cls(str(rejected), global_name) from None
-
-    _dashr_callable.__name__ = global_name
-    _dashr_callable.__qualname__ = global_name
-    return _dashr_callable
-
-
-class _DashrNoValue:
-    # Marks 'no completion value': a cell whose last statement is not an
-    # expression, or whose last expression evaluates to None — the REPL
-    # displayhook suppresses None (IPython behavior), so no value crosses.
-    __slots__ = ()
-
-
-_DASHR_NO_VALUE = _DashrNoValue()
-
-
-class _DashrTopLevelReturnChecker(_dashr_ast.NodeVisitor):
-    # A cell runs at module scope, like any native IPython cell: a top-level
-    # 'return'/'yield' is a SyntaxError decided by the kernel itself, exactly
-    # as in a real REPL. Nested scopes (functions, lambdas, classes) keep
-    # their own return semantics.
-    def visit_FunctionDef(self, node):
-        return
-
-    def visit_AsyncFunctionDef(self, node):
-        return
-
-    def visit_ClassDef(self, node):
-        return
-
-    def visit_Lambda(self, node):
-        return
-
-    def visit_Return(self, node):
-        raise SyntaxError("'return' outside function")
-
-    def visit_Yield(self, node):
-        raise SyntaxError("'yield' outside function")
-
-
-async def _dashr_run_program(source):
-    # Run one cell with the user namespace as BOTH globals and locals —
-    # module-scope REPL semantics: state persists across cells, top-level
-    # 'await' is legal (PyCF_ALLOW_TOP_LEVEL_AWAIT, the same mechanism IPython
-    # uses), a top-level 'return'/'yield' is a SyntaxError decided here by the
-    # kernel — exactly as in a native IPython cell — and the last expression's
-    # value is the cell's result (the REPL displayhook handoff).
-    import inspect as _dashr_inspect
-    user_ns = globals()
-    if not source.strip():
-        source = 'pass'
-    parsed = _dashr_ast.parse(source, '<dashr program>', 'exec')
-    _DashrTopLevelReturnChecker().visit(parsed)
-    body = parsed.body
-    if body and isinstance(body[-1], _dashr_ast.Expr):
-        # Capture the last expression the way a REPL's displayhook shows it:
-        # its value feeds the completion envelope instead of being discarded.
-        # The name is distinct from the scaffold's __dashr_completion__ (the
-        # envelope holder) so a statement-ending cell can never pop a stale
-        # envelope left by an earlier run.
-        last = body[-1]
-        body[-1] = _dashr_ast.Assign(
-            targets=[_dashr_ast.Name(id='__dashr_cell_value__', ctx=_dashr_ast.Store())],
-            value=last.value,
-        )
-        _dashr_ast.fix_missing_locations(body[-1])
-    code = compile(
-        parsed,
-        '<dashr program>',
-        'exec',
-        flags=_dashr_ast.PyCF_ALLOW_TOP_LEVEL_AWAIT,
-    )
-    # IPython's own run_code pattern: with PyCF_ALLOW_TOP_LEVEL_AWAIT, plain
-    # exec() DISCARDS the module coroutine silently; eval() under await
-    # returns it and runs the code (IPython InteractiveShell.run_code does
-    # exactly 'await eval(code_obj, user_global_ns, user_ns)').
-    result = eval(code, user_ns, user_ns)
-    if _dashr_inspect.iscoroutine(result):
-        await result
-    value = user_ns.pop('__dashr_cell_value__', _DASHR_NO_VALUE)
-    if value is None:
-        return _DASHR_NO_VALUE
-    return value
-
-
-def _dashr_install_bindings(spec_json):
-    spec = _dashr_json.loads(spec_json)
-    user_ns = globals()
-    injected = user_ns.get('__dashr_injected__', {})
-    for old_name, old_spec in list(injected.items()):
-        if old_name not in spec:
-            user_ns.pop(old_name, None)
-            if old_spec.get('errorClass'):
-                user_ns.pop(old_spec['errorClass']['name'], None)
-    fresh = {}
-    # The flat per-tool shape declares the SAME error class on many
-    # namespaces: materialize each DISTINCT name once, so every proxy's
-    # raise-time globals() lookup finds ONE class and a single
-    # 'except ToolCallError' catches failures from every binding.
-    error_classes = {}
-    for global_name, namespace in spec.items():
-        error_class = namespace.get('errorClass')
-        if namespace.get('callable'):
-            # Exactly one function entry was validated by the host; its key is
-            # the transport name, the bare global itself is the callable.
-            function_name = next(iter(namespace['functions']))
-            user_ns[global_name] = _dashr_make_callable(
-                global_name,
-                function_name,
-                error_class['name'] if error_class else None,
-                error_class['memberNameProperty'] if error_class else None,
-            )
-        else:
-            user_ns[global_name] = _dashr_make_holder(
-                global_name,
-                error_class['name'] if error_class else None,
-                error_class['memberNameProperty'] if error_class else None,
-                sorted(namespace['functions']),
-            )
-        if error_class and error_class['name'] not in error_classes:
-            cls = _dashr_make_error_class(
-                error_class['name'],
-                error_class['memberNameProperty'],
-            )
-            error_classes[error_class['name']] = cls
-            user_ns[error_class['name']] = cls
-        fresh[global_name] = namespace
-    user_ns['__dashr_injected__'] = fresh
-
-
-def _dashr_encode(value):
-    if value is _DASHR_NO_VALUE:
-        return {'ok': True}
-    try:
-        return {'ok': True, 'json': _dashr_json.dumps(value, allow_nan=False)}
-    except (TypeError, ValueError, OverflowError):
-        # Not lossless JSON: pass its repr TEXT through instead of failing
-        # the cell. The upstream renders the tool result as text either way,
-        # so a non-JSON value costs the model nothing; the host keeps a
-        # plain string it forwards untouched. The envelope itself never
-        # fails, so the completion never gate-rejects a return value.
-        return {'ok': True, 'json': _dashr_json.dumps(repr(value))}
-`
+/** Module-qualified initialization survives OMP %reset without leaking imports. */
+export const KERNEL_BOOTSTRAP = `__import__('better_support').initialize(globals())`
```

```diff
--- baseline/better-dsh/src/index.ts
+++ current/better-dsh/src/index.ts
@@ -1,17 +1,17 @@
 /** `dashr-repl`: the DASHR REPL surface — one plugin, one row.
  *
  * Naming (v0.1.5 layer model): the runtime class is `DashrRuntime`, the
  * standing-mount-layer component — one instance per mount holding the
  * cross-session kernel map, hence the de facto daemon while the
  * profile-level `DashrDaemon` concept stays an empty shell; the session
- * layer is each ipykernel subprocess, a pure interpreter with no harness
+ * layer is each OMP Python subprocess, a pure interpreter with no harness
  * awareness.
  *
  * This package merges what were two sibling plugins into a single
  * composition row: `DashrRuntime` (the stateful kernel runtime — the
  * `ctx.replRuntime` implementation, mounted first, below) and the
  * agent-plane presentation
  * (blueprint §7.4) — the `eval` transport tool, the generated Tool
  * Catalog prompt section, the model-direct-call collapse, the tool→binding
  * bridge that binds the registry's agent-visible tools as `await tool.name(args)`
  * members (v0.1.5 Q8: one `tool` holder, no flat globals), and the three
@@ -36,21 +36,21 @@
  * The presentation row registers against the harness tool registry the way
  * any dsh tool row must (shape-mirroring `dsh-agent-tool-presentation` and
  * the code-mode half of `dsh-tools`, 0.1.0-rc.6), but it re-points execution
  * at our own `ctx.replRuntime` (the harness's runtime seam, vendored from
  * `@deepseek-ai/dsh-code-runtime` in `src/vendored/repl-runtime.ts` as an
  * interface only): the host registry stays untouched. The bundle patch
  * mounts this row on the HOST plane, so every agent in every preset gets
  * the cell surface (scoping, where wanted, is a PTC preset's own
  * `tools:code-only` rule). One row per composition, not one per session.
  * The seam is transport only: the KERNEL semantics —
- * resident IPython REPL, context as variables, last-expression completion —
+ * resident Python REPL, context as variables, last-expression completion —
  * are ours, not the upstream code mode's.
  *
  * Registration deltas from the upstream code-mode row, recorded per
  * blueprint §7.6:
  * - `eval` (not `run_code`): the registry reserves `run_code`
  *   unconditionally, and a distinct name is what lets a DASHR preset and a
  *   PTC code preset share one process registry without collision.
  * - The transport is an ORDINARY scoped registration, not the registry's
  *   reserved non-filterable transport: reservation is registry-private
  *   machinery a plugin cannot mint. Under our own scope the effect matches
@@ -413,21 +413,21 @@
 }
 
 /** Canonical value returned by the outer `eval` transport. */
 type RunCellOutput = { logs: string[]; result?: JsonValue }
 
 /**
  * One settled `eval` sub-dispatch about to be logged, as seen by the
  * `dashr/repl-dispatch-log` waterfall — dashr's OWN dispatch-log event,
  * self-registered via the cordis Events merge below. Decoupled from
  * upstream's `tools/ptc-dispatch-log` (PTC `run_code` sub-dispatches): `eval`
- * is a broader session-persistent REPL (IPython kernel) than upstream's
+ * is a broader session-persistent REPL (OMP Python child) than upstream's
  * `run_code` TS-worker tool, so its durable-log reshape extension point is
  * dashr-owned and version-independent — no coupling to upstream's
  * `CodeDispatchLog`/`PtcDispatchLog` rename or the PTC tool's event name.
  */
 export interface ReplDispatchLog {
   /** The outer `eval` execution. */
   readonly exec: ToolRunContext
   /** The calling agent (scope routing key + spill owner), when present. */
   readonly agent?: Agent
   /** Deterministic sub-call id (`<parent>:code:<n>`). */
@@ -515,21 +515,21 @@
         type: 'string',
         required: true,
         description: EVAL_DESCRIPTION_PARAM_DESCRIPTION,
       },
       timeout: {
         type: 'number',
         description: 'Optional wall-clock budget for this cell, in seconds; the cell is interrupted (then force-stopped) if it exceeds the budget. Omit to use the runtime default.',
       },
       reset: {
         type: 'boolean',
-        description: 'Optional: reset the persistent pad namespace to EMPTY before running — variables, imports, and definitions from earlier cells are discarded and the pad restarts fresh. Omit to keep the namespace.',
+        description: 'Optional: reset the persistent pad namespace to EMPTY before running and delete its saved checkpoints — variables, imports, and definitions from earlier cells are discarded and the pad restarts fresh. Omit to keep the namespace.',
       },
     },
     output: {
       schema: {
         type: 'object',
         additionalProperties: false,
         properties: {
           logs: { type: 'array', required: true, items: { type: 'string' } },
           result: { type: 'json' },
         },
```

```diff
--- baseline/better-dsh/src/kernel-bridge.py
+++ current/better-dsh/src/kernel-bridge.py
@@ -1,172 +0,0 @@
-#!/usr/bin/env python3
-"""stdio <-> ZeroMQ bridge for the DASHR REPL.
-
-The host (Node/TS) owns the kernel lifecycle but must not link a native ZMQ
-binding: `zeromq` was a hard npm dependency whose install script compiles C++
-inside the consumer's install transaction (and whose top-level import killed
-the whole plugin when the binding was missing). This process is the only ZMQ
-speaker on the host side; it speaks JSON lines on stdio to Node.
-
-    Node  ──stdio JSON lines──►  kernel-bridge.py  ──pyzmq/jupyter_client──►  ipykernel
-
-Requirements come from the kernel's own environment: `jupyter_client` and
-`pyzmq` are transitive dependencies of the `ipykernel` we provision (see
-`kernel-env.ts`), so nothing extra is fetched from any package manager.
-
-Protocol
---------
-stdin (one JSON object per line)::
-
-    {"op":"send","channel":"shell"|"control","header":{...},"content":{...}}
-    {"op":"interrupt"}
-    {"op":"shutdown"}
-
-stdout (one JSON object per line)::
-
-    {"ev":"ready"}
-    {"ev":"msg","channel":"shell"|"iopub"|"control"|"stdin","msg":{...}}
-    {"ev":"fatal","message":"..."}
-
-The caller-supplied `header` is passed to `Session.msg` verbatim, so the
-message id the host generated is the id on the wire — parent-matching and
-request/response correlation stay exactly as they were on the raw-socket path.
-"""
-from __future__ import annotations
-
-import json
-import queue
-import sys
-import threading
-
-CHANNELS = ("iopub", "shell", "control", "stdin")
-POLL_SECONDS = 0.2
-
-# Protocol output goes to the real stdout; anything a library prints must never
-# corrupt the byte stream the host parses, so sys.stdout is repointed to stderr.
-_PROTOCOL_OUT = sys.stdout
-sys.stdout = sys.stderr
-
-_write_lock = threading.Lock()
-
-
-def emit(payload: dict) -> None:
-    """Write one protocol line, atomically across the pump threads."""
-    # `default=str`: jupyter_client hands back parsed values (a header `date`
-    # arrives as `datetime`, for instance) that are not JSON-native; the host
-    # only reads msg_id/msg_type/content, so stringifying the rest is lossless
-    # for its purposes and keeps one pump thread from dying on a header field.
-    line = json.dumps(payload, ensure_ascii=False, default=str)
-    with _write_lock:
-        _PROTOCOL_OUT.write(line + "\n")
-        _PROTOCOL_OUT.flush()
-
-
-def _clean(value: object) -> object:
-    """Strip binary buffers: this protocol carries JSON only."""
-    if isinstance(value, dict):
-        return {key: _clean(item) for key, item in value.items() if key != "buffers"}
-    if isinstance(value, (list, tuple)):
-        return [_clean(item) for item in value]
-    if isinstance(value, bytes):
-        return value.decode("utf-8", "replace")
-    return value
-
-
-def pump(client, name: str, stop: threading.Event) -> None:
-    """Relay one client channel onto stdout until `stop` is set."""
-    channel = getattr(client, f"{name}_channel")
-    while not stop.is_set():
-        try:
-            message = channel.get_msg(timeout=POLL_SECONDS)
-        except queue.Empty:
-            continue
-        except Exception as error:  # channel torn down, or the socket died
-            if not stop.is_set():
-                emit({"ev": "fatal", "channel": name, "message": f"{type(error).__name__}: {error}"})
-        try:
-            emit({
-                "ev": "msg",
-                "channel": name,
-                "msg": {
-                    "header": message.get("header") or {},
-                    "parent_header": message.get("parent_header") or {},
-                    "content": _clean(message.get("content") or {}),
-                    "metadata": _clean(message.get("metadata") or {}),
-                },
-            })
-        except Exception as error:  # never let one message kill a channel pump
-            sys.stderr.write(f"kernel-bridge: cannot relay {name} message: {type(error).__name__}: {error}\n")
-            sys.stderr.flush()
-
-
-def main() -> int:
-    if len(sys.argv) != 2:
-        emit({"ev": "fatal", "message": "usage: kernel-bridge.py <connection-file>"})
-        return 2
-
-    try:
-        from jupyter_client import BlockingKernelClient
-    except Exception as error:  # the kernel environment is incomplete
-        emit({"ev": "fatal", "message": f"jupyter_client unavailable: {type(error).__name__}: {error}"})
-        return 3
-
-    try:
-        client = BlockingKernelClient(connection_file=sys.argv[1])
-        client.load_connection_file()
-        client.start_channels()
-    except Exception as error:
-        emit({"ev": "fatal", "message": f"cannot connect to the kernel: {type(error).__name__}: {error}"})
-        return 4
-
-    stop = threading.Event()
-    for name in CHANNELS:
-        threading.Thread(target=pump, args=(client, name, stop), name=f"pump-{name}", daemon=True).start()
-
-    emit({"ev": "ready"})
-
-    try:
-        for line in sys.stdin:
-            line = line.strip()
-            if not line:
-                continue
-            try:
-                request = json.loads(line)
-            except Exception:
-                continue
-            op = request.get("op")
-            if op == "send":
-                channel_name = request.get("channel")
-                if channel_name not in ("shell", "control"):
-                    emit({"ev": "fatal", "message": f"unknown send channel {channel_name!r}"})
-                    continue
-                channel = getattr(client, f"{channel_name}_channel")
-                try:
-                    header = request.get("header") or None
-                    message = client.session.msg(
-                        header["msg_type"] if header else "comm_msg",
-                        content=request.get("content") or {},
-                        header=header,
-                    )
-                    channel.send(message)
-                except Exception as error:
-                    emit({"ev": "fatal", "channel": channel_name, "message": f"send failed: {type(error).__name__}: {error}"})
-            elif op == "interrupt":
-                try:
-                    client.interrupt_kernel()
-                except Exception as error:
-                    emit({"ev": "fatal", "message": f"interrupt failed: {type(error).__name__}: {error}"})
-            elif op == "shutdown":
-                break
-    except (KeyboardInterrupt, BrokenPipeError):
-        pass
-    finally:
-        stop.set()
-        try:
-            client.stop_channels()
-        except Exception:
-            pass
-    return 0
-
-
-if __name__ == "__main__":
-    sys.exit(main())
```

```diff
--- baseline/better-dsh/src/kernel-env.ts
+++ current/better-dsh/src/kernel-env.ts
@@ -1,248 +1,59 @@
-/**
- * Kernel environment resolution and provisioning.
- *
- * The runtime OWNS the interpreter it spawns: it never trusts a bare
- * `python3` on the PATH, because that interpreter may lack `ipykernel`
- * (hard failure — the kernel cannot start) or `dill` (snapshot capability —
- * silently degrading to no snapshots). Instead it resolves one of two
- * environments:
- *
- * - **Explicit** — `config.python` names a real interpreter (a path, or any
- *   name other than the bare-`python3` sentinel the default/patch produce).
- *   It is probed, and a missing `ipykernel` is a loud error while a missing
- *   `dill` is a loud warning (snapshots disabled).
- * - **Managed** — no explicit interpreter: the runtime provisions a venv
- *   UNDER THE PACKAGE (`<packageRoot>/.venv-kernel`, or `config.kernelEnvDir`)
- *   with `ipykernel` + `dill`, installing it on first use when
- *   `config.kernelAutoInstall` is on. The venv lives beside the package, NOT
- *   in `/tmp` (the pre-v0.1.9 dangling-symlink failure mode), so it survives
- *   the host's tmp reaper and the process restart.
- *
- * Provisioning uses `uv` when available (fast, can fetch the pinned CPython
- * version), falling back to `python3 -m venv` + `ensurepip`. It is idempotent:
- * a complete venv is reused untouched; a partial one is repaired.
- * @module dashr/kernel-env
- */
-
+/** Resolve a Python >=3.9 interpreter. The packaged OMP runner needs only stdlib. */
 import { execFile } from 'node:child_process'
 import { existsSync, mkdirSync } from 'node:fs'
 import { dirname, join, resolve } from 'node:path'
 import { fileURLToPath } from 'node:url'
 import { promisify } from 'node:util'
-
-const execFileAsync = promisify(execFile)
-
-/** The installed package root (where `lib/` and `src/` live): the default home of the managed venv. */
+const exec = promisify(execFile)
 export const PACKAGE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
-
-/** The config value meaning "no explicit interpreter — auto-manage a venv". */
 export const AUTO_PYTHON_SENTINEL = 'python3'
-
-/** Preferred CPython version for a managed venv. */
 export const DEFAULT_KERNEL_PYTHON_VERSION = '3.11'
-
-/** Pinned, tested `ipykernel` version (2026-09-02 tested value; upgrade = explicit change + regression). */
-export const IPYKERNEL_VERSION = '7.3.0'
-
-/** Pinned, tested `dill` version. */
 export const DILL_VERSION = '0.4.1'
-
 export interface KernelEnv {
-  /** Absolute path to the interpreter to spawn (`-m ipykernel_launcher`). */
   python: string
-  /** True when this runtime provisioned a venv (vs an explicit interpreter). */
   managed: boolean
-  /** The managed venv root, when {@link managed}. */
   venvDir: string | undefined
-  /** True when `dill` is importable — snapshot capability is available. */
+  /** Snapshot implementation is packaged rather than installed into Python. */
   dill: boolean
-  /** True when `ipykernel` is importable (a hard requirement). */
-  ipykernel: boolean
-  /** The interpreter's reported version, e.g. `3.11.15`. */
   version: string
 }
-
 export interface ResolveKernelEnvOptions {
-  /** `config.python`; the bare sentinel (or absent) selects a managed venv. */
   python?: string
-  /** Managed venv directory; defaults to `<packageRoot>/.venv-kernel`. */
   venvDir?: string
-  /** Preferred CPython version for the managed venv. */
   pythonVersion?: string
-  /** Provision the managed venv when missing/incomplete (default true). */
   autoInstall?: boolean
-  /** Logger callback (info on provisioning, warn on degraded snapshot). */
   log?: (level: 'info' | 'warn', message: string) => void
 }
-
-interface Probe {
-  version: string
-  ipykernel: boolean
-  dill: boolean
+export function uvToolEnv(venvDir: string): NodeJS.ProcessEnv {
+  const cache = join(dirname(venvDir), '.uv-cache')
+  return { ...process.env, UV_CACHE_DIR: cache, UV_PYTHON_INSTALL_DIR: join(cache, 'python'), UV_LINK_MODE: 'copy' }
 }
-
-/** A probe that never imports user modules and reports exactly what we need. */
-const PROBE_CODE = [
-  'import json, sys',
-  'r = {"version": sys.version.split()[0], "ipykernel": False, "dill": False}',
-  'try:',
-  '    import ipykernel  # noqa: F401',
-  '    r["ipykernel"] = True',
-  'except Exception:',
-  '    pass',
-  'try:',
-  '    import dill  # noqa: F401',
-  '    r["dill"] = True',
-  'except Exception:',
-  '    pass',
-  'print(json.dumps(r))',
-].join('\n')
-
-async function probePython(python: string): Promise<Probe | null> {
+export function uvVenvArgs(dir: string, version: string): string[] { return ['venv', dir, '--python', version] }
+export function venvFallbackArgs(dir: string): string[] { return ['-m', 'venv', '--without-pip', dir] }
+function venvPython(dir: string): string { return join(dir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python') }
+async function probe(python: string): Promise<string> {
   try {
-    const { stdout } = await execFileAsync(python, ['-c', PROBE_CODE], { timeout: 15_000 })
-    const parsed = JSON.parse(stdout.trim()) as Partial<Probe>
-    return {
-      version: typeof parsed.version === 'string' && parsed.version.length > 0 ? parsed.version : 'unknown',
-      ipykernel: parsed.ipykernel === true,
-      dill: parsed.dill === true,
-    }
-  } catch {
-    return null
+    const { stdout } = await exec(python, ['-c', 'import ast, asyncio, json, sys; assert sys.version_info >= (3, 9), "Python >=3.9 required"; print(json.dumps(sys.version.split()[0]))'], { timeout: 15_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' } })
+    return JSON.parse(stdout.trim()) as string
+  } catch (error) {
+    throw new Error(`Better Python REPL requires Python >=3.9. Could not use ${JSON.stringify(python)}: ${error instanceof Error ? error.message : String(error)}. Configure python with a working interpreter path.`)
   }
 }
-
-/** The venv interpreter path for this platform. */
-function venvPythonPath(venvDir: string): string {
-  return process.platform === 'win32'
-    ? join(venvDir, 'Scripts', 'python.exe')
-    : join(venvDir, 'bin', 'python')
+export async function resolveKernelEnv(options: ResolveKernelEnvOptions = {}): Promise<KernelEnv> {
+  if (options.python && options.python !== AUTO_PYTHON_SENTINEL) {
+    return { python: options.python, managed: false, venvDir: undefined, dill: true, version: await probe(options.python) }
+  }
+  const venvDir = options.venvDir ?? join(PACKAGE_ROOT, '.venv-kernel')
+  const python = venvPython(venvDir)
+  if (!existsSync(python)) {
+    if (options.autoInstall === false) throw new Error(`Better Python REPL managed interpreter is missing at ${python}; configure python or run npm run kernel:venv`)
+    options.log?.('info', `Creating stdlib-only Python environment at ${venvDir} (no pip packages)`)
+    let uv = false
+    try { await exec('uv', ['--version'], { timeout: 10_000 }); uv = true } catch { /* system Python fallback */ }
+    if (uv) {
+      mkdirSync(join(dirname(venvDir), '.uv-cache'), { recursive: true })
+      await exec('uv', uvVenvArgs(venvDir, options.pythonVersion ?? DEFAULT_KERNEL_PYTHON_VERSION), { timeout: 120_000, env: uvToolEnv(venvDir) })
+    } else await exec('python3', venvFallbackArgs(venvDir), { timeout: 120_000 })
+  }
+  return { python, managed: true, venvDir, dill: true, version: await probe(python) }
 }
-
-async function commandExists(cmd: string): Promise<boolean> {
-  try {
-    await execFileAsync(cmd, ['--version'], { timeout: 10_000 })
-    return true
-  } catch {
-    return false
-  }
-}
-
-/** Tool-cache env for uv: caches live NEXT TO the venv (plugin territory), so a read-only home can never block provisioning. */
-export function uvToolEnv(venvDir: string): NodeJS.ProcessEnv {
-  const cacheDir = join(dirname(venvDir), '.uv-cache')
-  return {
-    ...process.env,
-    UV_CACHE_DIR: cacheDir,
-    UV_PYTHON_INSTALL_DIR: join(cacheDir, 'python'),
-    UV_LINK_MODE: 'copy',
-  }
-}
-
-/** uv venv arguments (pure; unit-tested). */
-export function uvVenvArgs(venvDir: string, pythonVersion: string): string[] {
-  return ['venv', venvDir, '--python', pythonVersion]
-}
-
-/** python3 -m venv fallback arguments (pure; cache-free by construction). */
-export function venvFallbackArgs(venvDir: string): string[] {
-  return ['-m', 'venv', venvDir]
-}
-
-/** uv pip install arguments with pinned versions (pure; unit-tested). */
-export function uvInstallArgs(python: string): string[] {
-  return ['pip', 'install', '--python', python, '--quiet', `ipykernel==${IPYKERNEL_VERSION}`, `dill==${DILL_VERSION}`]
-}
-
-/** pip install arguments with pinned versions for the venv interpreter (pure). */
-export function pipInstallArgs(): string[] {
-  return ['-m', 'pip', 'install', '--quiet', '--disable-pip-version-check', `ipykernel==${IPYKERNEL_VERSION}`, `dill==${DILL_VERSION}`]
-}
-
-/** Create the venv (when absent) and return its interpreter path. */
-async function createVenv(venvDir: string, pythonVersion: string): Promise<string> {
-  const python = venvPythonPath(venvDir)
-  if (existsSync(python)) return python
-  if (await commandExists('uv')) {
-    mkdirSync(join(dirname(venvDir), '.uv-cache'), { recursive: true })
-    await execFileAsync('uv', uvVenvArgs(venvDir, pythonVersion), { timeout: 120_000, env: uvToolEnv(venvDir) })
-  } else {
-    await execFileAsync('python3', venvFallbackArgs(venvDir), { timeout: 120_000 })
-  }
-  return python
-}
-
-/** Install pinned `ipykernel` + `dill` into the venv interpreter. */
-async function installDeps(python: string, venvDir: string): Promise<void> {
-  if (await commandExists('uv')) {
-    await execFileAsync('uv', uvInstallArgs(python), { timeout: 180_000, env: uvToolEnv(venvDir) })
-  } else {
-    await execFileAsync(python, pipInstallArgs(), { timeout: 180_000 })
-  }
-}
-
-/** Provision (or repair) the managed venv so it has `ipykernel` + `dill`. */
-async function ensureVenv(venvDir: string, pythonVersion: string, log?: ResolveKernelEnvOptions['log']): Promise<string> {
-  const python = venvPythonPath(venvDir)
-  const existing = existsSync(python) ? await probePython(python) : null
-  if (existing?.ipykernel === true && existing.dill === true) {
-    return python
-  }
-  await createVenv(venvDir, pythonVersion)
-  if (!existsSync(python)) {
-    throw new Error(`dashr-repl: managed kernel venv was not created at ${venvDir} (no interpreter at ${python})`)
-  }
-  log?.('info', `dashr-repl: provisioning kernel venv at ${venvDir} (ipykernel + dill)`)
-  await installDeps(python, venvDir)
-  return python
-}
-
-/**
- * Resolve the kernel interpreter, provisioning a managed venv when no
- * explicit interpreter is configured. Throws when the resolved interpreter
- * cannot run `ipykernel`; a missing `dill` only disables snapshots (warned).
- */
-export async function resolveKernelEnv(options: ResolveKernelEnvOptions = {}): Promise<KernelEnv> {
-  const log = options.log
-  const explicit = options.python !== undefined && options.python !== '' && options.python !== AUTO_PYTHON_SENTINEL
-    ? options.python
-    : undefined
-
-  if (explicit !== undefined) {
-    const probe = await probePython(explicit)
-    if (probe === null) {
-      throw new Error(`dashr-repl: kernel python ${JSON.stringify(explicit)} could not be executed — check the path`)
-    }
-    if (!probe.ipykernel) {
-      throw new Error(`dashr-repl: kernel python ${JSON.stringify(explicit)} has no ipykernel — install it (pip install ipykernel) or set python to a managed venv`)
-    }
-    if (!probe.dill) {
-      log?.('warn', `dashr-repl: kernel python ${JSON.stringify(explicit)} has no dill — namespace snapshots are DISABLED (install it: pip install dill)`)
-    }
-    return { python: explicit, managed: false, venvDir: undefined, dill: probe.dill, ipykernel: true, version: probe.version }
-  }
-
-  const venvDir = options.venvDir ?? join(PACKAGE_ROOT, '.venv-kernel')
-  const python = venvPythonPath(venvDir)
-
-  if (options.autoInstall === false) {
-    const probe = await probePython(python)
-    if (probe === null || !probe.ipykernel) {
-      throw new Error(`dashr-repl: managed kernel venv is missing or incomplete at ${venvDir} — run 'npm run kernel:venv' in the dashr package, or set kernelAutoInstall: true (or python to a prepared interpreter)`)
-    }
-    if (!probe.dill) {
-      log?.('warn', `dashr-repl: kernel venv at ${venvDir} has no dill — namespace snapshots are DISABLED (run 'npm run kernel:venv' to reinstall)`)
-    }
-    return { python, managed: true, venvDir, dill: probe.dill, ipykernel: true, version: probe.version }
-  }
-
-  const resolved = await ensureVenv(venvDir, options.pythonVersion ?? DEFAULT_KERNEL_PYTHON_VERSION, log)
-  const probe = await probePython(resolved)
-  if (probe === null || !probe.ipykernel) {
-    throw new Error(`dashr-repl: managed kernel venv at ${venvDir} still has no ipykernel after provisioning — check uv/python3-venv availability and retry`)
-  }
-  if (!probe.dill) {
-    log?.('warn', `dashr-repl: managed kernel venv at ${venvDir} has no dill after provisioning — namespace snapshots are DISABLED`)
-  }
-  return { python: resolved, managed: true, venvDir, dill: probe.dill, ipykernel: true, version: probe.version }
-}
```

```diff
--- baseline/better-dsh/src/kernel-transport.ts
+++ current/better-dsh/src/kernel-transport.ts
@@ -1,289 +0,0 @@
-/**
- * stdio transport to the Python kernel bridge (`kernel-bridge.py`).
- *
- * The host never links a native ZMQ binding: `zeromq` was a hard npm
- * dependency whose install script compiled C++ inside the consumer's install
- * transaction, and whose top-level import took the whole plugin down with it
- * whenever the binding was absent. The bridge owns pyzmq/jupyter_client —
- * transitive dependencies of the `ipykernel` this plugin already provisions —
- * and speaks JSON lines on stdio to this process.
- *
- * Message ids stay host-generated: the header built here is passed through to
- * `jupyter_client.Session.msg` verbatim, so parent-matching is unchanged from
- * the raw-socket era.
- * @module dashr/kernel-transport
- */
-
-import { type ChildProcess, spawn } from 'node:child_process'
-import { createInterface, type Interface } from 'node:readline'
-import { fileURLToPath } from 'node:url'
-import { tmpdir } from 'node:os'
-
-/** Channels the bridge relays; `stdin` is unused (cells run with allow_stdin=false). */
-export type TransportChannel = 'shell' | 'iopub' | 'control' | 'stdin'
-
-/** One Jupyter message as relayed by the bridge. */
-export interface TransportMessage {
-  header: { msg_id: string, msg_type: string, [key: string]: unknown }
-  parent_header: Record<string, unknown>
-  content: Record<string, unknown>
-}
-
-/** Message handler; returning nothing, it must never throw into the reader. */
-export type TransportHandler = (channel: TransportChannel, message: TransportMessage) => void
-
-/** A one-shot wait for a specific channel message. */
-interface Waiter {
-  channel: TransportChannel
-  match: (message: TransportMessage) => boolean
-  settle: (message: TransportMessage | null) => void
-  timer: ReturnType<typeof setTimeout>
-}
-
-/** The bridge script shipped beside the built entry (`lib/kernel-bridge.py`). */
-const BRIDGE_SCRIPT = fileURLToPath(new URL('./kernel-bridge.py', import.meta.url))
-
-/** Options for one bridge process. */
-export interface KernelTransportOptions {
-  /** Absolute interpreter path; must be the kernel environment (jupyter_client + pyzmq). */
-  python: string
-  /** Connection file written by the kernel and already resolved to real ports. */
-  connectionFile: string
-  /** Working directory for the bridge process. */
-  cwd?: string
-  /** Budget for the bridge to report readiness, in milliseconds. */
-  readyTimeoutMs: number
-}
-
-/**
- * One bridge subprocess speaking JSON lines. Lifecycle is owned by the caller
- * (the kernel bridge registers it as an `ctx.effect`); this type installs no
- * process-level signal handlers.
- */
-export class KernelTransport {
-  private child?: ChildProcess
-  private reader?: Interface
-  private startup = false
-  private closed = false
-  private readySettled = false
-  private readyResolve?: () => void
-  private readyReject?: (error: Error) => void
-  private bridgeStderr = ''
-  private readonly handlers = new Set<TransportHandler>()
-  private readonly waiters = new Set<Waiter>()
-
-  constructor(private readonly options: KernelTransportOptions) { }
-
-  /** Spawn the bridge and resolve once it reports the channels are up. */
-  async start(): Promise<void> {
-    if (this.reader !== undefined) return
-    if (this.closed) throw new Error('kernel transport is closed')
-    const child = spawn(this.options.python, [BRIDGE_SCRIPT, this.options.connectionFile], {
-      ...this.options.cwd === undefined ? {} : { cwd: this.options.cwd },
-      // The same scrubbed environment as the kernel spawn: an absolute
-      // interpreter, no ambient credentials, HOME for interpreter caches.
-      env: {
-        PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin',
-        LANG: 'C.UTF-8',
-        HOME: process.env.HOME ?? tmpdir(),
-        PYTHONUNBUFFERED: '1',
-      },
-      stdio: ['pipe', 'pipe', 'pipe'],
-    })
-    this.child = child
-    this.startup = true
-    const ready = new Promise<void>((resolve, reject) => {
-      this.readyResolve = resolve
-      this.readyReject = reject
-    })
-    const timer = setTimeout(() => {
-      this.failReady(new Error(`kernel bridge did not report ready within ${this.options.readyTimeoutMs}ms; stderr tail:\n${this.stderrTail()}`))
-    }, this.options.readyTimeoutMs)
-    timer.unref?.()
-
-    child.stderr?.on('data', (buffer: Buffer) => { this.bridgeStderr += buffer.toString() })
-    // A bridge that died between the liveness check and a write surfaces EPIPE
-    // asynchronously; without a listener Node escalates it to an uncaught
-    // exception and takes the daemon down during teardown. Absorb it: the
-    // transport is already dead, and every waiter is settled below.
-    child.stdin?.on('error', (error: NodeJS.ErrnoException) => {
-      this.bridgeStderr += `stdin error: ${error.code ?? error.message}\n`
-      this.closed = true
-      this.failWaiters()
-    })
-    child.stdout?.on('error', (error: NodeJS.ErrnoException) => {
-      this.bridgeStderr += `stdout error: ${error.code ?? error.message}\n`
-    })
-    child.on('error', (error: Error) => {
-      this.bridgeStderr += `spawn error: ${error.message}\n`
-      this.failReady(new Error(`kernel bridge failed to spawn: ${error.message}`))
-      this.failWaiters()
-      this.failExit()
-    })
-    child.on('exit', (code, signal) => {
-      const detail = `kernel bridge exited (code=${String(code)} signal=${String(signal)})`
-      this.bridgeStderr += `${detail}\n`
-      this.closed = true
-      this.failReady(new Error(`${detail}; stderr tail:\n${this.stderrTail()}`))
-      this.failWaiters()
-      this.failExit()
-    })
-    if (child.stdout) {
-      this.reader = createInterface({ input: child.stdout })
-      this.reader.on('line', (line: string) => { this.accept(line) })
-    }
-
-    try {
-      await ready
-    } finally {
-      clearTimeout(timer)
-      this.startup = false
-    }
-  }
-
-  /** Whether the bridge process is still live. */
-  get alive(): boolean {
-    return this.child !== undefined && this.child.exitCode === null && !this.closed
-  }
-
-  /** The bridge's stderr tail, for startup and crash diagnostics. */
-  stderrTail(): string {
-    return this.bridgeStderr.slice(-1024) || '(empty)'
-  }
-
-  /** Register a message handler; the returned function removes it. */
-  onMessage(handler: TransportHandler): () => void {
-    this.handlers.add(handler)
-    return () => { this.handlers.delete(handler) }
-  }
-
-  /**
-   * Register a bridge-exit handler; the returned function removes it. A bridge
-   * that dies mid-cell must settle the active execution at once rather than at
-   * the cell budget.
-   */
-  onExit(handler: () => void): () => void {
-    this.exitHandlers.add(handler)
-    return () => { this.exitHandlers.delete(handler) }
-  }
-
-  private readonly exitHandlers = new Set<() => void>()
-
-  /** Notify exit handlers once per bridge process end. */
-  private failExit(): void {
-    const handlers = [...this.exitHandlers]
-    this.exitHandlers.clear()
-    for (const handler of handlers) handler()
-  }
-
-  /** Send one message on the shell or control channel. */
-  send(channel: 'shell' | 'control', message: { header: TransportMessage['header'], content: Record<string, unknown> }): void {
-    this.writeLine({ op: 'send', channel, header: message.header, content: message.content })
-  }
-
-  /** Ask the kernel to interrupt the running cell (control channel). */
-  interrupt(): void {
-    this.writeLine({ op: 'interrupt' })
-  }
-
-  /** Write one protocol line, refusing instead of throwing when the pipe is gone. */
-  private writeLine(payload: Record<string, unknown>): void {
-    const stdin = this.child?.stdin
-    if (stdin === null || stdin === undefined || this.closed || !stdin.writable) {
-      throw new Error('kernel bridge is not connected')
-    }
-    stdin.write(`${JSON.stringify(payload)}\n`)
-  }
-
-  /**
-   * Wait for the next message on `channel` matching `match`.
-   * @returns The message, or null when the budget expires or the bridge dies.
-   */
-  waitFor(channel: TransportChannel, match: (message: TransportMessage) => boolean, timeoutMs: number): Promise<TransportMessage | null> {
-    if (this.closed) return Promise.resolve(null)
-    return new Promise<TransportMessage | null>(resolve => {
-      const waiter: Waiter = {
-        channel,
-        match,
-        settle: (message) => {
-          clearTimeout(waiter.timer)
-          this.waiters.delete(waiter)
-          resolve(message)
-        },
-        timer: setTimeout(() => {
-          this.waiters.delete(waiter)
-          resolve(null)
-        }, timeoutMs),
-      }
-      waiter.timer.unref?.()
-      this.waiters.add(waiter)
-    })
-  }
-
-  /** Stop the bridge (graceful shutdown note, then kill). */
-  async dispose(): Promise<void> {
-    const child = this.child
-    this.closed = true
-    this.failWaiters()
-    this.reader?.close()
-    this.reader = undefined
-    if (child === undefined) return
-    try { if (child.stdin?.writable === true) child.stdin.write(`${JSON.stringify({ op: 'shutdown' })}\n`) } catch { /* already gone */ }
-    try { child.stdin?.end() } catch { /* already gone */ }
-    if (child.exitCode !== null) return
-    await new Promise<void>(resolve => {
-      const timer = setTimeout(() => {
-        try { child.kill('SIGKILL') } catch { /* already gone */ }
-        resolve()
-      }, 500)
-      timer.unref?.()
-      child.once('exit', () => { clearTimeout(timer); resolve() })
-    })
-  }
-
-  private failReady(error: Error): void {
-    if (this.readySettled) return
-    this.readySettled = true
-    this.readyReject?.(error)
-  }
-
-  private failWaiters(): void {
-    for (const waiter of [...this.waiters]) waiter.settle(null)
-  }
-
-  /** Route one decoded line; unknown events are ignored. */
-  private accept(line: string): void {
-    let event: { ev?: unknown, channel?: unknown, msg?: unknown, message?: unknown }
-    try {
-      event = JSON.parse(line) as typeof event
-    } catch {
-      return
-    }
-    if (event.ev === 'ready') {
-      if (!this.readySettled) {
-        this.readySettled = true
-        this.readyResolve?.()
-      }
-      return
-    }
-    if (event.ev === 'msg') {
-      const channel = event.channel
-      const raw = event.msg as { header?: unknown, parent_header?: unknown, content?: unknown } | undefined
-      if (typeof channel !== 'string' || raw === undefined || typeof raw.header !== 'object' || raw.header === null) return
-      const message: TransportMessage = {
-        header: raw.header as TransportMessage['header'],
-        parent_header: (raw.parent_header ?? {}) as Record<string, unknown>,
-        content: (raw.content ?? {}) as Record<string, unknown>,
-      }
-      for (const waiter of [...this.waiters]) {
-        if (waiter.channel === channel && waiter.match(message)) waiter.settle(message)
-      }
-      for (const handler of this.handlers) handler(channel as TransportChannel, message)
-      return
-    }
-    if (event.ev === 'fatal') {
-      this.bridgeStderr += `fatal: ${String(event.message ?? 'unknown')}\n`
-    }
-  }
-}
-
```

```diff
--- baseline/better-dsh/src/kernel.ts
+++ current/better-dsh/src/kernel.ts
@@ -1,892 +1,366 @@
-/**
- * Minimal IPython kernel bridge: spawns `python -m ipykernel_launcher`, speaks
- * the Jupyter wire protocol over ZeroMQ (shell/iopub/control), serializes cell
- * execution, and bridges kernel-side host requests (binding calls) over comms.
- * Ported from PA's `KernelManager` (prime-agent/packages/coding-agent/src/core/kernel/index.ts)
- * down to the subset DASHR needs; see README for the build-vs-reuse decision.
- *
- * Lifecycle is owned by the caller (the Cordis plugin registers it as a
- * `ctx.effect`); this class installs no process-level signal handlers, unlike
- * its PA ancestor.
- * @module dashr/kernel
- */
-
-import { type ChildProcess, spawn } from 'node:child_process'
+/** One persistent, serialized OMP Python child. No Jupyter ports or dependencies. */
+import { spawn, type ChildProcess } from 'node:child_process'
 import { randomBytes, randomUUID } from 'node:crypto'
-import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
-import { tmpdir } from 'node:os'
-import { join } from 'node:path'
-import { setTimeout as sleep } from 'node:timers/promises'
-import { KernelTransport } from './kernel-transport.ts'
-import type { TransportChannel, TransportMessage } from './kernel-transport.ts'
-import { HOST_COMM_TARGET, KERNEL_BOOTSTRAP } from './bootstrap.ts'
-import { buildQueryVarCell, buildRestoreCell, buildSetVarCell, buildSnapshotCell } from './python.ts'
+import { createServer, type Server } from 'node:http'
+import { createInterface } from 'node:readline'
+import type { Readable, Writable } from 'node:stream'
+import { fileURLToPath } from 'node:url'
+import { KERNEL_BOOTSTRAP } from './bootstrap.ts'
+import { buildQueryVarCell, buildSetVarCell, buildSnapshotCell, buildRestoreCell } from './python.ts'
 import type { SnapshotSpec } from './python.ts'
 import { extractStream } from './output.ts'
 
-/** Constructor options; every deployment-varying value arrives validated. */
 export interface KernelBridgeOptions {
-  /** Absolute or PATH-resolved python interpreter with `ipykernel` installed. */
   python: string
-  /** Working directory for the kernel subprocess. */
   cwd?: string
-  /** Budget for spawn → kernel_info reply, in milliseconds. */
   startupTimeoutMs: number
-  /** Budget for graceful dispose (shutdown_request → SIGTERM → SIGKILL), in milliseconds. */
   disposeTimeoutMs: number
-  /**
-   * Confirm window between the control-channel interrupt and the SIGALRM
-   * escalation, in milliseconds; must stay below every execute's grace.
-   */
+  /** Retained configuration seam; OMP interrupts with SIGINT directly. */
   interruptConfirmMs: number
-  /** Budget for internal snapshot/restore cells (dill dump/load), in milliseconds. */
   snapshotTimeoutMs: number
-  /** Jupyter username stamped on every message. */
   username: string
-}
-
-/** Host-supplied inputs a snapshot cell records beside the dill payload. */
+  snapshotDirectory?: string
+  snapshotSizeCapBytes?: number
+}
 export type { SnapshotSpec }
-
-/** One snapshot attempt's terminal outcome, parsed from the cell envelope. */
 export type SnapshotOutcome =
-  | { kind: 'ok', sizeBytes: number, names: number }
+  | { kind: 'ok', sizeBytes: number, names: string[], omitted: Record<string, string>, turn: number, warning?: string }
   | { kind: 'skipped', reason: string, estimateBytes?: number, sizeBytes?: number, capBytes: number }
   | { kind: 'failed', reason: string }
-
-/** One restore attempt's terminal outcome, parsed from the cell envelope. */
-export type RestoreStateOutcome =
-  | { kind: 'restored', count: number }
-  | { kind: 'degraded', reason: string }
-
-/** One user-namespace variable query, parsed from the cell envelope. */
-export type QueryVarOutcome =
-  | { kind: 'json', text: string }
-  | { kind: 'repr', text: string }
-  | { kind: 'names', names: string[] }
-  | { kind: 'missing' }
-  | { kind: 'failed', reason: string }
-
-/** One user-namespace variable assignment, parsed from the cell envelope. */
-export type SetVarOutcome =
-  | { kind: 'ok' }
-  | { kind: 'failed', reason: string }
-
-
-/** One host-request resolution: ok carries the reply payload, not-ok a message. */
+export type RestoreStateOutcome = { kind: 'restored', count: number, turn: number, omitted: Record<string, string> } | { kind: 'degraded', reason: string }
+export type QueryVarOutcome = { kind: 'json' | 'repr', text: string } | { kind: 'names', names: string[] } | { kind: 'missing' } | { kind: 'failed', reason: string }
+export type SetVarOutcome = { kind: 'ok' } | { kind: 'failed', reason: string }
 export type HostRequestOutcome = { ok: true, result: unknown } | { ok: false, message: string }
-
-/** Dispatches one typed request from kernel-side code. */
 export type HostRequestHandler = (data: Record<string, unknown>) => Promise<HostRequestOutcome>
-
 export interface ExecuteCellOptions {
-  /** Wall budget for the cell; interrupts then force-settles on expiry. */
   timeoutMs: number
-  /** Grace between interrupt and force-settle, in milliseconds. */
   interruptGraceMs: number
-  /**
-   * Confirm window between the control-channel interrupt and the SIGALRM
-   * escalation, in milliseconds; must stay below {@link interruptGraceMs}.
-   * The zmq interrupt alone settles any cell that yields to the kernel event
-   * loop, so SIGALRM — the channel that can terminate an idle kernel (see
-   * {@link IpyKernelBridge.interrupt | interrupt}) — is only sent when the
-   * cell provably ignored phase one. The kernel-side busy guard makes a
-   * signal that still sneaks onto an idle kernel harmless.
-   */
   interruptConfirmMs: number
-  /** Aborting interrupts the kernel and settles the cell as aborted. */
   signal?: AbortSignal
-  /** Host-request dispatcher active while this cell executes. */
   hostRequestHandler?: HostRequestHandler
 }
-
-/** A cell's terminal outcome; substrate-level failures arrive as `forced`. */
 export type CellOutcome =
-  | {
-    outcome: 'completed'
-    status: 'ok' | 'error'
-    streamText: string
-    cellError?: { ename: string, evalue: string, traceback: string[] }
-  }
-  | {
-    outcome: 'forced'
-    failure: { kind: 'timeout' | 'abort' | 'worker-exit', message: string }
-    streamText: string
-  }
-
-const PROTOCOL_VERSION = '5.3'
-/** Loopback PUB/SUB subscription propagation guard before the first execute. */
-const IOPUB_SUBSCRIBE_DELAY_MS = 50
-const CONNECT_POLL_MS = 25
-const SHUTDOWN_DRAIN_MS = 200
-
-interface ConnectionInfo {
-  ip: string
-  transport: 'tcp'
-  shell_port: number
-  iopub_port: number
-  stdin_port: number
-  control_port: number
-  hb_port: number
-  signature_scheme: 'hmac-sha256'
-  key: string
-  kernel_name: string
-}
-
-/** The bridge relays exactly this shape; the alias keeps call sites unchanged. */
-type JupyterMessage = TransportMessage
-
-interface ActiveExecution {
-  requestMsgId: string
+  | { outcome: 'completed', status: 'ok' | 'error', streamText: string, cellError?: { ename: string, evalue: string, traceback: string[] } }
+  | { outcome: 'forced', failure: { kind: 'timeout' | 'abort' | 'worker-exit', message: string }, streamText: string }
+type Failure = Extract<CellOutcome, { outcome: 'forced' }>['failure']
+interface Active {
+  id: string
   opts: ExecuteCellOptions
   streamText: string
-  cellError?: { ename: string, evalue: string, traceback: string[] }
-  status: 'ok' | 'error'
-  settled: boolean
+  started: boolean
+  error?: { ename: string, evalue: string, traceback: string[] }
+  pendingForce?: Failure
   resolve: (outcome: CellOutcome) => void
-  forceTimer?: ReturnType<typeof setTimeout>
-  timeoutTimer?: ReturnType<typeof setTimeout>
-  /** The phase-two SIGALRM escalation timer; cleared on every settle path like the others. */
-  alarmTimer?: ReturnType<typeof setTimeout>
-  /** Detach the caller signal's abort listener; EVERY settle path must run it exactly once. */
-  detachSignal?: () => void
-  /** Set when the budget/abort interrupt was sent; the interrupt's own error must not masquerade as a program exception. */
-  pendingForce?: { kind: 'timeout' | 'abort', message: string }
-}
-
-function isRecord(value: unknown): value is Record<string, unknown> {
-  return typeof value === 'object' && value !== null && !Array.isArray(value)
-}
-
-function buildMessage(msgType: string, content: Record<string, unknown>, session: string, username: string): JupyterMessage {
-  return {
-    header: {
-      msg_id: randomUUID(),
-      session,
-      username,
-      date: new Date().toISOString(),
-      msg_type: msgType,
-      version: PROTOCOL_VERSION,
-    },
-    parent_header: {},
-    content,
-  }
-}
-
-function makeConnection(): { path: string, tempDir: string } {
-  const info: ConnectionInfo = {
-    ip: '127.0.0.1',
-    transport: 'tcp',
-    shell_port: 0,
-    iopub_port: 0,
-    stdin_port: 0,
-    control_port: 0,
-    hb_port: 0,
-    signature_scheme: 'hmac-sha256',
-    key: randomBytes(16).toString('hex'),
-    kernel_name: 'python3',
-  }
-  const tempDir = mkdtempSync(join(tmpdir(), 'dashr-kernel-'))
-  const path = join(tempDir, 'connection.json')
-  writeFileSync(path, JSON.stringify(info, null, 2), { mode: 0o600 })
-  return { path, tempDir }
-}
-
-function readResolvedConnection(path: string): ConnectionInfo | null {
-  try {
-    const parsed: unknown = JSON.parse(readFileSync(path, 'utf8'))
-    if (!isRecord(parsed) || parsed.ip !== '127.0.0.1' || parsed.transport !== 'tcp' || parsed.signature_scheme !== 'hmac-sha256' || typeof parsed.key !== 'string') return null
-    for (const port of ['shell_port', 'iopub_port', 'stdin_port', 'control_port', 'hb_port'] as const) {
-      const value = parsed[port]
-      if (typeof value !== 'number' || !Number.isInteger(value) || value <= 0) return null
-    }
-    return parsed as unknown as ConnectionInfo
-  } catch {
-    return null
-  }
-}
-
-/**
- * One persistent IPython kernel subprocess with its ZeroMQ channels. Cell
- * execution is serialized on an internal queue (the Jupyter shell channel is
- * request/reply).
- */
+  timeout?: ReturnType<typeof setTimeout>
+  force?: ReturnType<typeof setTimeout>
+  detach?: () => void
+  confirm?: ReturnType<typeof setTimeout>
+  rejectCallbacks: Set<() => void>
+}
+function record(value: unknown): value is Record<string, unknown> {
+  return value !== null && typeof value === 'object' && !Array.isArray(value)
+}
+
+/** Historical class name retained for the runtime's private integration seam. */
 export class IpyKernelBridge {
-  private readonly session = randomUUID()
   private state: 'idle' | 'starting' | 'running' | 'shutdown' = 'idle'
+  private child?: ChildProcess
   private startPromise?: Promise<void>
-  private kernel?: ChildProcess
-  private transport?: KernelTransport
-  private connection?: ConnectionInfo
-  private tempDir?: string
-  private kernelStderr = ''
-  private executionQueue: Promise<unknown> = Promise.resolve()
-  private activeExec?: ActiveExecution
-  private readonly commTargets = new Map<string, string>()
-  private readonly servedComms = new Set<string>()
+  private disposePromise?: Promise<void>
+  private queue: Promise<unknown> = Promise.resolve()
+  private active?: Active
+  private stderr = ''
+  private deathFailure?: Failure
+  private callbackServer?: Server
+  private closePromise?: Promise<void>
+  private readonly ownedReaders: ReturnType<typeof createInterface>[] = []
 
   constructor(private readonly options: KernelBridgeOptions) {}
-
-  /** The kernel subprocess pid, for lifecycle assertions; absent before spawn. */
-  get pid(): number | undefined {
-    return this.kernel?.pid
-  }
-
-  get isRunning(): boolean {
-    return this.state === 'running'
-  }
-
-  /**
-   * Whether the subprocess is gone (crashed or disposed). A dead bridge is
-   * never resurrected — the owning provider replaces it with a fresh one
-   * (respawn, M3-A), because kernel state is unrecoverable in-process.
-   */
-  get isDead(): boolean {
-    return this.state === 'shutdown'
-  }
-
-  /**
-   * Start the kernel (idempotent; concurrent callers share one startup).
-   * @throws when the subprocess cannot spawn, ports never resolve, the
-   *   kernel_info probe times out, or the bootstrap cell fails.
-   */
-  async start(): Promise<void> {
-    if (!this.startPromise) {
-      this.startPromise = this.doStart().catch((error: unknown) => {
-        this.startPromise = undefined
-        throw error
+  get pid(): number | undefined { return this.child?.pid }
+  get isRunning(): boolean { return this.state === 'running' }
+  get isDead(): boolean { return this.state === 'shutdown' }
+
+  start(): Promise<void> {
+    this.startPromise ??= this.doStart()
+    return this.startPromise
+  }
+
+  private async windowsCallbacks(): Promise<Record<string, string>> {
+    const token = randomBytes(32).toString('hex')
+    const server = createServer((req, response) => {
+      if (req.method !== 'POST' || req.url !== '/callback' || req.headers.authorization !== `Bearer ${token}`) {
+        response.writeHead(403).end()
+        return
+      }
+      let body = ''
+      req.setEncoding('utf8')
+      req.on('data', (data: string) => { body += data })
+      req.on('end', () => {
+        let parsed: unknown
+        try { parsed = JSON.parse(body) } catch { response.writeHead(400).end(); return }
+        void this.callback(parsed).then(reply => {
+          if (!response.destroyed) response.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify(reply))
+        })
       })
-    }
-    return this.startPromise
-  }
-
-  private stderrTail(): string {
-    return this.kernelStderr.slice(-1024) || '(empty)'
+    })
+    this.callbackServer = server
+    await new Promise<void>((resolve, reject) => {
+      server.once('error', reject)
+      server.listen(0, '127.0.0.1', () => { server.off('error', reject); resolve() })
+    })
+    const address = server.address()
+    if (!address || typeof address === 'string') throw new Error('callback endpoint unavailable')
+    return { BETTER_CALLBACK_URL: `http://127.0.0.1:${address.port}/callback`, BETTER_CALLBACK_TOKEN: token }
   }
 
   private async doStart(): Promise<void> {
-    if (this.state !== 'idle') return
+    if (this.state !== 'idle') throw new Error('Python bridge cannot restart after shutdown')
     this.state = 'starting'
-    const { path, tempDir } = makeConnection()
-    this.tempDir = tempDir
-    // Scrubbed environment: the interpreter is invoked by absolute path, and
-    // the kernel needs no ambient credentials; HOME backs IPython's optional
-    // history writes.
-    const kernel = spawn(this.options.python, ['-m', 'ipykernel_launcher', '-f', path], {
-      cwd: this.options.cwd,
-      env: {
-        PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin',
-        LANG: 'C.UTF-8',
-        HOME: process.env.HOME ?? tmpdir(),
-      },
-      stdio: ['ignore', 'pipe', 'pipe'],
-    })
-    this.kernel = kernel
-    kernel.stderr?.on('data', (buf: Buffer) => { this.kernelStderr += buf.toString() })
-    kernel.on('error', (error: Error) => {
-      this.kernelStderr += `spawn error: ${error.message}\n`
-      this.onKernelDeath()
-    })
-    kernel.on('exit', (code, signal) => {
-      if (this.state !== 'shutdown') this.kernelStderr += `unexpected exit code=${code} signal=${signal}\n`
-      this.onKernelDeath()
-    })
-
-    let conn: ConnectionInfo
     try {
-      conn = await this.waitForConnection(path)
-      this.connection = conn
+      const resources = fileURLToPath(new URL('./omp-python/', import.meta.url))
+      const callbackEnv = process.platform === 'win32' ? await this.windowsCallbacks() : {}
+      if (this.isDead) throw new Error('Python startup cancelled by disposal')
+      const child = spawn(this.options.python, ['-u', fileURLToPath(new URL('./omp-python/runner.py', import.meta.url))], {
+        ...this.options.cwd ? { cwd: this.options.cwd } : {},
+        detached: process.platform !== 'win32',
+        stdio: process.platform === 'win32' ? ['pipe', 'pipe', 'pipe'] : ['pipe', 'pipe', 'pipe', 'pipe', 'pipe'],
+        env: { ...process.env, PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8',
+          PYTHONDONTWRITEBYTECODE: '1', PYTHONPATH: [resources, process.env.PYTHONPATH].filter(Boolean).join(process.platform === 'win32' ? ';' : ':'), ...callbackEnv },
+      })
+      this.child = child
+      this.closePromise = new Promise(resolve => child.once('close', () => resolve()))
+      child.on('error', error => this.died(`Python process error: ${error.message}`))
+      child.on('exit', (code, signal) => this.died(`Python process exited (${signal ?? code}); stderr: ${this.stderr.slice(-2048)}`))
+      child.stdin?.on('error', error => this.died(`Python input pipe failed: ${error.message}`))
+      child.stderr?.setEncoding('utf8').on('data', (data: string) => { this.stderr = (this.stderr + data).slice(-8192) })
+      const frames = createInterface({ input: child.stdout! })
+      this.ownedReaders.push(frames)
+      frames.on('line', line => {
+        try { this.frame(JSON.parse(line)) } catch { this.died('Python emitted invalid NDJSON protocol') }
+      })
+      if (process.platform !== 'win32') {
+        const requests = createInterface({ input: child.stdio[3] as Readable })
+        this.ownedReaders.push(requests)
+        const replies = child.stdio[4] as Writable
+        replies.on('error', () => { /* death/disposal closes callback pipes */ })
+        requests.on('line', line => {
+          let data: unknown
+          try { data = JSON.parse(line) } catch { return }
+          void this.callback(data).then(reply => {
+            if (!replies.destroyed && !replies.writableEnded) replies.write(JSON.stringify(reply) + '\n')
+          })
+        })
+      }
+      const result = await this.perform(KERNEL_BOOTSTRAP + `\n__import__('better_snapshot').configure(${JSON.stringify(this.options.snapshotDirectory ?? '')}, ${this.options.snapshotSizeCapBytes ?? 268435456}, ${this.options.snapshotTimeoutMs})`, {
+        timeoutMs: this.options.startupTimeoutMs, interruptGraceMs: 1_000, interruptConfirmMs: this.options.interruptConfirmMs,
+      })
+      if (result.outcome !== 'completed' || result.status !== 'ok') {
+        throw new Error(`OMP Python initialization failed: ${JSON.stringify(result)}`)
+      }
+      if (this.isDead) throw new Error('Python exited during initialization')
+      this.state = 'running'
     } catch (error) {
-      this.cleanupResources()
-      this.state = 'idle'
+      await this.dispose()
       throw error
     }
-
-    const transport = new KernelTransport({
-      python: this.options.python,
-      connectionFile: path,
-      ...this.options.cwd === undefined ? {} : { cwd: this.options.cwd },
-      readyTimeoutMs: this.options.startupTimeoutMs,
-    })
-    this.transport = transport
-    transport.onMessage((channel, message) => { this.handleTransportMessage(channel, message) })
-    transport.onExit(() => {
-      if (this.state !== 'shutdown') {
-        this.forceSettleActive({
-          kind: 'worker-exit',
-          message: `kernel bridge died. stderr tail:\n${transport.stderrTail()}`,
-        })
-      }
-    })
+  }
+
+  private async callback(data: unknown): Promise<Record<string, unknown>> {
+    const identity = record(data) ? { id: data.id, run: data.run } : {}
+    const active = this.active
+    if (!record(data) || !active || active.id !== data.run || active.pendingForce || !active.opts.hostRequestHandler) {
+      return { ...identity, ok: false, message: 'host callback rejected: its cell is no longer active' }
+    }
+    const revoked = { ...identity, ok: false, message: 'host callback cancelled: its cell ended' }
+    return new Promise(resolve => {
+      let settled = false
+      const finish = (reply: Record<string, unknown>): void => {
+        if (settled) return
+        settled = true
+        active.rejectCallbacks.delete(reject)
+        resolve(reply)
+      }
+      const reject = (): void => finish(revoked)
+      active.rejectCallbacks.add(reject)
+      // Calls are concurrent within the single active cell; every resolution
+      // is checked again after user code or cancellation may have finished.
+      void active.opts.hostRequestHandler!(data).then(reply => {
+        finish(this.active === active && !active.pendingForce ? { ...identity, ...reply } : revoked)
+      }, error => finish({ ...identity, ok: false, message: String(error) }))
+    })
+  }
+
+  private frame(frame: unknown): void {
+    if (!record(frame) || frame.id !== this.active?.id) return
+    const active = this.active!
+    if (frame.type === 'started') {
+      active.started = true
+      if (active.pendingForce) this.signal('SIGINT')
+    } else if (frame.type === 'stdout' || frame.type === 'stderr') {
+      if (typeof frame.data === 'string') active.streamText += frame.data
+    } else if (frame.type === 'display' || frame.type === 'result') {
+      // Rich displays remain explicit text when the runtime seam has no image field.
+      if (record(frame.bundle)) {
+        const text = frame.bundle['text/plain'] ?? frame.bundle['text/markdown'] ?? frame.bundle['text/html']
+        if (typeof text === 'string') active.streamText += `${text}\n`
+        else if (frame.bundle['application/json'] !== undefined) active.streamText += `${JSON.stringify(frame.bundle['application/json'])}\n`
+        else active.streamText += `[Python display: ${Object.keys(frame.bundle).join(', ')}]\n`
+      }
+    } else if (frame.type === 'error') {
+      active.error = { ename: String(frame.ename), evalue: String(frame.evalue),
+        traceback: Array.isArray(frame.traceback) ? frame.traceback.map(String) : [] }
+    } else if (frame.type === 'done') {
+      this.settle(active.pendingForce
+        ? { outcome: 'forced', failure: active.pendingForce, streamText: active.streamText }
+        : { outcome: 'completed', status: frame.status === 'ok' ? 'ok' : 'error', streamText: active.streamText,
+          ...active.error ? { cellError: active.error } : {} })
+    }
+  }
+
+  executeCell(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
+    const task = this.queue.then(() => {
+      if (!this.isRunning) return { outcome: 'forced' as const, failure: { kind: 'worker-exit' as const, message: 'Python is not running' }, streamText: '' }
+      return this.perform(code, opts)
+    })
+    this.queue = task.catch(() => undefined)
+    return task
+  }
+
+  private perform(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
+    if (opts.signal?.aborted) return Promise.resolve({ outcome: 'forced', failure: { kind: 'abort', message: String(opts.signal.reason) }, streamText: '' })
+    return new Promise(resolve => {
+      const active: Active = { id: randomUUID(), opts, streamText: '', started: false, resolve, rejectCallbacks: new Set() }
+      this.active = active
+      active.timeout = setTimeout(() => this.interrupt(active, { kind: 'timeout', message: `Python cell exceeded ${opts.timeoutMs}ms` }), opts.timeoutMs)
+      if (opts.signal) {
+        const signal = opts.signal
+        const abort = (): void => this.interrupt(active, { kind: 'abort', message: String(signal.reason) })
+        signal.addEventListener('abort', abort, { once: true })
+        active.detach = () => signal.removeEventListener('abort', abort)
+      }
+      this.child?.stdin?.write(JSON.stringify({ id: active.id, code, ...this.options.cwd ? { cwd: this.options.cwd } : {} }) + '\n')
+    })
+  }
+
+  private interrupt(active: Active, failure: Failure): void {
+    if (this.active !== active || active.pendingForce) return
+    active.pendingForce = failure
+    for (const revoke of [...active.rejectCallbacks]) revoke()
+    // Never signal an idle runner: defer until its started frame if necessary.
+    if (active.started) this.signal('SIGINT')
+    active.confirm = setTimeout(() => {
+      if (this.active === active && active.started && active.pendingForce) this.signal('SIGINT')
+    }, active.opts.interruptConfirmMs)
+    active.force = setTimeout(() => {
+      // A nonresponsive native operation cannot be left executing when the
+      // queue advances. Reap the entire owned group before returning.
+      void this.dispose()
+    }, active.opts.interruptGraceMs)
+  }
+
+  private settle(outcome: CellOutcome): void {
+    const active = this.active
+    if (!active) return
+    this.active = undefined
+    clearTimeout(active.timeout)
+    clearTimeout(active.force)
+    clearTimeout(active.confirm)
+    active.detach?.()
+    for (const revoke of [...active.rejectCallbacks]) revoke()
+    active.resolve(outcome)
+  }
+
+  private signal(signal: NodeJS.Signals): void {
+    try { this.child?.kill(signal) } catch { /* already exited */ }
+  }
+  private killGroup(): void {
+    const pid = this.child?.pid
+    if (pid === undefined) return
     try {
-      await transport.start()
-    } catch (error) {
-      this.cleanupResources()
-      this.state = 'idle'
-      throw error
-    }
-    // Loopback PUB/SUB propagation guard: the kernel publishes iopub only once
-    // the bridge's subscriber is connected.
-    await sleep(IOPUB_SUBSCRIBE_DELAY_MS)
-
+      if (process.platform !== 'win32') process.kill(-pid, 'SIGKILL')
+      else this.child?.kill('SIGKILL')
+    } catch { /* already reaped */ }
+  }
+  private died(message: string): void {
+    this.state = 'shutdown'
+    this.deathFailure ??= { kind: 'worker-exit', message }
+    this.killGroup() // leader exit must also retire owned descendants
+    // Exit is not close: callers settle only after close/drain in doDispose.
+    void this.dispose()
+  }
+
+  private async internal(code: string, sentinel: string): Promise<Record<string, unknown> | undefined> {
+    const result = await this.executeCell(code, { timeoutMs: this.options.snapshotTimeoutMs, interruptGraceMs: 1_000, interruptConfirmMs: this.options.interruptConfirmMs })
+    if (result.outcome !== 'completed' || result.status !== 'ok') return undefined
     try {
-      await this.probeReady()
-    } catch (error) {
-      this.cleanupResources()
-      this.state = 'idle'
-      throw error
-    }
-
-    const bootstrap = await this.executeCell(KERNEL_BOOTSTRAP, {
-      timeoutMs: this.options.startupTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (bootstrap.outcome !== 'completed' || bootstrap.status !== 'ok') {
-      const detail = bootstrap.outcome === 'completed' && bootstrap.cellError
-        ? `${bootstrap.cellError.ename}: ${bootstrap.cellError.evalue}`
-        : 'bootstrap cell failed'
-      this.cleanupResources()
-      this.state = 'idle'
-      throw new Error(`dashr kernel bootstrap failed: ${detail}`)
-    }
-
-    this.state = 'running'
-  }
-
-  private async waitForConnection(path: string): Promise<ConnectionInfo> {
-    const deadline = Date.now() + this.options.startupTimeoutMs
-    while (Date.now() < deadline) {
-      if (this.state === 'shutdown') {
-        throw new Error(`kernel exited before resolving ports. stderr:\n${this.stderrTail()}`)
-      }
-      const info = readResolvedConnection(path)
-      if (info) return info
-      await sleep(CONNECT_POLL_MS)
-    }
-    throw new Error(`kernel did not resolve connection ports within ${this.options.startupTimeoutMs}ms. stderr tail:\n${this.stderrTail()}`)
-  }
-
-  private async probeReady(): Promise<void> {
-    const transport = this.transport
-    if (!transport) throw new Error('kernel channels are not connected')
-    const msg = buildMessage('kernel_info_request', {}, this.session, this.options.username)
-    const requestMsgId = msg.header.msg_id
-    transport.send('shell', msg)
-
-    const reply = await transport.waitFor(
-      'shell',
-      incoming => incoming.header.msg_type === 'kernel_info_reply'
-        && (incoming.parent_header as { msg_id?: string }).msg_id === requestMsgId,
-      this.options.startupTimeoutMs,
-    )
-    if (reply) return
-    const bridgeTail = transport.stderrTail()
-    if (this.state === 'shutdown') {
-      throw new Error(`kernel exited during startup. kernel stderr:\n${this.stderrTail()}\nbridge stderr:\n${bridgeTail}`)
-    }
-    throw new Error(`kernel did not answer kernel_info_request within ${this.options.startupTimeoutMs}ms. kernel stderr:\n${this.stderrTail()}\nbridge stderr:\n${bridgeTail}`)
-  }
-
-  /**
-   * Execute one cell on the persistent kernel, serialized against all other
-   * executions. Resolves with the cell's outcome — never rejects for
-   * cell-level failures (program errors, timeouts, aborts, kernel death).
-   * @param code - complete cell source.
-   * @param opts - budgets, abort signal, and the host-request dispatcher.
-   */
-  async executeCell(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
-    const prev = this.executionQueue
-    let releaseQueue!: () => void
-    this.executionQueue = new Promise<void>(resolve => { releaseQueue = resolve })
-    await prev
-    try {
-      if (this.state === 'shutdown' || this.state === 'idle') {
-        return { outcome: 'forced', failure: { kind: 'worker-exit', message: 'kernel has been shut down' }, streamText: '' }
-      }
-      return await this.executeInner(code, opts)
-    } finally {
-      releaseQueue()
-    }
-  }
-
-  private executeInner(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
-    const transport = this.transport
-    if (!transport) {
-      return Promise.resolve({ outcome: 'forced', failure: { kind: 'worker-exit', message: 'kernel channels are not connected' }, streamText: '' })
-    }
-
-    const msg = buildMessage('execute_request', {
-      code,
-      silent: false,
-      store_history: false,
-      user_expressions: {},
-      allow_stdin: false,
-      stop_on_error: true,
-    }, this.session, this.options.username)
-
-    return new Promise<CellOutcome>(resolve => {
-      const execution: ActiveExecution = {
-        requestMsgId: msg.header.msg_id,
-        opts,
-        streamText: '',
-        status: 'ok',
-        settled: false,
-        resolve,
-      }
-      this.activeExec = execution
-
-      const settle = (outcome: CellOutcome): void => {
-        if (execution.settled) return
-        execution.settled = true
-        if (execution.forceTimer) clearTimeout(execution.forceTimer)
-        if (execution.timeoutTimer) clearTimeout(execution.timeoutTimer)
-        if (execution.alarmTimer) clearTimeout(execution.alarmTimer)
-        execution.detachSignal?.()
-        if (this.activeExec === execution) this.activeExec = undefined
-        resolve(outcome)
-      }
-
-      // Interrupt in two phases, then force-settle with the failure after the
-      // grace period. Phase one is the control-channel interrupt alone: it
-      // settles any cell that yields to the kernel event loop and is harmless
-      // to an idle kernel (measured: an idle ipykernel survives a bare
-      // interrupt_request). SIGALRM — the phase that CAN terminate the
-      // process when it lands outside cell execution — escalates only after
-      // the confirm window, and only when this execution still needs
-      // breaking. When an interrupt DOES break the cell, the resulting
-      // KeyboardInterrupt reports as the armed failure kind, not as a program
-      // exception.
-      const interruptAndForce = (failure: { kind: 'timeout' | 'abort', message: string }): void => {
-        // A stale interrupt (signal/timer fired after this execution left the
-        // active slot) must never reach the kernel: even phase one has no
-        // business hitting a cell that is no longer active.
-        if (this.activeExec !== execution) return
-        if (execution.pendingForce === undefined) execution.pendingForce = failure
-        void this.sendInterrupt(execution)
-        execution.forceTimer = setTimeout(() => {
-          settle({ outcome: 'forced', failure, streamText: execution.streamText })
-        }, opts.interruptGraceMs)
-        execution.forceTimer.unref?.()
-      }
-
-      const onAbort = (): void => {
-        interruptAndForce({ kind: 'abort', message: String(opts.signal?.reason) })
-      }
-
-      execution.timeoutTimer = setTimeout(() => {
-        interruptAndForce({ kind: 'timeout', message: `cell exceeded ${opts.timeoutMs}ms wall budget` })
-      }, opts.timeoutMs)
-      execution.timeoutTimer.unref?.()
-
-      opts.signal?.addEventListener('abort', onAbort, { once: true })
-      // Detach on EVERY settle path (the `settle` closure here,
-      // `settleCompleted`, and `forceSettleActive`): a listener surviving a
-      // completed cell would fire interruptAndForce at an IDLE kernel on the
-      // caller's next abort, and SIGALRM-ing an idle kernel kills it.
-      execution.detachSignal = () => opts.signal?.removeEventListener('abort', onAbort)
-      if (opts.signal?.aborted) onAbort()
-
-      try {
-        transport.send('shell', msg)
-      } catch {
-        settle({ outcome: 'forced', failure: { kind: 'worker-exit', message: 'shell channel send failed' }, streamText: execution.streamText })
-      }
-    })
-  }
-
-  /**
-   * Route one relayed message. Only iopub drives executions and comms; shell
-   * replies serve the startup probe (via `waitFor`), and control is inbound
-   * for host replies.
-   */
-  private handleTransportMessage(channel: TransportChannel, incoming: JupyterMessage): void {
-    if (channel !== 'iopub') return
-    const msgType = incoming.header.msg_type
-    if (msgType === 'comm_open' || msgType === 'comm_msg' || msgType === 'comm_close') {
-      this.handleCommMessage(incoming)
+      const envelope: unknown = JSON.parse(extractStream(result.streamText, sentinel).envelope ?? '')
+      return record(envelope) ? envelope : undefined
+    } catch { return undefined }
+  }
+  async queryVar(name: string | null): Promise<QueryVarOutcome> {
+    const sentinel = `__better_query_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildQueryVarCell(name, sentinel), sentinel)
+    if (reply?.kind === 'names' && Array.isArray(reply.names)) return { kind: 'names', names: reply.names.filter((name): name is string => typeof name === 'string') }
+    if (reply?.kind === 'missing') return { kind: 'missing' }
+    if ((reply?.kind === 'json' || reply?.kind === 'repr') && typeof reply.text === 'string') return { kind: reply.kind, text: reply.text }
+    return { kind: 'failed', reason: 'Python variable query failed' }
+  }
+  async setVar(name: string, valueJson: string): Promise<SetVarOutcome> {
+    const sentinel = `__better_set_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildSetVarCell(name, valueJson, sentinel), sentinel)
+    return reply?.ok === true ? { kind: 'ok' } : { kind: 'failed', reason: 'Python variable assignment failed' }
+  }
+  async snapshotState(payloadPath: string, manifestPath: string, spec: SnapshotSpec): Promise<SnapshotOutcome> {
+    const sentinel = `__better_save_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildSnapshotCell(payloadPath, manifestPath, spec, sentinel), sentinel)
+    if (reply?.kind === 'ok' && Array.isArray(reply.names) && typeof reply.sizeBytes === 'number' && typeof reply.turn === 'number' && record(reply.omitted)) {
+      return { kind: 'ok', sizeBytes: reply.sizeBytes, names: reply.names as string[], omitted: reply.omitted as Record<string, string>, turn: reply.turn, ...typeof reply.warning === 'string' ? { warning: reply.warning } : {} }
+    }
+    if (reply?.kind === 'skipped') return { kind: 'skipped', reason: String(reply.reason), capBytes: spec.sizeCapBytes }
+    return { kind: 'failed', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint helper timed out, failed, or exited; commit status could not be confirmed' }
+  }
+  async restoreState(payloadPath: string, manifestPath: string, bindings: string[] = []): Promise<RestoreStateOutcome> {
+    const sentinel = `__better_restore_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildRestoreCell(payloadPath, manifestPath, sentinel, bindings), sentinel)
+    if (reply?.kind === 'restored' && typeof reply.count === 'number' && typeof reply.turn === 'number' && record(reply.omitted)) {
+      return { kind: 'restored', count: reply.count, turn: reply.turn, omitted: reply.omitted as Record<string, string> }
+    }
+    return { kind: 'degraded', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint restore helper failed or timed out' }
+  }
+
+  dispose(): Promise<void> {
+    this.disposePromise ??= this.doDispose()
+    return this.disposePromise
+  }
+  private async doDispose(): Promise<void> {
+    this.state = 'shutdown'
+    const child = this.child
+    if (!child) {
+      this.callbackServer?.closeAllConnections()
+      this.callbackServer?.close()
       return
     }
-    this.handleExecutionMessage(incoming)
-  }
-
-  private forceSettleActive(failure: { kind: 'timeout' | 'abort' | 'worker-exit', message: string }): void {
-    const execution = this.activeExec
-    if (!execution || execution.settled) return
-    execution.settled = true
-    if (execution.forceTimer) clearTimeout(execution.forceTimer)
-    if (execution.timeoutTimer) clearTimeout(execution.timeoutTimer)
-    if (execution.alarmTimer) clearTimeout(execution.alarmTimer)
-    execution.detachSignal?.()
-    this.activeExec = undefined
-    execution.resolve({ outcome: 'forced', failure, streamText: execution.streamText })
-  }
-
-  private handleExecutionMessage(incoming: JupyterMessage): void {
-    const execution = this.activeExec
-    if (!execution || execution.settled) return
-    if ((incoming.parent_header as { msg_id?: string }).msg_id !== execution.requestMsgId) return
-    const msgType = incoming.header.msg_type
-    if (msgType === 'stream') {
-      const content = incoming.content as { text?: string }
-      if (typeof content.text === 'string') execution.streamText += content.text
-    } else if (msgType === 'error') {
-      const content = incoming.content as { ename?: string, evalue?: string, traceback?: string[] }
-      execution.cellError = {
-        ename: typeof content.ename === 'string' ? content.ename : 'Error',
-        evalue: typeof content.evalue === 'string' ? content.evalue : '',
-        traceback: Array.isArray(content.traceback) ? content.traceback : [],
-      }
-      execution.status = 'error'
-    } else if (msgType === 'status') {
-      const content = incoming.content as { execution_state?: string }
-      if (content.execution_state === 'idle') {
-        this.settleCompleted(execution)
-      }
-    }
-  }
-
-  private settleCompleted(execution: ActiveExecution): void {
-    if (execution.settled) return
-    execution.settled = true
-    if (execution.forceTimer) clearTimeout(execution.forceTimer)
-    if (execution.timeoutTimer) clearTimeout(execution.timeoutTimer)
-    if (execution.alarmTimer) clearTimeout(execution.alarmTimer)
-    execution.detachSignal?.()
-    if (this.activeExec === execution) this.activeExec = undefined
-    if (execution.pendingForce !== undefined) {
-      execution.resolve({ outcome: 'forced', failure: execution.pendingForce, streamText: execution.streamText })
-      return
-    }
-    execution.resolve({
-      outcome: 'completed',
-      status: execution.status,
-      streamText: execution.streamText,
-      ...execution.cellError ? { cellError: execution.cellError } : {},
-    })
-  }
-
-  private handleCommMessage(incoming: JupyterMessage): void {
-    const content = incoming.content
-    const commId = content.comm_id
-    if (typeof commId !== 'string') return
-    const msgType = incoming.header.msg_type
-
-    if (msgType === 'comm_close') {
-      this.commTargets.delete(commId)
-      this.servedComms.delete(commId)
-      return
-    }
-    if (msgType === 'comm_open') {
-      // Registration only: the shim opens the comm empty and carries its one
-      // request as the first comm_msg.
-      const targetName = content.target_name
-      if (typeof targetName === 'string') this.commTargets.set(commId, targetName)
-      return
-    }
-    if (msgType === 'comm_msg' && this.commTargets.get(commId) === HOST_COMM_TARGET) {
-      this.serveHostRequest(commId, content.data)
-    }
-  }
-
-  private serveHostRequest(commId: string, data: unknown): void {
-    // One request per comm: the kernel-side shim closes the comm after its
-    // reply, and duplicate delivery must not double-dispatch.
-    if (this.servedComms.has(commId)) return
-    this.servedComms.add(commId)
-
-    const handler = this.activeExec?.opts.hostRequestHandler
-    if (!handler) {
-      void this.replyComm(commId, { status: 'error', error: 'no host request handler is active' }).catch(() => undefined)
-      return
-    }
-    if (!isRecord(data)) {
-      void this.replyComm(commId, { status: 'error', error: 'host request payload must be an object' }).catch(() => undefined)
-      return
-    }
-    void (async () => {
-      try {
-        const outcome = await handler(data)
-        if (outcome.ok) {
-          await this.replyComm(commId, { status: 'ok', result: outcome.result })
-        } else {
-          await this.replyComm(commId, { status: 'error', error: outcome.message })
-        }
-      } catch (error: unknown) {
-        const message = error instanceof Error ? error.message : String(error)
-        await this.replyComm(commId, { status: 'error', error: message }).catch(() => undefined)
-      }
-    })().catch(() => undefined)
-  }
-
-  private async replyComm(commId: string, data: Record<string, unknown>): Promise<void> {
-    const transport = this.transport
-    if (!transport) throw new Error('kernel channels are not connected')
-    transport.send('control', buildMessage('comm_msg', { comm_id: commId, data }, this.session, this.options.username))
-  }
-
-  /**
-   * Phase one NOW, phase two on a timer: send the control-channel interrupt,
-   * then — after the confirm window, and only if the execution has still not
-   * settled — escalate to SIGALRM. The zmq interrupt only lands when the cell
-   * yields to the kernel event loop; a busy sync cell ('while True: pass')
-   * never does, which is why the escalation exists at all. Sending both
-   * channels in the same tick (the M1 design) made SIGALRM the FIRST signal
-   * an idle-or-booting kernel saw on timeout/abort: its handler raised
-   * KeyboardInterrupt at the top level and the process exited cleanly — a
-   * deterministic kill (10/10 same-tick aborts, 8/10 at +1-2ms, 40/40 during
-   * cold boot; dev/m2a-report.md §5.1). Two-phase escalation plus the
-   * kernel-side busy guard closes that window while keeping the hard-abort
-   * contract: a busy loop still breaks, one confirm window later.
-   */
-  private async sendInterrupt(execution: ActiveExecution): Promise<void> {
-    const transport = this.transport
-    if (!transport) return
-    try {
-      transport.interrupt()
-    } catch {
-      // Channels closed mid-interrupt (kernel death owns the settle).
-    }
-    execution.alarmTimer = setTimeout(() => {
-      // The execution settled inside the window — the zmq interrupt was
-      // enough (an awaiting cell, or one that finished) — no signal needed.
-      if (execution.settled) return
-      if (this.kernel?.exitCode === null) {
-        try { this.kernel.kill('SIGALRM') } catch { /* already gone */ }
-      }
-    }, execution.opts.interruptConfirmMs)
-    execution.alarmTimer.unref?.()
-  }
-
-  /**
-   * Snapshot the user namespace via an internal dill cell. Requires `dill` in
-   * the kernel environment. The cell reports its outcome through a nonce
-   * envelope (skipped-for-size vs written); a failed/skipped dump NEVER
-   * replaces a previous good snapshot on disk.
-   * @param payloadPath - dill payload destination.
-   * @param manifestPath - JSON manifest destination (turn, names, python
-   *   version, venv path, skills, size).
-   * @param spec - turn counter, skills list, and the size cap.
-   */
-  async snapshotState(payloadPath: string, manifestPath: string, spec: SnapshotSpec): Promise<SnapshotOutcome> {
-    if (!this.isRunning) return { kind: 'failed', reason: 'kernel is not running' }
-    const sentinel = `__dashr_snapshot_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildSnapshotCell(payloadPath, manifestPath, spec, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'failed', reason: 'snapshot cell failed' }
-    }
-    return this.parseSnapshotEnvelope(outcome.streamText, sentinel)
-  }
-
-  /** Parse one snapshot cell's nonce envelope into its outcome. */
-  private parseSnapshotEnvelope(streamText: string, sentinel: string): SnapshotOutcome {
-    const capture = extractStream(streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'failed', reason: 'snapshot cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'failed', reason: 'snapshot envelope was not valid JSON' }
-    }
-    if (typeof envelope !== 'object' || envelope === null) return { kind: 'failed', reason: 'snapshot envelope was not an object' }
-    const record = envelope as { ok?: unknown, skipped?: unknown, reason?: unknown, sizeBytes?: unknown, names?: unknown, estimateBytes?: unknown, capBytes?: unknown }
-    if (record.ok === true) {
-      return {
-        kind: 'ok',
-        sizeBytes: typeof record.sizeBytes === 'number' ? record.sizeBytes : 0,
-        names: typeof record.names === 'number' ? record.names : 0,
-      }
-    }
-    if (record.skipped === true) {
-      return {
-        kind: 'skipped',
-        reason: typeof record.reason === 'string' ? record.reason : 'size cap',
-        ...typeof record.estimateBytes === 'number' ? { estimateBytes: record.estimateBytes } : {},
-        ...typeof record.sizeBytes === 'number' ? { sizeBytes: record.sizeBytes } : {},
-        capBytes: typeof record.capBytes === 'number' ? record.capBytes : 0,
-      }
-    }
-    return { kind: 'failed', reason: typeof record.reason === 'string' ? record.reason : 'snapshot failed' }
-  }
-
-  /**
-   * Restore a dill snapshot into the user namespace via an internal cell. The
-   * kernel validates the manifest (python version, interpreter identity,
-   * skills) and reports restored vs degraded through a nonce envelope; a
-   * degraded restore leaves the namespace empty.
-   * @param payloadPath - dill payload source.
-   * @param manifestPath - JSON manifest source.
-   */
-  async restoreState(payloadPath: string, manifestPath: string): Promise<RestoreStateOutcome> {
-    if (!this.isRunning) return { kind: 'degraded', reason: 'kernel is not running' }
-    const sentinel = `__dashr_restore_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildRestoreCell(payloadPath, manifestPath, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'degraded', reason: 'restore cell failed' }
-    }
-    const capture = extractStream(outcome.streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'degraded', reason: 'restore cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'degraded', reason: 'restore envelope was not valid JSON' }
-    }
-    if (typeof envelope !== 'object' || envelope === null) return { kind: 'degraded', reason: 'restore envelope was not an object' }
-    const record = envelope as { ok?: unknown, restored?: unknown, reason?: unknown }
-    if (record.ok === true) {
-      return { kind: 'restored', count: typeof record.restored === 'number' ? record.restored : 0 }
-    }
-    return { kind: 'degraded', reason: typeof record.reason === 'string' ? record.reason : 'snapshot not replayable' }
-  }
-
-  /**
-   * Read one user-namespace variable by name (or list the namespace's user
-   * names when `name` is `null`) via an internal cell. JSON-serializable
-   * values cross as `kind: 'json'` text; anything else falls back to `repr`
-   * text (`kind: 'repr'`) so a non-JSON variable is still readable. A missing
-   * name reports `kind: 'missing'` rather than failing the cell.
-   * @param name - the exact variable name, or `null` to list namespace names.
-   */
-  async queryVar(name: string | null): Promise<QueryVarOutcome> {
-    if (!this.isRunning) return { kind: 'failed', reason: 'kernel is not running' }
-    const sentinel = `__dashr_query_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildQueryVarCell(name, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'failed', reason: 'query cell failed' }
-    }
-    const capture = extractStream(outcome.streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'failed', reason: 'query cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'failed', reason: 'query envelope was not valid JSON' }
-    }
-    if (!isRecord(envelope)) return { kind: 'failed', reason: 'query envelope was not an object' }
-    if (envelope.ok !== true) {
-      return { kind: 'failed', reason: typeof envelope.reason === 'string' ? envelope.reason : 'query failed' }
-    }
-    const kind = envelope.kind
-    if (kind === 'names') {
-      const names = Array.isArray(envelope.names) ? envelope.names.filter((name): name is string => typeof name === 'string') : []
-      return { kind: 'names', names }
-    }
-    if (kind === 'missing') return { kind: 'missing' }
-    if (kind === 'json' || kind === 'repr') {
-      return typeof envelope.text === 'string'
-        ? { kind, text: envelope.text }
-        : { kind: 'failed', reason: 'query envelope carried no text' }
-    }
-    return { kind: 'failed', reason: `unknown query kind ${JSON.stringify(kind)}` }
-  }
-
-  /**
-   * Assign one pre-serialized JSON value into the user namespace under
-   * `name` via an internal cell. The host already validated the name and the
-   * value; the cell only decodes and binds. Uses the same busy guard and
-   * internal-cell budget as the snapshot cells.
-   * @param name - the validated identifier to assign under.
-   * @param valueJson - the lossless-JSON text to decode and bind.
-   */
-  async setVar(name: string, valueJson: string): Promise<SetVarOutcome> {
-    if (!this.isRunning) return { kind: 'failed', reason: 'kernel is not running' }
-    const sentinel = `__dashr_set_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildSetVarCell(name, valueJson, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'failed', reason: 'set cell failed' }
-    }
-    const capture = extractStream(outcome.streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'failed', reason: 'set cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'failed', reason: 'set envelope was not valid JSON' }
-    }
-    if (!isRecord(envelope) || envelope.ok !== true) {
-      return { kind: 'failed', reason: isRecord(envelope) && typeof envelope.reason === 'string' ? envelope.reason : 'set failed' }
-    }
-    return { kind: 'ok' }
-  }
-
-  private onKernelDeath(): void {
-    this.state = 'shutdown'
-    this.forceSettleActive({ kind: 'worker-exit', message: `kernel process died. stderr tail:\n${this.stderrTail()}` })
-    this.cleanupResources()
-  }
-
-  private cleanupResources(): void {
-    void this.transport?.dispose()
-    this.transport = undefined
-    this.connection = undefined
-    try {
-      this.kernel?.kill('SIGKILL')
-    } catch {
-      // Kernel already exited.
-    }
-    this.kernel = undefined
-    if (this.tempDir) {
-      try {
-        rmSync(this.tempDir, { recursive: true, force: true })
-      } catch {
-        // Leave the temp dir for OS tmp cleanup.
-      }
-    }
-    this.tempDir = undefined
-  }
-
-  /** Graceful teardown: shutdown_request, then SIGKILL after the dispose budget. */
-  async dispose(): Promise<void> {
-    if (this.state === 'shutdown') {
-      this.cleanupResources()
-      return
-    }
-    this.state = 'shutdown'
-    try {
-      if (this.transport) {
-        this.transport.send('control', buildMessage('shutdown_request', { restart: false }, this.session, this.options.username))
-        await sleep(SHUTDOWN_DRAIN_MS)
-      }
-    } catch {
-      // Fall through to the kill path.
-    }
-    const kernel = this.kernel
-    this.cleanupResources()
-    if (kernel && kernel.exitCode === null && kernel.signalCode === null) {
-      await new Promise<void>(resolve => {
-        const timer = setTimeout(() => {
-          kernel.removeListener('exit', onExit)
-          try {
-            kernel.kill('SIGKILL')
-          } catch {
-            // Already gone.
-          }
-          resolve()
-        }, this.options.disposeTimeoutMs)
-        timer.unref?.()
-        const onExit = (): void => {
-          clearTimeout(timer)
-          resolve()
-        }
-        kernel.once('exit', onExit)
-      })
-    }
-  }
-}
+    const active = this.active
+    // In-flight disposal or cancellation reaps immediately; idle shutdown
+    // first asks the original runner to exit and bounds its drain.
+    if (!active && child.exitCode === null && child.signalCode === null) {
+      child.stdin?.end(JSON.stringify({ type: 'exit' }) + '\n')
+      await this.waitClose(Math.min(200, this.options.disposeTimeoutMs))
+    }
+    this.killGroup()
+    await this.waitClose(this.options.disposeTimeoutMs)
+    if (this.active) this.settle({ outcome: 'forced', failure: this.active.pendingForce ?? this.deathFailure ?? { kind: 'worker-exit', message: 'Python disposed during cell execution' }, streamText: this.active.streamText })
+    for (const reader of this.ownedReaders) reader.close()
+    for (const stream of child.stdio) (stream as Readable | null)?.destroy()
+    this.callbackServer?.closeAllConnections()
+    this.callbackServer?.close()
+    this.child = undefined
+  }
+  private async waitClose(ms: number): Promise<void> {
+    if (!this.closePromise) return
+    await new Promise<void>(resolve => {
+      const timer = setTimeout(resolve, ms)
+      void this.closePromise!.then(() => { clearTimeout(timer); resolve() })
+    })
+  }
+}
```

```diff
--- baseline/better-dsh/src/omp-python/better_snapshot.py
+++ current/better-dsh/src/omp-python/better_snapshot.py
@@ -0,0 +1,391 @@
+"""Best-effort checkpoints for the owned OMP namespace; dill 0.4.1 adapter.
+
+No cell history is stored/replayed. Pickling user objects is not a sandbox:
+reducers may execute arbitrary code. Host deadlines bound helper execution.
+"""
+import _thread
+import asyncio
+import dis
+import functools
+import hashlib
+import io
+import json
+import os
+import platform
+import re
+import socket
+import sqlite3
+import subprocess
+import sys
+import threading
+import time
+import types
+import uuid
+
+# Select the unchanged packaged implementation before ANY user cell can import dill.
+_VENDOR = os.path.join(os.path.dirname(__file__), 'vendor')
+sys.path.insert(0, _VENDOR)
+import dill
+if dill.__version__ != '0.4.1' or os.path.realpath(dill.__file__) != os.path.realpath(os.path.join(_VENDOR, 'dill', '__init__.py')):
+    raise RuntimeError('Better requires its packaged dill 0.4.1')
+
+_DIRECTORY = None
+_CAP = None
+_TIMEOUT = 30.0
+_FORMAT = 2
+_RESOURCES = (io.IOBase, _thread.LockType, type(threading.RLock()), socket.socket,
+    subprocess.Popen, threading.Thread, sqlite3.Connection, sqlite3.Cursor,
+    asyncio.Future, asyncio.AbstractEventLoop, types.GeneratorType,
+    types.CoroutineType, types.AsyncGeneratorType)
+_PRIMITIVES = (str, bytes, int, float, bool, type(None))
+
+
+class UnsupportedResource(Exception):
+    pass
+
+
+class SizeCap(Exception):
+    pass
+
+
+class NamespaceProxy:
+    pass
+
+
+def _proxy(ns):
+    proxy = NamespaceProxy()
+    proxy.__dict__ = ns
+    return proxy
+
+
+def configure(directory, cap, timeout_ms):
+    global _DIRECTORY, _CAP, _TIMEOUT
+    _DIRECTORY = os.path.abspath(directory) if directory else None
+    _CAP = cap
+    _TIMEOUT = timeout_ms / 1000.0 * 0.9
+
+
+def clear():
+    """Delete only our fixed manifest and generation files, including orphans."""
+    if _DIRECTORY and os.path.islink(_DIRECTORY):
+        raise ValueError('checkpoint directory cannot be a symlink')
+    if not _DIRECTORY or not os.path.isdir(_DIRECTORY):
+        return
+    for name in os.listdir(_DIRECTORY):
+        if name == 'manifest.json' or re.fullmatch(r'(state-[0-9a-f]{32}\.dill|\.checkpoint-[0-9a-f]{32}\.tmp)', name):
+            os.unlink(os.path.join(_DIRECTORY, name))
+
+
+def _paths(payload_path, manifest_path):
+    if not _DIRECTORY or os.path.abspath(manifest_path) != os.path.join(_DIRECTORY, 'manifest.json') or os.path.abspath(payload_path) != os.path.join(_DIRECTORY, 'state.dill'):
+        raise ValueError('checkpoint paths are not the configured session directory')
+    os.makedirs(_DIRECTORY, mode=0o700, exist_ok=True)
+    if os.path.islink(_DIRECTORY):
+        raise ValueError('checkpoint directory cannot be a symlink')
+    if os.path.islink(manifest_path):
+        raise ValueError('checkpoint manifest cannot be a symlink')
+    os.chmod(_DIRECTORY, 0o700)
+
+
+def _environment():
+    return dict(pythonVersion=platform.python_version(), implementation=platform.python_implementation(),
+        interpreter=os.path.realpath(sys.executable), venvPath=sys.prefix,
+        environmentHash=hashlib.sha256(json.dumps([sys.prefix, sys.base_prefix, sys.path], sort_keys=True).encode()).hexdigest(),
+        dillVersion=dill.__version__, protocol=4, skills=[])
+
+
+def _guard(ns):
+    import better_support
+    owned = [sys.modules['__main__'], sys.modules['better_support'], sys.modules[__name__]]
+    owned.extend(better_support.owned_objects())
+    denied = {id(value) for value in owned if not isinstance(value, _PRIMITIVES)}
+    def guard(value):
+        if id(value) in denied or (isinstance(value, (types.FunctionType, type)) and getattr(value, '__module__', None) in ('better_support', 'better_snapshot')) or type(value).__module__ == 'better_support':
+            raise UnsupportedResource('captured Better/runner binding')
+        if isinstance(value, _RESOURCES):
+            raise UnsupportedResource('unsupported live resource ' + type(value).__name__)
+        return None
+    return guard
+
+
+class CappedBuffer(io.BytesIO):
+    def __init__(self, cap):
+        super().__init__()
+        self.cap = cap
+    def write(self, value):
+        if self.tell() + len(value) > self.cap:
+            raise SizeCap('serialized graph exceeds snapshotSizeCapBytes')
+        return super().write(value)
+
+
+def _encode(ns, values, cap, guard):
+    output = CappedBuffer(cap)
+    # Exact Pickler: subclassing disables pinned dill's main-module logic.
+    pickler = dill.Pickler(output, protocol=4, recurse=False, byref=False)
+    pickler._main = _proxy(ns)
+    pickler._original_main = pickler._main
+    pickler._main_modified = True
+    pickler.persistent_id = guard
+    pickler.dump(values)
+    return output.getvalue()
+
+
+def _decode(ns, payload):
+    unpickler = dill.Unpickler(io.BytesIO(payload))
+    unpickler._main = _proxy(ns)
+    unpickler._ignore = True
+    return unpickler.load()
+
+
+def _dependencies(root, ns):
+    """Bounded static global scan; dynamic eval/globals lookups remain best effort."""
+    found, seen = set(), set()
+    def walk(value):
+        if id(value) in seen or isinstance(value, _PRIMITIVES):
+            return
+        seen.add(id(value))
+        if len(seen) > 10000:
+            raise UnsupportedResource('dependency graph exceeds inspection budget')
+        if isinstance(value, types.FunctionType):
+            if value.__globals__ is ns:
+                def code_names(code):
+                    for op in dis.get_instructions(code):
+                        if op.opname in ('LOAD_GLOBAL', 'LOAD_NAME'):
+                            found.add(op.argval)
+                    for item in code.co_consts:
+                        if isinstance(item, types.CodeType): code_names(item)
+                code_names(value.__code__)
+            walk(value.__defaults__)
+            walk(value.__kwdefaults__)
+            for cell in value.__closure__ or ():
+                try: walk(cell.cell_contents)
+                except ValueError: pass
+        elif isinstance(value, functools.partial):
+            walk(value.func); walk(value.args); walk(value.keywords); walk(vars(value))
+        elif isinstance(value, (staticmethod, classmethod)):
+            walk(value.__func__)
+        elif isinstance(value, property):
+            walk(value.fget); walk(value.fset); walk(value.fdel)
+        elif isinstance(value, types.MethodType):
+            walk(value.__func__); walk(value.__self__)
+        elif isinstance(value, dict):
+            for key, item in value.items(): walk(key); walk(item)
+        elif isinstance(value, (tuple, list, set, frozenset)):
+            for item in value: walk(item)
+        elif isinstance(value, type):
+            if value.__module__ == ns.get('__name__'):
+                for item in vars(value).values(): walk(item)
+                for base in value.__bases__: walk(base)
+        elif not isinstance(value, types.ModuleType) and type(value).__module__ == ns.get('__name__'):
+            walk(type(value))
+            if hasattr(value, '__dict__'): walk(vars(value))
+            # Scan descriptors across the MRO, including inherited/mangled slots.
+            for owner in type(value).__mro__:
+                for descriptor in vars(owner).values():
+                    if isinstance(descriptor, types.MemberDescriptorType):
+                        try: walk(descriptor.__get__(value, type(value)))
+                        except AttributeError: pass  # uninitialized slot
+    walk(root)
+    return found
+
+
+def _write_new(path, data):
+    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
+    with os.fdopen(fd, 'wb') as output:
+        output.write(data)
+        output.flush()
+        os.fsync(output.fileno())
+
+
+def _emit(sentinel, result):
+    print(sentinel + json.dumps(result, ensure_ascii=True))
+
+
+def _retained_payloads(manifest_path):
+    try:
+        with open(manifest_path, encoding='utf-8') as source:
+            manifest = json.load(source)
+    except (FileNotFoundError, ValueError):
+        return set(), None
+    if not isinstance(manifest, dict):
+        return set(), None
+    current = manifest.get('payload')
+    names = (current, manifest.get('previousPayload'))
+    retained = {name for name in names if isinstance(name, str) and re.fullmatch(r'state-[0-9a-f]{32}\.dill', name)}
+    return retained, current if isinstance(current, str) and current in retained else None
+
+
+def _scavenge(retained):
+    for name in os.listdir(_DIRECTORY):
+        if name not in retained and re.fullmatch(r'(state-[0-9a-f]{32}\.dill|\.checkpoint-[0-9a-f]{32}\.tmp)', name):
+            os.unlink(os.path.join(_DIRECTORY, name))
+
+
+def save(ns, payload_path, manifest_path, spec_json, sentinel):
+    attempt_paths, committed, result = [], False, None
+    payload_name, manifest, retained = None, None, set()
+    try:
+        _paths(payload_path, manifest_path)
+        retained, previous = _retained_payloads(manifest_path)
+        _scavenge(retained)  # collect killed-writer artifacts even if this attempt fails
+        deadline = time.monotonic() + _TIMEOUT
+        def check_deadline():
+            if time.monotonic() >= deadline:
+                raise TimeoutError('checkpoint deadline exceeded; previous generation retained')
+        spec = json.loads(spec_json)
+        cap = min(spec['sizeCapBytes'], _CAP)
+        import better_support
+        candidates = better_support.user_namespace(ns)
+        guard = _guard(ns)
+        kept, omitted, dependencies = {}, {}, {}
+        for name, value in candidates.items():
+            check_deadline()
+            try:
+                _encode(ns, {name: value}, cap, guard)
+                dependencies[name] = _dependencies(value, ns)
+                kept[name] = value
+            except SizeCap:
+                raise
+            except Exception as error:
+                omitted[name] = type(error).__name__ + ': ' + str(error)
+        changed = True
+        while changed:
+            changed = False
+            for name in list(kept):
+                missing = dependencies[name].intersection(omitted)
+                if missing:
+                    omitted[name] = 'depends on omitted globals: ' + ', '.join(sorted(missing))
+                    del kept[name]
+                    changed = True
+        check_deadline()
+        payload = _encode(ns, kept, cap, guard)
+        # Verify the FINAL shared graph, never independently reconstruct values.
+        trial_ns = dict(ns)
+        trial = _decode(trial_ns, payload)
+        if not isinstance(trial, dict) or set(trial) != set(kept):
+            raise ValueError('final graph round-trip changed admitted names')
+        trial_ns.update(trial)
+        groups = {}
+        for name, value in kept.items():
+            if id(value) in groups and trial[name] is not trial[groups[id(value)]]:
+                raise ValueError('final graph round-trip lost shared root identity')
+            groups[id(value)] = name
+        token = uuid.uuid4().hex
+        payload_name = 'state-' + token + '.dill'
+        manifest = dict(_environment(), snapshotFormat=_FORMAT, turn=spec['turn'],
+            payload=payload_name, previousPayload=previous, sizeBytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
+            names=sorted(kept), dependencies={name: sorted(dependencies[name]) for name in kept},
+            bindingNames=sorted(better_support.injected_names()), omitted=omitted, coverage='partial' if omitted else 'best-effort',
+            skipped=False, limitations=['Dynamic globals/eval and arbitrary extension resources cannot be exhaustively inspected.'])
+        payload_file = os.path.join(_DIRECTORY, payload_name)
+        attempt_paths.append(payload_file)
+        _write_new(payload_file, payload)
+        temp = os.path.join(_DIRECTORY, '.checkpoint-' + token + '.tmp')
+        attempt_paths.append(temp)
+        _write_new(temp, json.dumps(manifest, sort_keys=True).encode())
+        # Sole commit point. Cleanup must never remove this payload afterwards.
+        check_deadline()
+        os.replace(temp, manifest_path)
+        committed = True
+        result = dict(kind='ok', sizeBytes=len(payload), names=manifest['names'], omitted=omitted, turn=spec['turn'])
+        warnings = []
+        if os.name == 'posix':
+            try:
+                fd = os.open(_DIRECTORY, os.O_RDONLY)
+                try: os.fsync(fd)
+                finally: os.close(fd)
+            except OSError as error:
+                warnings.append('directory fsync failed: ' + str(error))
+        try:
+            _scavenge({payload_name, previous})
+        except OSError as error:
+            warnings.append('stale artifact cleanup failed: ' + str(error))
+        if warnings:
+            result['warning'] = 'checkpoint committed; ' + '; '.join(warnings)
+    except SizeCap as error:
+        result = dict(kind='skipped', reason=str(error), capBytes=_CAP)
+    except Exception as error:
+        reason = type(error).__name__ + ': ' + str(error)
+        if payload_name is not None and not committed:
+            try:
+                _, pointed = _retained_payloads(manifest_path)
+                committed = pointed == payload_name
+            except OSError:
+                pass
+        if committed:
+            result = dict(kind='ok', sizeBytes=len(payload), names=manifest['names'], omitted=omitted, turn=spec['turn'])
+            result['warning'] = 'checkpoint committed; postcommit finalization failed: ' + reason
+        else:
+            result = dict(kind='failed', reason=reason)
+    finally:
+        if not committed and attempt_paths:
+            # A signal/error can arrive immediately after replace, before the
+            # local flag changes. The pointer is authoritative for deletion.
+            try:
+                latest, _ = _retained_payloads(manifest_path)
+                retained.update(latest)
+            except OSError:
+                # Cannot prove non-commit: leave recognized artifacts for the
+                # next save's pre-write scavenger rather than risk data loss.
+                retained.update(os.path.basename(path) for path in attempt_paths)
+            for path in attempt_paths:
+                if os.path.basename(path) in retained:
+                    continue
+                try: os.unlink(path)
+                except FileNotFoundError: pass
+                except OSError as error:
+                    if result is not None:
+                        result['reason'] += '; uncommitted artifact cleanup failed: ' + str(error)
+    if result is not None:
+        _emit(sentinel, result)
+
+
+def restore(ns, payload_path, manifest_path, sentinel, bindings_json):
+    try:
+        _paths(payload_path, manifest_path)
+        if os.path.getsize(manifest_path) > 1048576:
+            raise ValueError('manifest exceeds metadata cap')
+        with open(manifest_path, encoding='utf-8') as source:
+            manifest = json.load(source)
+        if not isinstance(manifest, dict) or manifest.get('snapshotFormat') != _FORMAT:
+            raise ValueError('unsupported snapshot format')
+        for key, value in _environment().items():
+            if manifest.get(key) != value: raise ValueError('checkpoint environment mismatch: ' + key)
+        name = manifest.get('payload', '')
+        if not isinstance(name, str) or not re.fullmatch(r'state-[0-9a-f]{32}\.dill', name):
+            raise ValueError('invalid owned payload name')
+        names = manifest.get('names')
+        import better_support
+        if not isinstance(names, list) or any(not isinstance(n, str) or n.startswith('__omp_') or n in ('__name__', '__builtins__', '__doc__') for n in names):
+            raise ValueError('invalid checkpoint namespace names')
+        turn = manifest.get('turn')
+        if not isinstance(turn, int) or isinstance(turn, bool) or turn < 0:
+            raise ValueError('invalid checkpoint turn')
+        path = os.path.join(_DIRECTORY, name)
+        size = os.path.getsize(path)
+        if os.path.islink(path) or size != manifest.get('sizeBytes') or size > _CAP:
+            raise ValueError('payload size/cap/path validation failed')
+        with open(path, 'rb') as source: payload = source.read(_CAP + 1)
+        if hashlib.sha256(payload).hexdigest() != manifest.get('sha256'):
+            raise ValueError('payload integrity hash mismatch')
+        values = _decode(ns, payload)
+        if not isinstance(values, dict) or sorted(values) != sorted(names):
+            raise ValueError('payload namespace differs from manifest')
+        omitted = dict(manifest.get('omitted', {}))
+        unavailable = set(manifest.get('bindingNames', [])) - set(json.loads(bindings_json))
+        dependencies = manifest.get('dependencies', {})
+        changed = True
+        while changed:
+            changed = False
+            for root in list(values):
+                missing_bindings = set(dependencies.get(root, [])).intersection(unavailable)
+                missing_state = set(dependencies.get(root, [])).intersection(omitted)
+                if missing_bindings or missing_state:
+                    omitted[root] = ('missing current host binding: ' + ', '.join(sorted(missing_bindings))) if missing_bindings else ('depends on omitted globals: ' + ', '.join(sorted(missing_state)))
+                    del values[root]
+                    changed = True
+        ns.update(values)
+        _emit(sentinel, dict(kind='restored', count=len(values), turn=turn, names=names,
+            omitted=omitted))
+    except Exception as error:
+        _emit(sentinel, dict(kind='degraded', reason=type(error).__name__ + ': ' + str(error)))
```

```diff
--- baseline/better-dsh/src/omp-python/better_support.py
+++ current/better-dsh/src/omp-python/better_support.py
@@ -0,0 +1,425 @@
+"""Better-owned integration around the unchanged OMP runner (see provenance.json)."""
+import ast
+import asyncio
+import builtins
+import contextvars
+import json
+import inspect
+import os
+import signal
+import subprocess
+import time
+import sys
+import threading
+import urllib.request
+import uuid
+
+_RUN = contextvars.ContextVar('better_run', default=None)
+_SPECS = contextvars.ContextVar('better_specs', default={})
+_PENDING = {}
+_LOCK = threading.Lock()
+_WRITE_LOCK = threading.Lock()
+_OWNED = {}
+_INJECTED = {}
+_STARTED = False
+_WRITER = None
+
+
+class HostRejected(Exception):
+    pass
+
+
+def _deliver(reply):
+    with _LOCK:
+        item = _PENDING.get(reply.get('id'))
+    if item is None:
+        return
+    loop, future, run = item
+    if reply.get('run') != run:
+        return
+    def settle():
+        if not future.done():
+            if reply.get('ok') is True:
+                future.set_result(reply.get('result'))
+            else:
+                future.set_exception(HostRejected(reply.get('message') or 'host request failed'))
+    loop.call_soon_threadsafe(settle)
+
+
+def _read_replies():
+    with os.fdopen(4, 'r', encoding='utf-8') as reader:
+        for line in reader:
+            try:
+                _deliver(json.loads(line))
+            except (ValueError, RuntimeError):
+                continue
+
+
+def unsupported_input(*args, **kwargs):
+    raise RuntimeError('Interactive stdin is unsupported in Better Python REPL; pass input as a variable or tool argument')
+
+
+def initialize(ns):
+    global _STARTED, _WRITER
+    __import__('better_snapshot')  # preload pinned dill before user imports
+    if not _STARTED:
+        _OWNED.update(ns)
+        if not os.environ.get('BETTER_CALLBACK_URL'):
+            _WRITER = os.fdopen(3, 'w', encoding='utf-8', buffering=1)
+            threading.Thread(target=_read_replies, name='better-callback-replies', daemon=True).start()
+        _STARTED = True
+    # Do not mutate the runner's Python builtins or put internal imports in user globals.
+    ns['__builtins__'] = dict(vars(builtins), input=unsupported_input)
+    _OWNED['__builtins__'] = ns['__builtins__']
+    ns['__omp_with_call_site__'] = with_call_site
+
+
+async def with_call_site(site_id, action, args):
+    """Required runner compiler seam; Better has no speculative read cache."""
+    result = action(args)
+    return await result if inspect.isawaitable(result) else result
+
+
+def reset(ns, args):
+    """Invoke the native magic, then immediately restore Better capabilities."""
+    __import__('better_snapshot').clear()
+    sys.modules['__main__'].__dict__['__omp_magic']('reset', args)
+    initialize(ns)
+    install_bindings(ns, _SPECS.get())
+
+
+class ResetAdapter(ast.NodeTransformer):
+    def visit_Call(self, node):
+        node = self.generic_visit(node)
+        if (isinstance(node.func, ast.Name) and node.func.id == '__omp_magic'
+                and len(node.args) == 2 and isinstance(node.args[0], ast.Constant)
+                and node.args[0].value == 'reset'):
+            module = ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
+                args=[ast.Constant('better_support')], keywords=[])
+            adapted = ast.Call(func=ast.Attribute(value=module, attr='reset', ctx=ast.Load()),
+                args=[ast.Call(func=ast.Name(id='globals', ctx=ast.Load()), args=[], keywords=[]), node.args[1]], keywords=[])
+            return ast.copy_location(adapted, node)
+        return node
+
+
+async def host_request(payload):
+    run = _RUN.get()
+    if run is None:
+        raise HostRejected('host callbacks are only available during an active cell')
+    request_id = uuid.uuid4().hex
+    request = dict(payload, id=request_id, run=run)
+    if os.environ.get('BETTER_CALLBACK_URL'):
+        def http_call():
+            req = urllib.request.Request(os.environ['BETTER_CALLBACK_URL'],
+                data=json.dumps(request, allow_nan=False).encode('utf-8'),
+                headers={'Authorization': 'Bearer ' + os.environ['BETTER_CALLBACK_TOKEN'], 'Content-Type': 'application/json'})
+            # Explicitly bypass consumer proxy settings for the owned loopback endpoint.
+            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
+            with opener.open(req, timeout=30) as response:
+                return json.load(response)
+        reply = await asyncio.to_thread(http_call)
+        if reply.get('ok') is not True:
+            raise HostRejected(reply.get('message') or 'host request failed')
+        return reply.get('result')
+    loop = asyncio.get_running_loop()
+    future = loop.create_future()
+    with _LOCK:
+        _PENDING[request_id] = (loop, future, run)
+    try:
+        with _WRITE_LOCK:
+            _WRITER.write(json.dumps(request, allow_nan=False) + '\n')
+            _WRITER.flush()
+        return await future
+    finally:
+        with _LOCK:
+            _PENDING.pop(request_id, None)
+
+
+def _error_class(name, member_property):
+    def init(self, message, member=None):
+        Exception.__init__(self, message)
+        if member is not None:
+            setattr(self, member_property, member)
+    return type(name, (Exception,), {'__init__': init})
+
+
+def _proxy(ns, global_name, function_name, error_class, flat=False):
+    async def invoke(call_args):
+        try:
+            return await host_request({'type': 'binding.call', 'global': global_name, 'name': function_name, 'args': call_args})
+        except HostRejected as rejected:
+            cls = ns.get(error_class) if error_class else None
+            if cls is None:
+                raise
+            raise cls(str(rejected), global_name if flat else function_name) from None
+    if flat:
+        async def callable_binding(args=None, /):
+            return await invoke({'args': [] if args is None else [args], 'kwargs': {}})
+        callable_binding.__name__ = global_name
+        callable_binding.__qualname__ = global_name
+        return callable_binding
+    async def namespace_binding(*args, **kwargs):
+        if kwargs:
+            raise TypeError('Better binding calls do not accept keyword arguments')
+        return await invoke(args[0] if len(args) == 1 else list(args) if args else None)
+    return namespace_binding
+
+
+def install_bindings(ns, spec):
+    for name, value in list(_INJECTED.items()):
+        if ns.get(name) is value:
+            ns.pop(name, None)
+    _INJECTED.clear()
+    classes = {}
+    for global_name, config in spec.items():
+        error = config.get('errorClass')
+        error_name = error['name'] if error else None
+        if error and error_name not in classes:
+            classes[error_name] = _error_class(error_name, error['memberNameProperty'])
+        if config.get('callable'):
+            value = _proxy(ns, global_name, next(iter(config['functions'])), error_name, flat=True)
+        else:
+            def holder(global_name=global_name, config=config, error_name=error_name):
+                class BindingHolder:
+                    def __dir__(self):
+                        return sorted(config['functions'])
+                    def __getattr__(self, name):
+                        return _proxy(ns, global_name, name, error_name)
+                return BindingHolder()
+            value = holder()
+        ns[global_name] = value
+        _INJECTED[global_name] = value
+    ns.update(classes)
+    _INJECTED.update(classes)
+
+
+def complete(value, sentinel, absent=False):
+    envelope = {'ok': True}
+    if not absent and value is not None:
+        try:
+            envelope['json'] = json.dumps(value, allow_nan=False)
+        except (TypeError, ValueError, OverflowError):
+            envelope['json'] = json.dumps(repr(value))
+    print(sentinel + json.dumps(envelope))
+
+
+def _process_tree():
+    """Return descendants and birth identities; no subprocess monkeypatching."""
+    if os.name != 'posix':
+        return {}  # Windows limitation is explicit in the delivery report.
+    root = os.getpid()
+    if os.path.isdir('/proc/self/task'):
+        tree = {}
+        visited = {root}
+        pending = [root]
+        while pending:
+            parent = pending.pop()
+            try:
+                tasks = os.listdir('/proc/%d/task' % parent)
+            except FileNotFoundError:
+                continue
+            for task in tasks:
+                try:
+                    with open('/proc/%d/task/%s/children' % (parent, task)) as stream:
+                        children = stream.read().split()
+                except FileNotFoundError:
+                    continue
+                for child in children:
+                    pid = int(child)
+                    if pid in visited:
+                        continue
+                    visited.add(pid)
+                    identity = _process_identity(pid)
+                    if identity is not None:
+                        tree[pid] = identity[0]
+                        pending.append(pid)
+        return tree
+    result = subprocess.run(['ps', '-axo', 'pid=,ppid=,stat=,lstart='],
+        capture_output=True, text=True, check=True, timeout=0.03)
+    rows = {}
+    for line in result.stdout.splitlines():
+        parts = line.split(None, 3)
+        if len(parts) == 4:
+            rows[int(parts[0])] = (int(parts[1]), parts[3])
+    if root not in rows:
+        raise RuntimeError('cannot inspect Python process tree')
+    found = {root}
+    changed = True
+    while changed:
+        changed = False
+        for pid, (parent, _) in rows.items():
+            if parent in found and pid not in found:
+                found.add(pid)
+                changed = True
+    return {pid: rows[pid][1] for pid in found if pid != root}
+
+
+def _process_identity(pid):
+    if os.path.isdir('/proc/self/task'):
+        try:
+            with open('/proc/%d/stat' % pid) as stream:
+                text = stream.read()
+            fields = text[text.rfind(')') + 2:].split()
+            return fields[19], fields[0]
+        except FileNotFoundError:
+            return None
+    result = subprocess.run(['ps', '-p', str(pid), '-o', 'stat=,lstart='],
+        capture_output=True, text=True, timeout=0.02)
+    parts = result.stdout.strip().split(None, 1)
+    return (parts[1], parts[0]) if len(parts) == 2 else None
+
+
+def _cancel_new_children(baseline):
+    if baseline is None:
+        raise RuntimeError('process tree baseline unavailable')
+    # Capture identities before parents exit/reparent; never signal a reused PID.
+    current = _process_tree()
+    owned = {pid: birth for pid, birth in current.items() if baseline.get(pid) != birth}
+    deadline = time.monotonic() + 0.10
+    term_until = time.monotonic() + 0.025
+    killed = set()
+    for pid in reversed(list(owned)):
+        identity = _process_identity(pid)
+        if identity and identity[0] == owned[pid] and identity[1] != 'Z':
+            try:
+                os.kill(pid, signal.SIGTERM)
+            except ProcessLookupError:
+                pass
+    while True:
+        # Pick up children created by a terminating descendant while its
+        # parent is still visible; retain identities after reparenting.
+        for pid, birth in _process_tree().items():
+            if baseline.get(pid) != birth and pid not in owned:
+                owned[pid] = birth
+                try:
+                    os.kill(pid, signal.SIGTERM)
+                except ProcessLookupError:
+                    pass
+        # Reap only this cell's direct children; earlier persistent children
+        # are left to their owners. Grandchild zombies are no longer executing.
+        survivors = []
+        for pid, birth in owned.items():
+            try:
+                os.waitpid(pid, os.WNOHANG)
+            except ChildProcessError:
+                pass
+            identity = _process_identity(pid)
+            if identity and identity[0] == birth and not identity[1].startswith('Z'):
+                survivors.append(pid)
+        if not survivors:
+            return
+        now = time.monotonic()
+        if now >= deadline:
+            raise RuntimeError('cancelled descendants did not terminate')
+        if now >= term_until:
+            for pid in survivors:
+                if pid not in killed:
+                    try:
+                        os.kill(pid, signal.SIGKILL)
+                    except ProcessLookupError:
+                        pass
+                    killed.add(pid)
+        time.sleep(min(0.003, deadline - now))
+
+
+async def run(ns, source, spec_json, sentinel):
+    """Retain OMP transforms/compiler/TLA execution; adapt only typed completion."""
+    runner = sys.modules['__main__']
+    initialize(ns)
+    spec = json.loads(spec_json)
+    install_bindings(ns, spec)
+    spec_token = _SPECS.set(spec)
+    token = _RUN.set(runner._CURRENT_RID.get())
+    baseline = None
+    interrupted = False
+    previous_handler = signal.getsignal(signal.SIGINT)
+    def on_interrupt(signum, frame):
+        nonlocal interrupted
+        interrupted = True
+        if callable(previous_handler):
+            return previous_handler(signum, frame)
+        if previous_handler != signal.SIG_IGN:
+            return signal.default_int_handler(signum, frame)
+    signal.signal(signal.SIGINT, on_interrupt)
+    try:
+        try:
+            baseline = _process_tree()
+        except (OSError, ValueError, subprocess.SubprocessError):
+            pass
+        transformed = runner.transform_cell(source)
+        tree = ResetAdapter().visit(ast.parse(transformed or 'pass', '<cell>', 'exec'))
+        # OMP owns compilation and execution. Wrapping its final expression only
+        # changes the display boundary to the existing lossless JSON contract.
+        if tree.body and isinstance(tree.body[-1], ast.Expr):
+            expression = tree.body[-1]
+            call = ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
+                args=[ast.Constant('better_support')], keywords=[]), attr='complete', ctx=ast.Load()),
+                args=[expression.value, ast.Constant(sentinel)], keywords=[])
+            tree.body[-1] = ast.copy_location(ast.Expr(value=call), expression)
+        else:
+            tree.body.append(ast.Expr(value=ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
+                args=[ast.Constant('better_support')], keywords=[]), attr='complete', ctx=ast.Load()),
+                args=[ast.Constant(None), ast.Constant(sentinel)], keywords=[ast.keyword(arg='absent', value=ast.Constant(True))])))
+        ast.fix_missing_locations(tree)
+        await runner._exec_source_async(ast.unparse(tree), ns)
+    except KeyboardInterrupt:
+        interrupted = True
+        raise
+    finally:
+        if interrupted:
+            # User code may catch KeyboardInterrupt itself. Receipt tracking
+            # still makes cancellation clean current foreground descendants.
+            # The host's confirm SIGINT cannot interrupt cleanup.
+            signal.signal(signal.SIGINT, signal.SIG_IGN)
+            try:
+                _cancel_new_children(baseline)
+            except BaseException:
+                # Host observes death and sweeps group before queue admission.
+                os._exit(130)
+        signal.signal(signal.SIGINT, previous_handler)
+        _RUN.reset(token)
+        _SPECS.reset(spec_token)
+        # A detached Python task must not gain admission after its cell ended.
+        with _LOCK:
+            pending = [item for item in _PENDING.values() if item[2] == runner._CURRENT_RID.get()]
+        for loop, future, _ in pending:
+            if not future.done():
+                future.cancel()
+
+
+def user_namespace(ns):
+    return {name: value for name, value in ns.items()
+        if not name.startswith('__omp_') and name not in ('__name__', '__doc__', '__builtins__')
+        and not (name in _OWNED and _OWNED[name] is value)
+        and not (name in _INJECTED and _INJECTED[name] is value)}
+
+
+def query(ns, name_json, sentinel):
+    user = user_namespace(ns)
+    name = json.loads(name_json)
+    if name is None:
+        reply = {'ok': True, 'kind': 'names', 'names': sorted(user)}
+    elif name not in user:
+        reply = {'ok': True, 'kind': 'missing'}
+    else:
+        try:
+            reply = {'ok': True, 'kind': 'json', 'text': json.dumps(user[name], allow_nan=False)}
+        except (TypeError, ValueError, OverflowError):
+            reply = {'ok': True, 'kind': 'repr', 'text': repr(user[name])}
+    print(sentinel + json.dumps(reply))
+
+
+def set_var(ns, name, value_json, sentinel):
+    ns[name] = json.loads(value_json)
+    print(sentinel + json.dumps({'ok': True}))
+
+
+def owned_objects():
+    return list(_OWNED.values()) + list(_INJECTED.values())
+
+def reserved_names():
+    return set(_OWNED) | set(_INJECTED)
+
+
+def injected_names():
+    return set(_INJECTED)
```

```diff
--- baseline/better-dsh/src/omp-python/dill-provenance.json
+++ current/better-dsh/src/omp-python/dill-provenance.json
@@ -0,0 +1,55 @@
+{
+  "version": "0.4.1",
+  "artifact": {
+    "url": "https://files.pythonhosted.org/packages/1e/77/dc8c558f7593132cf8fefec57c4f60c83b16941c574ac5f619abb3ae7933/dill-0.4.1-py3-none-any.whl",
+    "sha256": "1e1ce33e978ae97fcfcff5638477032b801c46c7c65cf717f95fbc2248f79a9d"
+  },
+  "adaptations": "None. Runtime Python sources and BSD-3-Clause license copied unchanged from wheel; tests excluded. Better adapter lives in better_snapshot.py.",
+  "files": {
+    "vendor/dill/__diff.py": {
+      "sha256": "ed70aa5887a54d648b8e278e22edd7b6bd6652e8bd6019a5b4fefeb6fb6b1be4"
+    },
+    "vendor/dill/__info__.py": {
+      "sha256": "106836361f383613e762ad49da3e8400f8b105bde9b15c58fb9ac05b3afca6b9"
+    },
+    "vendor/dill/__init__.py": {
+      "sha256": "63cbac9f3a5fb1c949c53e93bd16066ab117916117a6bbf8942d992746c63366"
+    },
+    "vendor/dill/_dill.py": {
+      "sha256": "35d695c86cce6f94b9eda6d83747855dca20a1c1d0ad306452bbbb72ac367f03"
+    },
+    "vendor/dill/_objects.py": {
+      "sha256": "fd773b3aa9d97ac0e62819ad91b92b041303cc7dd3205cbfbed311b5cee5b122"
+    },
+    "vendor/dill/_shims.py": {
+      "sha256": "92421aee6b961c7a7db88b6935f7ea99b8413b830428f21d7b21ce2b1c76545e"
+    },
+    "vendor/dill/detect.py": {
+      "sha256": "55b0b234c68856e762a8cd672e61b04bec975ba33d0a47696e455aac09a726a5"
+    },
+    "vendor/dill/logger.py": {
+      "sha256": "675c2053c05b48011604aa2e71844762b16154baaaa934e2f811dc7ec79b8bcf"
+    },
+    "vendor/dill/objtypes.py": {
+      "sha256": "de10c49d14b4e34995c80de7309a74b1e222030f5269fc5bbaf1b9b45bed85f1"
+    },
+    "vendor/dill/pointers.py": {
+      "sha256": "cde5fc5ea94b0485bdbcbf971ff7abf475169889e56df5a362dbdae7a7939b0c"
+    },
+    "vendor/dill/session.py": {
+      "sha256": "f3c0c914842b03cef7dcff952a46c2ab47759722737244180ab1b170f79229e1"
+    },
+    "vendor/dill/settings.py": {
+      "sha256": "0d1169d900bcc6ca4f67949bdde201e9a6cfa75c0db8136d0848d9f032d8fb1e"
+    },
+    "vendor/dill/source.py": {
+      "sha256": "1ac9987fa6c43cb33dae2bf3d4473b1b613eb44800a1723de428aca9d7101860"
+    },
+    "vendor/dill/temp.py": {
+      "sha256": "785c8c8192094545607518b66b8236b597798371d25059df9b92b72d5d99f779"
+    },
+    "DILL-LICENSE": {
+      "sha256": "f669d63bebf765baaa0b20d8b0c1193296a7e0ea0c22c50a308b74d76ab3939c"
+    }
+  }
+}
```

```diff
--- baseline/better-dsh/src/omp-python/provenance.json
+++ current/better-dsh/src/omp-python/provenance.json
@@ -0,0 +1,13 @@
+{
+  "upstream": "https://github.com/can1357/oh-my-pi",
+  "commit": "fa5ff4a3a977a28b93d025f4cf50f046e019f18c",
+  "files": {
+    "runner.py": {
+      "path": "packages/coding-agent/src/eval/py/runner.py",
+      "sha256": "e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974",
+      "modified": false
+    }
+  },
+  "license": "OMP-LICENSE",
+  "adaptation": "Better-owned better_support.py runs runner.transform_cell and runner._exec_source_async without patching either. It wraps final expression display for lossless JSON, owns bindings, stdlib callback pipes on POSIX and authenticated loopback HTTP on Windows, namespace filtering and unsupported input(). The OMP Agent prelude is neither executed nor shipped. Better supplies the compiler-required __omp_with_call_site__ forwarding helper without speculative caching, restores current bindings/input guard immediately after native reset using its own AST adapter, and uses the default cell filename to avoid synthetic user state. Better tracks per-cell descendant birth identities and SIGINT receipt, cleans new foreground descendants on cancellation with bounded TERM/KILL/reaping, and restores the prior signal handler. Prior persistent children are retained; unproven cleanup retires the runner."
+}
```

```diff
--- baseline/better-dsh/src/output.ts
+++ current/better-dsh/src/output.ts
@@ -1,19 +1,19 @@
 /**
  * Result assembly helpers: sentinel extraction from the captured stream and
  * the outer-output ledger. Pure functions; the plugin owns their wiring.
  * @module dashr/output
  */
 
 import type { CodeJsonValue, CodeRunFailure, CodeRunResult } from './vendored/repl-runtime.ts'
 
-/** ANSI color escapes, which ipykernel embeds in published tracebacks. */
+/** ANSI color escapes, which Python may embed in tracebacks. */
 const ANSI_ESCAPE = /\x1b\[[0-9;]*[A-Za-z]/g
 
 /** Smallest cap that can represent an empty logs array plus a quoted message. */
 export const MIN_OUTPUT_BYTES = 4
 
 export interface StreamCapture {
   /** Emission lines with the completion envelope removed, in order. */
   logs: string[]
   /** The raw JSON text after the sentinel, when the envelope line arrived. */
   envelope: string | undefined
@@ -37,21 +37,21 @@
     }
     if (at > 0) logs.push(line.slice(0, at))
     envelope = line.slice(at + sentinel.length)
   }
   // A trailing '\n' yields a final empty line that is a split artifact, not an
   // emission.
   if (logs.length > 0 && logs.at(-1) === '') logs.pop()
   return { logs, envelope: envelope === '' ? undefined : envelope }
 }
 
-/** Strip ANSI escapes from an ipykernel traceback for a model-facing message. */
+/** Strip ANSI escapes from a Python traceback for a model-facing message. */
 export function plainTraceback(ename: string, evalue: string, traceback: string[]): string {
   const body = traceback.map(line => line.replace(ANSI_ESCAPE, '')).join('\n')
   return body.length > 0 ? `${ename}: ${evalue}\n${body}` : `${ename}: ${evalue}`
 }
 
 function byteLength(text: string): number {
   return Buffer.byteLength(text, 'utf8')
 }
 
 /** Serialized size of the counted payloads: logs array, value, failure message. */
```

```diff
--- baseline/better-dsh/src/python.ts
+++ current/better-dsh/src/python.ts
@@ -1,346 +1,35 @@
-/**
- * Per-run cell generation. One `run()` is exactly one `execute_request`: the
- * cell installs the run's binding namespaces, runs the program through
- * `_dashr_run_program` (module-scope statements executed with the user
- * namespace as BOTH globals and locals — pure IPython REPL semantics:
- * top-level `await` legal, top-level `return` a SyntaxError, and the last
- * expression's value is the completion), and prints the completion envelope
- * under a per-run nonce sentinel so the host can recover the exact JSON bytes
- * from the captured stream.
- *
- * The snapshot and restore cells live here too: they are internal cells on
- * the SAME kernel, generated the same way, and must therefore obey the same
- * busy-guard discipline as a user cell.
- * @module dashr/python
- */
-
-/** Binding namespaces as seen by the kernel-side installer, keyed by global. */
+/** Better-owned cells delegate to packaged Python modules, never user-global helpers. */
 export type NamespaceSpecs = Record<string, {
   functions: string[]
-  /** Materialize the global itself as a callable function (single `functions` entry). */
   callable?: true
   errorClass?: { name: string, memberNameProperty: string }
 }>
 
-/**
- * Build the single cell for one run.
- * @param program - the model's cell program, executed at module scope.
- * @param specJson - the JSON-encoded {@link NamespaceSpecs} map.
- * @param sentinel - per-run nonce prefix; the envelope line starts with it.
- * @returns the complete cell source.
- */
 export function buildRunCell(program: string, specJson: string, sentinel: string): string {
-  // The program executes via _dashr_run_program (exec with the user
-  // namespace as BOTH globals and locals — pure REPL semantics, so
-  // 'count = count + ...' reads state left by earlier runs instead of
-  // raising UnboundLocalError in a real function scope). Its result is the
-  // cell's completion value — the last expression's value, REPL
-  // displayhook-style.
-  // The scaffold brackets the whole cell with the SIGALRM busy guard (see the
-  // bootstrap's _dashr_state): from the kernel's first bytecode of this cell
-  // to its last, an interrupt may raise KeyboardInterrupt — the window where
-  // breaking the cell is the intended outcome. Outside it (boot, idle,
-  // post-cell unwind) the kernel-side handler swallows the signal instead of
-  // dying to it.
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    // The program executes via _dashr_run_program (exec with the user
-    // namespace as BOTH globals and locals — REPL semantics, so
-    // 'count = count + ...' reads state left by earlier runs instead of
-    // raising UnboundLocalError in a real function scope). Its result is the
-    // rewritten top-level return value.
-    `    _dashr_install_bindings(${JSON.stringify(specJson)})`,
-    `    __dashr_completion__ = _dashr_encode(await _dashr_run_program(${JSON.stringify(program)}))`,
-    // The full envelope is printed (never just the value's JSON text) so a
-    // rejected encoding cannot collide with a value that serializes to
-    // '{"ok": false}' itself.
-    `    print(${JSON.stringify(sentinel)} + _dashr_json.dumps(__dashr_completion__))`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+  return `await __import__('better_support').run(globals(), ${JSON.stringify(program)}, ${JSON.stringify(specJson)}, ${JSON.stringify(sentinel)})`
 }
 
-/** Host-supplied inputs a snapshot cell records beside the dill payload. */
 export interface SnapshotSpec {
   /** Which completed run this snapshot belongs to (the revive "turn-N" counter). */
   turn: number
   /** Minimal replay metadata: skills the kernel environment must provide (none today). */
   skills: string[]
   /** Serialized-size cap in bytes; over-cap snapshots are skipped, not written. */
   sizeCapBytes: number
 }
 
-/**
- * Build the internal cell that dumps the user namespace to a dill snapshot and
- * writes a JSON manifest next to it. Only USER state is captured: IPython's
- * own session plumbing (`exit`, `quit`, `get_ipython`, … tracked in the
- * shell's `user_ns_hidden` and still bound to the object IPython installed)
- * reaches unpicklable kernel machinery — e.g. the history manager's
- * sqlite3.Connection — and is never restored as program state anyway. Shim
- * names (any `_dashr`/`__dashr` spelling) are excluded by prefix.
- *
- * Size-cap policy (M3-B, blueprint §8.3): dill cannot report a serialized
- * size before dumping, and a GB-sized `DataFrame` dumped EVERY turn is the IO
- * storm the cap exists to stop. The cell therefore gates in two tiers:
- * first a bounded-depth namespace walk estimates the footprint (counting
- * container lengths and reading `nbytes` / `memory_usage(deep=True)` for
- * numpy/pandas objects — the stated pathological case — so the dump is
- * skipped BEFORE any dill IO), then the actual dump goes to a sibling
- * `.part` file whose true byte size is measured before it replaces the
- * previous good snapshot. Skipped snapshots leave the previous
- * `state.dill` + manifest untouched, so a revive restores the last good turn.
- * @param payloadPath - absolute path for the dill payload.
- * @param manifestPath - absolute path for the JSON manifest.
- * @param spec - turn counter, skills list, and the size cap.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildSnapshotCell(payloadPath: string, manifestPath: string, spec: SnapshotSpec, sentinel: string): string {
-  // Bracketed by the same SIGALRM busy guard as a run cell: a timed-out
-  // snapshot (e.g. dill stuck on a pathological object graph) must be
-  // breakable by the host's interrupt ladder exactly like user code.
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import dill as _dashr_dill, json as _dashr_json, platform as _dashr_platform`,
-    `    import os as _dashr_os, sys as _dashr_sys, datetime as _dashr_dt`,
-    `    _dashr_shell = globals().get('get_ipython', lambda: None)()`,
-    `    _dashr_hidden = getattr(_dashr_shell, 'user_ns_hidden', None) or {}`,
-    `    _dashr_user_ns = {`,
-    `        name: value`,
-    `        for name, value in globals().items()`,
-    `        if not name.lower().startswith(('_dashr', '__dashr'))`,
-    `        and (name not in _dashr_hidden or _dashr_hidden[name] is not value)`,
-    `    }`,
-    `    _dashr_cap = ${JSON.stringify(spec.sizeCapBytes)}`,
-    `    def _dashr_estimate(value, depth):`,
-    `        if value is None or isinstance(value, (bool, int, float, complex)):`,
-    `            return 32`,
-    `        if isinstance(value, (str, bytes, bytearray)):`,
-    `            return len(value) + 64`,
-    `        if isinstance(value, (list, tuple, set, frozenset)):`,
-    `            if depth <= 0:`,
-    `                return 4096`,
-    `            return 64 + sum(_dashr_estimate(item, depth - 1) for item in value)`,
-    `        if isinstance(value, dict):`,
-    `            if depth <= 0:`,
-    `                return 4096`,
-    `            total = 64`,
-    `            for key, item in value.items():`,
-    `                total += _dashr_estimate(key, depth - 1)`,
-    `                total += _dashr_estimate(item, depth - 1)`,
-    `                if total > _dashr_cap:`,
-    `                    return total`,
-    `            return total`,
-    `        _dashr_nbytes = getattr(value, 'nbytes', None)`,
-    `        if isinstance(_dashr_nbytes, int) and _dashr_nbytes > 0:`,
-    `            return _dashr_nbytes + 128`,
-    `        _dashr_mem = getattr(value, 'memory_usage', None)`,
-    `        if callable(_dashr_mem):`,
-    `            try:`,
-    `                _dashr_usage = _dashr_mem(deep=True)`,
-    `                _dashr_sum = getattr(_dashr_usage, 'sum', None)`,
-    `                if callable(_dashr_sum):`,
-    `                    # pandas returns a numpy scalar (np.int64), which is`,
-    `                    # not a Python int subclass; coerce, don't isinstance.`,
-    `                    _dashr_n = int(_dashr_sum())`,
-    `                    if _dashr_n > 0:`,
-    `                        return _dashr_n + 128`,
-    `            except Exception:`,
-    `                pass`,
-    `        return 4096`,
-    `    _dashr_estimate_bytes = sum(_dashr_estimate(value, 4) for value in _dashr_user_ns.values())`,
-    `    if _dashr_estimate_bytes > _dashr_cap:`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({`,
-    `            'ok': False, 'skipped': True, 'reason': 'estimate',`,
-    `            'estimateBytes': _dashr_estimate_bytes, 'capBytes': _dashr_cap,`,
-    `        }))`,
-    `    else:`,
-    `        _dashr_part = ${JSON.stringify(payloadPath)} + '.part'`,
-    `        try:`,
-    `            with open(_dashr_part, 'wb') as _dashr_f:`,
-    `                _dashr_dill.dump(_dashr_user_ns, _dashr_f)`,
-    `            _dashr_size = _dashr_os.path.getsize(_dashr_part)`,
-    `            if _dashr_size > _dashr_cap:`,
-    `                print(${JSON.stringify(sentinel)} + _dashr_json.dumps({`,
-    `                    'ok': False, 'skipped': True, 'reason': 'actual',`,
-    `                    'sizeBytes': _dashr_size, 'capBytes': _dashr_cap,`,
-    `                }))`,
-    `            else:`,
-    `                _dashr_os.replace(_dashr_part, ${JSON.stringify(payloadPath)})`,
-    `                _dashr_manifest = {`,
-    `                    'snapshotFormat': 1,`,
-    `                    'turn': ${JSON.stringify(spec.turn)},`,
-    `                    'pythonVersion': _dashr_platform.python_version(),`,
-    `                    'venvPath': _dashr_sys.executable,`,
-    `                    'skills': ${JSON.stringify(spec.skills)},`,
-    `                    'names': sorted(_dashr_user_ns),`,
-    `                    'sizeBytes': _dashr_size,`,
-    `                    'skipped': False,`,
-    `                    'createdAt': _dashr_dt.datetime.now(_dashr_dt.timezone.utc).isoformat(),`,
-    `                }`,
-    `                with open(${JSON.stringify(manifestPath)}, 'w', encoding='utf-8') as _dashr_f:`,
-    `                    _dashr_json.dump(_dashr_manifest, _dashr_f)`,
-    `                print(${JSON.stringify(sentinel)} + _dashr_json.dumps({`,
-    `                    'ok': True, 'sizeBytes': _dashr_size, 'names': len(_dashr_user_ns),`,
-    `                }))`,
-    `        finally:`,
-    `            if _dashr_os.path.exists(_dashr_part):`,
-    `                try:`,
-    `                    _dashr_os.unlink(_dashr_part)`,
-    `                except OSError:`,
-    `                    pass`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+export function buildQueryVarCell(name: string | null, sentinel: string): string {
+  return `__import__('better_support').query(globals(), ${JSON.stringify(JSON.stringify(name))}, ${JSON.stringify(sentinel)})`
 }
 
-/**
- * Build the internal cell that restores a dill snapshot into the user
- * namespace. The kernel validates the manifest ITSELF (it is the only party
- * that knows its own python version and `sys.executable`): a python-version
- * mismatch, a different interpreter (`venvPath`), a non-empty skills list, or
- * an unreadable/corrupt payload degrades to an empty namespace WITHOUT
- * touching globals, and reports the reason through the envelope so the host
- * can tell the model "snapshot not replayable, started from empty". Shim and
- * IPython-hidden names are re-filtered on the way in — the same exclusion the
- * snapshot applied on the way out, applied again defensively.
- * @param payloadPath - absolute path of the dill payload.
- * @param manifestPath - absolute path of the JSON manifest.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildRestoreCell(payloadPath: string, manifestPath: string, sentinel: string): string {
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import dill as _dashr_dill, json as _dashr_json, platform as _dashr_platform`,
-    `    import os as _dashr_os, sys as _dashr_sys`,
-    `    _dashr_manifest = None`,
-    `    _dashr_reason = 'snapshot manifest could not be read'`,
-    `    try:`,
-    `        with open(${JSON.stringify(manifestPath)}, 'r', encoding='utf-8') as _dashr_f:`,
-    `            _dashr_manifest = _dashr_json.load(_dashr_f)`,
-    `    except Exception as _dashr_err:`,
-    `        _dashr_reason = 'snapshot manifest could not be read: ' + repr(_dashr_err)`,
-    `    if _dashr_manifest is None:`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': _dashr_reason}))`,
-    `    elif _dashr_manifest.get('snapshotFormat') != 1:`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'snapshot format is not replayable'}))`,
-    `    elif _dashr_manifest.get('skipped'):`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'snapshot was skipped (namespace exceeded the size cap)'}))`,
-    `    elif _dashr_manifest.get('pythonVersion') != _dashr_platform.python_version():`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'python version mismatch: snapshot ' + str(_dashr_manifest.get('pythonVersion')) + ' vs kernel ' + _dashr_platform.python_version()}))`,
-    `    elif _dashr_os.path.realpath(_dashr_manifest.get('venvPath') or '') != _dashr_os.path.realpath(_dashr_sys.executable):`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'kernel interpreter differs from the snapshot venv'}))`,
-    `    elif _dashr_manifest.get('skills'):`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'snapshot skills are not replayable in this provider'}))`,
-    `    else:`,
-    `        try:`,
-    `            with open(${JSON.stringify(payloadPath)}, 'rb') as _dashr_f:`,
-    `                _dashr_restored = _dashr_dill.load(_dashr_f)`,
-    `        except Exception as _dashr_err:`,
-    `            _dashr_restored = None`,
-    `            _dashr_reason = 'snapshot payload could not be loaded: ' + repr(_dashr_err)`,
-    `        if not isinstance(_dashr_restored, dict):`,
-    `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': _dashr_reason if _dashr_restored is None else 'snapshot payload is not a namespace dict'}))`,
-    `        else:`,
-    `            _dashr_shell = globals().get('get_ipython', lambda: None)()`,
-    `            _dashr_hidden = getattr(_dashr_shell, 'user_ns_hidden', None) or {}`,
-    `            _dashr_user_ns = globals()`,
-    `            _dashr_restored_count = 0`,
-    `            for _dashr_name, _dashr_value in _dashr_restored.items():`,
-    `                if not isinstance(_dashr_name, str):`,
-    `                    continue`,
-    `                if _dashr_name.lower().startswith(('_dashr', '__dashr')):`,
-    `                    continue`,
-    `                if _dashr_name in _dashr_hidden and _dashr_hidden[_dashr_name] is _dashr_value:`,
-    `                    continue`,
-    `                _dashr_user_ns[_dashr_name] = _dashr_value`,
-    `                _dashr_restored_count += 1`,
-    `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'restored': _dashr_restored_count}))`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+export function buildSetVarCell(name: string, valueJson: string, sentinel: string): string {
+  return `__import__('better_support').set_var(globals(), ${JSON.stringify(name)}, ${JSON.stringify(valueJson)}, ${JSON.stringify(sentinel)})`
 }
 
-/**
- * Build the internal cell that reads ONE user-namespace variable by name, or
- * — when `name` is `null` — lists the namespace's user-variable names. The
- * same exclusion the snapshot applies on the way out (any `_dashr`/`__dashr`
- * spelling plus IPython's `user_ns_hidden`) defines what "user variable"
- * means here, so `ctx://` sees exactly the namespace a revive would restore.
- *
- * Serialization boundary (design.md D4): a value that survives
- * `json.dumps(…, allow_nan=False)` crosses as `kind: 'json'` text; anything
- * else falls back to `repr` text (`kind: 'repr'`) so a non-JSON variable
- * (the reason the snapshot uses dill at all) is still readable as text. The
- * host keeps the `kind` so the presentation can annotate a repr as "this is
- * repr text, not a JSON value".
- * @param name - the exact variable name, or `null` to list namespace names.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildQueryVarCell(name: string | null, sentinel: string): string {
-  const lines = [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import json as _dashr_json`,
-    `    _dashr_shell = globals().get('get_ipython', lambda: None)()`,
-    `    _dashr_hidden = getattr(_dashr_shell, 'user_ns_hidden', None) or {}`,
-    `    _dashr_user_ns = {`,
-    `        _name: _value`,
-    `        for _name, _value in globals().items()`,
-    `        if not _name.lower().startswith(('_dashr', '__dashr'))`,
-    `        and (_name not in _dashr_hidden or _dashr_hidden[_name] is not _value)`,
-    `    }`,
-  ]
-  if (name === null) {
-    lines.push(
-      `    print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'names', 'names': sorted(_dashr_user_ns)}))`,
-    )
-  } else {
-    lines.push(
-      `    _dashr_name = ${JSON.stringify(name)}`,
-      `    if _dashr_name not in _dashr_user_ns:`,
-      `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'missing'}))`,
-      `    else:`,
-      `        _dashr_value = _dashr_user_ns[_dashr_name]`,
-      `        try:`,
-      `            _dashr_text = _dashr_json.dumps(_dashr_value, allow_nan=False)`,
-      `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'json', 'text': _dashr_text}))`,
-      `        except (TypeError, ValueError, OverflowError):`,
-      `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'repr', 'text': repr(_dashr_value)}))`,
-    )
-  }
-  lines.push(
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  )
-  return lines.join('\n')
+export function buildSnapshotCell(payloadPath: string, manifestPath: string, spec: SnapshotSpec, sentinel: string): string {
+  return `__import__('better_snapshot').save(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(JSON.stringify(spec))}, ${JSON.stringify(sentinel)})`
 }
 
-/**
- * Build the internal cell that assigns one JSON value into the user
- * namespace under `name`. The value is carried as pre-serialized JSON text
- * (the host validated it as lossless JSON and the name as a usable
- * identifier), so the cell only decodes and binds — no arbitrary object can
- * cross the wire. Bracketed by the same SIGALRM busy guard as a run cell.
- * @param name - the validated identifier to assign under.
- * @param valueJson - the lossless-JSON text to decode and bind.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildSetVarCell(name: string, valueJson: string, sentinel: string): string {
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import json as _dashr_json`,
-    `    _dashr_value = _dashr_json.loads(${JSON.stringify(valueJson)})`,
-    `    globals()[${JSON.stringify(name)}] = _dashr_value`,
-    `    print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True}))`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+export function buildRestoreCell(payloadPath: string, manifestPath: string, sentinel: string, bindings: string[] = []): string {
+  return `__import__('better_snapshot').restore(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(sentinel)}, ${JSON.stringify(JSON.stringify(bindings))})`
 }
```

```diff
--- baseline/better-dsh/src/runtime.ts
+++ current/better-dsh/src/runtime.ts
@@ -1,45 +1,22 @@
 /**
- * `DashrRuntime`: DASHR's STATEFUL `ctx.replRuntime` backend (our vendored
- * Service Definition, blueprint v0.5 §7.6), the standing-mount layer of the
- * v0.1.5 architecture — between the profile-level DashrDaemon concept (a v0.1.5
- * empty shell: named, not yet built) and the session-level ipykernel
- * subprocess (a pure Python interpreter with no harness awareness). One
- * instance per standing mount owns a map of one persistent kernel subprocess
- * per SESSION (the run's `principal`) — the upstream "plugins key their
- * state by Session/Agent" model, which the roster's per-mount realm cannot
- * provide on its own (blueprint §7.4.1: an entry-local realm is one instance
- * per MOUNT, and every session joined to a standing mount shares it) — which
- * makes DashrRuntime the DE FACTO daemon today: it listens for `agent/disposed`,
- * keys kernels per session, snapshots them, and dispatches loopback host
- * requests. Each `run()` is exactly one cell on that session's kernel;
- * variables assigned in run N survive into run N+1 (blueprint §1.1 channel ②
- * — state codification, deliberately NOT the per-run isolation the
- * worker-thread backend provides), and two sessions never see each other's
- * variables. Kernels spawn lazily on a key's first run and die with their
- * session (the dsh `agent/disposed` event) or with the plugin. Binding
- * namespaces are materialized kernel-side as callable Python objects whose
- * calls travel back to the host over the `dashr.host` comm target (the PA
- * `host_request()` pattern). This is a capability seam, not a security
- * boundary.
- *
- * M3-B adds the namespace persistence half: turn-end snapshots (size-capped,
- * blueprint §8.3), restore-on-first-boot, and the death→revive chain (§8.3
- * "kernel death 行为链") that respawns onto the nearest replayable snapshot
- * instead of M3-A's fresh-empty respawn.
- * @module dashr-repl/runtime
+ * Stateful Python REPL backed by one owned OMP child per principal.
+ * Whole per-principal transactions serialize boot, restore, cells, queries,
+ * assignments and reset. Completed cells and assignments save best-effort
+ * object graphs; recovery never replays user code or external effects.
  */
 
-import { randomBytes } from 'node:crypto'
-import { existsSync, mkdirSync, readFileSync, rmSync } from 'node:fs'
+import { createHash, randomBytes } from 'node:crypto'
+import { existsSync, mkdirSync, rmSync } from 'node:fs'
 import { join } from 'node:path'
 import { Context } from '@deepseek-ai/cordis'
+import type { ProfileContext } from '@deepseek-ai/dsh-app-boot'
 import z from '#schemastery'
 import { snapshotJsonValue } from './snapshot-json.ts'
 import {
   DUNDER_MEMBER,
   PORTABLE_RESERVED_WORDS,
   RESERVED_BINDING_GLOBALS,
   RESERVED_ERROR_MEMBERS,
   ReplRuntime,
 } from './vendored/repl-runtime.ts'
 import type {
@@ -53,68 +30,59 @@
 import type { CellOutcome, HostRequestOutcome, QueryVarOutcome, SetVarOutcome, SnapshotSpec } from './kernel.ts'
 import { buildRunCell } from './python.ts'
 import type { NamespaceSpecs } from './python.ts'
 import { MIN_OUTPUT_BYTES, extractStream, finalizeOutput, plainTraceback } from './output.ts'
 import { resolveKernelEnv } from './kernel-env.ts'
 import type { KernelEnv } from './kernel-env.ts'
 import type { ReplVarQuery } from './runtime-surface.ts'
 
 /** Plugin config: every tunable, changeable from `cordis.yml` (no hardcoded tunables). */
 export interface Config {
-  /** Python interpreter with `ipykernel` installed. The bare sentinel `python3` (or absent) selects a managed venv under {@link Config.kernelEnvDir}. */
+  /** Python >=3.9 interpreter. The bare sentinel `python3` (or absent) selects a managed venv under {@link Config.kernelEnvDir}. */
   python?: string
   /** Budget for kernel spawn → ready, in milliseconds. */
   startupTimeoutMs?: number
   /** Wall budget per run; expiry interrupts the kernel then force-settles. */
   runTimeoutMs?: number
   /** Grace between a timeout/abort interrupt and the force-settle, in milliseconds. */
   interruptGraceMs?: number
   /**
-   * Confirm window between the control-channel interrupt and the SIGALRM
-   * escalation, in milliseconds; must stay below {@link Config.interruptGraceMs}.
+   * Confirm window before repeating SIGINT, in milliseconds; must stay below {@link Config.interruptGraceMs}.
    * See the bridge's two-phase interrupt for why the escalation is deferred.
    */
   interruptConfirmMs?: number
   /** Budget for graceful kernel teardown (shutdown_request → SIGKILL), in milliseconds. */
   disposeTimeoutMs?: number
   /** Budget for internal snapshot/restore cells (dill dump/load), in milliseconds. */
   snapshotTimeoutMs?: number
   /** Hard cap for serialized log-array, completion-value, and failure-message payloads. */
   maxOutputBytes?: number
-  /** Directory for per-session namespace snapshots (`state.dill` + `manifest.json`); none when absent. */
+  /** Per-session immutable checkpoints. Defaults to the official profile home; empty string disables, standalone callers opt in. */
   snapshotDir?: string
-  /** Serialized-size cap for a turn-end snapshot, in bytes; over-cap snapshots are skipped with a one-time model warning. */
+  /** Serialized graph cap in bytes; each over-cap attempt reports the last successful checkpoint. */
   snapshotSizeCapBytes?: number
   /** Managed venv directory (used when `python` is absent/`python3`); defaults to `<package>/.venv-kernel`. */
   kernelEnvDir?: string
   /** Preferred CPython version for a managed venv. */
   kernelPythonVersion?: string
-  /** Provision the managed venv (ipykernel + dill) on first use; default true. */
+  /** Provision a stdlib-only managed venv on first use; default true. */
   kernelAutoInstall?: boolean
   username?: string
 }
 
 /** {@link Config} after schemastery fills the defaults. */
 type ResolvedConfig = Required<Omit<Config, 'snapshotDir' | 'kernelEnvDir' | 'kernelPythonVersion'>> & Pick<Config, 'snapshotDir' | 'kernelEnvDir' | 'kernelPythonVersion'>
 
 const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/
 
-/**
- * Names the kernel-side shim owns (`_dashr`/`__dashr` prefixed, any case —
- * bootstrap helpers plus the per-run `__dashr_completion__` and
- * `__dashr_injected__`), refused as binding globals on top of the seam's
- * shared set.
- */
-const KERNEL_OWNED_NAME = /^_+dashr/i
-
-/** Manifest format version; a snapshot written under a different version is not replayable. */
-const SNAPSHOT_FORMAT = 1
+/** Runner internals and legacy reserved shim prefix are never injectable variables. */
+const KERNEL_OWNED_NAME = /^(?:_+dashr|__omp_)/i
 
 function messageOf(error: unknown): string {
   return error instanceof Error ? error.message : String(error)
 }
 
 /** Key under which the per-session kernel map stores agentless runs. */
 const AGENTLESS_KEY = '(agentless)'
 
 /**
  * Encode one principal as a single path segment for its per-key snapshot
@@ -137,40 +105,31 @@
   /**
    * Whether any cell has completed on this kernel — i.e. whether it may hold
    * user state a consumer could mistakenly assume still exists. Gates the
    * explicit namespace-lost error on respawn.
    */
   ranCells: boolean
   /** How many cells completed on this kernel — the snapshot "turn" counter. */
   turn: number
   /** Turn number of the last successfully written snapshot, when one exists. */
   lastSnapshotTurn?: number
-  /** Whether the one-time snapshot-size-cap warning has been delivered to the model. */
-  warnedSnapshotSkip?: boolean
   /** Whether restore-from-snapshot has been attempted for this entry (once per boot). */
   restoreAttempted?: boolean
   /** One-run notice (restore/degrade outcome) to surface on the next completed run. */
   pendingNotice?: string
 }
 
 /** What `restoreEntry` found and did, for the first-run notice and revive messaging. */
 type RestoreOutcome =
   | { kind: 'none' }
-  | { kind: 'restored', turn: number }
+  | { kind: 'restored', turn: number, omitted: Record<string, string> }
   | { kind: 'degraded', reason: string }
-
-/** Manifest fields the host reads before dispatching the restore cell. */
-interface SnapshotManifest {
-  snapshotFormat?: unknown
-  skipped?: unknown
-  turn?: unknown
-}
 
 /**
  * The {@link ReplRuntime} backend this package registers (`ctx.replRuntime`)
  * — the standing-mount layer of the v0.1.5 architecture, the de facto daemon
  * while the profile-level DashrDaemon stays an empty shell. One service
  * instance per mount holds one lazily-spawned kernel per session principal;
  * each kernel's lifecycle — snapshot and shutdown on session end, snapshot
  * and shutdown of every key on plugin disposal — is effect-owned.
  */
 export class DashrRuntime extends ReplRuntime {
@@ -192,37 +151,37 @@
   })
 
   readonly language = 'python'
   readonly isolation = 'process'
 
   private readonly config: ResolvedConfig
   private readonly logger: ReturnType<Context['logger']>
   /** One entry per session principal that has run code (lazy — never pre-seeded). */
   private readonly kernels = new Map<string, KeyedKernel>()
   private disposed = false
+  private readonly transactions = new Map<string, Promise<unknown>>()
   /** Lazily-resolved (and, when managed, provisioned) kernel interpreter. */
   private kernelEnvPromise: Promise<KernelEnv> | undefined
 
   constructor(ctx: Context, config: Config) {
     super(ctx)
-    this.config = config as ResolvedConfig
+    const profile: ProfileContext | undefined = ctx.get('profileContext')
+    this.config = { ...config, snapshotDir: config.snapshotDir ?? (profile ? join(profile.home, 'better-dsh', 'python-repl', createHash('sha256').update(profile.dir).digest('hex')) : undefined) } as ResolvedConfig
     // Schemastery filled the defaults; the cast records that. Positivity is a
     // semantic check the schema's plain number type does not carry.
     for (const key of ['startupTimeoutMs', 'runTimeoutMs', 'interruptGraceMs', 'disposeTimeoutMs', 'snapshotTimeoutMs'] as const) {
       const value = this.config[key]
       if (!(Number.isFinite(value) && value > 0)) {
         throw new Error(`dashr-repl: config.${key} must be a positive number, got ${String(value)}`)
       }
     }
-    // The SIGALRM escalation must fire strictly inside the force-settle grace,
-    // or it would never get its chance to break a busy cell before the run
-    // resolves.
+    // The repeat SIGINT must fire before the hard cancellation deadline.
     if (!(this.config.interruptConfirmMs > 0 && this.config.interruptConfirmMs < this.config.interruptGraceMs)) {
       throw new Error(`dashr-repl: config.interruptConfirmMs must be positive and below interruptGraceMs (${this.config.interruptGraceMs}), got ${String(this.config.interruptConfirmMs)}`)
     }
     if (!Number.isSafeInteger(this.config.maxOutputBytes) || this.config.maxOutputBytes < MIN_OUTPUT_BYTES) {
       throw new Error(`dashr-repl: config.maxOutputBytes must be a safe integer of at least ${MIN_OUTPUT_BYTES}, got ${String(this.config.maxOutputBytes)}`)
     }
     if (!Number.isSafeInteger(this.config.snapshotSizeCapBytes) || this.config.snapshotSizeCapBytes < 1) {
       throw new Error(`dashr-repl: config.snapshotSizeCapBytes must be a positive safe integer, got ${String(this.config.snapshotSizeCapBytes)}`)
     }
     this.logger = ctx.logger('dashr-repl')
@@ -262,66 +221,78 @@
   }
 
   /**
    * Execute one program as one cell on the persistent kernel. Program
    * outcomes — including kernel startup failure — resolve with
    * `result.error`; the method rejects only for Service Definition contract
    * misuse (a disposed runtime, an invalid binding namespace).
    * @param request - the program, its bindings, and the abort signal.
    * @returns the run's outcome per the seam contract.
    */
-  async run(request: CodeRunRequest): Promise<CodeRunResult> {
+  private transaction<T>(key: string, operation: () => Promise<T>): Promise<T> {
+    const result = (this.transactions.get(key) ?? Promise.resolve()).catch(() => undefined).then(operation)
+    this.transactions.set(key, result)
+    void result.finally(() => { if (this.transactions.get(key) === result) this.transactions.delete(key) }).catch(() => undefined)
+    return result
+  }
+
+  run(request: CodeRunRequest): Promise<CodeRunResult> {
+    return this.transaction(request.principal || AGENTLESS_KEY, () => this.runTransaction(request))
+  }
+
+  private async runTransaction(request: CodeRunRequest): Promise<CodeRunResult> {
     if (this.disposed) throw new Error('dashr-repl: run() after disposal')
     const bindings = this.validateBindings(request)
+    const bindingNames = request.bindings.flatMap(binding => [binding.global, ...binding.errorClass ? [binding.errorClass.name] : []])
     if (request.signal?.aborted) {
       return { logs: [], error: { kind: 'abort', message: String(request.signal.reason) } }
     }
     const key = request.principal && request.principal.length > 0 ? request.principal : AGENTLESS_KEY
     // reset=true abandons the persistent namespace: dispose the live kernel
     // and clear its on-disk snapshot BEFORE any dead-kernel or reuse logic,
     // so the next ensureKernel spawns a fresh, EMPTY kernel.
     if (request.reset) {
       await this.resetKey(key)
     }
 
     // A kernel that died since this key's last run is never silently reused:
     // its namespace is gone, and executing the program would surface a
     // misleading NameError instead of the substrate truth. The first run to
     // observe the death resolves with the explicit error (M3-B: after
-    // respawning onto the nearest replayable snapshot, so the message can
+    // respawning onto the nearest usable checkpoint, so the message can
     // name the turn) and the NEXT run continues on that restored kernel.
     // A kernel that died before ever completing a cell carried no user state
     // and is simply replaced (a prior SESSION's on-disk snapshot, if any, is
     // still restored by the normal first-boot path below).
     const dead = this.kernels.get(key)
     if (dead?.bridge.isDead) {
       this.kernels.delete(key)
       if (dead.ranCells) {
-        return await this.reviveAfterDeath(key, dead)
+        return await this.reviveAfterDeath(key, dead, false, bindingNames)
       }
     }
 
     let entry: KeyedKernel
     try {
       entry = await this.ensureKernel(key, request.cwd)
     } catch (error: unknown) {
       return finalizeOutput([], undefined, { kind: 'worker-exit', message: `kernel failed to start: ${messageOf(error)}` }, this.config.maxOutputBytes)
     }
     // First boot of this entry (fresh session OR resume OR revive): restore
     // the on-disk snapshot before any user code, once per boot. The notice is
     // consumed by the next COMPLETED run's logs, so the model learns where its
     // namespace came from (turn-N restored, or degraded-empty).
     if (!entry.restoreAttempted) {
       entry.restoreAttempted = true
-      const restore = await this.restoreEntry(entry)
+      const restore = await this.restoreEntry(entry, bindingNames)
       if (restore.kind === 'restored') {
-        entry.pendingNotice = `namespace restored from the turn-${restore.turn} snapshot`
+        entry.pendingNotice = `namespace restored from the turn-${restore.turn} snapshot${this.omissionNotice(restore.omitted)}`
       } else if (restore.kind === 'degraded') {
         entry.pendingNotice = `snapshot not replayable (${restore.reason}); started from an EMPTY namespace — re-create any state you need`
       }
     }
     const kernel = entry.bridge
 
     const specs: NamespaceSpecs = Object.fromEntries([...bindings.entries()].map(([global, namespace]) => [global, {
       functions: Object.keys(namespace.functions),
       ...namespace.callable ? { callable: true as const } : {},
       ...namespace.errorClass ? { errorClass: namespace.errorClass } : {},
@@ -339,41 +310,30 @@
     if (outcome.outcome === 'completed') {
       entry.ranCells = true
       entry.turn += 1
     } else if (outcome.outcome === 'forced' && outcome.failure.kind === 'worker-exit' && kernel.isDead && !this.disposed) {
       // The substrate died under this run. M3-B unifies this path with the
       // post-death-arrival branch: a kernel that had completed cells revives
       // onto its nearest snapshot and this run reports the turn-N loss; a
       // first-cell death has no state to lose and the run's own worker-exit
       // failure is the whole story.
       if (this.kernels.get(key) === entry) this.kernels.delete(key)
-      if (entry.ranCells) {
-        return await this.reviveAfterDeath(key, entry)
-      }
+      const revived = await this.reviveAfterDeath(key, entry, true, bindingNames)
+      return finalizeOutput(extractStream(outcome.streamText, sentinel).logs, revived.value, revived.error, this.config.maxOutputBytes)
     }
     let result = this.assembleResult(outcome, sentinel)
 
     if (outcome.outcome === 'completed') {
-      // Turn-end snapshot (M3-B, blueprint §8.3): after every successful run,
-      // size-capped. The cap warning is delivered ONCE per kernel to the
-      // model through the run's own logs; the first-run restore notice rides
-      // the same channel. Both are re-finalized so the outer-output cap stays
-      // honest even with the notices appended.
+      // Save completed cells even after user exceptions. Recovery notices
+      // share the same output ledger as user output.
       const snapshot = await this.snapshotTurnEnd(entry)
-      const notices: string[] = []
-      if (snapshot.skipped && !entry.warnedSnapshotSkip) {
-        entry.warnedSnapshotSkip = true
-        const detail = snapshot.estimateBytes !== undefined
-          ? `estimated ${snapshot.estimateBytes} bytes`
-          : `${snapshot.sizeBytes ?? 'unknown'} bytes serialized`
-        notices.push(`[dashr] namespace snapshot skipped: ${detail} exceeds snapshotSizeCapBytes (${this.config.snapshotSizeCapBytes}) — later turn-end snapshots are skipped while the namespace stays this large`)
-      }
+      const notices: string[] = snapshot ? [snapshot] : []
       if (entry.pendingNotice) {
         notices.push(`[dashr] ${entry.pendingNotice}`)
         entry.pendingNotice = undefined
       }
       if (notices.length > 0) {
         result = finalizeOutput([...result.logs, ...notices], result.value, result.error, this.config.maxOutputBytes)
       }
     }
     return result
   }
@@ -382,21 +342,24 @@
    * Read one user-namespace variable by name on the session's kernel. A
    * bare/empty name lists the namespace's user-variable names; a
    * JSON-serializable value resolves to its JSON text, any other value to its
    * `repr` text, and a missing name to `{ kind: 'missing' }`. When no live
    * kernel holds state for the key the namespace is empty (no spawn — this
    * channel never creates a kernel). Pure additive: the run/execute/snapshot
    * lifecycle is untouched.
    * @param name - the variable name, or empty to list namespace names.
    * @param principal - the session key (absent → the shared default).
    */
-  async queryVar(name: string, principal?: string): Promise<ReplVarQuery> {
+  queryVar(name: string, principal?: string): Promise<ReplVarQuery> {
+    return this.transaction(principal || AGENTLESS_KEY, () => this.queryTransaction(name, principal))
+  }
+  private async queryTransaction(name: string, principal?: string): Promise<ReplVarQuery> {
     if (this.disposed) throw new Error('dashr-repl: queryVar() after disposal')
     const key = principal && principal.length > 0 ? principal : AGENTLESS_KEY
     const bridge = this.kernels.get(key)?.bridge
     if (!bridge || !bridge.isRunning) {
       return name.trim().length === 0 ? { kind: 'names', names: [] } : { kind: 'missing' }
     }
     const outcome: QueryVarOutcome = await bridge.queryVar(name.trim().length === 0 ? null : name)
     switch (outcome.kind) {
       case 'json':
         return { kind: 'json', text: outcome.text }
@@ -414,45 +377,51 @@
   /**
    * Assign one lossless-JSON value into the user namespace under `name` on
    * the session's kernel. `name` must be a usable identifier (and not a
    * kernel-shim name); `value` must be lossless JSON. Requires a live kernel
    * for the key — the channel never spawns one, so a session that has not yet
    * run a cell must `run` first. Pure additive to the existing lifecycle.
    * @param name - the identifier to assign under.
    * @param value - the lossless-JSON value to bind.
    * @param principal - the session key (absent → the shared default).
    */
-  async setVar(name: string, value: unknown, principal?: string): Promise<void> {
+  setVar(name: string, value: unknown, principal?: string): Promise<void> {
+    return this.transaction(principal || AGENTLESS_KEY, () => this.setTransaction(name, value, principal))
+  }
+  private async setTransaction(name: string, value: unknown, principal?: string): Promise<void> {
     if (this.disposed) throw new Error('dashr-repl: setVar() after disposal')
     const trimmed = name.trim()
     if (trimmed.length === 0) {
       throw new Error('dashr-repl: setVar() requires a non-empty variable name')
     }
     if (!IDENTIFIER.test(trimmed)) {
       throw new Error(`dashr-repl: setVar() name ${JSON.stringify(trimmed)} is not a usable identifier`)
     }
-    if (KERNEL_OWNED_NAME.test(trimmed)) {
+    if (KERNEL_OWNED_NAME.test(trimmed) || RESERVED_BINDING_GLOBALS.has(trimmed) || trimmed === '__doc__') {
       throw new Error(`dashr-repl: setVar() name ${JSON.stringify(trimmed)} is reserved by the kernel`)
     }
     const jsonValue = snapshotJsonValue(value)
     if (jsonValue === undefined) {
       throw new Error('dashr-repl: setVar() value must be lossless JSON')
     }
     const key = principal && principal.length > 0 ? principal : AGENTLESS_KEY
     const bridge = this.kernels.get(key)?.bridge
     if (!bridge || !bridge.isRunning) {
       throw new Error('dashr-repl: setVar() requires a live kernel for this session — run a cell first')
     }
     const outcome: SetVarOutcome = await bridge.setVar(trimmed, JSON.stringify(jsonValue))
     if (outcome.kind === 'failed') {
       throw new Error(`dashr-repl: setVar(${JSON.stringify(trimmed)}) failed: ${outcome.reason}`)
     }
+    const entry = this.kernels.get(key)!
+    const notice = await this.snapshotTurnEnd(entry)
+    if (notice) entry.pendingNotice = [entry.pendingNotice, notice].filter(Boolean).join('; ')
   }
 
   /** Map one cell outcome onto the seam's result shape under the output ledger. */
   private assembleResult(outcome: CellOutcome, sentinel: string): CodeRunResult {
     const capture = extractStream(outcome.streamText, sentinel)
     const maxBytes = this.config.maxOutputBytes
 
     if (outcome.outcome === 'forced') {
       return finalizeOutput(capture.logs, undefined, outcome.failure, maxBytes)
     }
@@ -609,193 +578,150 @@
         key,
         cwd: kernelCwd,
         bridge: new IpyKernelBridge({
           python: (await this.resolveKernelPython()).python,
           ...kernelCwd ? { cwd: kernelCwd } : {},
           startupTimeoutMs: this.config.startupTimeoutMs,
           disposeTimeoutMs: this.config.disposeTimeoutMs,
           interruptConfirmMs: this.config.interruptConfirmMs,
           snapshotTimeoutMs: this.config.snapshotTimeoutMs,
           username: this.config.username,
+          snapshotDirectory: this.config.snapshotDir ? join(this.config.snapshotDir, keyDirectoryName(key)) : undefined,
+          snapshotSizeCapBytes: this.config.snapshotSizeCapBytes,
         }),
         ranCells: false,
         turn: 0,
       }
       this.kernels.set(key, entry)
     }
+    if (this.disposed) { await entry.bridge.dispose(); throw new Error('runtime disposed during startup') }
     await entry.bridge.start()
     return entry
   }
 
-  /**
-   * Restore a key's on-disk snapshot into a freshly booted kernel, when one
-   * exists and its manifest is plausible. Called once per entry boot. The
-   * kernel-side restore cell performs the authoritative environment checks
-   * (python version, interpreter identity, skills); this method only gates on
-   * the manifest the host can read cheaply, then records the turn so the
-   * first-run notice and the revive chain can name it.
-   */
-  private async restoreEntry(entry: KeyedKernel): Promise<RestoreOutcome> {
+  /** Restore once before user admission; any degraded load retires that child. */
+  private async restoreEntry(entry: KeyedKernel, bindingNames: string[]): Promise<RestoreOutcome> {
     if (!this.config.snapshotDir) return { kind: 'none' }
     const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
-    const payloadPath = join(dir, 'state.dill')
     const manifestPath = join(dir, 'manifest.json')
-    const manifest = this.readSnapshotManifest(entry.key)
-    if (manifest === undefined) return { kind: 'none' }
-    if (manifest.snapshotFormat !== SNAPSHOT_FORMAT) {
-      return { kind: 'degraded', reason: `snapshot format ${String(manifest.snapshotFormat)} is not replayable` }
-    }
-    if (manifest.skipped === true) return { kind: 'none' }
-    if (!existsSync(payloadPath)) return { kind: 'degraded', reason: 'snapshot payload is missing' }
-    const restored = await entry.bridge.restoreState(payloadPath, manifestPath)
+    if (!existsSync(manifestPath)) return { kind: 'none' }
+    const restored = await entry.bridge.restoreState(join(dir, 'state.dill'), manifestPath, bindingNames)
     if (restored.kind === 'restored') {
-      entry.turn = typeof manifest.turn === 'number' && Number.isSafeInteger(manifest.turn) && manifest.turn >= 0 ? manifest.turn : 0
-      entry.lastSnapshotTurn = entry.turn
+      entry.turn = restored.turn
+      entry.lastSnapshotTurn = restored.turn
       entry.ranCells = true
-      return { kind: 'restored', turn: entry.turn }
-    }
+      return { kind: 'restored', turn: restored.turn, omitted: restored.omitted }
+    }
+    // A malicious/failed reducer can mutate globals before failing. Retire the
+    // whole attempted interpreter before admitting any user cell.
+    await entry.bridge.dispose()
+    this.kernels.delete(entry.key)
+    const fresh = await this.ensureKernel(entry.key, entry.cwd)
+    entry.bridge = fresh.bridge
+    this.kernels.set(entry.key, entry)
     return { kind: 'degraded', reason: restored.reason }
   }
 
-  /** Read the per-key manifest's host-relevant fields; absent when unreadable/missing. */
-  private readSnapshotManifest(key: string): SnapshotManifest | undefined {
-    if (!this.config.snapshotDir) return undefined
-    try {
-      const manifest = JSON.parse(readFileSync(join(this.config.snapshotDir, keyDirectoryName(key), 'manifest.json'), 'utf8')) as SnapshotManifest
-      return manifest
-    } catch {
-      return undefined
-    }
-  }
-
-  /**
-   * Revive one session's kernel after death: respawn a fresh kernel, restore
-   * the nearest replayable snapshot onto it (the normal restore path), and
-   * return the death-observing run's explicit error naming the turn. When no
-   * replayable snapshot exists the message falls back to M3-A's fresh-empty
-   * contract. The run itself does NOT execute — an error that lies about a
-   * NameError costs the model more than one dropped cell (blueprint §8.3).
-   * @param key - the run principal.
-   * @param dead - the entry that died (its `turn` is the last completed turn).
-   */
-  private async reviveAfterDeath(key: string, dead: KeyedKernel): Promise<CodeRunResult> {
+  private omissionNotice(omitted: Record<string, string>): string {
+    const entries = Object.entries(omitted)
+    return entries.length ? `; partial coverage, omitted ${entries.map(([name, reason]) => `${name} (${reason})`).join(', ')}` : ''
+  }
+
+  /** Restore a fresh child and report whether the observing call had started. */
+  private async reviveAfterDeath(key: string, dead: KeyedKernel, started: boolean, bindingNames: string[]): Promise<CodeRunResult> {
+    const execution = started
+      ? 'This cell may have executed partially, including external side effects; inspect their state before choosing any retry. No user code was replayed.'
+      : 'This observing call did not execute. No user code was replayed.'
     let entry: KeyedKernel
     try {
       entry = await this.ensureKernel(key, dead.cwd)
     } catch (error: unknown) {
       return finalizeOutput([], undefined, {
         kind: 'worker-exit',
-        message: `kernel died and respawn failed (${messageOf(error)}); the next run will retry a fresh kernel`,
+        message: `kernel died and respawn failed (${messageOf(error)}); the next run will retry a fresh kernel. ${execution}`,
       }, this.config.maxOutputBytes)
     }
     entry.restoreAttempted = true
-    const restore = await this.restoreEntry(entry)
-    const observingTurn = dead.turn + 1
+    const restore = await this.restoreEntry(entry, bindingNames)
+    entry.turn = Math.max(entry.turn, dead.turn)
     if (restore.kind === 'restored') {
-      const lost = observingTurn - restore.turn
-      const rounds = lost === 1 ? 'round' : 'rounds'
       return finalizeOutput([], undefined, {
         kind: 'worker-exit',
-        message: `the kernel for this session died; its namespace was restored from the turn-${restore.turn} snapshot — the last ${lost} ${rounds} of variable operations must be replayed. This run did not execute.`,
+        message: `the kernel for this session died; its namespace was restored from the turn-${restore.turn} snapshot${this.omissionNotice(restore.omitted)}. Changes after that checkpoint may be lost. ${execution}`,
       }, this.config.maxOutputBytes)
     }
     const detail = restore.kind === 'degraded' ? ` (${restore.reason})` : ''
     return finalizeOutput([], undefined, {
       kind: 'worker-exit',
-      message: `the kernel for this session died and no replayable snapshot was available${detail}; the next run starts a fresh kernel with an EMPTY namespace — re-create any state you still need. This run did not execute.`,
+      message: `the kernel for this session died and no usable snapshot was available${detail}; the next run uses an EMPTY namespace. ${execution}`,
     }, this.config.maxOutputBytes)
   }
 
-  /**
-   * Write one key's turn-end snapshot, when a snapshot directory is
-   * configured. A size-cap skip is reported (so the run can warn the model
-   * once); other failures log without disturbing the run.
-   */
-  private async snapshotTurnEnd(entry: KeyedKernel): Promise<{ skipped: boolean, estimateBytes?: number, sizeBytes?: number }> {
-    if (!this.config.snapshotDir) return { skipped: false }
-    const kernel = entry.bridge
-    if (!kernel.isRunning) return { skipped: false }
+  /** Save completed mutations and expose partial/failed coverage within output limits. */
+  private async snapshotTurnEnd(entry: KeyedKernel): Promise<string | undefined> {
+    if (!this.config.snapshotDir || !entry.bridge.isRunning || this.disposed) return
     const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
-    mkdirSync(dir, { recursive: true })
+    mkdirSync(dir, { recursive: true, mode: 0o700 })
     const spec: SnapshotSpec = { turn: entry.turn, skills: [], sizeCapBytes: this.config.snapshotSizeCapBytes }
-    const outcome = await kernel.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
+    const outcome = await entry.bridge.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
     if (outcome.kind === 'ok') {
-      entry.lastSnapshotTurn = entry.turn
-      return { skipped: false }
-    }
-    if (outcome.kind === 'skipped') {
-      return { skipped: true, ...outcome.estimateBytes !== undefined ? { estimateBytes: outcome.estimateBytes } : {}, ...outcome.sizeBytes !== undefined ? { sizeBytes: outcome.sizeBytes } : {} }
-    }
-    this.logger.warn(`turn-end snapshot for ${JSON.stringify(entry.key)} failed: ${outcome.reason}`)
-    return { skipped: false }
-  }
-
-  /**
-   * Dispose to quiescence: snapshot every live key's namespace when a
-   * snapshot directory is configured (each under its own per-key
-   * subdirectory), then shut the subprocesses down. Registered as the
-   * plugin's `ctx.effect` disposer.
-   */
+      entry.lastSnapshotTurn = outcome.turn
+      const omission = this.omissionNotice(outcome.omitted)
+      const warning = outcome.warning ? `; ${outcome.warning}` : ''
+      return omission || warning ? `[dashr] turn-${outcome.turn} checkpoint saved${omission}${warning}` : undefined
+    }
+    const latest = entry.lastSnapshotTurn === undefined ? 'no successful checkpoint available' : `latest successful checkpoint is turn-${entry.lastSnapshotTurn}`
+    return `[dashr] namespace snapshot ${outcome.kind === 'skipped' ? 'skipped' : 'failed'}: ${outcome.reason}; ${latest}`
+  }
+
+  /** Cancel active work, drain admitted transactions, and reap every owned child. */
   private async teardown(): Promise<void> {
     this.disposed = true
-    const entries = [...this.kernels.values()]
+    // Cancel active children before draining transactions, so disposal never
+    // waits for a user cell's full timeout. Completed mutations already save.
+    await Promise.all([...this.kernels.values()].map(entry => entry.bridge.dispose()))
+    await Promise.allSettled([...this.transactions.values()])
+    await Promise.all([...this.kernels.values()].map(entry => entry.bridge.dispose()))
     this.kernels.clear()
-    await Promise.all(entries.map(entry => this.teardownKernel(entry)))
   }
 
   /**
    * Tear one session's kernel down (session end via the `agent/disposed`
    * listener). A no-op for keys that never ran code through this instance —
    * which is what makes hearing every agent's disposal safe.
    */
   private async destroyKey(key: string): Promise<void> {
-    const entry = this.kernels.get(key)
-    if (!entry) return
-    this.kernels.delete(key)
-    await this.teardownKernel(entry)
-  }
+    await this.kernels.get(key)?.bridge.dispose()
+    await this.transaction(key, async () => {
+      const entry = this.kernels.get(key)
+      this.kernels.delete(key)
+      await entry?.bridge.dispose()
+    })
+  }
+
   /**
    * Reset one session's kernel to a fresh, empty namespace: dispose the live
    * subprocess WITHOUT a turn-end snapshot and clear its on-disk snapshot, so
-   * the next ensureKernel spawns empty (restore finds nothing to replay).
+   * the next ensureKernel spawns empty (restore finds no checkpoint).
    */
   private async resetKey(key: string): Promise<void> {
     const entry = this.kernels.get(key)
     if (entry) {
       this.kernels.delete(key)
       await entry.bridge.dispose()
     }
     if (this.config.snapshotDir) {
       rmSync(join(this.config.snapshotDir, keyDirectoryName(key)), { recursive: true, force: true })
     }
   }
 
-  /** Snapshot (when configured) then dispose one key's kernel; failures log, never throw into a listener. */
-  private async teardownKernel(entry: KeyedKernel): Promise<void> {
-    const kernel = entry.bridge
-    if (this.config.snapshotDir && kernel.isRunning) {
-      try {
-        // Per-key subdirectory: sessions sharing one snapshotDir must not
-        // overwrite each other's state.dill.
-        const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
-        mkdirSync(dir, { recursive: true })
-        const spec: SnapshotSpec = { turn: entry.turn, skills: [], sizeCapBytes: this.config.snapshotSizeCapBytes }
-        const saved = await kernel.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
-        if (saved.kind !== 'ok' && saved.kind !== 'skipped') {
-          this.logger.warn(`kernel namespace snapshot for ${JSON.stringify(entry.key)} failed: ${saved.reason}`)
-        }
-      } catch (error: unknown) {
-        this.logger.warn(`kernel namespace snapshot for ${JSON.stringify(entry.key)} failed: ${messageOf(error)}`)
-      }
-    }
-    await kernel.dispose()
-  }
+
 }
 
 export default DashrRuntime
 
 /**
  * The vendored Service Definition's public contract, re-exported from the
  * package root so consumers (the sibling presentation package, its drift
  * tests, any future backend) can depend on the PUBLISHED shape instead of
  * reaching into `./src/*` (which the published tarball does not carry).
  */
```

```diff
--- baseline/better-dsh/test/helpers.ts
+++ current/better-dsh/test/helpers.ts
@@ -1,32 +1,39 @@
+import assert from 'node:assert/strict'
 import { existsSync } from 'node:fs'
 import { fileURLToPath } from 'node:url'
 import { Context } from '@deepseek-ai/cordis'
 import { onTestFinished } from 'vitest'
 import { DashrRuntime } from '../src/index.ts'
 import type { Config } from '../src/index.ts'
 
 const venvPython = fileURLToPath(new URL('../.venv-kernel/bin/python', import.meta.url))
 
 /** Interpreter for real-kernel tests: explicit override, package venv, then PATH. */
 export const KERNEL_PYTHON = process.env.DASHR_TEST_PYTHON ?? (existsSync(venvPython) ? venvPython : 'python3')
 
 /** Boot a fresh context with the eval provider mounted, worker-thread test style. */
 export async function setupRuntime(config: Config = {}): Promise<{ fiber: Awaited<ReturnType<Context['plugin']>>, runtime: DashrRuntime }> {
   const ctx = new Context()
   const fiber = await ctx.plugin(DashrRuntime, { python: KERNEL_PYTHON, ...config })
   const runtime = ctx.replRuntime as DashrRuntime
   // Dispose even when a spec forgets to: kernel children are not killed with
-  // the worker process, so an undisposed fiber leaks an idle ipykernel
+  // the worker process, so an undisposed fiber leaks an idle OMP
   // subprocess forever (208 leaked orphans were found mid-project). Double
   // disposal is safe — the fiber disposer is single-shot.
-  onTestFinished(() => fiber.dispose())
+  onTestFinished(async () => {
+    const ownedPids = runtime.kernelPids
+    await fiber.dispose()
+    for (const pid of ownedPids) {
+      assert.throws(() => process.kill(pid, 0), { code: 'ESRCH' }, `owned OMP child ${pid} survived disposal`)
+    }
+  })
   return { fiber, runtime }
 }
 
 import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
 import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
 import type { ToolExecutionResult } from '@deepseek-ai/dsh-tools'
 import { toolCallId } from '../src/tool-call-id.ts'
 import { createScope } from '@deepseek-ai/dsh-scope'
 import type { Scope } from '@deepseek-ai/dsh-scope'
 import type { Agent } from '@deepseek-ai/dsh-agent'
@@ -80,21 +87,21 @@
   config: Config = {},
   agentRoute?: { provider?: string, model?: string },
 ): Promise<Harness> {
   const ctx = new Context()
   await ctx.plugin(SystemPrompt, {})
   await ctx.plugin(ToolRuntime, {})
   if (runtime !== false) {
     const runtimeFiber = await runtime(ctx)
     // The runtime service (a real kernel provider owns a subprocess) must be
     // torn down with the test: its fiber disposer snapshots/shuts the kernel
-    // down, and skipping it leaks an ipykernel_launcher orphan (§10.9).
+    // down, and skipping it leaks an OMP runner orphan (§10.9).
     if (runtimeFiber && typeof (runtimeFiber as { dispose?: unknown }).dispose === 'function') {
       onTestFinished(async () => { await (runtimeFiber as { dispose(): Promise<void> }).dispose() })
     }
   }
 
   // A host fiber that injects the registry services, so contexts derived
   // from it may address `ctx.tools` / `ctx.systemPrompt` as properties (the
   // upstream code-mode spec's `mintAgentScope` does the same).
   let host!: Context
   await ctx.plugin(Object.assign((inner: Context) => { host = inner }, { inject: ['tools', 'systemPrompt'] }))
@@ -139,21 +146,21 @@
     },
   } as unknown as Agent
   return { agent, events }
 }
 
 /**
  * Boot the same composition with the REAL kernel provider (M1's
  * `DashrRuntime` from `dashr-repl`). One kernel boots
  * per test; the fiber's registered disposer shuts it down
  * (`onTestFinished`), and the acceptance gate asserts no orphan
- * `ipykernel_launcher` processes remain (blueprint §10.9).
+ * `OMP runner` processes remain (blueprint §10.9).
  */
 export async function setupKernel(
   presentationConfig: Config = {},
   kernelConfig: import('../src/runtime.ts').Config = {},
 ): Promise<Harness> {
   const { DashrRuntime } = await import('../src/runtime.ts')
   return setupPresentation(async (ctx) => ctx.plugin(DashrRuntime, {
     python: KERNEL_PYTHON,
     // Shorter budgets keep the suite fast while leaving the abort path
     // measurable.
```

```diff
--- baseline/better-dsh/test/interrupt-race.spec.ts
+++ current/better-dsh/test/interrupt-race.spec.ts
@@ -34,21 +34,21 @@
       const pending = runtime.run({ program: `race_marker = ${trial}`, bindings: [], signal: controller.signal })
       // Same tick as run(): the abort lands before the cell starts (and on
       // trial 1, before the kernel even finishes booting).
       controller.abort(`same-tick-${trial}`)
       const result = await pending
       expect(result.error?.kind, `trial ${trial}`).toBe('abort')
 
       // The kernel survived (same pid, state intact) — and if the aborted
       // cell did run to completion after the force-settle, its side effect
       // is benign; what must NEVER happen is the substrate dying.
-      const verify = await runtime.run({ program: `print("alive", race_marker is not None)`, bindings: [] })
+      const verify = await runtime.run({ program: 'print("alive")', bindings: [] })
       expect(verify.error, `trial ${trial}`).toBeUndefined()
     }
     expect(runtime.kernelPids).toHaveLength(1)
   }, 60_000)
 
   it('survives abort during cold boot — 10/10 fresh kernels', async () => {
     for (let trial = 1; trial <= 10; trial++) {
       const { runtime } = await setupRuntime(RACE_CONFIG)
       const controller = new AbortController()
       const pending = runtime.run({ program: 'print("boot-race")', bindings: [], signal: controller.signal })
```

```diff
--- baseline/better-dsh/test/kernel-env.spec.ts
+++ current/better-dsh/test/kernel-env.spec.ts
@@ -1,31 +1,34 @@
+import { execFileSync } from 'node:child_process'
+import { mkdtempSync, rmSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
 import { describe, expect, it } from 'vitest'
-import {
-  DILL_VERSION,
-  IPYKERNEL_VERSION,
-  pipInstallArgs,
-  uvInstallArgs,
-  uvToolEnv,
-  uvVenvArgs,
-  venvFallbackArgs,
-} from '../src/kernel-env.ts'
+import { resolveKernelEnv, uvToolEnv, uvVenvArgs, venvFallbackArgs } from '../src/kernel-env.ts'
 
-describe('kernel provisioning commands (pinned versions + cache redirection)', () => {
-  it('pins ipykernel and dill in both install paths', () => {
-    for (const args of [uvInstallArgs('/pkg/.venv-kernel/bin/python'), pipInstallArgs()]) {
-      expect(args).toContain(`ipykernel==${IPYKERNEL_VERSION}`)
-      expect(args).toContain(`dill==${DILL_VERSION}`)
-    }
+describe('Python environment resolution without consumer kernel packages', () => {
+  it('accepts an explicit stdlib-only venv without installing pip packages', async () => {
+    const dir = mkdtempSync(join(tmpdir(), 'better-env-'))
+    try {
+      execFileSync('python3', ['-m', 'venv', '--without-pip', dir])
+      const python = join(dir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
+      const env = await resolveKernelEnv({ python })
+      expect(env.python).toBe(python)
+      expect(env.managed).toBe(false)
+      expect(env.version).toMatch(/^3\./)
+      expect(execFileSync(python, ['-c', 'import importlib.util; print(any(importlib.util.find_spec(x) for x in ["pip", "ipykernel", "jupyter_client", "zmq", "dill"]))'], { encoding: 'utf8' }).trim()).toBe('False')
+    } finally { rmSync(dir, { recursive: true, force: true }) }
   })
-
-  it('redirects uv caches next to the venv so a read-only home cannot block provisioning', () => {
+  it('reports an actionable interpreter error', async () => {
+    await expect(resolveKernelEnv({ python: '/nonexistent/better-python' })).rejects.toThrow(/Python >=3.9.*Configure python/)
+  })
+  it('redirects uv caches next to the venv', () => {
     const env = uvToolEnv('/pkg/.venv-kernel')
     expect(env.UV_CACHE_DIR).toBe('/pkg/.uv-cache')
     expect(env.UV_PYTHON_INSTALL_DIR).toBe('/pkg/.uv-cache/python')
     expect(env.UV_LINK_MODE).toBe('copy')
   })
-
-  it('keeps the python3-venv fallback cache-free and shapes uv venv args', () => {
-    expect(venvFallbackArgs('/pkg/.venv-kernel')).toEqual(['-m', 'venv', '/pkg/.venv-kernel'])
-    expect(uvVenvArgs('/pkg/.venv-kernel', '3.11')).toEqual(['venv', '/pkg/.venv-kernel', '--python', '3.11'])
+  it('creates environments without pip and retains configured uv Python selection', () => {
+    expect(venvFallbackArgs('/pkg/env')).toEqual(['-m', 'venv', '--without-pip', '/pkg/env'])
+    expect(uvVenvArgs('/pkg/env', '3.11')).toEqual(['venv', '/pkg/env', '--python', '3.11'])
   })
 })
```

```diff
--- baseline/better-dsh/test/lifecycle.spec.ts
+++ current/better-dsh/test/lifecycle.spec.ts
@@ -57,21 +57,21 @@
     const snapshotDir = mkdtempSync(join(tmpdir(), 'dashr-snapshot-'))
     snapshotDirs.push(snapshotDir)
     const { fiber, runtime } = await setupRuntime({ snapshotDir })
     await runtime.run({ program: 'x = 40 + 2\npayload = {"kept": True}', bindings: [] })
     await fiber.dispose()
 
     // M3-A: snapshots are per-session — one subdirectory per kernel key
     // (this test's runs carry no principal, so the agentless default key).
     const keyDir = join(snapshotDir, '(agentless)')
     const manifestPath = join(keyDir, 'manifest.json')
-    expect(existsSync(join(keyDir, 'state.dill'))).toBe(true)
+    expect(existsSync(join(keyDir, JSON.parse(readFileSync(join(keyDir, 'manifest.json'), 'utf8')).payload))).toBe(true)
     expect(existsSync(manifestPath)).toBe(true)
     const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as { names: string[], pythonVersion: string }
     expect(manifest.names).toContain('x')
     expect(manifest.names).toContain('payload')
     expect(manifest.names).not.toContain('__dashr_program__')
     // IPython's own session plumbing (whose object graph is unpicklable) and
     // the shim names stay out of the snapshot — user state only.
     expect(manifest.names).not.toContain('get_ipython')
     expect(manifest.names).not.toContain('exit')
     expect(manifest.pythonVersion).toMatch(/^\d+\.\d+\.\d+$/)
```

```diff
--- baseline/better-dsh/test/omp-checkpoint-review.spec.ts
+++ current/better-dsh/test/omp-checkpoint-review.spec.ts
@@ -0,0 +1,157 @@
+import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { describe, expect, it, onTestFinished } from 'vitest'
+import { KERNEL_PYTHON, setupRuntime } from './helpers.ts'
+
+function directory() {
+  const dir = mkdtempSync(join(tmpdir(), 'better-checkpoint-review-'))
+  onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+  return dir
+}
+const request = (program: string) => ({ program, principal: 's', bindings: [] })
+const files = (dir: string) => readdirSync(join(dir, 's')).sort()
+const manifest = (dir: string) => JSON.parse(readFileSync(join(dir, 's', 'manifest.json'), 'utf8'))
+// Fault injection stays inside the owned child/helper module, out of user globals.
+function moduleCode(code: string) { return `exec(${JSON.stringify(code)}, __import__('better_snapshot').__dict__)` }
+
+describe('checkpoint review regressions', () => {
+  it('restores legal startup binding replacements alongside valuable state', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    expect((await first.runtime.run(request('display = 42\nvaluable = [1, 2]\nvalue = lambda: display'))).error).toBeUndefined()
+    expect(manifest(snapshotDir).names).toContain('display')
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('[display, valuable, value()]'))
+    expect(result.error).toBeUndefined()
+    expect(result.value).toEqual([42, [1, 2], 42])
+  })
+
+  it('prunes partial and inherited slot callbacks with missing globals transitively', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    const result = await first.runtime.run(request([
+      'import functools', 'good = [7]',
+      'class Bad:', '    def __reduce__(self): raise TypeError("bad value")', 'bad = Bad()',
+      'class Base:', '    __slots__ = ("callback",)',
+      'class Child(Base):', '    __slots__ = ()',
+      'slot = Child()', 'slot.callback = lambda: bad',
+      'wrapped = functools.partial(lambda: bad)',
+      'indirect = lambda: wrapped()', 'via_slot = lambda: slot.callback()',
+      'safe_slot = Child()', 'safe_slot.callback = lambda: good[0]',
+      'safe_partial = functools.partial(lambda n: good[0] + n, 2)',
+    ].join('\n')))
+    expect(result.error).toBeUndefined()
+    for (const name of ['bad', 'slot', 'wrapped', 'indirect', 'via_slot']) expect(manifest(snapshotDir).omitted).toHaveProperty(name)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const restored = await second.runtime.run(request('good = [9]\n[safe_slot.callback(), safe_partial(), "slot" in globals(), "wrapped" in globals(), "indirect" in globals(), "via_slot" in globals()]'))
+    expect(restored.error).toBeUndefined()
+    expect(restored.value).toEqual([9, 11, false, false, false, false])
+  })
+
+  it('cleans every uncommitted pointer-failure attempt while preserving current and previous payloads', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('kept = 1'))
+    await runtime.run(request('kept = 2'))
+    const before = files(snapshotDir)
+    const pointer = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const setup = moduleCode('def _test_replace(*args):\n    raise OSError("injected pointer failure")\nos.replace = _test_replace')
+    for (let n = 0; n < 3; n++) {
+      const result = await runtime.run(request(n === 0 ? setup : 'kept += 1'))
+      expect(result.logs.join(' ')).toMatch(/snapshot failed.*injected pointer failure/)
+      expect(files(snapshotDir)).toEqual(before)
+      expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(pointer)
+    }
+  })
+
+  it('cleans files written by an attempt whose deadline expires before commit', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir, snapshotTimeoutMs: 300 })
+    await runtime.run(request('kept = 1'))
+    const before = files(snapshotDir)
+    const result = await runtime.run(request(moduleCode([
+      '_test_original_write = _write_new',
+      'def _test_slow_write(path, data):',
+      '    _test_original_write(path, data)',
+      '    if path.endswith(".tmp"):',
+      '        try: time.sleep(0.5)',
+      '        except KeyboardInterrupt: pass',
+      '_write_new = _test_slow_write',
+    ].join('\n'))))
+    expect(result.logs.join(' ')).toMatch(/snapshot failed/)
+    expect(files(snapshotDir)).toEqual(before)
+    expect(manifest(snapshotDir).turn).toBe(1)
+  })
+
+  it('scavenges recognized crash orphans before a subsequent capped attempt', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir, snapshotSizeCapBytes: 5000 })
+    await runtime.run(request('kept = 1'))
+    await runtime.run(request('kept = 2'))
+    const before = files(snapshotDir)
+    writeFileSync(join(snapshotDir, 's', `state-${'a'.repeat(32)}.dill`), 'abandoned payload')
+    writeFileSync(join(snapshotDir, 's', `.checkpoint-${'b'.repeat(32)}.tmp`), 'abandoned manifest')
+    writeFileSync(join(snapshotDir, 's', 'unrelated.txt'), 'leave this')
+    const result = await runtime.run(request('huge = "x" * 20000'))
+    expect(result.logs.join(' ')).toMatch(/snapshot skipped/)
+    expect(files(snapshotDir)).toEqual([...before, 'unrelated.txt'].sort())
+    expect(manifest(snapshotDir).turn).toBe(2)
+  })
+
+  it('keeps a committed payload and reports a postcommit directory fsync failure truthfully', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 1'))
+    const result = await first.runtime.run(request(moduleCode([
+      'import stat as _test_stat', '_test_original_fsync = os.fsync',
+      'def _test_fsync(fd):',
+      '    if _test_stat.S_ISDIR(os.fstat(fd).st_mode): raise OSError("injected directory fsync failure")',
+      '    return _test_original_fsync(fd)', 'os.fsync = _test_fsync',
+    ].join('\n')) + '\nkept = 2'))
+    expect(result.logs.join(' ')).toMatch(/committed.*fsync/)
+    const saved = manifest(snapshotDir)
+    expect(saved.turn).toBe(2)
+    expect(existsSync(join(snapshotDir, 's', saved.payload))).toBe(true)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    expect((await second.runtime.run(request('kept'))).value).toBe(2)
+  })
+
+  it('keeps the pointed-to payload when replacement succeeds and its wrapper then throws', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 1'))
+    const result = await first.runtime.run(request(moduleCode([
+      '_test_original_replace = os.replace',
+      'def _test_replace_after(source, target):',
+      '    _test_original_replace(source, target)',
+      '    raise OSError("injected after pointer commit")',
+      'os.replace = _test_replace_after',
+    ].join('\n')) + '\nkept = 3'))
+    expect(result.logs.join(' ')).toMatch(/committed.*after pointer commit/)
+    const saved = manifest(snapshotDir)
+    expect(saved.turn).toBe(2)
+    expect(existsSync(join(snapshotDir, 's', saved.payload))).toBe(true)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    expect((await second.runtime.run(request('kept'))).value).toBe(3)
+  })
+
+  it('retains partial-execution wording when a side-effecting cell cannot respawn', async () => {
+    const dir = directory()
+    const marker = join(dir, 'side-effect')
+    const python = join(dir, 'python-wrapper')
+    const quote = (value: string) => "'" + value.replaceAll("'", "'\\''") + "'"
+    writeFileSync(python, `#!/bin/sh\nif [ -f ${quote(marker)} ]; then exit 7; fi\nexec ${quote(KERNEL_PYTHON)} "$@"\n`, { mode: 0o700 })
+    const { runtime } = await setupRuntime({ python, snapshotDir: join(dir, 'snapshots') })
+    await runtime.run(request('kept = 1'))
+    const result = await runtime.run(request(`import os\nwith open(${JSON.stringify(marker)}, "w") as f:\n    f.write("once")\nos._exit(1)`))
+    expect(result.error?.message).toMatch(/respawn failed/)
+    expect(result.error?.message).toMatch(/may have executed partially/)
+    expect(result.error?.message).toMatch(/No user code was replayed/)
+    expect(readFileSync(marker, 'utf8')).toBe('once')
+  })
+})
```

```diff
--- baseline/better-dsh/test/omp-checkpoint-safety.spec.ts
+++ current/better-dsh/test/omp-checkpoint-safety.spec.ts
@@ -0,0 +1,205 @@
+import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, symlinkSync, writeFileSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { createHash } from 'node:crypto'
+import { Context } from '@deepseek-ai/cordis'
+import type { ProfileContext } from '@deepseek-ai/dsh-app-boot'
+import { describe, expect, it, onTestFinished } from 'vitest'
+import { DashrRuntime } from '../src/runtime.ts'
+import { KERNEL_PYTHON, setupRuntime } from './helpers.ts'
+
+function directory() {
+  const dir = mkdtempSync(join(tmpdir(), 'better-checkpoint-safety-'))
+  onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+  return dir
+}
+function manifest(dir: string) { return JSON.parse(readFileSync(join(dir, 's', 'manifest.json'), 'utf8')) }
+const request = (program: string) => ({ program, principal: 's', bindings: [] })
+
+describe('checkpoint safety and truthful outcomes', () => {
+  it('omits captured proxies and transitive missing globals but permits fresh global tools', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    const bindings = [{ global: 'tool', callable: true as const, functions: { call: async () => 'old' } }]
+    const save = await first.runtime.run({ ...request([
+      'good = [1]', 'alias = good', 'class Bad:', '    def __reduce__(self): raise TypeError("bad value")',
+      'bad = Bad()', 'dependent = lambda: bad', 'indirect = lambda: dependent()',
+      'class Getter:', '    def get(self): return bad', 'getter = Getter()',
+      'def capture(value): return lambda: value', 'captured = capture(tool)',
+      'fresh = lambda: tool({})', '_user_private = 7',
+    ].join('\n')), bindings })
+    expect(save.error).toBeUndefined()
+    expect(save.logs.join('\n')).toMatch(/partial.*bad/s)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run({ ...request('[good is alias, await fresh(), _user_private, "dependent" in globals(), "indirect" in globals(), "getter" in globals(), "captured" in globals()]'), bindings: [{ ...bindings[0]!, functions: { call: async () => 'fresh' } }] })
+    expect(result.error).toBeUndefined()
+    expect(result.value).toEqual([true, 'fresh', 7, false, false, false, false])
+    const names = await second.runtime.queryVar('', 's')
+    expect(names.kind).toBe('names')
+    if (names.kind === 'names') expect(names.names).not.toEqual(expect.arrayContaining(['tool', '__omp_with_call_site__']))
+  })
+
+  it.each(['manifest', 'payload', 'environment'])('rejects corrupt %s before restoring and stays usable', async mode => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 9'))
+    await first.fiber.dispose()
+    const m = manifest(snapshotDir)
+    if (mode === 'manifest') writeFileSync(join(snapshotDir, 's', 'manifest.json'), '{broken')
+    else if (mode === 'payload') writeFileSync(join(snapshotDir, 's', m.payload), 'broken')
+    else { m.pythonVersion = '0.0.0'; writeFileSync(join(snapshotDir, 's', 'manifest.json'), JSON.stringify(m)) }
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('"kept" in globals()'))
+    expect(result.error).toBeUndefined()
+    expect(result.value).toBe(false)
+    expect(result.logs.join('\n')).toMatch(/snapshot.*(failed|not replayable|unavailable)/i)
+  })
+
+  it('retains the previous generation on cap and serialization timeout', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir, snapshotSizeCapBytes: 5000, snapshotTimeoutMs: 300 })
+    await first.runtime.run(request('kept = 11'))
+    const committed = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const cap = await first.runtime.run(request('huge = "x" * 20000'))
+    expect(cap.logs.join('\n')).toMatch(/snapshot.*skipped/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(committed)
+    const slow = await first.runtime.run(request('del huge\nimport time\nclass Slow:\n    def __reduce__(self):\n        time.sleep(5)\n        return (int, (3,))\nslow = Slow()'))
+    expect(slow.logs.join('\n')).toMatch(/snapshot.*failed/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(committed)
+    expect((await first.runtime.queryVar('kept', 's')).kind).toBe('json')
+    process.kill(first.runtime.kernelPids[0]!, 'SIGKILL')
+    const second = await setupRuntime({ snapshotDir })
+    expect((await second.runtime.run(request('kept'))).value).toBe(11)
+  })
+
+  it('raw reset removes prior generations and preserves callable helpers', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('old = 1'))
+    const old = manifest(snapshotDir).payload
+    const result = await runtime.run(request('%reset\nnew = 2'))
+    expect(result.error).toBeUndefined()
+    expect(existsSync(join(snapshotDir, 's', old))).toBe(false)
+    expect((await runtime.queryVar('', 's'))).toEqual({ kind: 'names', names: ['new'] })
+    expect(manifest(snapshotDir).names).toEqual(['new'])
+    expect(statSync(join(snapshotDir, 's')).mode & 0o777).toBe(0o700)
+    for (const name of readdirSync(join(snapshotDir, 's'))) expect(statSync(join(snapshotDir, 's', name)).mode & 0o777).toBe(0o600)
+  })
+
+  it('does not replay or deny a side effect performed by the dying cell', async () => {
+    const snapshotDir = directory()
+    const marker = join(snapshotDir, 'side-effect.txt')
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('kept = 17'))
+    const died = await runtime.run(request(`import os\nwith open(${JSON.stringify(marker)}, "a") as output:\n    output.write("once")\nprint("side effect written", flush=True)\nos._exit(1)`))
+    expect(died.error?.kind).toBe('worker-exit')
+    expect(died.logs).toContain('side effect written')
+    expect(died.error?.message).toMatch(/may have executed|partially executed/)
+    expect(died.error?.message).not.toMatch(/must be replayed|did not execute/)
+    expect(readFileSync(marker, 'utf8')).toBe('once')
+    expect((await runtime.run(request('kept'))).value).toBe(17)
+    expect(readFileSync(marker, 'utf8')).toBe('once')
+  })
+
+  it('refuses an aggregate graph failure without replacing the checkpoint', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('kept = 23'))
+    const previous = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const result = await runtime.run(request('class Unstable:\n    calls = 0\n    def __reduce__(self):\n        type(self).calls += 1\n        if type(self).calls > 1: raise ValueError("aggregate failure")\n        return (int, (4,))\nunstable = Unstable()'))
+    expect(result.logs.join(' ')).toMatch(/snapshot failed.*aggregate failure/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(previous)
+  })
+
+  it('retains the checkpoint even when a reducer catches its timeout interrupt', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir, snapshotTimeoutMs: 300 })
+    await runtime.run(request('kept = 29'))
+    const previous = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const result = await runtime.run(request('import time\nclass Slow:\n    def __reduce__(self):\n        try: time.sleep(0.4)\n        except KeyboardInterrupt: pass\n        return (int, (4,))\nslow = Slow()'))
+    expect(result.logs.join(' ')).toMatch(/snapshot failed/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(previous)
+  })
+
+  it('rejects internal setVar names while retaining genuine private user names', async () => {
+    const { runtime } = await setupRuntime()
+    await runtime.run(request('value = 1'))
+    for (const name of ['__name__', '__builtins__', '__omp_magic']) {
+      await expect(runtime.setVar(name, 7, 's')).rejects.toThrow(/reserved/)
+    }
+    await runtime.setVar('_private', 9, 's')
+    expect(await runtime.queryVar('', 's')).toEqual({ kind: 'names', names: ['_private', 'value'] })
+    expect((await runtime.run(request('value + _private'))).value).toBe(10)
+  })
+
+  it('retains at most two immutable generations after successful commits', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    for (let n = 0; n < 5; n++) await runtime.run(request(`kept = ${n}`))
+    const files = readdirSync(join(snapshotDir, 's')).filter(name => name.endsWith('.dill'))
+    expect(files).toHaveLength(2)
+    expect(files).toContain(manifest(snapshotDir).payload)
+  })
+
+  it('rejects a symlinked manifest instead of importing another session', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 1'))
+    await first.fiber.dispose()
+    const outside = join(snapshotDir, 'external.json')
+    const path = join(snapshotDir, 's', 'manifest.json')
+    writeFileSync(outside, readFileSync(path))
+    rmSync(path)
+    symlinkSync(outside, path)
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('"kept" in globals()'))
+    expect(result.value).toBe(false)
+    expect(result.logs.join(' ')).toMatch(/symlink/)
+  })
+
+  it('reports missing current host bindings when restoring dependent functions', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run({ ...request('fresh = lambda: tool({})'), bindings: [{ global: 'tool', callable: true, functions: { call: async () => 1 } }] })
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('"fresh" in globals()'))
+    expect(result.value).toBe(false)
+    expect(result.logs.join(' ')).toMatch(/missing.*binding.*tool/)
+  })
+
+  it('serializes queries, assignments and reset around an active cell', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    const running = runtime.run(request('import asyncio\nx = 1\nawait asyncio.sleep(0.05)\nx = 2'))
+    const queried = runtime.queryVar('x', 's')
+    const assigned = runtime.setVar('x', 3, 's')
+    const reset = runtime.run({ ...request('"x" in globals()'), reset: true })
+    expect((await running).error).toBeUndefined()
+    expect(await queried).toEqual({ kind: 'json', text: '2' })
+    await assigned
+    expect((await reset).value).toBe(false)
+    expect((await runtime.queryVar('x', 's')).kind).toBe('missing')
+  })
+
+  it('uses official profile home and respects explicit disable', async () => {
+    const home = directory()
+    const profileDir = join(home, 'profiles', 'work')
+    const root = join(home, 'better-dsh', 'python-repl', createHash('sha256').update(profileDir).digest('hex'))
+    const ctx = new Context()
+    const profile = { home, dir: profileDir, name: 'work', patchPath: join(profileDir, 'cordis.patch.yml'), installAnchor: profileDir, cwd: home, startedBundles: [], overlays: [], telemetryDisabledEnv: '1' } satisfies ProfileContext
+    ctx.provide('profileContext', profile)
+    const fiber = await ctx.plugin(DashrRuntime, { python: KERNEL_PYTHON })
+    onTestFinished(() => fiber.dispose())
+    await ctx.replRuntime.run(request('kept = 1'))
+    expect(existsSync(join(root, 's', 'manifest.json'))).toBe(true)
+    await fiber.dispose()
+    const disabled = new Context()
+    disabled.provide('profileContext', profile)
+    const other = await disabled.plugin(DashrRuntime, { python: KERNEL_PYTHON, snapshotDir: '' })
+    onTestFinished(() => other.dispose())
+    const result = await disabled.replRuntime.run(request('"kept" in globals()'))
+    expect(result.value).toBe(false)
+  })
+})
```

```diff
--- baseline/better-dsh/test/omp-checkpoints.spec.ts
+++ current/better-dsh/test/omp-checkpoints.spec.ts
@@ -0,0 +1,91 @@
+import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { describe, expect, it, onTestFinished } from 'vitest'
+import { setupRuntime } from './helpers.ts'
+
+function checkpointDirectory(): string {
+  const dir = mkdtempSync(join(tmpdir(), 'better-omp-checkpoint-'))
+  onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+  return dir
+}
+
+describe('OMP checkpoint object graph and operation ordering', () => {
+  it('restores aliases, closures and class methods into the live fresh namespace', async () => {
+    const snapshotDir = checkpointDirectory()
+    const first = await setupRuntime({ snapshotDir })
+    const saved = await first.runtime.run({ principal: 'graph', bindings: [], program: [
+      'x = [1, 2]', 'alias = x', 'f = lambda n: x[0] + n',
+      'def make_closure(value):', '    return lambda n: value + n',
+      'closure = make_closure(10)',
+      'class Counter:', '    def current(self):', '        return x[0]',
+      'instance = Counter()', 'cycle = []', 'cycle.append(cycle)',
+    ].join('\n') })
+    expect(saved.error).toBeUndefined()
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const restored = await second.runtime.run({ principal: 'graph', bindings: [], program: [
+      'assert x is alias and cycle[0] is cycle',
+      'assert f(4) == 5 and closure(2) == 12 and instance.current() == 1',
+      'x = [9]',
+      'assert f.__globals__ is globals()',
+      'assert Counter.current.__globals__ is globals()',
+      '[f(4), instance.current(), closure(2)]',
+    ].join('\n') })
+    expect(restored.error).toBeUndefined()
+    expect(restored.value).toEqual([13, 9, 12])
+    expect(restored.logs.join('\n')).toContain('restored')
+  })
+
+  it('reports partial coverage for bad values and nested live handles while retaining good aliases', async () => {
+    const snapshotDir = checkpointDirectory()
+    const first = await setupRuntime({ snapshotDir })
+    const saved = await first.runtime.run({ principal: 'partial', bindings: [], program: [
+      'import threading', 'import os',
+      'good = [42]', 'good_alias = good',
+      'class Bad:', '    def __reduce__(self):', '        raise TypeError("cannot checkpoint this value")',
+      'bad = Bad()', 'nested_handle = {"file": open(os.devnull, "r")}',
+      'nested_lock = [threading.Lock()]',
+    ].join('\n') })
+    expect(saved.error).toBeUndefined()
+    expect(saved.logs.join('\n')).toMatch(/partial|omitted|skipped/i)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const restored = await second.runtime.run({ principal: 'partial', bindings: [], program: [
+      'assert good is good_alias',
+      '[good[0], "bad" in globals(), "nested_handle" in globals(), "nested_lock" in globals()]',
+    ].join('\n') })
+    expect(restored.error).toBeUndefined()
+    expect(restored.value).toEqual([42, false, false, false])
+    expect(restored.logs.join('\n')).toMatch(/partial|omitted|skipped/i)
+  })
+
+  it('serializes cold same-session runs and commits the matching completed-cell sequence', async () => {
+    const snapshotDir = checkpointDirectory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    const [first, second] = await Promise.all([
+      runtime.run({ principal: 'cold', bindings: [], program: 'counter = 1' }),
+      runtime.run({ principal: 'cold', bindings: [], program: 'counter += 1\ncounter' }),
+    ])
+    expect(first.error).toBeUndefined()
+    expect(second.error).toBeUndefined()
+    expect(second.value).toBe(2)
+    expect(runtime.kernelPids).toHaveLength(1)
+    const manifest = JSON.parse(readFileSync(join(snapshotDir, 'cold', 'manifest.json'), 'utf8'))
+    expect(manifest.turn).toBe(2)
+  })
+
+  it('checkpoints mutations before a user exception and subsequent setVar assignments', async () => {
+    const snapshotDir = checkpointDirectory()
+    const first = await setupRuntime({ snapshotDir })
+    const errored = await first.runtime.run({ principal: 'exception', bindings: [], program: 'before_error = 73\nraise ValueError("expected")' })
+    expect(errored.error?.kind).toBe('exception')
+    await first.runtime.setVar('from_host', { value: 42 }, 'exception')
+    // Deliberately kill rather than dispose: dispose itself must not be the only save trigger.
+    process.kill(first.runtime.kernelPids[0]!, 'SIGKILL')
+    const second = await setupRuntime({ snapshotDir })
+    const restored = await second.runtime.run({ principal: 'exception', bindings: [], program: '[before_error, from_host["value"]]' })
+    expect(restored.error).toBeUndefined()
+    expect(restored.value).toEqual([73, 42])
+  })
+})
```

```diff
--- baseline/better-dsh/test/omp-execution.spec.ts
+++ current/better-dsh/test/omp-execution.spec.ts
@@ -0,0 +1,195 @@
+import { describe, expect, it } from 'vitest'
+import { setupRuntime } from './helpers.ts'
+import { IpyKernelBridge } from '../src/kernel.ts'
+
+function alive(pid: number): boolean {
+  try { process.kill(pid, 0); return true } catch { return false }
+}
+
+describe('OMP runner adaptation boundaries', () => {
+  it('stops native foreground shell descendants before returning timeout and retains the runner', async () => {
+    if (process.platform !== 'linux') return
+    const { runtime } = await setupRuntime({ runTimeoutMs: 250, interruptGraceMs: 800, interruptConfirmMs: 20 })
+    await runtime.run({ program: '42', bindings: [] })
+    const runnerPid = runtime.kernelPid
+    const result = await runtime.run({ program: '!echo $$; sleep 20', bindings: [] })
+    expect(result.error?.kind).toBe('timeout')
+    const shellPid = Number(result.logs.find(line => /^\d+$/.test(line.trim())))
+    expect(shellPid).toBeGreaterThan(0)
+    expect(alive(shellPid)).toBe(false)
+    const after = await runtime.run({ program: '42', bindings: [] })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+    expect(runtime.kernelPid).toBe(runnerPid)
+  })
+
+  it('kills new Popen descendants ignoring SIGINT and SIGTERM before returning timeout', async () => {
+    if (process.platform !== 'linux') return
+    const { runtime } = await setupRuntime({ runTimeoutMs: 300, interruptGraceMs: 800, interruptConfirmMs: 20 })
+    const persistent = await runtime.run({ program: 'import subprocess,sys\nprior = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(20)"])\nprior.pid', bindings: [] })
+    const priorPid = Number(persistent.value)
+    expect(priorPid).toBeGreaterThan(0)
+    const runnerPid = runtime.kernelPid
+    const childCode = 'import signal,time; signal.signal(signal.SIGINT,signal.SIG_IGN); signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(20)'
+    const result = await runtime.run({ program: [
+      'import subprocess,sys,time',
+      `p = subprocess.Popen([sys.executable, "-c", ${JSON.stringify(childCode)}])`,
+      'print(p.pid, flush=True)',
+      'time.sleep(20)',
+    ].join('\n'), bindings: [] })
+    expect(result.error?.kind).toBe('timeout')
+    const childPid = Number(result.logs.find(line => /^\d+$/.test(line.trim())))
+    expect(childPid).toBeGreaterThan(0)
+    expect(alive(childPid)).toBe(false)
+    expect(alive(priorPid)).toBe(true)
+    const after = await runtime.run({ program: 'prior.terminate()\nprior.wait()\n42', bindings: [] })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+    expect(runtime.kernelPid).toBe(runnerPid)
+  })
+
+  it('cleans new subprocesses even when user code catches the timeout KeyboardInterrupt', async () => {
+    if (process.platform !== 'linux') return
+    const { runtime } = await setupRuntime({ runTimeoutMs: 250, interruptGraceMs: 800, interruptConfirmMs: 20 })
+    await runtime.run({ program: '42', bindings: [] })
+    const runnerPid = runtime.kernelPid
+    const result = await runtime.run({ program: [
+      'import subprocess,sys,time',
+      'p = subprocess.Popen([sys.executable, "-c", "import signal,time; signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(20)"])',
+      'print(p.pid, flush=True)',
+      'try:',
+      '    time.sleep(20)',
+      'except KeyboardInterrupt:',
+      '    pass',
+      '"caught"',
+    ].join('\n'), bindings: [] })
+    expect(result.error?.kind).toBe('timeout')
+    const childPid = Number(result.logs.find(line => /^\d+$/.test(line.trim())))
+    expect(childPid).toBeGreaterThan(0)
+    expect(alive(childPid)).toBe(false)
+    const after = await runtime.run({ program: '42', bindings: [] })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+    expect(runtime.kernelPid).toBe(runnerPid)
+  })
+
+  it('runs native tool.read through the runner call-site helper and preserves typed rejection', async () => {
+    const { runtime } = await setupRuntime()
+    const calls: unknown[] = []
+    const bindings = [{ global: 'tool', functions: { read: async (args: unknown) => {
+      calls.push(args)
+      if ((args as { path?: string }).path === 'bad') throw new Error('read rejected')
+      return { content: 'read-ok' }
+    } }, errorClass: { name: 'ToolCallError', memberNameProperty: 'toolName' } }]
+    const result = await runtime.run({ program: 'await tool.read({"path": "ok"})', bindings })
+    expect(result.error).toBeUndefined()
+    expect(result.value).toEqual({ content: 'read-ok' })
+    const rejected = await runtime.run({ program: [
+      'try:',
+      '    await tool.read({"path": "bad"})',
+      'except ToolCallError as error:',
+      '    caught = {"name": error.toolName, "message": str(error)}',
+      'caught',
+    ].join('\n'), bindings })
+    expect(rejected.error).toBeUndefined()
+    expect(rejected.value).toEqual({ name: 'read', message: 'read rejected' })
+    expect(calls).toEqual([{ path: 'ok' }, { path: 'bad' }])
+  })
+
+  it('reinstalls the input guard immediately after native %reset in the same cell', async () => {
+    const { runtime } = await setupRuntime({ runTimeoutMs: 150, interruptGraceMs: 150, interruptConfirmMs: 20 })
+    const result = await runtime.run({ program: '%reset\ninput("question")', bindings: [] })
+    expect(result.error?.kind).toBe('exception')
+    expect(result.error?.message).toContain('Interactive stdin is unsupported')
+    const after = await runtime.run({ program: '42', bindings: [] })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+  })
+
+  it('reinstalls current tool bindings immediately after native %reset', async () => {
+    const { runtime } = await setupRuntime()
+    const result = await runtime.run({ program: '%reset\nawait tool.read({"path": "ok"})',
+      bindings: [{ global: 'tool', functions: { read: async () => 'ok' } }] })
+    expect(result.error).toBeUndefined()
+    expect(result.value).toBe('ok')
+  })
+
+  it('keeps synthetic execution file metadata out of the user namespace', async () => {
+    const { runtime } = await setupRuntime()
+    await runtime.run({ program: '42', bindings: [] })
+    const names = await runtime.queryVar('')
+    expect(names).toEqual({ kind: 'names', names: [] })
+  })
+
+  it('runs binding fanout concurrently and preserves gather order', async () => {
+    const { runtime } = await setupRuntime()
+    let active = 0
+    let peak = 0
+    const result = await runtime.run({
+      program: 'import asyncio\nawait asyncio.gather(tools.echo(1), tools.echo(2), tools.echo(3))',
+      bindings: [{ global: 'tools', functions: { echo: async value => {
+        active++
+        peak = Math.max(peak, active)
+        await new Promise(resolve => setTimeout(resolve, 40))
+        active--
+        return Number(value)
+      } } }],
+    })
+    expect(result.error).toBeUndefined()
+    expect(result.value).toEqual([1, 2, 3])
+    expect(peak).toBe(3)
+  })
+
+  it('rejects detached old-cell callbacks before invoking the host', async () => {
+    const { runtime } = await setupRuntime()
+    let calls = 0
+    const bindings = [{ global: 'tools', functions: { echo: async () => { calls++; return 1 } } }]
+    const first = await runtime.run({ program: [
+      'import asyncio',
+      'async def later():',
+      '    await asyncio.sleep(0.1)',
+      '    try:',
+      '        await tools.echo({})',
+      '    except Exception:',
+      '        pass',
+      'background = asyncio.create_task(later())',
+    ].join('\n'), bindings })
+    expect(first.error).toBeUndefined()
+    const after = await runtime.run({ program: 'await asyncio.sleep(0.2)\n42', bindings })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+    expect(calls).toBe(0)
+  })
+
+  it('captures native subprocess stdout without corrupting JSON protocol', async () => {
+    const { runtime } = await setupRuntime()
+    const result = await runtime.run({ program: 'import subprocess, sys\nsubprocess.run([sys.executable, "-c", "print(12345)"], check=True)\nawait __import__("asyncio").sleep(0.05)\n42', bindings: [] })
+    expect(result.error).toBeUndefined()
+    expect(result.logs.join('\n')).toContain('12345')
+    expect(result.value).toBe(42)
+  })
+
+  it('rejects interactive input immediately with an actionable message', async () => {
+    const { runtime } = await setupRuntime()
+    const result = await runtime.run({ program: 'input("prompt")', bindings: [] })
+    expect(result.error?.message).toContain('Interactive stdin is unsupported')
+    const after = await runtime.run({ program: '42', bindings: [] })
+    expect(after.value).toBe(42)
+  })
+
+  it('reaps an interrupt-resistant child before returning cancellation', async () => {
+    if (process.platform === 'win32') return
+    const bridge = new IpyKernelBridge({ python: 'python3', startupTimeoutMs: 3_000,
+      disposeTimeoutMs: 1_000, interruptConfirmMs: 10, snapshotTimeoutMs: 3_000, username: 'test' })
+    try {
+      await bridge.start()
+      const pid = bridge.pid!
+      const result = await bridge.executeCell('import signal, time\nsignal.signal(signal.SIGINT, signal.SIG_IGN)\ntime.sleep(30)', {
+        timeoutMs: 100, interruptGraceMs: 100, interruptConfirmMs: 10,
+      })
+      expect(result.outcome).toBe('forced')
+      expect(bridge.isDead).toBe(true)
+      expect(alive(pid)).toBe(false)
+    } finally { await bridge.dispose() }
+  })
+})
```

```diff
--- baseline/better-dsh/test/presentation.spec.ts
+++ current/better-dsh/test/presentation.spec.ts
@@ -226,21 +226,21 @@
     const assembly = await ctx.systemPrompt.assemble({ scope: agent.agent })
     const evalTool = assembly.tools.find(tool => tool.name === 'eval')
     expect(evalTool?.description).toContain('not plain identifiers')
     expect(evalTool?.description).not.toContain('`__` infixes')
   })
 
   it('eval description equals the packaged markdown, and its example keys exist on the referenced tools\' wire schemas', async () => {
     const { ctx, agent } = await setupPresentation(fakeRuntime)
     // The real wire parameter names of the tools the description exemplifies.
     const wireParams: Record<string, string[]> = {
-      read: ['path', 'offset', 'limit'],
+      read: ['file_path', 'offset', 'limit'],
       bash: ['command', 'description', 'timeoutMs', 'workdir', 'run_in_background', 'sandbox_permissions', 'justification'],
       grep: ['pattern', 'path', 'include'],
       glob: ['pattern', 'path'],
     }
     for (const [name, properties] of Object.entries(wireParams)) {
       ctx.tools.register(defineTool({
         name,
         description: `Fake ${name} (wire-shape fixture).`,
         parameters: Object.fromEntries(properties.map(key => [key, { type: 'string' }])),
         output: { schema: { type: 'string' }, render: (_args, value) => [{ type: 'text', text: String(value) }] },
```

```diff
--- baseline/better-dsh/test/runtime.spec.ts
+++ current/better-dsh/test/runtime.spec.ts
@@ -1,20 +1,52 @@
+import { execFileSync } from 'node:child_process'
+import { mkdtempSync, rmSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { onTestFinished } from 'vitest'
 import { describe, expect, it } from 'vitest'
 import type { CodeRunResult } from '../src/vendored/repl-runtime.ts'
-import { setupRuntime } from './helpers.ts'
+import { KERNEL_PYTHON, setupRuntime } from './helpers.ts'
 
 /**
- * Integration suite over a REAL ipykernel subprocess (no mocks — kernels are
+ * Integration suite over a REAL OMP Python subprocess (no mocks — kernels are
  * local and cheap once booted, per dsh's real-over-mock policy). Each test
  * builds a fresh context and shares nothing with the others.
  */
 describe('DashrRuntime — programs on a persistent kernel', () => {
+  it('runs persistent Python without pip, ipykernel, Jupyter, ZMQ or external dill', async () => {
+    const dir = mkdtempSync(join(tmpdir(), 'better-stdlib-'))
+    onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+    execFileSync('python3', ['-m', 'venv', '--without-pip', dir])
+    const python = join(dir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
+    const { fiber, runtime } = await setupRuntime({ python })
+    const first = await runtime.run({ program: 'x = 40', bindings: [] })
+    expect(first.error).toBeUndefined()
+    const second = await runtime.run({ program: 'x + 2', bindings: [] })
+    expect(second.error).toBeUndefined()
+    expect(second.value).toBe(42)
+    await fiber.dispose()
+  })
+
+  it('preserves OMP magic and shell source transformation, including helpers after %reset', async () => {
+    const { runtime } = await setupRuntime()
+    const result = await runtime.run({ program: '!echo omp-shell\n%pwd', bindings: [] })
+    expect(result.error).toBeUndefined()
+    expect(result.logs.join('\n')).toContain('omp-shell')
+    expect(typeof result.value).toBe('string')
+    const reset = await runtime.run({ program: '%reset', bindings: [] })
+    expect(reset.error).toBeUndefined()
+    const after = await runtime.run({ program: '40 + 2', bindings: [] })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+  })
+
   it('registers with the seam descriptors', async () => {
     const { runtime } = await setupRuntime()
     expect(runtime.language).toBe('python')
     expect(runtime.isolation).toBe('process')
   })
 
   it('is stateful: variables from one run survive into the next', async () => {
     const { runtime } = await setupRuntime()
     const first = await runtime.run({ program: 'x = 40 + 2', bindings: [] })
     expect(first.error).toBeUndefined()
@@ -40,32 +72,41 @@
       '  name',
       'FROM users"""',
       'template',
     ].join('\n')
     const result = await runtime.run({ program, bindings: [] })
     expect(result.error).toBeUndefined()
     // Interior lines of the literal must not gain the scaffold's indentation.
     expect(result.value).toBe('SELECT\n  id,\n  name\nFROM users')
   })
 
-  it('keeps function docstrings intact', async () => {
+  it('matches native Python docstring semantics', async () => {
     const { runtime } = await setupRuntime()
     const program = [
       'def helper():',
       '    """First summary line.',
       '    Details follow."""',
       '    return 1',
       'helper.__doc__',
     ].join('\n')
     const result = await runtime.run({ program, bindings: [] })
     expect(result.error).toBeUndefined()
-    expect(result.value).toBe('First summary line.\n    Details follow.')
+    // Python >=3.13 removes common docstring indentation in the compiler.
+    // Compare the untouched source with the SAME interpreter, so the adapter
+    // must preserve native semantics rather than a pre-3.13 spelling.
+    const nativeDoc: unknown = JSON.parse(execFileSync(KERNEL_PYTHON, ['-c', [
+      'import json, sys',
+      'namespace = {}',
+      'exec(compile(sys.argv[1], "<native-docstring>", "exec"), namespace)',
+      'print(json.dumps(namespace["helper"].__doc__))',
+    ].join('\n'), program], { encoding: 'utf8', timeout: 15_000 }))
+    expect(result.value).toBe(nativeDoc)
   })
 
   it('suppresses a None completion and omits value for a statement-ending cell', async () => {
     const { runtime } = await setupRuntime()
     const suppressed = await runtime.run({ program: 'None', bindings: [] })
     expect(suppressed.error).toBeUndefined()
     expect(suppressed.value).toBeUndefined()
     const absent = await runtime.run({ program: 'pass', bindings: [] })
     expect(absent.error).toBeUndefined()
     expect(absent.value).toBeUndefined()
```

```diff
--- baseline/better-dsh/test/session-keys.spec.ts
+++ current/better-dsh/test/session-keys.spec.ts
@@ -166,21 +166,21 @@
     snapshotDirs.push(snapshotDir)
     const { fiber, runtime } = await setupRuntime({ snapshotDir })
     await runtime.run({ program: 'x = "a"', bindings: [], principal: 'sess-snap-a' })
     await runtime.run({ program: 'y = "b"', bindings: [], principal: 'sess-snap-b' })
     // Dispose deterministically (the onTestFinished disposer is idempotent)
     // so the per-key artifacts exist when this test reads them.
     await fiber.dispose()
 
     for (const [key, marker] of [['sess-snap-a', 'x'], ['sess-snap-b', 'y']] as const) {
       const dir = join(snapshotDir, key)
-      expect(existsSync(join(dir, 'state.dill'))).toBe(true)
+      expect(existsSync(join(dir, JSON.parse(readFileSync(join(dir, 'manifest.json'), 'utf8')).payload))).toBe(true)
       const manifest = JSON.parse(readFileSync(join(dir, 'manifest.json'), 'utf8')) as { names: string[] }
       expect(manifest.names).toContain(marker)
     }
   }, 30_000)
 })
 
 describe('DashrRuntime — per-session kernel cwd', () => {
   it('spawns the kernel in the request cwd (session workspace), never the host process cwd', async () => {
     const ctx = new Context()
     const workspace = mkdtempSync(join(tmpdir(), 'dashr-cwd-'))
```

```diff
--- baseline/better-dsh/test/snapshot-restore.spec.ts
+++ current/better-dsh/test/snapshot-restore.spec.ts
@@ -56,23 +56,22 @@
     expect((warm.value as { result: unknown }).result).toBe('child-1')
     expect(callsFirst.map(call => call.tool)).toEqual(['subagent'])
 
     const manifestPath = join(snapshotDir, 'dashr-agent', 'manifest.json')
     expect(existsSync(manifestPath)).toBe(true)
     const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as ManifestShape
     expect(manifest.skipped).toBe(false)
     expect(manifest.turn).toBe(1)
     // USER state is captured...
     for (const name of ['kept', 'math', 'handle']) expect(manifest.names).toContain(name)
-    // ...alongside the flat binding surface itself (dill captures the
-    // callable proxies and the error class — plain non-shim globals).
-    for (const name of ['tool', 'ToolCallError']) expect(manifest.names).toContain(name)
+    // Host proxies are recreated on the fresh runtime, never persisted.
+    for (const name of ['tool', 'ToolCallError']) expect(manifest.names).not.toContain(name)
     // The pre-0.1.5 holder name and the deleted rlm_await are gone.
     for (const name of ['tools', 'rlm_await']) expect(manifest.names).not.toContain(name)
     // No flat tool global ever leaks: every tool (native or bridged) is a
     // member of the `tool` object, never a top-level namespace name.
     for (const name of ['subagent', 'send_message', 'workflow']) expect(manifest.names).not.toContain(name)
     // The exclusion semantics still hold around them: no dashr shim name
     // (the `_dashr`/`__dashr` prefix rule, any case) and none of IPython's
     // own session plumbing (`user_ns_hidden` members like exit/quit/In/Out)
     // ever enters the payload.
     expect(manifest.names.filter(name => name.toLowerCase().startsWith('_dashr') || name.toLowerCase().startsWith('__dashr'))).toEqual([])
```

```diff
--- baseline/better-dsh/test/snapshot-revive.spec.ts
+++ current/better-dsh/test/snapshot-revive.spec.ts
@@ -2,21 +2,21 @@
 import { tmpdir } from 'node:os'
 import { join } from 'node:path'
 import { afterEach, describe, expect, it } from 'vitest'
 import { setupRuntime } from './helpers.ts'
 
 /**
  * M3-B namespace persistence (blueprint §8): turn-end size-capped snapshots,
  * restore-on-first-boot, and the death→revive chain that respawns onto the
  * nearest replayable snapshot. Real kernels throughout; every provider is
  * disposed through the helper's onTestFinished hook, and the orphan gate
- * (`pgrep ipykernel_launcher`) runs after the suite.
+ * verifies only owned OMP runner PIDs; production processes are untouched.
  */
 
 const snapshotDirs: string[] = []
 
 afterEach(() => {
   for (const dir of snapshotDirs.splice(0)) {
     rmSync(dir, { recursive: true, force: true })
   }
 })
 
@@ -99,38 +99,39 @@
     expect(isAlive(deadPid)).toBe(true)
 
     process.kill(deadPid, 'SIGKILL')
     expect(await waitFor(() => !isAlive(deadPid), 5_000)).toBe(true)
 
     // The death-observing run does NOT execute: it respawns onto the turn-2
     // snapshot and reports the one lost round (turn 3 - turn 2).
     const observed = await runtime.run({ program: 'print("never")', bindings: [], principal: 'sess-revive' })
     expect(observed.error?.kind).toBe('worker-exit')
     expect(observed.error?.message).toContain('restored from the turn-2 snapshot')
-    expect(observed.error?.message).toContain('1 round')
+    expect(observed.error?.message).toContain('This observing call did not execute')
+    expect(observed.error?.message).not.toContain('must be replayed')
 
     // The next run executes on the restored namespace: both a and b survive.
     const revived = await runtime.run({ program: 'print(a + b)', bindings: [], principal: 'sess-revive' })
     expect(revived.error).toBeUndefined()
     expect(revived.logs).toContain('3')
     expect(runtime.kernelPids[0]).not.toBe(deadPid)
   }, 30_000)
 
-  it('skips an over-cap turn-end snapshot and warns the model exactly once', async () => {
+  it('skips an over-cap turn-end snapshot and reports each over-cap attempt and keeps the previous generation', async () => {
     const snapshotDir = mkdtempSync(join(tmpdir(), 'dashr-snapshot-'))
     snapshotDirs.push(snapshotDir)
     const { runtime } = await setupRuntime({ snapshotDir, snapshotSizeCapBytes: 10_000 })
 
     // ~50KB of string is estimated over the 10KB cap before any dill IO.
     const first = await runtime.run({ program: 'big = "x" * 50000', bindings: [] })
     expect(first.error).toBeUndefined()
     expect(first.logs.some(line => line.includes('namespace snapshot skipped'))).toBe(true)
     // Skipped snapshots never replace a previous good one — there was none.
     expect(existsSync(join(snapshotDir, '(agentless)', 'manifest.json'))).toBe(false)
     expect(existsSync(join(snapshotDir, '(agentless)', 'state.dill'))).toBe(false)
 
-    // The warning is one-time: a second over-cap run skips silently.
+    // Every failed attempt exposes current recovery coverage.
     const second = await runtime.run({ program: 'big2 = "y" * 50000', bindings: [] })
     expect(second.error).toBeUndefined()
-    expect(second.logs.some(line => line.includes('namespace snapshot skipped'))).toBe(false)
+    expect(second.logs.some(line => line.includes('namespace snapshot skipped'))).toBe(true)
   }, 30_000)
 })
```

```diff
--- baseline/docs/package-catalog.json
+++ current/docs/package-catalog.json
@@ -1337,13 +1337,15 @@
     "superpowers/plans/2026-10-03-ast-engine-deomp.md",
     "superpowers/plans/2026-10-03-docs-packaging-trim.md",
     "superpowers/specs/2026-10-02-ctx-navigation-design.md",
     "upstream-dsh-0.1.5-rc.2-report.md",
     {
       "source": "legacy/better-dash/docs/dev-test-environment-notes.md",
       "target": "dev-test-environment-notes.md"
     },
     "remote-tools.md",
     "adr/0015-independent-bundles-agent-remote.md",
-    "specs/remote-tool-enhancement/spec.md"
+    "specs/remote-tool-enhancement/spec.md",
+    "specs/omp-python-repl-port/spec.md",
+    "specs/omp-python-repl-port/runtime-guide.md"
   ]
 }
```

```diff
--- baseline/docs/specs/omp-python-repl-port/runtime-guide.md
+++ current/docs/specs/omp-python-repl-port/runtime-guide.md
@@ -0,0 +1,33 @@
+# Better Dash Python REPL execution and recovery
+
+Implementation and acceptance are tracked in the [plan](../../superpowers/plans/2026-10-12-omp-python-repl-port.md). The [spec](spec.md) defines the recovery boundary; this guide explains the consumer contract being implemented.
+
+Better runs a persistent Python child for each DSH session. Node communicates with an unchanged, pinned OMP runner over JSON lines. Better owns tool bindings, cancellation, output mapping and checkpoint management. The runtime requires Python >=3.9; the compatibility managed-environment path may let uv download that interpreter, while an explicit path uses an existing installation. Better ships the Python runner and dill 0.4.1 source. It does not install Jupyter, IPython, ZeroMQ or dill into the consumer's interpreter. OMP's Agent-specific prelude is not exposed as a DSH feature.
+
+Variables, functions, classes and imports remain available across cells while the child lives. Top-level await works; a top-level return is invalid. The final expression supplies the completion value and print supplies logs. Host tools remain callable with `await tool.<name>({...})`. Internal initialization and checkpoint cells do not appear as user results or user scratchpad variables.
+
+`tool.read` forwards to the current DSH native read tool with its usual permissions, scheduling and results. Better supplies the call-site helper required by OMP's compiler without enabling OMP speculative reads. Interactive `input()` is unsupported and returns an actionable error. Output uses the existing text/log/result contract; a nontext-only display produces an explicit MIME notice.
+
+## Checkpoint boundary
+
+In a native DSH profile, checkpoints belong under that profile's resolved DSH home and are isolated by profile and session. An explicitly configured checkpoint directory takes precedence; `snapshotDir: ""` disables persistence and leaves process-local state only. A standalone runtime without a native profile must explicitly choose a checkpoint directory.
+
+A completed cell attempts a new checkpoint, including a cell that raises after changing variables. Saving a checkpoint can fail or skip values. Better reports the coverage and latest committed cell instead of claiming complete process recovery. Aliases and dependencies among retained values must survive as one object graph; values whose dependencies cannot safely be preserved are omitted or the checkpoint is rejected.
+
+The serializer does not preserve runner state, host tool bindings, open files, sockets, subprocesses, threads, locks or database connections. Tool bindings are recreated from the current host. Current directory, environment changes, module caches and library global state are not generally restored. File modifications and network/tool side effects have their own real sources and are never replayed or rolled back by a variable checkpoint.
+
+The checkpoint manifest records format, completed-cell sequence, interpreter/environment identity, payload size/integrity, saved names and omissions. Only a complete committed generation is eligible for restoration. A failed attempt before commit preserves the previous valid generation. If interruption prevents commit confirmation, the result reports that uncertainty; the manifest remains the authority on the latest complete generation. Restore validates the owned session checkpoint before loading it and runs once before admitting a new user cell. Damage or incompatibility produces an explicit empty-state notice. A partial restore lists the missing coverage.
+
+`reset: true` discards the session child and its persisted checkpoints. Do not use it when you intend to retain state.
+
+## After a crash or interruption
+
+Read the recovery notice, check the latest successful checkpoint and inspect real external state. A cell that died after starting may already have performed side effects. Better does not automatically retry it and does not instruct blind replay. Recreate omitted resources and rerun only the operations you determine are still needed.
+
+Snapshots are private executable serialization, not an interchange format. Do not copy arbitrary external dill files into the checkpoint directory or treat them as data imports. The owned directory, session isolation and permissions are part of the recovery contract.
+
+## Delivery verification
+
+The original OMP runner, its MIT license and source/hash provenance travel inside the npm package. Vendored dill carries its version, original source hashes and BSD-3-Clause license. The build verifies these resources and copies them beside compiled JavaScript; consumers never execute TypeScript or load OMP/Bun packages.
+
+Acceptance uses the normal dual tarball launcher and a dev3 test installation. Source tests, successful build or a live Python process alone are insufficient. The final test report records exact artifacts and the observed model-visible recovery behavior.
```

```diff
--- baseline/docs/specs/omp-python-repl-port/spec.md
+++ current/docs/specs/omp-python-repl-port/spec.md
@@ -0,0 +1,61 @@
+# Better Dash Python REPL：移植 OMP 执行链与快照边界
+
+状态：实施中；2026-10-12 user 明确批准第一、第二阶段一起实施。原调研日期：2026-10-11。执行计划见 `docs/superpowers/plans/2026-10-12-omp-python-repl-port.md`。
+
+## 1. 方向
+
+“抄 OMP”指将所需源码复制到 Better Dash 自有源码中，完成本地 Node、DSH、Cordis 接口适配并随 `better-dsh` 交付；不 import OMP 包，也不要求消费者安装 Bun。现有 AST device 已有同类剥离先例：`better-dsh/src/devices/ast/ast-device.ts`。
+
+第一阶段以 OMP Python REPL 的运行语义为基线，**`runner.py` 逐字节复制，保持原文件不改**。复制的 Python runner 本身不依赖 IPython、ipykernel、Jupyter 或 ZeroMQ，只使用 Python 标准库。根据实际采用的便利函数，将 OMP `prelude.py` 一同纳入并注明来源；它和 OMP 专有的 Agent 桥接需要在 Better 的工具面上作取舍。宿主侧从 OMP 的 TypeScript kernel、共享 IPC 与会话管理中抽取所需逻辑，接上 Better 的 `ReplRuntime`、工具绑定、输出、取消、reset 和生命周期接口。`Bun.spawn` 换成 Node `child_process.spawn`；Bun 的脚本文本导入换成包内 `.py` 资源路径。Better 的 TS 在构建时编译为 JS，运行时不执行 TS。
+
+新路径是 `Better/Node → stdin/stdout JSON 行 → Python runner → Python 解释器`。因此可移除这条路径上的 IPython、ipykernel、Jupyter client 和 ZeroMQ 需求；**Python 解释器仍是运行前提**。是否随包交付解释器是另一项决策，不由移植 OMP 自动解决。第一阶段按 OMP 策略保留进程内会话状态，不承诺进程重启后的变量恢复。
+
+复制时固定一个 OMP commit，保存原始文件、许可证和来源记录；若 `runner.py` 原样复制，校验其字节哈希。本文调研时的 OMP HEAD 为 `fa5ff4a3a977a28b93d025f4cf50f046e019f18c`，实施时应以实际复制的 commit 为准。MIT 许可声明随交付物保留。
+
+资料：[OMP Python REPL 说明](https://github.com/can1357/oh-my-pi/blob/fa5ff4a3a977a28b93d025f4cf50f046e019f18c/docs/python-repl.md)、[runner.py](https://github.com/can1357/oh-my-pi/blob/fa5ff4a3a977a28b93d025f4cf50f046e019f18c/packages/coding-agent/src/eval/py/runner.py)、[TS kernel](https://github.com/can1357/oh-my-pi/blob/fa5ff4a3a977a28b93d025f4cf50f046e019f18c/packages/coding-agent/src/eval/py/kernel.ts)、[共享 IPC](https://github.com/can1357/oh-my-pi/blob/fa5ff4a3a977a28b93d025f4cf50f046e019f18c/packages/coding-agent/src/eval/kernel-base.ts)、[MIT 许可](https://github.com/can1357/oh-my-pi/blob/fa5ff4a3a977a28b93d025f4cf50f046e019f18c/LICENSE)。
+
+## 2. “快照恢复”恢复什么
+
+快照是**会话运行时 Python 用户命名空间的一份持久检查点**，用于 Python 子进程死亡、插件重启或同一会话恢复时，让新进程尽量接续旧 REPL 中由模型创建的值。例如 `x = 3`、列表、字典、对象实例、可序列化的函数或类，以及 Better 经 `setVar` 放入命名空间的值。它不是模型聊天记录或 compaction 摘要；那些属于 DSH 会话数据。也不是“把整个 Python 进程冻住”。
+
+| 状态 | 是否属于快照目标 | 说明 |
+| --- | --- | --- |
+| 每会话的用户变量及其可序列化对象图 | 是，best effort | 核心恢复对象；按会话键隔离 |
+| 检查点序号、格式、解释器及环境标识、跳过项 | 是 | 判断能否加载、丢失了多少轮、向模型准确报告 |
+| Better 的宿主工具绑定、prelude、IPC、事件循环 | 否 | 新 runner 启动时重新建立；不得把旧进程句柄反序列化 |
+| DSH 对话、工具日志、compaction、文件内容 | 否 | 各有独立持久化和真实来源；快照不复制它们 |
+| 打开的文件/套接字、子进程、线程、数据库连接、锁 | 否 | 与旧 OS 进程绑定；恢复后需重新打开 |
+| `cwd`、环境变量、`sys.path`、模块缓存和库内部全局状态 | 默认不保证 | 启动配置可重新应用；用户代码造成的任意进程副作用不能由变量快照完整重建 |
+| 对外副作用，如文件修改、网络请求、工具调用 | 否 | 已发生的副作用不可通过恢复变量撤销，也不可盲目重放代码 |
+
+特别要区分：会话**活着时**，OMP runner 中的变量自然跨 cell 保留；需要快照的是**旧 runner 退出、新 runner 启动**这个边界。OMP 自身的 compaction 只提供有限的运行时提示，不恢复新进程中的历史变量值。[OMP eval 文档](https://github.com/can1357/oh-my-pi/blob/fa5ff4a3a977a28b93d025f4cf50f046e019f18c/docs/tools/eval.md)
+
+## 3. 若第二阶段加快照：技术边界
+
+快照功能放在 Better 自有扩展层，仍保持复制的 `runner.py` 字节不变：在没有用户 cell 并发执行的时点，由宿主发送内部 cell，在同一用户 namespace 中读取 `globals()`、过滤 runner/prelude/Better 内部绑定，并调用随包交付的快照辅助逻辑。恢复时先启动 runner、完成初始化与 prelude，再运行内部恢复 cell，最后允许用户 cell 进入。内部 cell 必须不污染可见结果和用户变量清单。若这一方式经实测无法满足隔离要求，再单独裁决是否改 runner；不能暗中把“原样复制”改成 fork。
+
+触发点：完成的用户 cell 后尝试保存最新检查点；正常关闭时可再尝试一次。`reset` 清除内存与磁盘检查点。异常终止时只使用**已经完整提交**的最近检查点，不重放死亡时的 cell，也不假装它执行成功。检查点写入临时文件、验证大小与格式后再原子替换；失败或超限保留上一份可用检查点。每个会话单独存放，首次启动或故障重启只尝试恢复一次。
+
+### 3.1 `dill` 随包源码交付的裁决
+
+以 Better 当前锁定的 `dill==0.4.1` 为基线，将其 Python 包源码复制到 Better 的交付资源中，让子进程直接从包内路径 `import dill`，不在消费者机器上执行 `pip install dill`。保留上游 BSD-3-Clause 许可、版本和来源记录。优先保持 vendored 源码原样；Better 特有的 namespace 过滤、检查点格式和错误报告放在自有快照辅助层，避免改动 dill 内部。`dill` 自身不是解释器，Python 解释器仍需由宿主或另行交付。
+
+包体积实测（PyPI 的 0.4.1 `py3-none-any` wheel）：压缩 wheel **120,019 bytes**；其中 `dill/` 目录的 46 个 `.py` 文件展开为 **350,717 bytes**，排除自带测试后 14 个 `.py` 文件为 **245,541 bytes**。这些是 Python 源文件体积，不含打包后的 npm 压缩率或解释器体积。wheel 元数据没有默认 `Requires-Dist`；`objgraph`、`gprof2dot` 是可选诊断功能的 extra。PyPI 页面列出的 `setuptools` 是构建/安装要求，不是把已复制的 `dill/` 源码导入并运行时须安装的包。上游声明支持 Python/PyPy ≥3.9。资料：[PyPI dill 0.4.1](https://pypi.org/project/dill/0.4.1/)、[dill 源码](https://github.com/uqfoundation/dill)、[BSD 许可](https://github.com/uqfoundation/dill/blob/master/LICENSE)。
+
+衔接点是 OMP runner 的用户 namespace，与 IPython 或 Jupyter 协议无关。在隔离探针中，未修改的 OMP `runner.py` 使用随进程路径提供的 dill 0.4.1：第一个 Python 子进程创建 `x = [1, 2]` 与引用 `x` 的 lambda，内部 cell 用 `dill.dump` 保存变量字典；第二个全新子进程用 `dill.load` 和 `globals().update` 恢复，随后 `f(4)` 得到 `5`。这证明基本衔接可行，不证明任意对象都可恢复，也尚未经过 Better 的真实交付测试。
+
+Best effort 不应退回普通标准库 `pickle`，否则对 REPL 函数、闭包等的覆盖可能明显缩小。仍会有 dill 无法序列化或恢复的对象，以及依赖缺失或环境不一致的对象；这些值允许跳过并报告。要注意：把整个变量字典一次 `dill.dump` 时，一个坏值可使整份失败；若要“丢弃坏值并保住其他变量”，须由 Better 自有层实现筛选与部分恢复记录，并验证对象间引用关系。不能只捕获一次异常就声称做到了按变量 best effort。也不能重放任意历史 cell 来假装恢复，因为副作用可能重复发生。
+
+`dill.load` 会执行反序列化逻辑，因此只加载本会话受控目录中的检查点，目录权限和会话键隔离属于恢复边界；不要把外来 `.dill` 文件当作数据导入。
+
+## 4. Best effort 的具体承诺
+
+可以沿用现有 best effort 标准，但必须**如实暴露恢复结果**，不能把“找到快照文件”等同于“状态完整恢复”——当前 `dill` 实现也会因不可序列化对象、超限、超时或环境变化而退化。
+
+1. 保存与恢复都允许失败，失败不阻止 REPL 从空命名空间继续运行；失败原因写入日志和模型可见结果。
+2. Manifest 记录检查点轮次、格式、Python/环境标识、大小和保存覆盖情况。恢复前校验；不兼容或损坏时明确报告空状态。
+3. 若只恢复部分变量，应报告“部分恢复”及跳过的名称或数量；**不能报告“已恢复整个 namespace”**。对象间共享引用和依赖关系无法保持时也应视作部分恢复，或整份拒绝。
+4. 模型须知道最新成功检查点的轮次，以及检查点之后哪些 cell 可能丢失；故障时观察到的那次调用不自动重试。
+5. 资源句柄、网络连接和其他进程副作用始终超出承诺；用户代码应能检测和重建这些资源。
+
+因此，第二阶段的目标是“尽可能恢复模型的 Python scratchpad 变量，并准确报告缺口”，不是恢复整个 Python 进程。是否加这一阶段，不影响先完成 OMP 执行链移植与去除 Jupyter/ZMQ 依赖。
```

```diff
--- baseline/docs/superpowers/plans/2026-10-12-omp-python-repl-port.md
+++ current/docs/superpowers/plans/2026-10-12-omp-python-repl-port.md
@@ -0,0 +1,68 @@
+# OMP Python REPL port implementation plan
+
+> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Track steps with checkboxes. Repository acceptance and release gates override skill commit steps: no commits, tags, pushes or publishing before acceptance, report and user release.
+
+**Goal:** Replace Better's Jupyter/ZMQ substrate with the pinned OMP Python runner, retaining tool calls, session state and honest best-effort checkpoints without consumer pip installs.
+
+**Architecture:** Node owns one Python child per session and serializes user and internal execution over OMP's NDJSON protocol. Unmodified upstream resources have provenance and licenses; Better owns initialization, binding callbacks, namespace filtering, checkpoints, output mapping and lifecycle. Checkpoints preserve an admitted object graph and expose incomplete coverage without replaying user code.
+
+**Tech Stack:** Node child_process, TypeScript, Python stdlib, vendored dill 0.4.1, Vitest, Cordis/DSH native composition.
+
+**Spec:** `docs/specs/omp-python-repl-port/spec.md`. User approved BOTH phases on 2026-10-12.
+
+## Global constraints
+
+- `runner.py` is copied byte for byte from commit `fa5ff4a3a977a28b93d025f4cf50f046e019f18c`; expected SHA256 `e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974`.
+- Copy required MIT notices and original source provenance; no OMP package import or Bun runtime. Use packaged `.py` resources, compiled JS at runtime.
+- Vendor dill 0.4.1 Python sources unchanged with BSD-3-Clause notices; no consumer pip install. Python interpreter remains required, supported baseline >=3.9 subject to pinned runner verification.
+- Preserve `ReplRuntime` public seam and lossless JSON/tool-error/cancellation contracts. No upstream checkout edits.
+- Internal cells serialize with user cells and cannot pollute visible output/user namespace lists. No unowned listener or callback admission after cell completion.
+- Checkpoints exclude runner/Better/tool bindings and OS resources, commit atomically, retain previous valid generation after failure/cap, validate manifest/environment/integrity before load, and report skipped state and latest successful turn.
+- Do not automatically retry/replay the death-observing cell or assert it did not execute if it began. Reset clears memory and disk.
+- Use existing checkout on `codex/omp-python-repl-port`; preserve unrelated working changes. LSP/AST inspection evidence is `/tmp/omp-lsp-ast.json` plus protocol research evidence.
+- Test versions synchronize using root `version:release`; next round `0.3.0-s`. No npm publish, Git commit/tag/push or production actions.
+- Acceptance requires current launcher tarballs at PC4999 and dev3 independent test installation, actual model-visible tool use, report under `docs/test-reports/`, and running browser review URL.
+
+## Task 1: Replace execution substrate and deliver resources
+
+**Files:** create `better-dsh/src/omp-python/` for pinned runner, own support, provenance/notices; replace `src/kernel.ts`, `src/kernel-env.ts`, `src/bootstrap.ts` and `src/python.ts` as needed; remove retired `src/kernel-transport.ts`/`src/kernel-bridge.py`; update `scripts/copy-kernel-bridge.mjs`, `scripts/kernel-provision.mjs`, package scripts/notices and affected execution/env tests.
+
+**Interfaces:** preserve bridge methods `start()`, `executeCell(code, opts)`, `queryVar(name)`, `setVar(name, valueJson)`, `snapshotState(payloadPath, manifestPath, spec)`, `restoreState(payloadPath, manifestPath)`, `dispose()`; preserve `pid`, `isRunning`, `isDead`. Add outcome fields only when Task2 consumes them. Host callback handler retains `{global, function, args}` request and `{ok,result|message}` reply.
+
+- [x] Read pinned source/protocol report `/tmp/omp-python-protocol-research.md` and actual existing runtime contracts. Record any deliberate adaptation in provenance.
+- [x] Add failing execution test using a temporary stdlib-only Python venv: `python3 -m venv --without-pip <dir>` and `setupRuntime({python:<dir>/bin/python})`; run `x=40`, then `x+2`, assert value42 and no Jupyter dependency. Add OMP magic/shell behavior test and binding gather/error/cancel tests where existing coverage is insufficient.
+- [x] Run `npm --prefix better-dsh test -- test/runtime.spec.ts test/kernel-env.spec.ts`, save expected missing-ipykernel failure as RED evidence.
+- [x] Copy runner unchanged; provide Better support module with per-child authenticated HTTP or dedicated inherited callback pipes (prefer pipes when portable). Route async tool calls concurrently within a serialized cell; correlate request/response and discard stale replies.
+- [x] Implement Node NDJSON transport/startup probe, actual OMP source transformation/execution, typed completion mapping, text output, error/abort/timeout mapping, no invisible truncation, and bounded termination/close. Separate internal output consumption from user results. Preserve None suppression, top-level await and return rejection.
+- [x] Resolve/probe >=3.9 interpreter without requiring ipykernel, jupyter_client, pyzmq or external dill. Preserve configured interpreter/managed venv compatibility without installing kernel packages; provide actionable interpreter errors.
+- [x] Copy all Python resources/licenses/provenance into `lib/` after build; remove obsolete bridge/provision mechanisms and update descriptions which claim IPython.
+- [x] Run execution/binding/output/cancel/lifecycle suites and host typecheck; verify no orphan children. Task reviewer checks protocol, state/cancellation ordering and packaged resource resolution before Task2.
+
+## Task 2: Checkpoints and truthful recovery
+
+**Files:** create Better-owned `src/omp-python/better_snapshot.py`; vendor runtime-only dill source under `src/omp-python/vendor/dill/`; update `src/runtime.ts`, `src/kernel.ts` outcome types and helpers; update `test/snapshot-restore.spec.ts`, `test/snapshot-revive.spec.ts`, variable tests and lifecycle tests.
+
+**Interfaces:** keep `SnapshotSpec {turn, skills, sizeCapBytes}`. Snapshot success includes admitted names, skipped names/reasons and turn. Restore success includes count, skipped/partial coverage and turn; degraded outcome includes reason. Runtime puts save/restore/death notices into model-visible `logs` or error while preserving `maxOutputBytes`.
+
+- [x] Add failing fresh-process restoration tests for `x=[1,2]`, alias `y=x`, lambda `f=lambda n:x[0]+n`, a user class/instance, and `setVar`; assert `f(4)==5`, `x is y`, and valid internal-name filtering.
+- [x] Add failing mixed namespace test with a bad `__reduce__` and live file/lock handle alongside good variables; assert partial recovery lists omissions and retains aliases. If dependencies/shared references cannot safely be separated, refuse graph and report failure instead of falsely promising preservation.
+- [x] Add corrupt manifest/payload, environment mismatch, cap/timeout with previous generation retention, failed user cell, reset deletion, death during side-effecting cell and namespace-query isolation tests. Assert no code replay; failure states remain usable.
+- [x] Run the targeted tests to record RED failures before implementation.
+- [x] Vendor dill0.4.1 runtime source and license/provenance; explicitly put package path first only for this child/helper, without runtime install or upstream source modifications.
+- [x] Implement own helper selecting user bindings against startup/internal/injected bindings, blocking resources, probing candidates then round-tripping the final graph to verify it before commit. Manifest records format, Python/interpreter/environment, checkpoint turn, payload size/hash, names, omissions and coverage. All helper locals stay in helper module/function scopes.
+- [x] Use a complete-generation commit (single atomic manifest pointer to immutable payload, or equivalent single-file envelope) so a crash cannot pair new payload with old metadata. Use restricted per-session dirs and validate size/hash/environment before dill.load; never accept arbitrary external checkpoint paths.
+- [x] Runtime snapshots completed cells after success or user exception, and setVar when applicable; reports failures/partial/cap honestly, including latest successful checkpoint. Restore once before first user cell. Preserve affected session counters; distinguish unstarted observation from partially executed dying call, and never demand blind replay of side effects.
+- [x] Set checkpoint path through official DSH home/profile APIs in delivered composition, preserving explicit custom directory or disabled choice. Reset removes current and retained owned generations.
+- [x] Run checkpoint/execution suites and host/client typechecks; reviewer checks reference preservation, atomicity, permissions and model-facing recovery wording.
+
+## Task 3: Consumer validation, Surface and review handoff
+
+**Files:** update `better-dsh/eval-description.md`, relevant canonical docs and package-catalog as needed; update spec status with implementation evidence; write `docs/test-reports/2026-10-12-omp-python-repl-port.md`.
+
+- [x] Update runtime-visible tool guidance to explain OMP-backed Python, interpreter prerequisite, process-local state plus best-effort checkpoints, skipped resources and no automatic replay. Avoid claiming complete process restoration.
+- [x] Run full affected Better tests and both typecheck lanes. Run root packaging checks and `npm run version:release -- 0.3.0-s` before a clean dual pack.
+- [x] Inspect actual tarball resources/hashes/licenses and absence of obsolete ZMQ or consumer pip install, plus two independent bundles contract.
+- [x] Launch via `super-dsh/test/start-4999.sh` in retained `.tests/superd`; first-person model performs Python assignment, cross-cell lookup, native tool call, exception recovery, cancellation and reset. Inspect model-visible results.
+- [x] Transfer exact two tarballs and `pair.json` to retained dev3 test environment; use same launcher/prebuilt pair with independent host anchor. Run equivalent actual installed REPL/state/restore probes. Never touch production homes/ports/Caddy.
+- [x] Exercise installed checkpoint creation, fresh-child restore, partial restore/corruption and death side effects through actual consumer runtime; correlate files/manifests and model notices with results.
+- [x] Write exact artifact hashes, versions, checks/failures, session IDs, target services and review URL in report. Leave test web running for user review. No commit/publish; report any remaining externally blocked verification honestly.
```

```diff
--- baseline/docs/test-reports/2026-10-12-omp-python-repl-port.md
+++ current/docs/test-reports/2026-10-12-omp-python-repl-port.md
@@ -0,0 +1,93 @@
+# OMP Python REPL port: implementation and acceptance
+
+Date: 2026-10-12 (Asia/Hong_Kong). Status: in progress; no release approval, Git finalization or npm publication.
+
+## Scope and authority
+
+The user approved both the OMP execution-chain port and vendored-dill checkpoint recovery on 2026-10-12. Canonical [spec](../specs/omp-python-repl-port/spec.md), [runtime guide](../specs/omp-python-repl-port/runtime-guide.md) and [execution plan](../superpowers/plans/2026-10-12-omp-python-repl-port.md). Existing checkout is used on `codex/omp-python-repl-port`; unrelated pre-existing changes remain untouched.
+
+OMP source is fixed to `fa5ff4a3a977a28b93d025f4cf50f046e019f18c`. Original runner is 90,278 bytes, SHA-256 `e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974`. Its MIT license travels with the resource. Better's adaptation and snapshot helper are separate source files. dill baseline is0.4.1 with BSD-3-Clause license.
+
+## Pre-implementation evidence
+
+Actual TypeScript language-server definition/reference/call-hierarchy queries traced `DashrRuntime.run` to bridge execution, host dispatch, restore and checkpoint operations. TypeScript AST inspection enumerated bridge construction and execution/query/setVar/save/restore call sites. Evidence: `/tmp/omp-lsp-ast.json`, `/tmp/omp-runtime-call-hierarchy.json`.
+
+Pinned runner research used actual pyright definitions/references and Python AST import/control-flow inspection. Unchanged-runner probes covered native stdout, SIGINT and next-cell state, partial mutation after exception, explicit image MIME output, internal helper namespace isolation and ignored `silent` flags. Evidence: `/tmp/omp-python-protocol-research.md`, `/tmp/omp-python-lsp-probe-output.txt`, `/tmp/omp-python-protocol-probe-output.txt`. These are research probes, not installed-consumer acceptance.
+
+Baseline command: `npm --prefix better-dsh test -- test/runtime.spec.ts test/snapshot-revive.spec.ts test/snapshot-restore.spec.ts test/kernel-env.spec.ts`. Result: 4 files,22 tests passed before implementation. Log: `/tmp/omp-python-baseline.log`.
+
+Task1 RED tests used a stdlib-only venv and OMP magic/shell syntax. Existing implementation failed for missing ipykernel and unsupported syntax, as expected;17 existing tests passed. Log: `/tmp/omp-task1-red.log`.
+
+Native model catalog was inspected from the retained PC test line; available route at inspection time: `deepseek-official/deepseek-flash` and `deepseek-official/deepseek-v4-pro`. Acceptance selects from the actual live catalog, not a hardcoded historical provider alias.
+
+## Execution verification
+
+The initial port passed 48 execution/binding/environment checks,9 cancellation checks,3 selected lifecycle checks and host/client typechecks. Independent review then reproduced four gaps: native `tool.read` compiler helper, surviving foreground shell work after cancellation, same-cell reset/input and synthetic `__file__`. The independent scoped re-review accepted all four fixes for both specification and quality. The final focused execution/cancellation suite passed16/16; these source results do not substitute for installed-consumer acceptance.
+
+An isolated Python3.9.25 interpreter under `.scratch/omp-python-repl/python-cache` compiled the unchanged runner and all14 unchanged dill runtime files. The actual `omp-execution.spec.ts` integration suite then passed11/11 on Python3.9.25 (`/tmp/omp-task1-python39.log`), including native tool read, magic/reset and cancellation behavior. Snapshot graph/safety checks also passed19/19 on Python3.9.25 before the subsequent independent snapshot review identified additional edge cases.
+
+## Broad source run and follow-up
+
+`DASHR_TEST_PYTHON=/usr/bin/python3 npm --prefix better-dsh test` initially completed88 files with830 passed,9 failed and12 skipped tests (`/tmp/omp-python-full-better.log`). Follow-up isolated causes rather than changing unrelated business code:
+
+- Six browser failures came from missing distro Chrome at the default path. The existing cached Chrome was supplied through `DASHR_BROWSER_BIN`; browser-device10/10 passed (`/tmp/omp-python-browser-recheck.log`).
+- The remote cross-copy fixture lacked its ignored `.scratch` parent. Creating the test scratch directory made container-copy3/3 pass (`/tmp/omp-python-container-recheck.log`).
+- The presentation fixture used stale `read.path`; the actual upstream `tool-fs/src/read.ts` declares `file_path`. Aligning the fixture with the corrected delivered example made presentation20/20 pass (`/tmp/omp-python-presentation-recheck.log`).
+- The docstring expectation assumed pre3.13 compilation. Direct native source/AST compilation on actual3.14 and3.11 established the version difference; [Python3.13 release notes](https://docs.python.org/3.13/whatsnew/3.13.html#other-language-changes) document compiler whitespace stripping. The corrected test compares an independent same-interpreter native compile; docstring and multiline checks passed2/2 on both3.14.4 and3.9.25. No product semantic override is required.
+
+The initial checkpoint implementation passed94/94 scoped integration checks and both typecheck lanes. Independent review then reproduced startup-name admission/restore mismatch, missed partial/slot callback dependencies, and failed-write orphan growth. All four review findings, including failed-respawn wording, are now addressed and the independent scoped re-review passed both specification and quality. Final focused checkpoint verification is32/32; minimum Python3.9.25 graph/safety/review verification is27/27; both typechecks and original-resource copying passed.
+
+Final full Better rerun used the actual system Python plus the existing Chrome fixture and scratch parent: **88 files passed,1 file skipped;847 tests passed,12 skipped;0 failed** (`/tmp/omp-python-full-final.log`,203.42s). Snapshot fix regressions and the native-compiler docstring assertion are included. Root versions synchronized to `0.3.0-s` before the normal dual pack.
+
+## Root package checks
+
+The ordinary dual build/pack succeeded for `0.3.0-s`; the independent bundle verifier accepted both artifacts. Better tarball SHA-256 `73dfb82d1b259438225770144937f7f3fa0b8a7656b01deec59df197e8714071`; Super tarball SHA-256 `1626e2a52f4936ccd3492cb34b12272bde0fe16b0ef9d81344115368a0808fd2`. Actual Better tarball verification confirmed the fixed runner hash, all14 dill runtime sources plus original license hashes, helpers/licenses, and absence of obsolete transport or consumer install hooks (`/tmp/omp-python-artifact-s.log`).
+
+`npm test` root package suite completed40/42 passed,2 failed (`/tmp/omp-python-root-checks.log`). Both reproduce in standalone bundle-delivery12/14 (`/tmp/omp-python-bundle-delivery-recheck.log`): legacy companion receipt re-arms on a later controller, and polling clears a native failed-application diagnosis. The test and `companions.ts`/`bundle-setup.ts` sources have zero diff from HEAD; this port changes none of them. These existing companion findings remain recorded for final review; root suite is **not** reported green. No unrelated business workaround was applied.
+
+## Installed consumer results
+
+Both targets consumed the exact synchronized `0.3.0-s` pair through the canonical launcher. Existing independent Better installations were upgraded through native Plugin Manager, which returned `restart-required` and package exit0; only test services restarted to load code. No test-specific snapshot override was used. Shipped default persistence resolves under the official test profile home.
+
+| Proof | PC4999 | dev3 independent installation |
+| --- | --- | --- |
+| Persistent list/alias/function, TLA, typed completion | Passed | Passed |
+| Native `tool.glob` and native `tool.read(file_path)` | Passed | Passed after correcting target fixture path |
+| Exception after assignment retains value73 | Passed | Passed |
+| Real host restart restores function, alias identity and value | Turn4 restored | Turn6 restored |
+| Mixed bad reducer/nested file/lock omitted with reasons | Passed before/after restart | Passed before/after restart |
+| One dying cell, partial-execution notice, no replay | Marker count1 | Marker count1 |
+| Actual native session cancel, subsequent cell42 | Passed | Passed |
+| Timeout1s, next42, native magic/shell, reset/input guard | Passed | Passed |
+| Explicit reset:true clears previous memory/checkpoints | Source tests; native %reset installed | Installed explicit reset:true passed |
+| Intentionally corrupt manifest starts EMPTY with reason | Passed | Passed |
+| Actual model-wire eval description equals packaged markdown | Byte-identical3029bytes | Byte-identical3029bytes |
+
+PC sessions: basic/cold/death `session-b432b933-d6eb-47fe-8067-89b953c207c9`; partial/corruption `session-83cc13a4-924b-4ead-9321-603ea26bb339`; cancellation `session-7f381e15-b209-40f9-9be3-9d21a0414bb6`; magic/timeout/reset `session-f56c1076-54b8-48cc-8d37-8bbf16e660bf`. Actual calls/results, sequence IDs and exact notices are retained in [PC evidence](assets/2026-10-12-omp-python-repl-port/pc.json).
+
+PC default snapshot root is `.tests/superd/better-dsh/python-repl/0b20ba864208b04c6d9d3a51a9decf4fd46c24812dffc08c3ab9223ff9d87547/`. Basic turn4 admitted `asyncio,g,omp_alias,omp_before_error,omp_f,omp_x,r`, with no omissions; payload456982bytes. Managed CPython3.11.17 and packaged dill0.4.1 were exercised. Directory0700, manifest/payload0600 verified. Native read returned original DSH hashline text. The death result explicitly said the cell may have executed partially and no user code was replayed; subsequent actual model read verified one marker. Corruption was injected only into the acceptance partial session's manifest while the test host was stopped, after backing up/hash-verifying its original generation.
+
+Dev3 uses the independent DSH0.2.1-alpha.1 installation anchor and retained `.tests/foreign-substrate` home. Its compatible managed CPython3.11.15 was actually selected, rather than the inventoried system3.14.4. Installed runner/helpers/licenses/dill sources were hashed; both installed bundle versions are0.3.0-s. Root independently rechecked received artifact hashes, installed versions/runner hash, marker count1 and all three active target test units. Detailed sessions/sequences and exact outputs: [dev3 report](assets/2026-10-12-omp-python-repl-port/dev3.md), [compact native events](assets/2026-10-12-omp-python-repl-port/dev3.json), [final checkpoint metadata](assets/2026-10-12-omp-python-repl-port/dev3-checkpoints-final.json).
+
+The initial target relative `package.json` fixture did not exist; native read correctly raised E_NOT_FOUND. A later actual native read used the installed profile's absolute package.json and passed. The model also made and corrected a dict-versus-string assumption. Those errors remain in evidence. Actual cancellation reports an abort and captured start marker but retains the existing rough `[object Object]` reason text; neither target automatically repeated the sleep.
+
+Actual `request/header` records prove the model received the packaged eval description, including OMP, interpreter prerequisites, best-effort state, resource omissions and no automatic retries. Actual reset schema explicitly deletes checkpoints. The model's own narrative is not used as the behavior verdict: native tool call/result records establish each result.
+
+## Review entrances and remaining limits
+
+PC [https://test.pc.randomhash.app/](https://test.pc.randomhash.app/) and [LAN4999](http://192.168.31.130:4999/) remain running. dev3's same installed service is available through the owned test SSH forward [LAN4996](http://192.168.31.130:4996/). Both public PC and direct LAN-forward HTTP entrances returned200; the forward required no target configuration, firewall or Caddy change. Native authentication remains in force.
+
+Both rosters contain7 local runtimes plus7 preserved paired entries,14 total, all ready and not failed. Pairing state was retained. PC test journal and target log contain0 world-failed entries. Active PC units: `superd-4999-test`, its registry/relay, and `superd-4996-dev3-review`. Active target units: `superd-4998-test`, `superd-4998-pair-registry`, `superd-lan-4998-relay`.
+
+Snapshotting is a best-effort executable Python object graph, with exclusions and omission reporting, rather than whole-process recovery. Dynamic globals/eval and arbitrary extension resources cannot be exhaustively inspected. Environment checks do not hash every installed third-party distribution. Linux consumer behavior is verified; Windows lifecycle parity remains unverified. No production home, production3080/3081 service or live Caddy configuration was part of this work.
+
+Final whole-branch review is pending. No commit, tag, push or npm publication occurred. Root companion-suite failures above remain a separate release/integration gate.
+
+## Execution decisions
+
+- Reused the suitable checkout on a dedicated codex branch, retaining unrelated changes. Cost if wrong: weaker filesystem isolation requires careful ownership review.
+- Deferred skill intermediate commits to obey repository acceptance/release gates; reviews use exact backups and owned working diffs. Cost: intermediate evidence remains local until Git finalization.
+- Used official profileContext for default checkpoint home, preserving custom directory/disabled choices. Cost: standalone contexts must explicitly opt into disk persistence.
+- Cancellation cleans new current-cell descendants while retaining prior persistent children; unproven cleanup retires the runner. Cost: escaped processes and unverified platforms remain outside the Linux proof.
+- Named the helper better_snapshot.py to match the qualified bridge seam. Cost: documentation generic snapshot.py references need alignment; no public interface changed.
+- Preserved the local SDD workspace because repository gates prohibit the commits that would otherwise make Git its durable record. Cost: ignored review artifacts need retention until finalization; canonical evidence is additionally archived beside this report.
```

```diff
--- baseline/package-lock.json
+++ current/package-lock.json
@@ -1,13 +1,13 @@
 {
   "name": "superd-workspace",
-  "version": "0.3.0-r",
+  "version": "0.3.0-s",
   "lockfileVersion": 3,
   "requires": true,
   "packages": {
     "": {
       "name": "superd-workspace",
-      "version": "0.3.0-r",
+      "version": "0.3.0-s",
       "license": "MIT"
     }
   }
 }
```

```diff
--- baseline/package.json
+++ current/package.json
@@ -1,14 +1,14 @@
 {
   "name": "superd-workspace",
   "private": true,
-  "version": "0.3.0-r",
+  "version": "0.3.0-s",
   "releaseTarget": "0.3.0",
   "type": "module",
   "description": "Super D unified development repository: Better Dash native tools and Super Dash multi-agent platform.",
   "license": "MIT",
   "repository": {
     "type": "git",
     "url": "git+https://github.com/pgmi-builds/super-dsh.git"
   },
   "scripts": {
     "build": "node super-dsh/scripts/pack.mjs",
```

```diff
--- baseline/super-dsh/package-lock.json
+++ current/super-dsh/package-lock.json
@@ -1,19 +1,19 @@
 {
   "name": "super-dsh",
-  "version": "0.3.0-r",
+  "version": "0.3.0-s",
   "lockfileVersion": 3,
   "requires": true,
   "packages": {
     "": {
       "name": "super-dsh",
-      "version": "0.3.0-r",
+      "version": "0.3.0-s",
       "bundleDependencies": [
         "@earendil-works/pi-coding-agent"
       ],
       "license": "MIT",
       "dependencies": {
         "@earendil-works/pi-coding-agent": "0.84.2",
         "zod": "4.4.3",
         "@modelcontextprotocol/sdk": "^1.29.0"
       },
       "peerDependencies": {
```

```diff
--- baseline/super-dsh/package.json
+++ current/super-dsh/package.json
@@ -1,13 +1,13 @@
 {
   "name": "super-dsh",
-  "version": "0.3.0-r",
+  "version": "0.3.0-s",
   "description": "Super D for the DeepSeek Harness (DSH) — one dsh plugin that mounts the superd hub (runtime selector, roster, per-runtime agents) and joins local foreign-agent runtimes (OMP, Codex, Claude, Pi, Hermes, Antigravity) into the DSH Web UI. Each runtime keeps its native home and session store; the hub only bridges.",
   "type": "module",
   "license": "MIT",
   "repository": {
     "type": "git",
     "url": "git+https://github.com/pgmi-builds/super-dsh.git",
     "directory": "super-dsh"
   },
   "exports": {
     ".": "./superd-hub/dist/index.js",
```
