# Final fix wave requirements
Read global-context.md for binding constraints, then final-review.md for the complete independent findings list.

Own the single final fix wave: R1 must be addressed with focused RED→GREEN real-child regressions for completed execution, exceptions/stdout, setVar, retained live state, earlier successful checkpoint/latest-turn reporting, and continued usability after directory preparation/dispatch failure. Use the smallest robust best-effort snapshot boundary; do not change user-code semantics. Inspect with LSP/AST as repository requires; prior scripts/evidence can be reused.

M1 structured native abort reason is non-blocking and may remain deferred; avoid unrelated cancellation redesign. M2 spec closeout is handled by controller before next packaging; do not edit docs/version/packaging.

Scope: Better runtime and meaningful covering tests only. No vendor/upstream changes, no production/consumer operations, no commits/tags/push/npm publish. Do not spawn subagents. Existing working tree is shared; preserve all unrelated changes. Backup reviewed source exists final-fix-base/better-dsh/{src,test,scripts} for scoped comparison.

Report in final-fix-report.md: status, exact changed files, diagnosis, RED and GREEN commands/results/logs, both typecheck results, LSP/AST use, self-review, any open findings. Short return only. Final reviewer then performs one scoped re-review.
