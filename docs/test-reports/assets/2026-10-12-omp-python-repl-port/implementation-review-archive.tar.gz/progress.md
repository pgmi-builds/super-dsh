# SDD ledger — plan: docs/superpowers/plans/2026-10-12-omp-python-repl-port.md

2026-10-12: User explicitly approved both execution port and snapshot phase. Working branch codex/omp-python-repl-port in existing suitable checkout per repository/app preference. No commit/tag/push/publish authorized.

Preflight review:

| Tasks | Shared contract / check | Finding / ruling |
|---|---|---|
| 1 | Resource paths, stdlib execution test, Node methods | Existing methods preserved; runner hash fixed. |
| 2 | Snapshot tests vs implementation, graph and resource boundaries | Partial selection must verify final graph; cannot claim arbitrary restoration. |
| 3 | Tarball, targets, reports vs release gates | Full consumer acceptance required; no Git or registry finalization. |
| 1,2 | kernel.ts, python/helper support and snapshot bridge methods | Sequential implementation, add partial outcome fields in Task2; no simultaneous writers. |
| 1,3 | package metadata, resources, runtime Surface | Task1 owns packaging code; Task3 changes versions and user docs only after Task1. |
| 2,3 | Delivered default snapshot path and recovery notices | Task2 uses official home/profile APIs; Task3 proves ordinary installed consumer behavior. |

Ruling: no new worktree — repository and app prefer suitable existing checkout; existing untracked spec must stay accessible and production/test launcher path is current checkout. Branch isolates Git identity, unrelated files retained.
Ruling: no skill-mandated intermediate commits — root AGENTS acceptance/report/release gates override skills. Reviews use git diff and explicit owned new files instead of commit-range-only tooling.
Ruling: checkpoint defaults must use official DSH APIs; do not persist under cwd or hard-code production home. Preserve existing explicit config where possible; determine official home scope before changing default.

Baseline: npm --prefix better-dsh test -- test/runtime.spec.ts test/snapshot-revive.spec.ts test/snapshot-restore.spec.ts test/kernel-env.spec.ts: 4 files /22 tests passed, /tmp/omp-python-baseline.log.
LSP/AST: /tmp/omp-lsp-ast.json contains actual typescript-language-server definition/references/call hierarchy and TS AST new/call sites; protocol researcher also used pyright/Python AST.
Task1: ready; Task2: pending; Task3: pending.

Task2 preflight finding: existing runtime serializes individual bridge cells only; concurrent cold run calls can race across resolveKernelPython before kernels.set, and completed-cell snapshot transactions can interleave with next user cell. Required correction: serialize whole per-principal operations (run/restore/snapshot/reset/query/setVar/dispose) while allowing separate principals and tool fanout to remain independent. Add cold-concurrency and exact checkpoint-turn tests.
Root independent Task3 preparation: model proof scripts/prompts under .scratch/omp-python-repl; official catalog route deepseek-official/deepseek-flash; canonical guide/package catalog and eval recovery wording updated; README stale IPython/ZMQ descriptions replaced pending final field reconciliation. Report scaffold explicitly marks consumer gates pending.
Task2 RED: root added test/omp-checkpoints.spec.ts, all4 tests failed against pending snapshot seam as expected (/tmp/omp-task2-red.log). Also exposes actual existing cold same-principal race (second call NameError). Tests require post-restore function/class method globals identity and later x rebinding, nested handle/lock exclusion with partial report, aliases/closures/cycles, durable exception and setVar state.
Task1 implementation reported DONE_WITH_CONCERNS. Owned working diff packaged in task-1-working-review.md (no commit-range workaround). Review dispatched execution_reviewer against scope only; known Task2 snapshot/transaction work explicitly deferred. Reported final tests48/48 execution,9/9 cancellation and3 selected lifecycle, host/client typechecks; root inspected logs. Concrete Windows lifecycle and same-cell reset/input limitations await reviewer disposition.

Task1 fix round1: independent review reproduced R1 native tool.read helper missing, R2 foreground shell descendants surviving cancellation, R3 same-cell reset/input bypass and R4 synthetic __file__. Implementer fixing focused regression cases.
Ruling: cancellation cleans descendants newly created during current cell, with bounded TERM/KILL/reap before completion, preserving prior persistent children and ordinary runner PID; unresponsive leader still gets Node group termination. This meets foreground ownership without destroying previous intentionally persistent subprocesses; platform tracking failures must retire the runner honestly.
User asked whether Better read passes through native: confirmed compiler helper only forwards/awaits the existing host binding, no OMP speculative read/cache; native permissions and scheduling remain authoritative. Actual native read added to installed model acceptance prompt.

Task 1: complete — execution_reviewer scoped review PASS for both specification and quality; R1–R4 addressed, no new blocker (task-1-fix1-review.md). Final execution/cancellation16/16, root independent Python3.9 actual execution11/11. Immutable runner build guard verified positive/negative.
Task 2: running — fresh snapshot_implementer (gpt-6-astra high), reads task-2-brief/global constraints/research. Pre-edit baseline saved task-2-base for working diff review.
Ruling: snapshot module named better_snapshot.py to match Task1 qualified helper seam; task generic snapshot.py label superseded, no interface break.

Task2 implementation handed to fresh snapshot_reviewer for independent spec+quality gate (report task-2-review.md). Reported source94/94 + Python3.9 graph/safety19/19 + host/client typechecks; root inspected logs. Root full Better suite now running with explicit /usr/bin/python3 (3.14.4), /tmp/omp-python-full-better.log. Task3 package/version/target operations still wait Task2 review.

Task2 fix round1 — independent task-2-review.md rejects spec+quality for three reproduced findings: startup name replacement admission mismatch, partial/slots callback dependency omissions, failed commit orphan growth. Minor failed-respawn wording will also be fixed. Task2 pre-fix baseline saved task-2-fix1-base. Root Surface correction (Task3) read example uses native file_path; reset schema explicitly deletes checkpoints.
Broad Better test run pending; Chrome fixture defaults missing distro path, isolated supplied existing cached Chrome rerun10/10 passes (/tmp/omp-python-browser-recheck.log), no business workaround.

Root broad Better run completed 830passed/9failed/12skipped. Six browser failures are missing default Chrome (existing cached Chrome scoped rerun10/10passed). Remote cross-copy failure is absent fixture scratch parent; created ignored better-dsh/.scratch, scoped container-copy3/3passed. Presentation read example contract fixture used stale path; official native read.ts uses file_path; aligned fixture and20/20passed. One actual port regression remains: function docstring literal interior indentation on Python3.14; original execution implementer investigating read-only until snapshot fixes stabilize. /tmp/omp-python-full-better.log is retained RED evidence, not claimed fullgreen.

Broad-suite docstring investigation resolves as native compiler behavior, not port regression: unchanged source/AST compile on3.14 normalizes,3.11retains; official Python3.13 language-change notes confirm. Original implementer corrected test to compare independent same-interpreter native compile, focused2/2passed on3.14.4 and3.9.25. No product edits. Task3/final-review includes test-only correction.
Target readiness: current launcher/read-pair/pair-verifier/version-reader/dev-webmcp assets on dev3 have exact same SHA256 as PC; no test asset synchronization needed.

Task 2: fix round1/5 — all4 findings addressed,0open, independent scoped spec PASS + quality Approved (task-2-fix1-review.md). Source32/32 checkpoint set,3.9 graph/safety/review27/27, host/client typechecks and original-resource copier pass. No commits per root gate.
Task 2: complete — reviewed source stable, consumer gates still Task3.
Task3: active — root owns synchronized artifacts/PC/docs; fresh consumer_implementer owns dev3 exactpair native installation/actual model behavior, read-only prep completed; waiting newartifact.

Root final full Better suite:88filespassed/1skipped;847testspassed/12skipped/0failed,203.42s, /tmp/omp-python-full-final.log. Includes allTask2fixes + docstring/native read fixturecorrections. Versionrelease synchronized0.3.0-s; normaldualpack running /tmp/omp-python-pack-s.log.

Dualpack0.3.0-s succeeded; Better73dfb82d1b259438225770144937f7f3fa0b8a7656b01deec59df197e8714071 Super1626e2a52f4936ccd3492cb34b12272bde0fe16b0ef9d81344115368a0808fd2. Actualtarball originalresources/licensing/no-oldtransport/installhooks verified. Root npmtest40/42,2failedcompaniontests, standalone12/14 samefailures; test+companions.ts+bundle-setup.ts zeroHEADdiff. Existinglegacyreceipt/errorpolling findings recorded forfinalreview; rootchecksNOTgreen, no outside-scope businessfix. Task3PC launcher consumedexactpair, nativeBetterinstallinprogress; dev3agentownsparallel targetacceptance.

Task3 consumerwork complete: PC10proofcases +dev3 13nativeproofcases, actualmodelwireevaldescriptionbyteidentical3029bytes and resetdeletecheckpoints; native read/TLA/exception/typedcompletion/coldfunctionaliases/partialomissions/corruption/no-replaymarker1/cancel+42/timeouts/reset/input pass. PC+target7local+7retainedpairedready; worldfailed0. Exactversions/resource/artifacthashes verified, root independentlycheckedtargetfinalunits/marker/version/hash. Permanentcompactevidence docs/test-reports/assets/2026-10-12-omp-python-repl-port. Root mainreport integrated. PC4999public200 +testSSHforwardLAN4996direct200 retained.
Ruling: preserve SDD workspace until Git finalization — root forbids intermediate commits, so Git does not yet contain the review/evidence record; permanent sanitized consumer evidence also archived under docs/test-reports/assets. Cost: ignored local audit files need retention.

Final review: completed; Important R1 host checkpoint mkdir escapes best-effort boundary; final fix wave dispatched. Minor M1 structured abort reason deferred; M2 spec closeout scheduled with next artifact. Task 3 s acceptance preserved; t delta acceptance pending.

Final fix wave: source R1 done (2 files; 5 RED→GREEN, covering37/37, both typechecks0); scoped re-review dispatched. Normal synchronized0.3.0-t dualpack next.

Final fix scoped re-review: R1 ADDRESSED, spec PASS, quality Approved; M2 ADDRESSED; M1 deferred non-blocking; no new breakage. t artifact and both consumer delta verification pending.

Final follow-up: complete — scoped review spec PASS / quality Approved; synchronizedt normaldualpack/resource/pair checks passed; PC5 prompts including retained bad-kwargs fixture + dev3four actualmodelstages verified FSfailure nonfatal/live74/nativehashlineread; ownfixturesrecovered, exactreceivedhashes andtargetphysicalversions/rootverified, bothreviewURLs200, servicesactive. Complete s fullmatrix retained. No Git/npm finalization; two unchanged rootcompanion failures and deferredM1 disclosed. Canonical status/evidence closeout updated aftertpack; executable resources/Surface match artifacts.

First-person t report reconciliation: read independent report and actual retainednativehistory;41evalcalls/41results (corrected reportcount25); actualwire Surface byteequality verified;14probesummaries+82actualcall/resultrecords archived. Five nonblocking observations retained (O1–3Surfacecandidates,O4compilerseam,O5coverage limit). Mainreportcompanionlinkupdateds→t. Documentation/evidenceonly; no source/artifact/service changes or faultcell replay.
