Working tree review; no commits per root AGENTS. Base cac344e5aea4f53c40439b0f63d1db29c86eaacc

 better-dsh/package.json                   |    4 +-
 better-dsh/scripts/copy-kernel-bridge.mjs |   28 +-
 better-dsh/scripts/kernel-provision.mjs   |   38 +-
 better-dsh/src/bootstrap.ts               |  359 +---------
 better-dsh/src/kernel-bridge.py           |  172 -----
 better-dsh/src/kernel-env.ts              |  245 +------
 better-dsh/src/kernel-transport.ts        |  289 --------
 better-dsh/src/kernel.ts                  | 1063 +++++++----------------------
 better-dsh/src/python.ts                  |  331 +--------
 better-dsh/test/interrupt-race.spec.ts    |    2 +-
 better-dsh/test/kernel-env.spec.ts        |   45 +-
 better-dsh/test/runtime.spec.ts           |   32 +
 12 files changed, 371 insertions(+), 2237 deletions(-)

diff --git a/better-dsh/package.json b/better-dsh/package.json
index 3e646ac..599fd03 100644
--- a/better-dsh/package.json
+++ b/better-dsh/package.json
@@ -1,12 +1,12 @@
 {
   "name": "better-dsh",
   "version": "0.3.0-r",
-  "description": "Make your dsh ready for serious coding tasks. (Tools x Schemas)^REPL. `skill://`, `ctx://`, `agent://`, `dvc://`, `dsh://`, IPython REPL, Context as Variables, cross compactions recallable, full context revive. `hash-edit`, `dvc://browser`, subagent as function, workflow as function.",
+  "description": "Make your dsh ready for serious coding tasks. (Tools x Schemas)^REPL. `skill://`, `ctx://`, `agent://`, `dvc://`, `dsh://`, Python REPL, Context as Variables, cross compactions recallable, full context revive. `hash-edit`, `dvc://browser`, subagent as function, workflow as function.",
   "type": "module",
   "main": "lib/index.js",
   "types": "lib/index.d.ts",
   "exports": {
     ".": {
       "types": "./lib/index.d.ts",
       "default": "./lib/index.js"
     },
@@ -396,17 +396,17 @@
     "url": "git+https://github.com/pgmi-builds/super-dsh.git",
     "directory": "better-dsh"
   },
   "keywords": [
     "dsh",
     "deepseek-harness",
     "repl",
     "eval",
-    "ipython",
+    "python",
     "kernel",
     "agent",
     "plugin"
   ],
   "homepage": "https://github.com/pgmi-builds/super-dsh/tree/master/better-dsh",
   "bugs": {
     "url": "https://github.com/pgmi-builds/super-dsh/issues"
   }
diff --git a/better-dsh/scripts/copy-kernel-bridge.mjs b/better-dsh/scripts/copy-kernel-bridge.mjs
index 495e64c..9b6dd73 100644
--- a/better-dsh/scripts/copy-kernel-bridge.mjs
+++ b/better-dsh/scripts/copy-kernel-bridge.mjs
@@ -1,23 +1,7 @@
 #!/usr/bin/env node
-/**
- * Ship the Python kernel bridge beside the built entry.
- *
- * `tsdown` clears `lib/` on every build and only emits JavaScript, so the
- * stdio<->ZMQ bridge (`src/kernel-bridge.py`) is copied in afterwards:
- * `lib/kernel-bridge.py` is what `kernel-transport.ts` resolves through
- * `new URL('./kernel-bridge.py', import.meta.url)`. `files: ["lib", …]` then
- * carries it into the tarball with no extra manifest entry.
- *
- * Zero dependencies: `node:fs` only, like the rest of the build scripts.
- */
-import { copyFileSync, existsSync, mkdirSync, statSync } from 'node:fs'
-import { dirname, join } from 'node:path'
-import { fileURLToPath } from 'node:url'
-
-const here = dirname(fileURLToPath(import.meta.url))
-const source = join(here, '..', 'src', 'kernel-bridge.py')
-const target = join(here, '..', 'lib', 'kernel-bridge.py')
-
-if (!existsSync(join(here, '..', 'lib'))) mkdirSync(join(here, '..', 'lib'), { recursive: true })
-copyFileSync(source, target)
-console.log(`copy-kernel-bridge: ${statSync(target).size} bytes -> lib/kernel-bridge.py`)
+/** Copy all original runner, support, license and provenance resources after tsdown. */
+import { cpSync, mkdirSync } from 'node:fs'
+const target = new URL('../lib/omp-python/', import.meta.url)
+mkdirSync(target, { recursive: true })
+cpSync(new URL('../src/omp-python/', import.meta.url), target, { recursive: true, filter: path => !path.includes('__pycache__') && !path.endsWith('.pyc') })
+console.log('copy-kernel-bridge: packaged omp-python resources')
diff --git a/better-dsh/scripts/kernel-provision.mjs b/better-dsh/scripts/kernel-provision.mjs
index 1f11a22..fb912c5 100644
--- a/better-dsh/scripts/kernel-provision.mjs
+++ b/better-dsh/scripts/kernel-provision.mjs
@@ -1,35 +1,5 @@
 #!/usr/bin/env node
-/**
- * Best-effort kernel provisioning entry — the single code path behind BOTH
- * `postinstall` and `npm run kernel:venv`.
- *
- * Fail-open by design (2026-09-03 ruling): any failure logs a remedy hint and
- * exits 0. The installation must NEVER fail because the kernel could not be
- * provisioned here — the daemon spin-up check (primary path) and first-use
- * lazy provisioning (final fallback) complete the three-trigger ladder.
- */
-import { access } from 'node:fs/promises'
-
-const libUrl = new URL('../lib/kernel-env.js', import.meta.url)
-
-try {
-  await access(libUrl)
-} catch {
-  // Dev checkout before the first build, or a pruned install: nothing to call.
-  console.log('[dashr] kernel-env build output not present yet — skipping install-time pre-provision (the daemon spin-up check will provision on start)')
-  process.exit(0)
-}
-
-const { resolveKernelEnv } = await import(libUrl)
-
-try {
-  const env = await resolveKernelEnv({
-    autoInstall: true,
-    log: (level, message) => console[level === 'warn' ? 'warn' : 'log'](`[dashr] ${message}`),
-  })
-  console.log(`[dashr] kernel ready: python ${env.version} at ${env.python}${env.dill ? '' : ' (dill missing — snapshots disabled)'}`)
-} catch (error) {
-  console.warn(`[dashr] kernel pre-provision failed (non-blocking): ${error instanceof Error ? error.message : String(error)}`)
-  console.warn('[dashr] remedies: run "npm run kernel:venv" in the dashr package; or rely on the daemon spin-up check / first-use auto-install; or set python to a prepared interpreter')
-  process.exit(0)
-}
+/** Explicit compatibility command: prepare only a stdlib Python environment, never pip packages. */
+const { resolveKernelEnv } = await import(new URL('../lib/kernel-env.js', import.meta.url).href)
+const env = await resolveKernelEnv({ log: (level, message) => console[level === 'warn' ? 'warn' : 'log'](message) })
+console.log(`Better Python REPL ready: Python ${env.version} at ${env.python}`)
diff --git a/better-dsh/src/bootstrap.ts b/better-dsh/src/bootstrap.ts
index 62161a0..ed58d89 100644
--- a/better-dsh/src/bootstrap.ts
+++ b/better-dsh/src/bootstrap.ts
@@ -1,357 +1,2 @@
-/**
- * Python-side bootstrap executed once as an internal cell right after kernel
- * startup. Seeds the user namespace with the host-request comm bridge
- * (`dashr.host` target, the PA `host_request()` pattern), the binding-proxy
- * factories, the typed rejection classes, and the lossless-JSON completion
- * encoder. Names are `_dashr`/`__dashr` prefixed (any case) so they are
- * excluded from namespace snapshots and never leak into user state.
- * @module dashr/bootstrap
- */
-
-/** Comm target the kernel-side shim opens for typed host requests. */
-export const HOST_COMM_TARGET = 'dashr.host'
-
-/**
- * The bootstrap source. Kept dependency-free apart from `ast`, `asyncio`,
- * `json`, and `comm` (present by construction — it IS the kernel).
- */
-export const KERNEL_BOOTSTRAP = `
-import ast as _dashr_ast
-import json as _dashr_json
-
-
-def _dashr_install_control_comm_handlers():
-    # Host replies arrive as comm_msg on the CONTROL channel while the shell
-    # channel is busy executing our cell; teach the kernel to route them.
-    try:
-        from IPython import get_ipython
-    except Exception:
-        return
-    shell = get_ipython()
-    kernel = getattr(shell, 'kernel', None)
-    comm_manager = getattr(kernel, 'comm_manager', None)
-    control_handlers = getattr(kernel, 'control_handlers', None)
-    if comm_manager is None or not isinstance(control_handlers, dict):
-        return
-    control_handlers.setdefault('comm_msg', comm_manager.comm_msg)
-    control_handlers.setdefault('comm_close', comm_manager.comm_close)
-
-
-def _dashr_install_interrupt():
-    # ipykernel's async-cell SIGINT handling only schedules a callback on the
-    # kernel event loop, and a non-yielding cell ('while True: pass') blocks
-    # that very loop, so the control-channel interrupt can never break it.
-    # SIGALRM is untouched by ipykernel: raising KeyboardInterrupt from its
-    # handler breaks any cell, and the host sends it (after a confirm window,
-    # see the bridge) on timeout/abort. Best effort — where SIGALRM is
-    # unavailable the control-channel interrupt is all there is.
-    #
-    # The busy guard is load-bearing (M3-A, blueprint §5 "SIGALRM-at-idle 双重
-    # 窗口"): a KeyboardInterrupt raised OUTSIDE cell execution — while the
-    # kernel boots, idles between cells, or unwinds a finished one — escapes
-    # the shell's containment and terminates the process cleanly, which used
-    # to kill the kernel deterministically (10/10 same-tick aborts, 40/40
-    # during cold boot; dev/m2a-report.md §5.1). The handler therefore only
-    # raises while a dashr cell is actually executing, tracked by the
-    # module-level _dashr_state dict below and set/cleared by the run/snapshot
-    # cell scaffolds around their whole body. A stray SIGALRM outside that
-    # window is swallowed — the host's force-settle already resolves the run,
-    # and the kernel lives. The dict (not a bare flag) is captured by the
-    # handler closure, so user code rebinding the NAME cannot disarm the
-    # guard; mutating the dict itself stays possible and accepted — this shim
-    # is a capability seam, not a security boundary.
-    try:
-        import signal as _dashr_signal
-
-        def _dashr_on_sigalrm(_signum, _frame):
-            if not _dashr_state['executing']:
-                return
-            raise KeyboardInterrupt
-
-        _dashr_signal.signal(_dashr_signal.SIGALRM, _dashr_on_sigalrm)
-    except (ImportError, AttributeError, OSError, ValueError):
-        pass
-
-
-# The dashr busy-guard flag (see _dashr_install_interrupt): True for the whole
-# duration of a run or snapshot cell — the only window in which a SIGALRM may
-# raise KeyboardInterrupt. Lives at module (user-namespace) level so the cell
-# scaffolds can flip it; excluded from snapshots by the _dashr prefix rule.
-_dashr_state = {'executing': False}
-
-
-_dashr_install_interrupt()
-
-
-class _DashrRejected(Exception):
-    def __init__(self, message):
-        Exception.__init__(self, message)
-
-
-def _dashr_host_request(payload):
-    from comm import create_comm
-    import asyncio
-    _dashr_install_control_comm_handlers()
-    loop = asyncio.get_running_loop()
-    future = loop.create_future()
-    # primary=True publishes comm_open so the host learns this comm_id; the
-    # request itself travels as the first comm_msg.
-    comm = create_comm(target_name=${JSON.stringify(HOST_COMM_TARGET)})
-
-    def _resolve(action):
-        def _apply():
-            if future.done():
-                return
-            action()
-            comm.close()
-        # Replies arrive on the kernel's control channel, which may run off
-        # the event-loop thread; only call_soon_threadsafe may touch the
-        # future from there.
-        loop.call_soon_threadsafe(_apply)
-
-    def _on_msg(msg):
-        content = msg.get('content', {})
-        reply = content.get('data', {}) if isinstance(content, dict) else {}
-        if not isinstance(reply, dict) or future.done():
-            return
-        status = reply.get('status')
-        if status == 'ok':
-            _resolve(lambda: future.set_result(reply.get('result')))
-        elif status == 'error':
-            _resolve(lambda: future.set_exception(_DashrRejected(reply.get('error') or 'host request failed')))
-
-    comm.on_msg(_on_msg)
-    comm.send(dict(payload))
-    return future
-
-
-def _dashr_make_error_class(name, member_property):
-    def _init(self, message, member=None):
-        Exception.__init__(self, message)
-        if member is not None:
-            setattr(self, member_property, member)
-    return type(name, (Exception,), {'__init__': _init})
-
-
-def _dashr_make_proxy(global_name, function_name, error_class_name, member_property):
-    async def _dashr_proxy(*args, **kwargs):
-        if kwargs:
-            raise TypeError('dashr binding calls do not accept keyword arguments')
-        if len(args) == 1:
-            call_args = args[0]
-        elif len(args) == 0:
-            call_args = None
-        else:
-            call_args = list(args)
-        payload = {
-            'type': 'binding.call',
-            'global': global_name,
-            'name': function_name,
-            'args': call_args,
-        }
-        try:
-            return await _dashr_host_request(payload)
-        except _DashrRejected as rejected:
-            cls = globals().get(error_class_name) if error_class_name else None
-            if cls is None:
-                raise
-            raise cls(str(rejected), function_name) from None
-    return _dashr_proxy
-
-
-def _dashr_make_holder(global_name, error_class_name, member_property, members):
-    # Attribute misses travel to the host instead of raising AttributeError
-    # here: the host owns the namespace, so IT rejects an unknown member as an
-    # unknown binding rather than the kernel inventing a local error class.
-    class _DashrBindingHolder:
-        def __dir__(self):
-            # F9 (v0.2.0-a): introspection tells the truth — dir(tool) lists
-            # exactly the bound names. A custom __dir__ fully replaces the
-            # default object.__dir__, so no dunder noise leaks in.
-            return list(members)
-
-        def __getattr__(self, function_name):
-            return _dashr_make_proxy(
-                global_name,
-                function_name,
-                error_class_name,
-                member_property,
-            )
-
-    return _DashrBindingHolder()
-
-
-def _dashr_make_callable(global_name, function_name, error_class_name, member_property):
-    # A BARE callable global (the flat per-tool bindings AND the bridge
-    # tools: 'callable: true' on the namespace) instead of an object
-    # holder. The one-object form is the single convention: every callable
-    # takes exactly one positional arguments object (e.g.
-    # agent_message({'receiver': 'child', ...})), and keyword / multi-positional forms are
-    # rejected HERE, at the Python call boundary, so the introspectable
-    # signature tells the truth and a TypeError names the binding global
-    # (read(...) got an unexpected keyword argument ...). The wire envelope
-    # keeps the historical {'args': [...], 'kwargs': {}} shape so the host's
-    # parseReplCall / flatToolArgs / flatBridgeToolArgs validation layers stay
-    # authoritative and unchanged. The single functions-entry name is
-    # transport-only: the program never sees it, and a typed rejection
-    # carries the GLOBAL name as its member (for a flat tool binding the
-    # global IS the tool name the program knows). __name__/__qualname__ are
-    # pinned to the global name so introspection shows the binding's name,
-    # not the factory-local _dashr_callable.
-    async def _dashr_callable(args=None, /):
-        payload = {
-            'type': 'binding.call',
-            'global': global_name,
-            'name': function_name,
-            'args': {'args': [] if args is None else [args], 'kwargs': {}},
-        }
-        try:
-            return await _dashr_host_request(payload)
-        except _DashrRejected as rejected:
-            cls = globals().get(error_class_name) if error_class_name else None
-            if cls is None:
-                raise
-            raise cls(str(rejected), global_name) from None
-
-    _dashr_callable.__name__ = global_name
-    _dashr_callable.__qualname__ = global_name
-    return _dashr_callable
-
-
-class _DashrNoValue:
-    # Marks 'no completion value': a cell whose last statement is not an
-    # expression, or whose last expression evaluates to None — the REPL
-    # displayhook suppresses None (IPython behavior), so no value crosses.
-    __slots__ = ()
-
-
-_DASHR_NO_VALUE = _DashrNoValue()
-
-
-class _DashrTopLevelReturnChecker(_dashr_ast.NodeVisitor):
-    # A cell runs at module scope, like any native IPython cell: a top-level
-    # 'return'/'yield' is a SyntaxError decided by the kernel itself, exactly
-    # as in a real REPL. Nested scopes (functions, lambdas, classes) keep
-    # their own return semantics.
-    def visit_FunctionDef(self, node):
-        return
-
-    def visit_AsyncFunctionDef(self, node):
-        return
-
-    def visit_ClassDef(self, node):
-        return
-
-    def visit_Lambda(self, node):
-        return
-
-    def visit_Return(self, node):
-        raise SyntaxError("'return' outside function")
-
-    def visit_Yield(self, node):
-        raise SyntaxError("'yield' outside function")
-
-
-async def _dashr_run_program(source):
-    # Run one cell with the user namespace as BOTH globals and locals —
-    # module-scope REPL semantics: state persists across cells, top-level
-    # 'await' is legal (PyCF_ALLOW_TOP_LEVEL_AWAIT, the same mechanism IPython
-    # uses), a top-level 'return'/'yield' is a SyntaxError decided here by the
-    # kernel — exactly as in a native IPython cell — and the last expression's
-    # value is the cell's result (the REPL displayhook handoff).
-    import inspect as _dashr_inspect
-    user_ns = globals()
-    if not source.strip():
-        source = 'pass'
-    parsed = _dashr_ast.parse(source, '<dashr program>', 'exec')
-    _DashrTopLevelReturnChecker().visit(parsed)
-    body = parsed.body
-    if body and isinstance(body[-1], _dashr_ast.Expr):
-        # Capture the last expression the way a REPL's displayhook shows it:
-        # its value feeds the completion envelope instead of being discarded.
-        # The name is distinct from the scaffold's __dashr_completion__ (the
-        # envelope holder) so a statement-ending cell can never pop a stale
-        # envelope left by an earlier run.
-        last = body[-1]
-        body[-1] = _dashr_ast.Assign(
-            targets=[_dashr_ast.Name(id='__dashr_cell_value__', ctx=_dashr_ast.Store())],
-            value=last.value,
-        )
-        _dashr_ast.fix_missing_locations(body[-1])
-    code = compile(
-        parsed,
-        '<dashr program>',
-        'exec',
-        flags=_dashr_ast.PyCF_ALLOW_TOP_LEVEL_AWAIT,
-    )
-    # IPython's own run_code pattern: with PyCF_ALLOW_TOP_LEVEL_AWAIT, plain
-    # exec() DISCARDS the module coroutine silently; eval() under await
-    # returns it and runs the code (IPython InteractiveShell.run_code does
-    # exactly 'await eval(code_obj, user_global_ns, user_ns)').
-    result = eval(code, user_ns, user_ns)
-    if _dashr_inspect.iscoroutine(result):
-        await result
-    value = user_ns.pop('__dashr_cell_value__', _DASHR_NO_VALUE)
-    if value is None:
-        return _DASHR_NO_VALUE
-    return value
-
-
-def _dashr_install_bindings(spec_json):
-    spec = _dashr_json.loads(spec_json)
-    user_ns = globals()
-    injected = user_ns.get('__dashr_injected__', {})
-    for old_name, old_spec in list(injected.items()):
-        if old_name not in spec:
-            user_ns.pop(old_name, None)
-            if old_spec.get('errorClass'):
-                user_ns.pop(old_spec['errorClass']['name'], None)
-    fresh = {}
-    # The flat per-tool shape declares the SAME error class on many
-    # namespaces: materialize each DISTINCT name once, so every proxy's
-    # raise-time globals() lookup finds ONE class and a single
-    # 'except ToolCallError' catches failures from every binding.
-    error_classes = {}
-    for global_name, namespace in spec.items():
-        error_class = namespace.get('errorClass')
-        if namespace.get('callable'):
-            # Exactly one function entry was validated by the host; its key is
-            # the transport name, the bare global itself is the callable.
-            function_name = next(iter(namespace['functions']))
-            user_ns[global_name] = _dashr_make_callable(
-                global_name,
-                function_name,
-                error_class['name'] if error_class else None,
-                error_class['memberNameProperty'] if error_class else None,
-            )
-        else:
-            user_ns[global_name] = _dashr_make_holder(
-                global_name,
-                error_class['name'] if error_class else None,
-                error_class['memberNameProperty'] if error_class else None,
-                sorted(namespace['functions']),
-            )
-        if error_class and error_class['name'] not in error_classes:
-            cls = _dashr_make_error_class(
-                error_class['name'],
-                error_class['memberNameProperty'],
-            )
-            error_classes[error_class['name']] = cls
-            user_ns[error_class['name']] = cls
-        fresh[global_name] = namespace
-    user_ns['__dashr_injected__'] = fresh
-
-
-def _dashr_encode(value):
-    if value is _DASHR_NO_VALUE:
-        return {'ok': True}
-    try:
-        return {'ok': True, 'json': _dashr_json.dumps(value, allow_nan=False)}
-    except (TypeError, ValueError, OverflowError):
-        # Not lossless JSON: pass its repr TEXT through instead of failing
-        # the cell. The upstream renders the tool result as text either way,
-        # so a non-JSON value costs the model nothing; the host keeps a
-        # plain string it forwards untouched. The envelope itself never
-        # fails, so the completion never gate-rejects a return value.
-        return {'ok': True, 'json': _dashr_json.dumps(repr(value))}
-`
+/** Module-qualified initialization survives OMP %reset without leaking imports. */
+export const KERNEL_BOOTSTRAP = `__import__('better_support').initialize(globals())`
diff --git a/better-dsh/src/kernel-bridge.py b/better-dsh/src/kernel-bridge.py
deleted file mode 100644
index b5bd2a1..0000000
--- a/better-dsh/src/kernel-bridge.py
+++ /dev/null
@@ -1,172 +0,0 @@
-#!/usr/bin/env python3
-"""stdio <-> ZeroMQ bridge for the DASHR REPL.
-
-The host (Node/TS) owns the kernel lifecycle but must not link a native ZMQ
-binding: `zeromq` was a hard npm dependency whose install script compiles C++
-inside the consumer's install transaction (and whose top-level import killed
-the whole plugin when the binding was missing). This process is the only ZMQ
-speaker on the host side; it speaks JSON lines on stdio to Node.
-
-    Node  ──stdio JSON lines──►  kernel-bridge.py  ──pyzmq/jupyter_client──►  ipykernel
-
-Requirements come from the kernel's own environment: `jupyter_client` and
-`pyzmq` are transitive dependencies of the `ipykernel` we provision (see
-`kernel-env.ts`), so nothing extra is fetched from any package manager.
-
-Protocol
---------
-stdin (one JSON object per line)::
-
-    {"op":"send","channel":"shell"|"control","header":{...},"content":{...}}
-    {"op":"interrupt"}
-    {"op":"shutdown"}
-
-stdout (one JSON object per line)::
-
-    {"ev":"ready"}
-    {"ev":"msg","channel":"shell"|"iopub"|"control"|"stdin","msg":{...}}
-    {"ev":"fatal","message":"..."}
-
-The caller-supplied `header` is passed to `Session.msg` verbatim, so the
-message id the host generated is the id on the wire — parent-matching and
-request/response correlation stay exactly as they were on the raw-socket path.
-"""
-from __future__ import annotations
-
-import json
-import queue
-import sys
-import threading
-
-CHANNELS = ("iopub", "shell", "control", "stdin")
-POLL_SECONDS = 0.2
-
-# Protocol output goes to the real stdout; anything a library prints must never
-# corrupt the byte stream the host parses, so sys.stdout is repointed to stderr.
-_PROTOCOL_OUT = sys.stdout
-sys.stdout = sys.stderr
-
-_write_lock = threading.Lock()
-
-
-def emit(payload: dict) -> None:
-    """Write one protocol line, atomically across the pump threads."""
-    # `default=str`: jupyter_client hands back parsed values (a header `date`
-    # arrives as `datetime`, for instance) that are not JSON-native; the host
-    # only reads msg_id/msg_type/content, so stringifying the rest is lossless
-    # for its purposes and keeps one pump thread from dying on a header field.
-    line = json.dumps(payload, ensure_ascii=False, default=str)
-    with _write_lock:
-        _PROTOCOL_OUT.write(line + "\n")
-        _PROTOCOL_OUT.flush()
-
-
-def _clean(value: object) -> object:
-    """Strip binary buffers: this protocol carries JSON only."""
-    if isinstance(value, dict):
-        return {key: _clean(item) for key, item in value.items() if key != "buffers"}
-    if isinstance(value, (list, tuple)):
-        return [_clean(item) for item in value]
-    if isinstance(value, bytes):
-        return value.decode("utf-8", "replace")
-    return value
-
-
-def pump(client, name: str, stop: threading.Event) -> None:
-    """Relay one client channel onto stdout until `stop` is set."""
-    channel = getattr(client, f"{name}_channel")
-    while not stop.is_set():
-        try:
-            message = channel.get_msg(timeout=POLL_SECONDS)
-        except queue.Empty:
-            continue
-        except Exception as error:  # channel torn down, or the socket died
-            if not stop.is_set():
-                emit({"ev": "fatal", "channel": name, "message": f"{type(error).__name__}: {error}"})
-        try:
-            emit({
-                "ev": "msg",
-                "channel": name,
-                "msg": {
-                    "header": message.get("header") or {},
-                    "parent_header": message.get("parent_header") or {},
-                    "content": _clean(message.get("content") or {}),
-                    "metadata": _clean(message.get("metadata") or {}),
-                },
-            })
-        except Exception as error:  # never let one message kill a channel pump
-            sys.stderr.write(f"kernel-bridge: cannot relay {name} message: {type(error).__name__}: {error}\n")
-            sys.stderr.flush()
-
-
-def main() -> int:
-    if len(sys.argv) != 2:
-        emit({"ev": "fatal", "message": "usage: kernel-bridge.py <connection-file>"})
-        return 2
-
-    try:
-        from jupyter_client import BlockingKernelClient
-    except Exception as error:  # the kernel environment is incomplete
-        emit({"ev": "fatal", "message": f"jupyter_client unavailable: {type(error).__name__}: {error}"})
-        return 3
-
-    try:
-        client = BlockingKernelClient(connection_file=sys.argv[1])
-        client.load_connection_file()
-        client.start_channels()
-    except Exception as error:
-        emit({"ev": "fatal", "message": f"cannot connect to the kernel: {type(error).__name__}: {error}"})
-        return 4
-
-    stop = threading.Event()
-    for name in CHANNELS:
-        threading.Thread(target=pump, args=(client, name, stop), name=f"pump-{name}", daemon=True).start()
-
-    emit({"ev": "ready"})
-
-    try:
-        for line in sys.stdin:
-            line = line.strip()
-            if not line:
-                continue
-            try:
-                request = json.loads(line)
-            except Exception:
-                continue
-            op = request.get("op")
-            if op == "send":
-                channel_name = request.get("channel")
-                if channel_name not in ("shell", "control"):
-                    emit({"ev": "fatal", "message": f"unknown send channel {channel_name!r}"})
-                    continue
-                channel = getattr(client, f"{channel_name}_channel")
-                try:
-                    header = request.get("header") or None
-                    message = client.session.msg(
-                        header["msg_type"] if header else "comm_msg",
-                        content=request.get("content") or {},
-                        header=header,
-                    )
-                    channel.send(message)
-                except Exception as error:
-                    emit({"ev": "fatal", "channel": channel_name, "message": f"send failed: {type(error).__name__}: {error}"})
-            elif op == "interrupt":
-                try:
-                    client.interrupt_kernel()
-                except Exception as error:
-                    emit({"ev": "fatal", "message": f"interrupt failed: {type(error).__name__}: {error}"})
-            elif op == "shutdown":
-                break
-    except (KeyboardInterrupt, BrokenPipeError):
-        pass
-    finally:
-        stop.set()
-        try:
-            client.stop_channels()
-        except Exception:
-            pass
-    return 0
-
-
-if __name__ == "__main__":
-    sys.exit(main())
diff --git a/better-dsh/src/kernel-env.ts b/better-dsh/src/kernel-env.ts
index 07485ac..514e2b7 100644
--- a/better-dsh/src/kernel-env.ts
+++ b/better-dsh/src/kernel-env.ts
@@ -1,248 +1,59 @@
-/**
- * Kernel environment resolution and provisioning.
- *
- * The runtime OWNS the interpreter it spawns: it never trusts a bare
- * `python3` on the PATH, because that interpreter may lack `ipykernel`
- * (hard failure — the kernel cannot start) or `dill` (snapshot capability —
- * silently degrading to no snapshots). Instead it resolves one of two
- * environments:
- *
- * - **Explicit** — `config.python` names a real interpreter (a path, or any
- *   name other than the bare-`python3` sentinel the default/patch produce).
- *   It is probed, and a missing `ipykernel` is a loud error while a missing
- *   `dill` is a loud warning (snapshots disabled).
- * - **Managed** — no explicit interpreter: the runtime provisions a venv
- *   UNDER THE PACKAGE (`<packageRoot>/.venv-kernel`, or `config.kernelEnvDir`)
- *   with `ipykernel` + `dill`, installing it on first use when
- *   `config.kernelAutoInstall` is on. The venv lives beside the package, NOT
- *   in `/tmp` (the pre-v0.1.9 dangling-symlink failure mode), so it survives
- *   the host's tmp reaper and the process restart.
- *
- * Provisioning uses `uv` when available (fast, can fetch the pinned CPython
- * version), falling back to `python3 -m venv` + `ensurepip`. It is idempotent:
- * a complete venv is reused untouched; a partial one is repaired.
- * @module dashr/kernel-env
- */
-
+/** Resolve a Python >=3.9 interpreter. The packaged OMP runner needs only stdlib. */
 import { execFile } from 'node:child_process'
 import { existsSync, mkdirSync } from 'node:fs'
 import { dirname, join, resolve } from 'node:path'
 import { fileURLToPath } from 'node:url'
 import { promisify } from 'node:util'
-
-const execFileAsync = promisify(execFile)
-
-/** The installed package root (where `lib/` and `src/` live): the default home of the managed venv. */
+const exec = promisify(execFile)
 export const PACKAGE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
-
-/** The config value meaning "no explicit interpreter — auto-manage a venv". */
 export const AUTO_PYTHON_SENTINEL = 'python3'
-
-/** Preferred CPython version for a managed venv. */
 export const DEFAULT_KERNEL_PYTHON_VERSION = '3.11'
-
-/** Pinned, tested `ipykernel` version (2026-09-02 tested value; upgrade = explicit change + regression). */
-export const IPYKERNEL_VERSION = '7.3.0'
-
-/** Pinned, tested `dill` version. */
 export const DILL_VERSION = '0.4.1'
-
 export interface KernelEnv {
-  /** Absolute path to the interpreter to spawn (`-m ipykernel_launcher`). */
   python: string
-  /** True when this runtime provisioned a venv (vs an explicit interpreter). */
   managed: boolean
-  /** The managed venv root, when {@link managed}. */
   venvDir: string | undefined
-  /** True when `dill` is importable — snapshot capability is available. */
+  /** Snapshot implementation is packaged rather than installed into Python. */
   dill: boolean
-  /** True when `ipykernel` is importable (a hard requirement). */
-  ipykernel: boolean
-  /** The interpreter's reported version, e.g. `3.11.15`. */
   version: string
 }
-
 export interface ResolveKernelEnvOptions {
-  /** `config.python`; the bare sentinel (or absent) selects a managed venv. */
   python?: string
-  /** Managed venv directory; defaults to `<packageRoot>/.venv-kernel`. */
   venvDir?: string
-  /** Preferred CPython version for the managed venv. */
   pythonVersion?: string
-  /** Provision the managed venv when missing/incomplete (default true). */
   autoInstall?: boolean
-  /** Logger callback (info on provisioning, warn on degraded snapshot). */
   log?: (level: 'info' | 'warn', message: string) => void
 }
-
-interface Probe {
-  version: string
-  ipykernel: boolean
-  dill: boolean
-}
-
-/** A probe that never imports user modules and reports exactly what we need. */
-const PROBE_CODE = [
-  'import json, sys',
-  'r = {"version": sys.version.split()[0], "ipykernel": False, "dill": False}',
-  'try:',
-  '    import ipykernel  # noqa: F401',
-  '    r["ipykernel"] = True',
-  'except Exception:',
-  '    pass',
-  'try:',
-  '    import dill  # noqa: F401',
-  '    r["dill"] = True',
-  'except Exception:',
-  '    pass',
-  'print(json.dumps(r))',
-].join('\n')
-
-async function probePython(python: string): Promise<Probe | null> {
-  try {
-    const { stdout } = await execFileAsync(python, ['-c', PROBE_CODE], { timeout: 15_000 })
-    const parsed = JSON.parse(stdout.trim()) as Partial<Probe>
-    return {
-      version: typeof parsed.version === 'string' && parsed.version.length > 0 ? parsed.version : 'unknown',
-      ipykernel: parsed.ipykernel === true,
-      dill: parsed.dill === true,
-    }
-  } catch {
-    return null
-  }
-}
-
-/** The venv interpreter path for this platform. */
-function venvPythonPath(venvDir: string): string {
-  return process.platform === 'win32'
-    ? join(venvDir, 'Scripts', 'python.exe')
-    : join(venvDir, 'bin', 'python')
-}
-
-async function commandExists(cmd: string): Promise<boolean> {
-  try {
-    await execFileAsync(cmd, ['--version'], { timeout: 10_000 })
-    return true
-  } catch {
-    return false
-  }
-}
-
-/** Tool-cache env for uv: caches live NEXT TO the venv (plugin territory), so a read-only home can never block provisioning. */
 export function uvToolEnv(venvDir: string): NodeJS.ProcessEnv {
-  const cacheDir = join(dirname(venvDir), '.uv-cache')
-  return {
-    ...process.env,
-    UV_CACHE_DIR: cacheDir,
-    UV_PYTHON_INSTALL_DIR: join(cacheDir, 'python'),
-    UV_LINK_MODE: 'copy',
-  }
-}
-
-/** uv venv arguments (pure; unit-tested). */
-export function uvVenvArgs(venvDir: string, pythonVersion: string): string[] {
-  return ['venv', venvDir, '--python', pythonVersion]
-}
-
-/** python3 -m venv fallback arguments (pure; cache-free by construction). */
-export function venvFallbackArgs(venvDir: string): string[] {
-  return ['-m', 'venv', venvDir]
+  const cache = join(dirname(venvDir), '.uv-cache')
+  return { ...process.env, UV_CACHE_DIR: cache, UV_PYTHON_INSTALL_DIR: join(cache, 'python'), UV_LINK_MODE: 'copy' }
 }
-
-/** uv pip install arguments with pinned versions (pure; unit-tested). */
-export function uvInstallArgs(python: string): string[] {
-  return ['pip', 'install', '--python', python, '--quiet', `ipykernel==${IPYKERNEL_VERSION}`, `dill==${DILL_VERSION}`]
-}
-
-/** pip install arguments with pinned versions for the venv interpreter (pure). */
-export function pipInstallArgs(): string[] {
-  return ['-m', 'pip', 'install', '--quiet', '--disable-pip-version-check', `ipykernel==${IPYKERNEL_VERSION}`, `dill==${DILL_VERSION}`]
-}
-
-/** Create the venv (when absent) and return its interpreter path. */
-async function createVenv(venvDir: string, pythonVersion: string): Promise<string> {
-  const python = venvPythonPath(venvDir)
-  if (existsSync(python)) return python
-  if (await commandExists('uv')) {
-    mkdirSync(join(dirname(venvDir), '.uv-cache'), { recursive: true })
-    await execFileAsync('uv', uvVenvArgs(venvDir, pythonVersion), { timeout: 120_000, env: uvToolEnv(venvDir) })
-  } else {
-    await execFileAsync('python3', venvFallbackArgs(venvDir), { timeout: 120_000 })
-  }
-  return python
-}
-
-/** Install pinned `ipykernel` + `dill` into the venv interpreter. */
-async function installDeps(python: string, venvDir: string): Promise<void> {
-  if (await commandExists('uv')) {
-    await execFileAsync('uv', uvInstallArgs(python), { timeout: 180_000, env: uvToolEnv(venvDir) })
-  } else {
-    await execFileAsync(python, pipInstallArgs(), { timeout: 180_000 })
-  }
-}
-
-/** Provision (or repair) the managed venv so it has `ipykernel` + `dill`. */
-async function ensureVenv(venvDir: string, pythonVersion: string, log?: ResolveKernelEnvOptions['log']): Promise<string> {
-  const python = venvPythonPath(venvDir)
-  const existing = existsSync(python) ? await probePython(python) : null
-  if (existing?.ipykernel === true && existing.dill === true) {
-    return python
-  }
-  await createVenv(venvDir, pythonVersion)
-  if (!existsSync(python)) {
-    throw new Error(`dashr-repl: managed kernel venv was not created at ${venvDir} (no interpreter at ${python})`)
+export function uvVenvArgs(dir: string, version: string): string[] { return ['venv', dir, '--python', version] }
+export function venvFallbackArgs(dir: string): string[] { return ['-m', 'venv', '--without-pip', dir] }
+function venvPython(dir: string): string { return join(dir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python') }
+async function probe(python: string): Promise<string> {
+  try {
+    const { stdout } = await exec(python, ['-c', 'import ast, asyncio, json, sys; assert sys.version_info >= (3, 9), "Python >=3.9 required"; print(json.dumps(sys.version.split()[0]))'], { timeout: 15_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' } })
+    return JSON.parse(stdout.trim()) as string
+  } catch (error) {
+    throw new Error(`Better Python REPL requires Python >=3.9. Could not use ${JSON.stringify(python)}: ${error instanceof Error ? error.message : String(error)}. Configure python with a working interpreter path.`)
   }
-  log?.('info', `dashr-repl: provisioning kernel venv at ${venvDir} (ipykernel + dill)`)
-  await installDeps(python, venvDir)
-  return python
 }
-
-/**
- * Resolve the kernel interpreter, provisioning a managed venv when no
- * explicit interpreter is configured. Throws when the resolved interpreter
- * cannot run `ipykernel`; a missing `dill` only disables snapshots (warned).
- */
 export async function resolveKernelEnv(options: ResolveKernelEnvOptions = {}): Promise<KernelEnv> {
-  const log = options.log
-  const explicit = options.python !== undefined && options.python !== '' && options.python !== AUTO_PYTHON_SENTINEL
-    ? options.python
-    : undefined
-
-  if (explicit !== undefined) {
-    const probe = await probePython(explicit)
-    if (probe === null) {
-      throw new Error(`dashr-repl: kernel python ${JSON.stringify(explicit)} could not be executed — check the path`)
-    }
-    if (!probe.ipykernel) {
-      throw new Error(`dashr-repl: kernel python ${JSON.stringify(explicit)} has no ipykernel — install it (pip install ipykernel) or set python to a managed venv`)
-    }
-    if (!probe.dill) {
-      log?.('warn', `dashr-repl: kernel python ${JSON.stringify(explicit)} has no dill — namespace snapshots are DISABLED (install it: pip install dill)`)
-    }
-    return { python: explicit, managed: false, venvDir: undefined, dill: probe.dill, ipykernel: true, version: probe.version }
+  if (options.python && options.python !== AUTO_PYTHON_SENTINEL) {
+    return { python: options.python, managed: false, venvDir: undefined, dill: true, version: await probe(options.python) }
   }
-
   const venvDir = options.venvDir ?? join(PACKAGE_ROOT, '.venv-kernel')
-  const python = venvPythonPath(venvDir)
-
-  if (options.autoInstall === false) {
-    const probe = await probePython(python)
-    if (probe === null || !probe.ipykernel) {
-      throw new Error(`dashr-repl: managed kernel venv is missing or incomplete at ${venvDir} — run 'npm run kernel:venv' in the dashr package, or set kernelAutoInstall: true (or python to a prepared interpreter)`)
-    }
-    if (!probe.dill) {
-      log?.('warn', `dashr-repl: kernel venv at ${venvDir} has no dill — namespace snapshots are DISABLED (run 'npm run kernel:venv' to reinstall)`)
-    }
-    return { python, managed: true, venvDir, dill: probe.dill, ipykernel: true, version: probe.version }
-  }
-
-  const resolved = await ensureVenv(venvDir, options.pythonVersion ?? DEFAULT_KERNEL_PYTHON_VERSION, log)
-  const probe = await probePython(resolved)
-  if (probe === null || !probe.ipykernel) {
-    throw new Error(`dashr-repl: managed kernel venv at ${venvDir} still has no ipykernel after provisioning — check uv/python3-venv availability and retry`)
-  }
-  if (!probe.dill) {
-    log?.('warn', `dashr-repl: managed kernel venv at ${venvDir} has no dill after provisioning — namespace snapshots are DISABLED`)
-  }
-  return { python: resolved, managed: true, venvDir, dill: probe.dill, ipykernel: true, version: probe.version }
+  const python = venvPython(venvDir)
+  if (!existsSync(python)) {
+    if (options.autoInstall === false) throw new Error(`Better Python REPL managed interpreter is missing at ${python}; configure python or run npm run kernel:venv`)
+    options.log?.('info', `Creating stdlib-only Python environment at ${venvDir} (no pip packages)`)
+    let uv = false
+    try { await exec('uv', ['--version'], { timeout: 10_000 }); uv = true } catch { /* system Python fallback */ }
+    if (uv) {
+      mkdirSync(join(dirname(venvDir), '.uv-cache'), { recursive: true })
+      await exec('uv', uvVenvArgs(venvDir, options.pythonVersion ?? DEFAULT_KERNEL_PYTHON_VERSION), { timeout: 120_000, env: uvToolEnv(venvDir) })
+    } else await exec('python3', venvFallbackArgs(venvDir), { timeout: 120_000 })
+  }
+  return { python, managed: true, venvDir, dill: true, version: await probe(python) }
 }
diff --git a/better-dsh/src/kernel-transport.ts b/better-dsh/src/kernel-transport.ts
deleted file mode 100644
index 89dbff8..0000000
--- a/better-dsh/src/kernel-transport.ts
+++ /dev/null
@@ -1,289 +0,0 @@
-/**
- * stdio transport to the Python kernel bridge (`kernel-bridge.py`).
- *
- * The host never links a native ZMQ binding: `zeromq` was a hard npm
- * dependency whose install script compiled C++ inside the consumer's install
- * transaction, and whose top-level import took the whole plugin down with it
- * whenever the binding was absent. The bridge owns pyzmq/jupyter_client —
- * transitive dependencies of the `ipykernel` this plugin already provisions —
- * and speaks JSON lines on stdio to this process.
- *
- * Message ids stay host-generated: the header built here is passed through to
- * `jupyter_client.Session.msg` verbatim, so parent-matching is unchanged from
- * the raw-socket era.
- * @module dashr/kernel-transport
- */
-
-import { type ChildProcess, spawn } from 'node:child_process'
-import { createInterface, type Interface } from 'node:readline'
-import { fileURLToPath } from 'node:url'
-import { tmpdir } from 'node:os'
-
-/** Channels the bridge relays; `stdin` is unused (cells run with allow_stdin=false). */
-export type TransportChannel = 'shell' | 'iopub' | 'control' | 'stdin'
-
-/** One Jupyter message as relayed by the bridge. */
-export interface TransportMessage {
-  header: { msg_id: string, msg_type: string, [key: string]: unknown }
-  parent_header: Record<string, unknown>
-  content: Record<string, unknown>
-}
-
-/** Message handler; returning nothing, it must never throw into the reader. */
-export type TransportHandler = (channel: TransportChannel, message: TransportMessage) => void
-
-/** A one-shot wait for a specific channel message. */
-interface Waiter {
-  channel: TransportChannel
-  match: (message: TransportMessage) => boolean
-  settle: (message: TransportMessage | null) => void
-  timer: ReturnType<typeof setTimeout>
-}
-
-/** The bridge script shipped beside the built entry (`lib/kernel-bridge.py`). */
-const BRIDGE_SCRIPT = fileURLToPath(new URL('./kernel-bridge.py', import.meta.url))
-
-/** Options for one bridge process. */
-export interface KernelTransportOptions {
-  /** Absolute interpreter path; must be the kernel environment (jupyter_client + pyzmq). */
-  python: string
-  /** Connection file written by the kernel and already resolved to real ports. */
-  connectionFile: string
-  /** Working directory for the bridge process. */
-  cwd?: string
-  /** Budget for the bridge to report readiness, in milliseconds. */
-  readyTimeoutMs: number
-}
-
-/**
- * One bridge subprocess speaking JSON lines. Lifecycle is owned by the caller
- * (the kernel bridge registers it as an `ctx.effect`); this type installs no
- * process-level signal handlers.
- */
-export class KernelTransport {
-  private child?: ChildProcess
-  private reader?: Interface
-  private startup = false
-  private closed = false
-  private readySettled = false
-  private readyResolve?: () => void
-  private readyReject?: (error: Error) => void
-  private bridgeStderr = ''
-  private readonly handlers = new Set<TransportHandler>()
-  private readonly waiters = new Set<Waiter>()
-
-  constructor(private readonly options: KernelTransportOptions) { }
-
-  /** Spawn the bridge and resolve once it reports the channels are up. */
-  async start(): Promise<void> {
-    if (this.reader !== undefined) return
-    if (this.closed) throw new Error('kernel transport is closed')
-    const child = spawn(this.options.python, [BRIDGE_SCRIPT, this.options.connectionFile], {
-      ...this.options.cwd === undefined ? {} : { cwd: this.options.cwd },
-      // The same scrubbed environment as the kernel spawn: an absolute
-      // interpreter, no ambient credentials, HOME for interpreter caches.
-      env: {
-        PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin',
-        LANG: 'C.UTF-8',
-        HOME: process.env.HOME ?? tmpdir(),
-        PYTHONUNBUFFERED: '1',
-      },
-      stdio: ['pipe', 'pipe', 'pipe'],
-    })
-    this.child = child
-    this.startup = true
-    const ready = new Promise<void>((resolve, reject) => {
-      this.readyResolve = resolve
-      this.readyReject = reject
-    })
-    const timer = setTimeout(() => {
-      this.failReady(new Error(`kernel bridge did not report ready within ${this.options.readyTimeoutMs}ms; stderr tail:\n${this.stderrTail()}`))
-    }, this.options.readyTimeoutMs)
-    timer.unref?.()
-
-    child.stderr?.on('data', (buffer: Buffer) => { this.bridgeStderr += buffer.toString() })
-    // A bridge that died between the liveness check and a write surfaces EPIPE
-    // asynchronously; without a listener Node escalates it to an uncaught
-    // exception and takes the daemon down during teardown. Absorb it: the
-    // transport is already dead, and every waiter is settled below.
-    child.stdin?.on('error', (error: NodeJS.ErrnoException) => {
-      this.bridgeStderr += `stdin error: ${error.code ?? error.message}\n`
-      this.closed = true
-      this.failWaiters()
-    })
-    child.stdout?.on('error', (error: NodeJS.ErrnoException) => {
-      this.bridgeStderr += `stdout error: ${error.code ?? error.message}\n`
-    })
-    child.on('error', (error: Error) => {
-      this.bridgeStderr += `spawn error: ${error.message}\n`
-      this.failReady(new Error(`kernel bridge failed to spawn: ${error.message}`))
-      this.failWaiters()
-      this.failExit()
-    })
-    child.on('exit', (code, signal) => {
-      const detail = `kernel bridge exited (code=${String(code)} signal=${String(signal)})`
-      this.bridgeStderr += `${detail}\n`
-      this.closed = true
-      this.failReady(new Error(`${detail}; stderr tail:\n${this.stderrTail()}`))
-      this.failWaiters()
-      this.failExit()
-    })
-    if (child.stdout) {
-      this.reader = createInterface({ input: child.stdout })
-      this.reader.on('line', (line: string) => { this.accept(line) })
-    }
-
-    try {
-      await ready
-    } finally {
-      clearTimeout(timer)
-      this.startup = false
-    }
-  }
-
-  /** Whether the bridge process is still live. */
-  get alive(): boolean {
-    return this.child !== undefined && this.child.exitCode === null && !this.closed
-  }
-
-  /** The bridge's stderr tail, for startup and crash diagnostics. */
-  stderrTail(): string {
-    return this.bridgeStderr.slice(-1024) || '(empty)'
-  }
-
-  /** Register a message handler; the returned function removes it. */
-  onMessage(handler: TransportHandler): () => void {
-    this.handlers.add(handler)
-    return () => { this.handlers.delete(handler) }
-  }
-
-  /**
-   * Register a bridge-exit handler; the returned function removes it. A bridge
-   * that dies mid-cell must settle the active execution at once rather than at
-   * the cell budget.
-   */
-  onExit(handler: () => void): () => void {
-    this.exitHandlers.add(handler)
-    return () => { this.exitHandlers.delete(handler) }
-  }
-
-  private readonly exitHandlers = new Set<() => void>()
-
-  /** Notify exit handlers once per bridge process end. */
-  private failExit(): void {
-    const handlers = [...this.exitHandlers]
-    this.exitHandlers.clear()
-    for (const handler of handlers) handler()
-  }
-
-  /** Send one message on the shell or control channel. */
-  send(channel: 'shell' | 'control', message: { header: TransportMessage['header'], content: Record<string, unknown> }): void {
-    this.writeLine({ op: 'send', channel, header: message.header, content: message.content })
-  }
-
-  /** Ask the kernel to interrupt the running cell (control channel). */
-  interrupt(): void {
-    this.writeLine({ op: 'interrupt' })
-  }
-
-  /** Write one protocol line, refusing instead of throwing when the pipe is gone. */
-  private writeLine(payload: Record<string, unknown>): void {
-    const stdin = this.child?.stdin
-    if (stdin === null || stdin === undefined || this.closed || !stdin.writable) {
-      throw new Error('kernel bridge is not connected')
-    }
-    stdin.write(`${JSON.stringify(payload)}\n`)
-  }
-
-  /**
-   * Wait for the next message on `channel` matching `match`.
-   * @returns The message, or null when the budget expires or the bridge dies.
-   */
-  waitFor(channel: TransportChannel, match: (message: TransportMessage) => boolean, timeoutMs: number): Promise<TransportMessage | null> {
-    if (this.closed) return Promise.resolve(null)
-    return new Promise<TransportMessage | null>(resolve => {
-      const waiter: Waiter = {
-        channel,
-        match,
-        settle: (message) => {
-          clearTimeout(waiter.timer)
-          this.waiters.delete(waiter)
-          resolve(message)
-        },
-        timer: setTimeout(() => {
-          this.waiters.delete(waiter)
-          resolve(null)
-        }, timeoutMs),
-      }
-      waiter.timer.unref?.()
-      this.waiters.add(waiter)
-    })
-  }
-
-  /** Stop the bridge (graceful shutdown note, then kill). */
-  async dispose(): Promise<void> {
-    const child = this.child
-    this.closed = true
-    this.failWaiters()
-    this.reader?.close()
-    this.reader = undefined
-    if (child === undefined) return
-    try { if (child.stdin?.writable === true) child.stdin.write(`${JSON.stringify({ op: 'shutdown' })}\n`) } catch { /* already gone */ }
-    try { child.stdin?.end() } catch { /* already gone */ }
-    if (child.exitCode !== null) return
-    await new Promise<void>(resolve => {
-      const timer = setTimeout(() => {
-        try { child.kill('SIGKILL') } catch { /* already gone */ }
-        resolve()
-      }, 500)
-      timer.unref?.()
-      child.once('exit', () => { clearTimeout(timer); resolve() })
-    })
-  }
-
-  private failReady(error: Error): void {
-    if (this.readySettled) return
-    this.readySettled = true
-    this.readyReject?.(error)
-  }
-
-  private failWaiters(): void {
-    for (const waiter of [...this.waiters]) waiter.settle(null)
-  }
-
-  /** Route one decoded line; unknown events are ignored. */
-  private accept(line: string): void {
-    let event: { ev?: unknown, channel?: unknown, msg?: unknown, message?: unknown }
-    try {
-      event = JSON.parse(line) as typeof event
-    } catch {
-      return
-    }
-    if (event.ev === 'ready') {
-      if (!this.readySettled) {
-        this.readySettled = true
-        this.readyResolve?.()
-      }
-      return
-    }
-    if (event.ev === 'msg') {
-      const channel = event.channel
-      const raw = event.msg as { header?: unknown, parent_header?: unknown, content?: unknown } | undefined
-      if (typeof channel !== 'string' || raw === undefined || typeof raw.header !== 'object' || raw.header === null) return
-      const message: TransportMessage = {
-        header: raw.header as TransportMessage['header'],
-        parent_header: (raw.parent_header ?? {}) as Record<string, unknown>,
-        content: (raw.content ?? {}) as Record<string, unknown>,
-      }
-      for (const waiter of [...this.waiters]) {
-        if (waiter.channel === channel && waiter.match(message)) waiter.settle(message)
-      }
-      for (const handler of this.handlers) handler(channel as TransportChannel, message)
-      return
-    }
-    if (event.ev === 'fatal') {
-      this.bridgeStderr += `fatal: ${String(event.message ?? 'unknown')}\n`
-    }
-  }
-}
-
diff --git a/better-dsh/src/kernel.ts b/better-dsh/src/kernel.ts
index 9d4f403..d8d254e 100644
--- a/better-dsh/src/kernel.ts
+++ b/better-dsh/src/kernel.ts
@@ -1,892 +1,353 @@
-/**
- * Minimal IPython kernel bridge: spawns `python -m ipykernel_launcher`, speaks
- * the Jupyter wire protocol over ZeroMQ (shell/iopub/control), serializes cell
- * execution, and bridges kernel-side host requests (binding calls) over comms.
- * Ported from PA's `KernelManager` (prime-agent/packages/coding-agent/src/core/kernel/index.ts)
- * down to the subset DASHR needs; see README for the build-vs-reuse decision.
- *
- * Lifecycle is owned by the caller (the Cordis plugin registers it as a
- * `ctx.effect`); this class installs no process-level signal handlers, unlike
- * its PA ancestor.
- * @module dashr/kernel
- */
-
-import { type ChildProcess, spawn } from 'node:child_process'
+/** One persistent, serialized OMP Python child. No Jupyter ports or dependencies. */
+import { spawn, type ChildProcess } from 'node:child_process'
 import { randomBytes, randomUUID } from 'node:crypto'
-import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
-import { tmpdir } from 'node:os'
-import { join } from 'node:path'
-import { setTimeout as sleep } from 'node:timers/promises'
-import { KernelTransport } from './kernel-transport.ts'
-import type { TransportChannel, TransportMessage } from './kernel-transport.ts'
-import { HOST_COMM_TARGET, KERNEL_BOOTSTRAP } from './bootstrap.ts'
-import { buildQueryVarCell, buildRestoreCell, buildSetVarCell, buildSnapshotCell } from './python.ts'
+import { createServer, type Server } from 'node:http'
+import { createInterface } from 'node:readline'
+import type { Readable, Writable } from 'node:stream'
+import { fileURLToPath } from 'node:url'
+import { KERNEL_BOOTSTRAP } from './bootstrap.ts'
+import { buildQueryVarCell, buildSetVarCell } from './python.ts'
 import type { SnapshotSpec } from './python.ts'
 import { extractStream } from './output.ts'
 
-/** Constructor options; every deployment-varying value arrives validated. */
 export interface KernelBridgeOptions {
-  /** Absolute or PATH-resolved python interpreter with `ipykernel` installed. */
   python: string
-  /** Working directory for the kernel subprocess. */
   cwd?: string
-  /** Budget for spawn → kernel_info reply, in milliseconds. */
   startupTimeoutMs: number
-  /** Budget for graceful dispose (shutdown_request → SIGTERM → SIGKILL), in milliseconds. */
   disposeTimeoutMs: number
-  /**
-   * Confirm window between the control-channel interrupt and the SIGALRM
-   * escalation, in milliseconds; must stay below every execute's grace.
-   */
+  /** Retained configuration seam; OMP interrupts with SIGINT directly. */
   interruptConfirmMs: number
-  /** Budget for internal snapshot/restore cells (dill dump/load), in milliseconds. */
   snapshotTimeoutMs: number
-  /** Jupyter username stamped on every message. */
   username: string
 }
-
-/** Host-supplied inputs a snapshot cell records beside the dill payload. */
 export type { SnapshotSpec }
-
-/** One snapshot attempt's terminal outcome, parsed from the cell envelope. */
 export type SnapshotOutcome =
   | { kind: 'ok', sizeBytes: number, names: number }
   | { kind: 'skipped', reason: string, estimateBytes?: number, sizeBytes?: number, capBytes: number }
   | { kind: 'failed', reason: string }
-
-/** One restore attempt's terminal outcome, parsed from the cell envelope. */
-export type RestoreStateOutcome =
-  | { kind: 'restored', count: number }
-  | { kind: 'degraded', reason: string }
-
-/** One user-namespace variable query, parsed from the cell envelope. */
-export type QueryVarOutcome =
-  | { kind: 'json', text: string }
-  | { kind: 'repr', text: string }
-  | { kind: 'names', names: string[] }
-  | { kind: 'missing' }
-  | { kind: 'failed', reason: string }
-
-/** One user-namespace variable assignment, parsed from the cell envelope. */
-export type SetVarOutcome =
-  | { kind: 'ok' }
-  | { kind: 'failed', reason: string }
-
-
-/** One host-request resolution: ok carries the reply payload, not-ok a message. */
+export type RestoreStateOutcome = { kind: 'restored', count: number } | { kind: 'degraded', reason: string }
+export type QueryVarOutcome = { kind: 'json' | 'repr', text: string } | { kind: 'names', names: string[] } | { kind: 'missing' } | { kind: 'failed', reason: string }
+export type SetVarOutcome = { kind: 'ok' } | { kind: 'failed', reason: string }
 export type HostRequestOutcome = { ok: true, result: unknown } | { ok: false, message: string }
-
-/** Dispatches one typed request from kernel-side code. */
 export type HostRequestHandler = (data: Record<string, unknown>) => Promise<HostRequestOutcome>
-
 export interface ExecuteCellOptions {
-  /** Wall budget for the cell; interrupts then force-settles on expiry. */
   timeoutMs: number
-  /** Grace between interrupt and force-settle, in milliseconds. */
   interruptGraceMs: number
-  /**
-   * Confirm window between the control-channel interrupt and the SIGALRM
-   * escalation, in milliseconds; must stay below {@link interruptGraceMs}.
-   * The zmq interrupt alone settles any cell that yields to the kernel event
-   * loop, so SIGALRM — the channel that can terminate an idle kernel (see
-   * {@link IpyKernelBridge.interrupt | interrupt}) — is only sent when the
-   * cell provably ignored phase one. The kernel-side busy guard makes a
-   * signal that still sneaks onto an idle kernel harmless.
-   */
   interruptConfirmMs: number
-  /** Aborting interrupts the kernel and settles the cell as aborted. */
   signal?: AbortSignal
-  /** Host-request dispatcher active while this cell executes. */
   hostRequestHandler?: HostRequestHandler
 }
-
-/** A cell's terminal outcome; substrate-level failures arrive as `forced`. */
 export type CellOutcome =
-  | {
-    outcome: 'completed'
-    status: 'ok' | 'error'
-    streamText: string
-    cellError?: { ename: string, evalue: string, traceback: string[] }
-  }
-  | {
-    outcome: 'forced'
-    failure: { kind: 'timeout' | 'abort' | 'worker-exit', message: string }
-    streamText: string
-  }
-
-const PROTOCOL_VERSION = '5.3'
-/** Loopback PUB/SUB subscription propagation guard before the first execute. */
-const IOPUB_SUBSCRIBE_DELAY_MS = 50
-const CONNECT_POLL_MS = 25
-const SHUTDOWN_DRAIN_MS = 200
-
-interface ConnectionInfo {
-  ip: string
-  transport: 'tcp'
-  shell_port: number
-  iopub_port: number
-  stdin_port: number
-  control_port: number
-  hb_port: number
-  signature_scheme: 'hmac-sha256'
-  key: string
-  kernel_name: string
-}
-
-/** The bridge relays exactly this shape; the alias keeps call sites unchanged. */
-type JupyterMessage = TransportMessage
-
-interface ActiveExecution {
-  requestMsgId: string
+  | { outcome: 'completed', status: 'ok' | 'error', streamText: string, cellError?: { ename: string, evalue: string, traceback: string[] } }
+  | { outcome: 'forced', failure: { kind: 'timeout' | 'abort' | 'worker-exit', message: string }, streamText: string }
+type Failure = Extract<CellOutcome, { outcome: 'forced' }>['failure']
+interface Active {
+  id: string
   opts: ExecuteCellOptions
   streamText: string
-  cellError?: { ename: string, evalue: string, traceback: string[] }
-  status: 'ok' | 'error'
-  settled: boolean
+  started: boolean
+  error?: { ename: string, evalue: string, traceback: string[] }
+  pendingForce?: Failure
   resolve: (outcome: CellOutcome) => void
-  forceTimer?: ReturnType<typeof setTimeout>
-  timeoutTimer?: ReturnType<typeof setTimeout>
-  /** The phase-two SIGALRM escalation timer; cleared on every settle path like the others. */
-  alarmTimer?: ReturnType<typeof setTimeout>
-  /** Detach the caller signal's abort listener; EVERY settle path must run it exactly once. */
-  detachSignal?: () => void
-  /** Set when the budget/abort interrupt was sent; the interrupt's own error must not masquerade as a program exception. */
-  pendingForce?: { kind: 'timeout' | 'abort', message: string }
+  timeout?: ReturnType<typeof setTimeout>
+  force?: ReturnType<typeof setTimeout>
+  detach?: () => void
+  confirm?: ReturnType<typeof setTimeout>
+  rejectCallbacks: Set<() => void>
 }
-
-function isRecord(value: unknown): value is Record<string, unknown> {
-  return typeof value === 'object' && value !== null && !Array.isArray(value)
+function record(value: unknown): value is Record<string, unknown> {
+  return value !== null && typeof value === 'object' && !Array.isArray(value)
 }
 
-function buildMessage(msgType: string, content: Record<string, unknown>, session: string, username: string): JupyterMessage {
-  return {
-    header: {
-      msg_id: randomUUID(),
-      session,
-      username,
-      date: new Date().toISOString(),
-      msg_type: msgType,
-      version: PROTOCOL_VERSION,
-    },
-    parent_header: {},
-    content,
-  }
-}
-
-function makeConnection(): { path: string, tempDir: string } {
-  const info: ConnectionInfo = {
-    ip: '127.0.0.1',
-    transport: 'tcp',
-    shell_port: 0,
-    iopub_port: 0,
-    stdin_port: 0,
-    control_port: 0,
-    hb_port: 0,
-    signature_scheme: 'hmac-sha256',
-    key: randomBytes(16).toString('hex'),
-    kernel_name: 'python3',
-  }
-  const tempDir = mkdtempSync(join(tmpdir(), 'dashr-kernel-'))
-  const path = join(tempDir, 'connection.json')
-  writeFileSync(path, JSON.stringify(info, null, 2), { mode: 0o600 })
-  return { path, tempDir }
-}
-
-function readResolvedConnection(path: string): ConnectionInfo | null {
-  try {
-    const parsed: unknown = JSON.parse(readFileSync(path, 'utf8'))
-    if (!isRecord(parsed) || parsed.ip !== '127.0.0.1' || parsed.transport !== 'tcp' || parsed.signature_scheme !== 'hmac-sha256' || typeof parsed.key !== 'string') return null
-    for (const port of ['shell_port', 'iopub_port', 'stdin_port', 'control_port', 'hb_port'] as const) {
-      const value = parsed[port]
-      if (typeof value !== 'number' || !Number.isInteger(value) || value <= 0) return null
-    }
-    return parsed as unknown as ConnectionInfo
-  } catch {
-    return null
-  }
-}
-
-/**
- * One persistent IPython kernel subprocess with its ZeroMQ channels. Cell
- * execution is serialized on an internal queue (the Jupyter shell channel is
- * request/reply).
- */
+/** Historical class name retained for the runtime's private integration seam. */
 export class IpyKernelBridge {
-  private readonly session = randomUUID()
   private state: 'idle' | 'starting' | 'running' | 'shutdown' = 'idle'
+  private child?: ChildProcess
   private startPromise?: Promise<void>
-  private kernel?: ChildProcess
-  private transport?: KernelTransport
-  private connection?: ConnectionInfo
-  private tempDir?: string
-  private kernelStderr = ''
-  private executionQueue: Promise<unknown> = Promise.resolve()
-  private activeExec?: ActiveExecution
-  private readonly commTargets = new Map<string, string>()
-  private readonly servedComms = new Set<string>()
+  private disposePromise?: Promise<void>
+  private queue: Promise<unknown> = Promise.resolve()
+  private active?: Active
+  private stderr = ''
+  private deathFailure?: Failure
+  private callbackServer?: Server
+  private closePromise?: Promise<void>
+  private readonly ownedReaders: ReturnType<typeof createInterface>[] = []
 
   constructor(private readonly options: KernelBridgeOptions) {}
+  get pid(): number | undefined { return this.child?.pid }
+  get isRunning(): boolean { return this.state === 'running' }
+  get isDead(): boolean { return this.state === 'shutdown' }
 
-  /** The kernel subprocess pid, for lifecycle assertions; absent before spawn. */
-  get pid(): number | undefined {
-    return this.kernel?.pid
-  }
-
-  get isRunning(): boolean {
-    return this.state === 'running'
-  }
-
-  /**
-   * Whether the subprocess is gone (crashed or disposed). A dead bridge is
-   * never resurrected — the owning provider replaces it with a fresh one
-   * (respawn, M3-A), because kernel state is unrecoverable in-process.
-   */
-  get isDead(): boolean {
-    return this.state === 'shutdown'
-  }
-
-  /**
-   * Start the kernel (idempotent; concurrent callers share one startup).
-   * @throws when the subprocess cannot spawn, ports never resolve, the
-   *   kernel_info probe times out, or the bootstrap cell fails.
-   */
-  async start(): Promise<void> {
-    if (!this.startPromise) {
-      this.startPromise = this.doStart().catch((error: unknown) => {
-        this.startPromise = undefined
-        throw error
-      })
-    }
+  start(): Promise<void> {
+    this.startPromise ??= this.doStart()
     return this.startPromise
   }
 
-  private stderrTail(): string {
-    return this.kernelStderr.slice(-1024) || '(empty)'
+  private async windowsCallbacks(): Promise<Record<string, string>> {
+    const token = randomBytes(32).toString('hex')
+    const server = createServer((req, response) => {
+      if (req.method !== 'POST' || req.url !== '/callback' || req.headers.authorization !== `Bearer ${token}`) {
+        response.writeHead(403).end()
+        return
+      }
+      let body = ''
+      req.setEncoding('utf8')
+      req.on('data', (data: string) => { body += data })
+      req.on('end', () => {
+        let parsed: unknown
+        try { parsed = JSON.parse(body) } catch { response.writeHead(400).end(); return }
+        void this.callback(parsed).then(reply => {
+          if (!response.destroyed) response.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify(reply))
+        })
+      })
+    })
+    this.callbackServer = server
+    await new Promise<void>((resolve, reject) => {
+      server.once('error', reject)
+      server.listen(0, '127.0.0.1', () => { server.off('error', reject); resolve() })
+    })
+    const address = server.address()
+    if (!address || typeof address === 'string') throw new Error('callback endpoint unavailable')
+    return { BETTER_CALLBACK_URL: `http://127.0.0.1:${address.port}/callback`, BETTER_CALLBACK_TOKEN: token }
   }
 
   private async doStart(): Promise<void> {
-    if (this.state !== 'idle') return
+    if (this.state !== 'idle') throw new Error('Python bridge cannot restart after shutdown')
     this.state = 'starting'
-    const { path, tempDir } = makeConnection()
-    this.tempDir = tempDir
-    // Scrubbed environment: the interpreter is invoked by absolute path, and
-    // the kernel needs no ambient credentials; HOME backs IPython's optional
-    // history writes.
-    const kernel = spawn(this.options.python, ['-m', 'ipykernel_launcher', '-f', path], {
-      cwd: this.options.cwd,
-      env: {
-        PATH: process.env.PATH ?? '/usr/local/bin:/usr/bin:/bin',
-        LANG: 'C.UTF-8',
-        HOME: process.env.HOME ?? tmpdir(),
-      },
-      stdio: ['ignore', 'pipe', 'pipe'],
-    })
-    this.kernel = kernel
-    kernel.stderr?.on('data', (buf: Buffer) => { this.kernelStderr += buf.toString() })
-    kernel.on('error', (error: Error) => {
-      this.kernelStderr += `spawn error: ${error.message}\n`
-      this.onKernelDeath()
-    })
-    kernel.on('exit', (code, signal) => {
-      if (this.state !== 'shutdown') this.kernelStderr += `unexpected exit code=${code} signal=${signal}\n`
-      this.onKernelDeath()
-    })
-
-    let conn: ConnectionInfo
     try {
-      conn = await this.waitForConnection(path)
-      this.connection = conn
-    } catch (error) {
-      this.cleanupResources()
-      this.state = 'idle'
-      throw error
-    }
-
-    const transport = new KernelTransport({
-      python: this.options.python,
-      connectionFile: path,
-      ...this.options.cwd === undefined ? {} : { cwd: this.options.cwd },
-      readyTimeoutMs: this.options.startupTimeoutMs,
-    })
-    this.transport = transport
-    transport.onMessage((channel, message) => { this.handleTransportMessage(channel, message) })
-    transport.onExit(() => {
-      if (this.state !== 'shutdown') {
-        this.forceSettleActive({
-          kind: 'worker-exit',
-          message: `kernel bridge died. stderr tail:\n${transport.stderrTail()}`,
+      const resources = fileURLToPath(new URL('./omp-python/', import.meta.url))
+      const callbackEnv = process.platform === 'win32' ? await this.windowsCallbacks() : {}
+      if (this.isDead) throw new Error('Python startup cancelled by disposal')
+      const child = spawn(this.options.python, ['-u', fileURLToPath(new URL('./omp-python/runner.py', import.meta.url))], {
+        ...this.options.cwd ? { cwd: this.options.cwd } : {},
+        detached: process.platform !== 'win32',
+        stdio: process.platform === 'win32' ? ['pipe', 'pipe', 'pipe'] : ['pipe', 'pipe', 'pipe', 'pipe', 'pipe'],
+        env: { ...process.env, PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8',
+          PYTHONDONTWRITEBYTECODE: '1', PYTHONPATH: [resources, process.env.PYTHONPATH].filter(Boolean).join(process.platform === 'win32' ? ';' : ':'), ...callbackEnv },
+      })
+      this.child = child
+      this.closePromise = new Promise(resolve => child.once('close', () => resolve()))
+      child.on('error', error => this.died(`Python process error: ${error.message}`))
+      child.on('exit', (code, signal) => this.died(`Python process exited (${signal ?? code}); stderr: ${this.stderr.slice(-2048)}`))
+      child.stdin?.on('error', error => this.died(`Python input pipe failed: ${error.message}`))
+      child.stderr?.setEncoding('utf8').on('data', (data: string) => { this.stderr = (this.stderr + data).slice(-8192) })
+      const frames = createInterface({ input: child.stdout! })
+      this.ownedReaders.push(frames)
+      frames.on('line', line => {
+        try { this.frame(JSON.parse(line)) } catch { this.died('Python emitted invalid NDJSON protocol') }
+      })
+      if (process.platform !== 'win32') {
+        const requests = createInterface({ input: child.stdio[3] as Readable })
+        this.ownedReaders.push(requests)
+        const replies = child.stdio[4] as Writable
+        replies.on('error', () => { /* death/disposal closes callback pipes */ })
+        requests.on('line', line => {
+          let data: unknown
+          try { data = JSON.parse(line) } catch { return }
+          void this.callback(data).then(reply => {
+            if (!replies.destroyed && !replies.writableEnded) replies.write(JSON.stringify(reply) + '\n')
+          })
         })
       }
-    })
-    try {
-      await transport.start()
-    } catch (error) {
-      this.cleanupResources()
-      this.state = 'idle'
-      throw error
-    }
-    // Loopback PUB/SUB propagation guard: the kernel publishes iopub only once
-    // the bridge's subscriber is connected.
-    await sleep(IOPUB_SUBSCRIBE_DELAY_MS)
-
-    try {
-      await this.probeReady()
+      const result = await this.perform(KERNEL_BOOTSTRAP, {
+        timeoutMs: this.options.startupTimeoutMs, interruptGraceMs: 1_000, interruptConfirmMs: this.options.interruptConfirmMs,
+      })
+      if (result.outcome !== 'completed' || result.status !== 'ok') {
+        throw new Error(`OMP Python initialization failed: ${JSON.stringify(result)}`)
+      }
+      if (this.isDead) throw new Error('Python exited during initialization')
+      this.state = 'running'
     } catch (error) {
-      this.cleanupResources()
-      this.state = 'idle'
+      await this.dispose()
       throw error
     }
-
-    const bootstrap = await this.executeCell(KERNEL_BOOTSTRAP, {
-      timeoutMs: this.options.startupTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (bootstrap.outcome !== 'completed' || bootstrap.status !== 'ok') {
-      const detail = bootstrap.outcome === 'completed' && bootstrap.cellError
-        ? `${bootstrap.cellError.ename}: ${bootstrap.cellError.evalue}`
-        : 'bootstrap cell failed'
-      this.cleanupResources()
-      this.state = 'idle'
-      throw new Error(`dashr kernel bootstrap failed: ${detail}`)
-    }
-
-    this.state = 'running'
   }
 
-  private async waitForConnection(path: string): Promise<ConnectionInfo> {
-    const deadline = Date.now() + this.options.startupTimeoutMs
-    while (Date.now() < deadline) {
-      if (this.state === 'shutdown') {
-        throw new Error(`kernel exited before resolving ports. stderr:\n${this.stderrTail()}`)
+  private async callback(data: unknown): Promise<Record<string, unknown>> {
+    const identity = record(data) ? { id: data.id, run: data.run } : {}
+    const active = this.active
+    if (!record(data) || !active || active.id !== data.run || active.pendingForce || !active.opts.hostRequestHandler) {
+      return { ...identity, ok: false, message: 'host callback rejected: its cell is no longer active' }
+    }
+    const revoked = { ...identity, ok: false, message: 'host callback cancelled: its cell ended' }
+    return new Promise(resolve => {
+      let settled = false
+      const finish = (reply: Record<string, unknown>): void => {
+        if (settled) return
+        settled = true
+        active.rejectCallbacks.delete(reject)
+        resolve(reply)
       }
-      const info = readResolvedConnection(path)
-      if (info) return info
-      await sleep(CONNECT_POLL_MS)
-    }
-    throw new Error(`kernel did not resolve connection ports within ${this.options.startupTimeoutMs}ms. stderr tail:\n${this.stderrTail()}`)
-  }
-
-  private async probeReady(): Promise<void> {
-    const transport = this.transport
-    if (!transport) throw new Error('kernel channels are not connected')
-    const msg = buildMessage('kernel_info_request', {}, this.session, this.options.username)
-    const requestMsgId = msg.header.msg_id
-    transport.send('shell', msg)
-
-    const reply = await transport.waitFor(
-      'shell',
-      incoming => incoming.header.msg_type === 'kernel_info_reply'
-        && (incoming.parent_header as { msg_id?: string }).msg_id === requestMsgId,
-      this.options.startupTimeoutMs,
-    )
-    if (reply) return
-    const bridgeTail = transport.stderrTail()
-    if (this.state === 'shutdown') {
-      throw new Error(`kernel exited during startup. kernel stderr:\n${this.stderrTail()}\nbridge stderr:\n${bridgeTail}`)
-    }
-    throw new Error(`kernel did not answer kernel_info_request within ${this.options.startupTimeoutMs}ms. kernel stderr:\n${this.stderrTail()}\nbridge stderr:\n${bridgeTail}`)
+      const reject = (): void => finish(revoked)
+      active.rejectCallbacks.add(reject)
+      // Calls are concurrent within the single active cell; every resolution
+      // is checked again after user code or cancellation may have finished.
+      void active.opts.hostRequestHandler!(data).then(reply => {
+        finish(this.active === active && !active.pendingForce ? { ...identity, ...reply } : revoked)
+      }, error => finish({ ...identity, ok: false, message: String(error) }))
+    })
   }
 
-  /**
-   * Execute one cell on the persistent kernel, serialized against all other
-   * executions. Resolves with the cell's outcome — never rejects for
-   * cell-level failures (program errors, timeouts, aborts, kernel death).
-   * @param code - complete cell source.
-   * @param opts - budgets, abort signal, and the host-request dispatcher.
-   */
-  async executeCell(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
-    const prev = this.executionQueue
-    let releaseQueue!: () => void
-    this.executionQueue = new Promise<void>(resolve => { releaseQueue = resolve })
-    await prev
-    try {
-      if (this.state === 'shutdown' || this.state === 'idle') {
-        return { outcome: 'forced', failure: { kind: 'worker-exit', message: 'kernel has been shut down' }, streamText: '' }
+  private frame(frame: unknown): void {
+    if (!record(frame) || frame.id !== this.active?.id) return
+    const active = this.active!
+    if (frame.type === 'started') {
+      active.started = true
+      if (active.pendingForce) this.signal('SIGINT')
+    } else if (frame.type === 'stdout' || frame.type === 'stderr') {
+      if (typeof frame.data === 'string') active.streamText += frame.data
+    } else if (frame.type === 'display' || frame.type === 'result') {
+      // Rich displays remain explicit text when the runtime seam has no image field.
+      if (record(frame.bundle)) {
+        const text = frame.bundle['text/plain'] ?? frame.bundle['text/markdown'] ?? frame.bundle['text/html']
+        if (typeof text === 'string') active.streamText += `${text}\n`
+        else if (frame.bundle['application/json'] !== undefined) active.streamText += `${JSON.stringify(frame.bundle['application/json'])}\n`
+        else active.streamText += `[Python display: ${Object.keys(frame.bundle).join(', ')}]\n`
       }
-      return await this.executeInner(code, opts)
-    } finally {
-      releaseQueue()
+    } else if (frame.type === 'error') {
+      active.error = { ename: String(frame.ename), evalue: String(frame.evalue),
+        traceback: Array.isArray(frame.traceback) ? frame.traceback.map(String) : [] }
+    } else if (frame.type === 'done') {
+      this.settle(active.pendingForce
+        ? { outcome: 'forced', failure: active.pendingForce, streamText: active.streamText }
+        : { outcome: 'completed', status: frame.status === 'ok' ? 'ok' : 'error', streamText: active.streamText,
+          ...active.error ? { cellError: active.error } : {} })
     }
   }
 
-  private executeInner(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
-    const transport = this.transport
-    if (!transport) {
-      return Promise.resolve({ outcome: 'forced', failure: { kind: 'worker-exit', message: 'kernel channels are not connected' }, streamText: '' })
-    }
-
-    const msg = buildMessage('execute_request', {
-      code,
-      silent: false,
-      store_history: false,
-      user_expressions: {},
-      allow_stdin: false,
-      stop_on_error: true,
-    }, this.session, this.options.username)
-
-    return new Promise<CellOutcome>(resolve => {
-      const execution: ActiveExecution = {
-        requestMsgId: msg.header.msg_id,
-        opts,
-        streamText: '',
-        status: 'ok',
-        settled: false,
-        resolve,
-      }
-      this.activeExec = execution
-
-      const settle = (outcome: CellOutcome): void => {
-        if (execution.settled) return
-        execution.settled = true
-        if (execution.forceTimer) clearTimeout(execution.forceTimer)
-        if (execution.timeoutTimer) clearTimeout(execution.timeoutTimer)
-        if (execution.alarmTimer) clearTimeout(execution.alarmTimer)
-        execution.detachSignal?.()
-        if (this.activeExec === execution) this.activeExec = undefined
-        resolve(outcome)
-      }
-
-      // Interrupt in two phases, then force-settle with the failure after the
-      // grace period. Phase one is the control-channel interrupt alone: it
-      // settles any cell that yields to the kernel event loop and is harmless
-      // to an idle kernel (measured: an idle ipykernel survives a bare
-      // interrupt_request). SIGALRM — the phase that CAN terminate the
-      // process when it lands outside cell execution — escalates only after
-      // the confirm window, and only when this execution still needs
-      // breaking. When an interrupt DOES break the cell, the resulting
-      // KeyboardInterrupt reports as the armed failure kind, not as a program
-      // exception.
-      const interruptAndForce = (failure: { kind: 'timeout' | 'abort', message: string }): void => {
-        // A stale interrupt (signal/timer fired after this execution left the
-        // active slot) must never reach the kernel: even phase one has no
-        // business hitting a cell that is no longer active.
-        if (this.activeExec !== execution) return
-        if (execution.pendingForce === undefined) execution.pendingForce = failure
-        void this.sendInterrupt(execution)
-        execution.forceTimer = setTimeout(() => {
-          settle({ outcome: 'forced', failure, streamText: execution.streamText })
-        }, opts.interruptGraceMs)
-        execution.forceTimer.unref?.()
-      }
-
-      const onAbort = (): void => {
-        interruptAndForce({ kind: 'abort', message: String(opts.signal?.reason) })
-      }
-
-      execution.timeoutTimer = setTimeout(() => {
-        interruptAndForce({ kind: 'timeout', message: `cell exceeded ${opts.timeoutMs}ms wall budget` })
-      }, opts.timeoutMs)
-      execution.timeoutTimer.unref?.()
-
-      opts.signal?.addEventListener('abort', onAbort, { once: true })
-      // Detach on EVERY settle path (the `settle` closure here,
-      // `settleCompleted`, and `forceSettleActive`): a listener surviving a
-      // completed cell would fire interruptAndForce at an IDLE kernel on the
-      // caller's next abort, and SIGALRM-ing an idle kernel kills it.
-      execution.detachSignal = () => opts.signal?.removeEventListener('abort', onAbort)
-      if (opts.signal?.aborted) onAbort()
-
-      try {
-        transport.send('shell', msg)
-      } catch {
-        settle({ outcome: 'forced', failure: { kind: 'worker-exit', message: 'shell channel send failed' }, streamText: execution.streamText })
-      }
+  executeCell(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
+    const task = this.queue.then(() => {
+      if (!this.isRunning) return { outcome: 'forced' as const, failure: { kind: 'worker-exit' as const, message: 'Python is not running' }, streamText: '' }
+      return this.perform(code, opts)
     })
+    this.queue = task.catch(() => undefined)
+    return task
   }
 
-  /**
-   * Route one relayed message. Only iopub drives executions and comms; shell
-   * replies serve the startup probe (via `waitFor`), and control is inbound
-   * for host replies.
-   */
-  private handleTransportMessage(channel: TransportChannel, incoming: JupyterMessage): void {
-    if (channel !== 'iopub') return
-    const msgType = incoming.header.msg_type
-    if (msgType === 'comm_open' || msgType === 'comm_msg' || msgType === 'comm_close') {
-      this.handleCommMessage(incoming)
-      return
-    }
-    this.handleExecutionMessage(incoming)
-  }
-
-  private forceSettleActive(failure: { kind: 'timeout' | 'abort' | 'worker-exit', message: string }): void {
-    const execution = this.activeExec
-    if (!execution || execution.settled) return
-    execution.settled = true
-    if (execution.forceTimer) clearTimeout(execution.forceTimer)
-    if (execution.timeoutTimer) clearTimeout(execution.timeoutTimer)
-    if (execution.alarmTimer) clearTimeout(execution.alarmTimer)
-    execution.detachSignal?.()
-    this.activeExec = undefined
-    execution.resolve({ outcome: 'forced', failure, streamText: execution.streamText })
-  }
-
-  private handleExecutionMessage(incoming: JupyterMessage): void {
-    const execution = this.activeExec
-    if (!execution || execution.settled) return
-    if ((incoming.parent_header as { msg_id?: string }).msg_id !== execution.requestMsgId) return
-    const msgType = incoming.header.msg_type
-    if (msgType === 'stream') {
-      const content = incoming.content as { text?: string }
-      if (typeof content.text === 'string') execution.streamText += content.text
-    } else if (msgType === 'error') {
-      const content = incoming.content as { ename?: string, evalue?: string, traceback?: string[] }
-      execution.cellError = {
-        ename: typeof content.ename === 'string' ? content.ename : 'Error',
-        evalue: typeof content.evalue === 'string' ? content.evalue : '',
-        traceback: Array.isArray(content.traceback) ? content.traceback : [],
-      }
-      execution.status = 'error'
-    } else if (msgType === 'status') {
-      const content = incoming.content as { execution_state?: string }
-      if (content.execution_state === 'idle') {
-        this.settleCompleted(execution)
+  private perform(code: string, opts: ExecuteCellOptions): Promise<CellOutcome> {
+    if (opts.signal?.aborted) return Promise.resolve({ outcome: 'forced', failure: { kind: 'abort', message: String(opts.signal.reason) }, streamText: '' })
+    return new Promise(resolve => {
+      const active: Active = { id: randomUUID(), opts, streamText: '', started: false, resolve, rejectCallbacks: new Set() }
+      this.active = active
+      active.timeout = setTimeout(() => this.interrupt(active, { kind: 'timeout', message: `Python cell exceeded ${opts.timeoutMs}ms` }), opts.timeoutMs)
+      if (opts.signal) {
+        const signal = opts.signal
+        const abort = (): void => this.interrupt(active, { kind: 'abort', message: String(signal.reason) })
+        signal.addEventListener('abort', abort, { once: true })
+        active.detach = () => signal.removeEventListener('abort', abort)
       }
-    }
-  }
-
-  private settleCompleted(execution: ActiveExecution): void {
-    if (execution.settled) return
-    execution.settled = true
-    if (execution.forceTimer) clearTimeout(execution.forceTimer)
-    if (execution.timeoutTimer) clearTimeout(execution.timeoutTimer)
-    if (execution.alarmTimer) clearTimeout(execution.alarmTimer)
-    execution.detachSignal?.()
-    if (this.activeExec === execution) this.activeExec = undefined
-    if (execution.pendingForce !== undefined) {
-      execution.resolve({ outcome: 'forced', failure: execution.pendingForce, streamText: execution.streamText })
-      return
-    }
-    execution.resolve({
-      outcome: 'completed',
-      status: execution.status,
-      streamText: execution.streamText,
-      ...execution.cellError ? { cellError: execution.cellError } : {},
+      this.child?.stdin?.write(JSON.stringify({ id: active.id, code, ...this.options.cwd ? { cwd: this.options.cwd } : {} }) + '\n')
     })
   }
 
-  private handleCommMessage(incoming: JupyterMessage): void {
-    const content = incoming.content
-    const commId = content.comm_id
-    if (typeof commId !== 'string') return
-    const msgType = incoming.header.msg_type
-
-    if (msgType === 'comm_close') {
-      this.commTargets.delete(commId)
-      this.servedComms.delete(commId)
-      return
-    }
-    if (msgType === 'comm_open') {
-      // Registration only: the shim opens the comm empty and carries its one
-      // request as the first comm_msg.
-      const targetName = content.target_name
-      if (typeof targetName === 'string') this.commTargets.set(commId, targetName)
-      return
-    }
-    if (msgType === 'comm_msg' && this.commTargets.get(commId) === HOST_COMM_TARGET) {
-      this.serveHostRequest(commId, content.data)
-    }
+  private interrupt(active: Active, failure: Failure): void {
+    if (this.active !== active || active.pendingForce) return
+    active.pendingForce = failure
+    for (const revoke of [...active.rejectCallbacks]) revoke()
+    // Never signal an idle runner: defer until its started frame if necessary.
+    if (active.started) this.signal('SIGINT')
+    active.confirm = setTimeout(() => {
+      if (this.active === active && active.started && active.pendingForce) this.signal('SIGINT')
+    }, active.opts.interruptConfirmMs)
+    active.force = setTimeout(() => {
+      // A nonresponsive native operation cannot be left executing when the
+      // queue advances. Reap the entire owned group before returning.
+      void this.dispose()
+    }, active.opts.interruptGraceMs)
   }
 
-  private serveHostRequest(commId: string, data: unknown): void {
-    // One request per comm: the kernel-side shim closes the comm after its
-    // reply, and duplicate delivery must not double-dispatch.
-    if (this.servedComms.has(commId)) return
-    this.servedComms.add(commId)
-
-    const handler = this.activeExec?.opts.hostRequestHandler
-    if (!handler) {
-      void this.replyComm(commId, { status: 'error', error: 'no host request handler is active' }).catch(() => undefined)
-      return
-    }
-    if (!isRecord(data)) {
-      void this.replyComm(commId, { status: 'error', error: 'host request payload must be an object' }).catch(() => undefined)
-      return
-    }
-    void (async () => {
-      try {
-        const outcome = await handler(data)
-        if (outcome.ok) {
-          await this.replyComm(commId, { status: 'ok', result: outcome.result })
-        } else {
-          await this.replyComm(commId, { status: 'error', error: outcome.message })
-        }
-      } catch (error: unknown) {
-        const message = error instanceof Error ? error.message : String(error)
-        await this.replyComm(commId, { status: 'error', error: message }).catch(() => undefined)
-      }
-    })().catch(() => undefined)
+  private settle(outcome: CellOutcome): void {
+    const active = this.active
+    if (!active) return
+    this.active = undefined
+    clearTimeout(active.timeout)
+    clearTimeout(active.force)
+    clearTimeout(active.confirm)
+    active.detach?.()
+    for (const revoke of [...active.rejectCallbacks]) revoke()
+    active.resolve(outcome)
   }
 
-  private async replyComm(commId: string, data: Record<string, unknown>): Promise<void> {
-    const transport = this.transport
-    if (!transport) throw new Error('kernel channels are not connected')
-    transport.send('control', buildMessage('comm_msg', { comm_id: commId, data }, this.session, this.options.username))
+  private signal(signal: NodeJS.Signals): void {
+    try { this.child?.kill(signal) } catch { /* already exited */ }
   }
-
-  /**
-   * Phase one NOW, phase two on a timer: send the control-channel interrupt,
-   * then — after the confirm window, and only if the execution has still not
-   * settled — escalate to SIGALRM. The zmq interrupt only lands when the cell
-   * yields to the kernel event loop; a busy sync cell ('while True: pass')
-   * never does, which is why the escalation exists at all. Sending both
-   * channels in the same tick (the M1 design) made SIGALRM the FIRST signal
-   * an idle-or-booting kernel saw on timeout/abort: its handler raised
-   * KeyboardInterrupt at the top level and the process exited cleanly — a
-   * deterministic kill (10/10 same-tick aborts, 8/10 at +1-2ms, 40/40 during
-   * cold boot; dev/m2a-report.md §5.1). Two-phase escalation plus the
-   * kernel-side busy guard closes that window while keeping the hard-abort
-   * contract: a busy loop still breaks, one confirm window later.
-   */
-  private async sendInterrupt(execution: ActiveExecution): Promise<void> {
-    const transport = this.transport
-    if (!transport) return
+  private killGroup(): void {
+    const pid = this.child?.pid
+    if (pid === undefined) return
     try {
-      transport.interrupt()
-    } catch {
-      // Channels closed mid-interrupt (kernel death owns the settle).
-    }
-    execution.alarmTimer = setTimeout(() => {
-      // The execution settled inside the window — the zmq interrupt was
-      // enough (an awaiting cell, or one that finished) — no signal needed.
-      if (execution.settled) return
-      if (this.kernel?.exitCode === null) {
-        try { this.kernel.kill('SIGALRM') } catch { /* already gone */ }
-      }
-    }, execution.opts.interruptConfirmMs)
-    execution.alarmTimer.unref?.()
-  }
-
-  /**
-   * Snapshot the user namespace via an internal dill cell. Requires `dill` in
-   * the kernel environment. The cell reports its outcome through a nonce
-   * envelope (skipped-for-size vs written); a failed/skipped dump NEVER
-   * replaces a previous good snapshot on disk.
-   * @param payloadPath - dill payload destination.
-   * @param manifestPath - JSON manifest destination (turn, names, python
-   *   version, venv path, skills, size).
-   * @param spec - turn counter, skills list, and the size cap.
-   */
-  async snapshotState(payloadPath: string, manifestPath: string, spec: SnapshotSpec): Promise<SnapshotOutcome> {
-    if (!this.isRunning) return { kind: 'failed', reason: 'kernel is not running' }
-    const sentinel = `__dashr_snapshot_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildSnapshotCell(payloadPath, manifestPath, spec, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'failed', reason: 'snapshot cell failed' }
-    }
-    return this.parseSnapshotEnvelope(outcome.streamText, sentinel)
+      if (process.platform !== 'win32') process.kill(-pid, 'SIGKILL')
+      else this.child?.kill('SIGKILL')
+    } catch { /* already reaped */ }
   }
-
-  /** Parse one snapshot cell's nonce envelope into its outcome. */
-  private parseSnapshotEnvelope(streamText: string, sentinel: string): SnapshotOutcome {
-    const capture = extractStream(streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'failed', reason: 'snapshot cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'failed', reason: 'snapshot envelope was not valid JSON' }
-    }
-    if (typeof envelope !== 'object' || envelope === null) return { kind: 'failed', reason: 'snapshot envelope was not an object' }
-    const record = envelope as { ok?: unknown, skipped?: unknown, reason?: unknown, sizeBytes?: unknown, names?: unknown, estimateBytes?: unknown, capBytes?: unknown }
-    if (record.ok === true) {
-      return {
-        kind: 'ok',
-        sizeBytes: typeof record.sizeBytes === 'number' ? record.sizeBytes : 0,
-        names: typeof record.names === 'number' ? record.names : 0,
-      }
-    }
-    if (record.skipped === true) {
-      return {
-        kind: 'skipped',
-        reason: typeof record.reason === 'string' ? record.reason : 'size cap',
-        ...typeof record.estimateBytes === 'number' ? { estimateBytes: record.estimateBytes } : {},
-        ...typeof record.sizeBytes === 'number' ? { sizeBytes: record.sizeBytes } : {},
-        capBytes: typeof record.capBytes === 'number' ? record.capBytes : 0,
-      }
-    }
-    return { kind: 'failed', reason: typeof record.reason === 'string' ? record.reason : 'snapshot failed' }
+  private died(message: string): void {
+    this.state = 'shutdown'
+    this.deathFailure ??= { kind: 'worker-exit', message }
+    this.killGroup() // leader exit must also retire owned descendants
+    // Exit is not close: callers settle only after close/drain in doDispose.
+    void this.dispose()
   }
 
-  /**
-   * Restore a dill snapshot into the user namespace via an internal cell. The
-   * kernel validates the manifest (python version, interpreter identity,
-   * skills) and reports restored vs degraded through a nonce envelope; a
-   * degraded restore leaves the namespace empty.
-   * @param payloadPath - dill payload source.
-   * @param manifestPath - JSON manifest source.
-   */
-  async restoreState(payloadPath: string, manifestPath: string): Promise<RestoreStateOutcome> {
-    if (!this.isRunning) return { kind: 'degraded', reason: 'kernel is not running' }
-    const sentinel = `__dashr_restore_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildRestoreCell(payloadPath, manifestPath, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'degraded', reason: 'restore cell failed' }
-    }
-    const capture = extractStream(outcome.streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'degraded', reason: 'restore cell produced no envelope' }
-    let envelope: unknown
+  private async internal(code: string, sentinel: string): Promise<Record<string, unknown> | undefined> {
+    const result = await this.executeCell(code, { timeoutMs: this.options.snapshotTimeoutMs, interruptGraceMs: 1_000, interruptConfirmMs: this.options.interruptConfirmMs })
+    if (result.outcome !== 'completed' || result.status !== 'ok') return undefined
     try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'degraded', reason: 'restore envelope was not valid JSON' }
-    }
-    if (typeof envelope !== 'object' || envelope === null) return { kind: 'degraded', reason: 'restore envelope was not an object' }
-    const record = envelope as { ok?: unknown, restored?: unknown, reason?: unknown }
-    if (record.ok === true) {
-      return { kind: 'restored', count: typeof record.restored === 'number' ? record.restored : 0 }
-    }
-    return { kind: 'degraded', reason: typeof record.reason === 'string' ? record.reason : 'snapshot not replayable' }
+      const envelope: unknown = JSON.parse(extractStream(result.streamText, sentinel).envelope ?? '')
+      return record(envelope) ? envelope : undefined
+    } catch { return undefined }
   }
-
-  /**
-   * Read one user-namespace variable by name (or list the namespace's user
-   * names when `name` is `null`) via an internal cell. JSON-serializable
-   * values cross as `kind: 'json'` text; anything else falls back to `repr`
-   * text (`kind: 'repr'`) so a non-JSON variable is still readable. A missing
-   * name reports `kind: 'missing'` rather than failing the cell.
-   * @param name - the exact variable name, or `null` to list namespace names.
-   */
   async queryVar(name: string | null): Promise<QueryVarOutcome> {
-    if (!this.isRunning) return { kind: 'failed', reason: 'kernel is not running' }
-    const sentinel = `__dashr_query_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildQueryVarCell(name, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'failed', reason: 'query cell failed' }
-    }
-    const capture = extractStream(outcome.streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'failed', reason: 'query cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'failed', reason: 'query envelope was not valid JSON' }
-    }
-    if (!isRecord(envelope)) return { kind: 'failed', reason: 'query envelope was not an object' }
-    if (envelope.ok !== true) {
-      return { kind: 'failed', reason: typeof envelope.reason === 'string' ? envelope.reason : 'query failed' }
-    }
-    const kind = envelope.kind
-    if (kind === 'names') {
-      const names = Array.isArray(envelope.names) ? envelope.names.filter((name): name is string => typeof name === 'string') : []
-      return { kind: 'names', names }
-    }
-    if (kind === 'missing') return { kind: 'missing' }
-    if (kind === 'json' || kind === 'repr') {
-      return typeof envelope.text === 'string'
-        ? { kind, text: envelope.text }
-        : { kind: 'failed', reason: 'query envelope carried no text' }
-    }
-    return { kind: 'failed', reason: `unknown query kind ${JSON.stringify(kind)}` }
+    const sentinel = `__better_query_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildQueryVarCell(name, sentinel), sentinel)
+    if (reply?.kind === 'names' && Array.isArray(reply.names)) return { kind: 'names', names: reply.names.filter((name): name is string => typeof name === 'string') }
+    if (reply?.kind === 'missing') return { kind: 'missing' }
+    if ((reply?.kind === 'json' || reply?.kind === 'repr') && typeof reply.text === 'string') return { kind: reply.kind, text: reply.text }
+    return { kind: 'failed', reason: 'Python variable query failed' }
   }
-
-  /**
-   * Assign one pre-serialized JSON value into the user namespace under
-   * `name` via an internal cell. The host already validated the name and the
-   * value; the cell only decodes and binds. Uses the same busy guard and
-   * internal-cell budget as the snapshot cells.
-   * @param name - the validated identifier to assign under.
-   * @param valueJson - the lossless-JSON text to decode and bind.
-   */
   async setVar(name: string, valueJson: string): Promise<SetVarOutcome> {
-    if (!this.isRunning) return { kind: 'failed', reason: 'kernel is not running' }
-    const sentinel = `__dashr_set_${randomBytes(9).toString('hex')}__`
-    const outcome = await this.executeCell(buildSetVarCell(name, valueJson, sentinel), {
-      timeoutMs: this.options.snapshotTimeoutMs,
-      interruptGraceMs: 1_000,
-      interruptConfirmMs: Math.min(this.options.interruptConfirmMs, 500),
-    })
-    if (outcome.outcome !== 'completed' || outcome.status !== 'ok') {
-      return { kind: 'failed', reason: 'set cell failed' }
-    }
-    const capture = extractStream(outcome.streamText, sentinel)
-    if (capture.envelope === undefined) return { kind: 'failed', reason: 'set cell produced no envelope' }
-    let envelope: unknown
-    try {
-      envelope = JSON.parse(capture.envelope)
-    } catch {
-      return { kind: 'failed', reason: 'set envelope was not valid JSON' }
-    }
-    if (!isRecord(envelope) || envelope.ok !== true) {
-      return { kind: 'failed', reason: isRecord(envelope) && typeof envelope.reason === 'string' ? envelope.reason : 'set failed' }
-    }
-    return { kind: 'ok' }
+    const sentinel = `__better_set_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildSetVarCell(name, valueJson, sentinel), sentinel)
+    return reply?.ok === true ? { kind: 'ok' } : { kind: 'failed', reason: 'Python variable assignment failed' }
   }
-
-  private onKernelDeath(): void {
-    this.state = 'shutdown'
-    this.forceSettleActive({ kind: 'worker-exit', message: `kernel process died. stderr tail:\n${this.stderrTail()}` })
-    this.cleanupResources()
+  async snapshotState(_payloadPath: string, _manifestPath: string, _spec: SnapshotSpec): Promise<SnapshotOutcome> {
+    return { kind: 'failed', reason: 'OMP checkpoint integration pending Task 2' }
   }
-
-  private cleanupResources(): void {
-    void this.transport?.dispose()
-    this.transport = undefined
-    this.connection = undefined
-    try {
-      this.kernel?.kill('SIGKILL')
-    } catch {
-      // Kernel already exited.
-    }
-    this.kernel = undefined
-    if (this.tempDir) {
-      try {
-        rmSync(this.tempDir, { recursive: true, force: true })
-      } catch {
-        // Leave the temp dir for OS tmp cleanup.
-      }
-    }
-    this.tempDir = undefined
+  async restoreState(_payloadPath: string, _manifestPath: string): Promise<RestoreStateOutcome> {
+    return { kind: 'degraded', reason: 'OMP checkpoint integration pending Task 2' }
   }
 
-  /** Graceful teardown: shutdown_request, then SIGKILL after the dispose budget. */
-  async dispose(): Promise<void> {
-    if (this.state === 'shutdown') {
-      this.cleanupResources()
-      return
-    }
+  dispose(): Promise<void> {
+    this.disposePromise ??= this.doDispose()
+    return this.disposePromise
+  }
+  private async doDispose(): Promise<void> {
     this.state = 'shutdown'
-    try {
-      if (this.transport) {
-        this.transport.send('control', buildMessage('shutdown_request', { restart: false }, this.session, this.options.username))
-        await sleep(SHUTDOWN_DRAIN_MS)
-      }
-    } catch {
-      // Fall through to the kill path.
-    }
-    const kernel = this.kernel
-    this.cleanupResources()
-    if (kernel && kernel.exitCode === null && kernel.signalCode === null) {
-      await new Promise<void>(resolve => {
-        const timer = setTimeout(() => {
-          kernel.removeListener('exit', onExit)
-          try {
-            kernel.kill('SIGKILL')
-          } catch {
-            // Already gone.
-          }
-          resolve()
-        }, this.options.disposeTimeoutMs)
-        timer.unref?.()
-        const onExit = (): void => {
-          clearTimeout(timer)
-          resolve()
-        }
-        kernel.once('exit', onExit)
-      })
+    const child = this.child
+    if (!child) {
+      this.callbackServer?.closeAllConnections()
+      this.callbackServer?.close()
+      return
     }
+    const active = this.active
+    // In-flight disposal or cancellation reaps immediately; idle shutdown
+    // first asks the original runner to exit and bounds its drain.
+    if (!active && child.exitCode === null && child.signalCode === null) {
+      child.stdin?.end(JSON.stringify({ type: 'exit' }) + '\n')
+      await this.waitClose(Math.min(200, this.options.disposeTimeoutMs))
+    }
+    this.killGroup()
+    await this.waitClose(this.options.disposeTimeoutMs)
+    if (this.active) this.settle({ outcome: 'forced', failure: this.active.pendingForce ?? this.deathFailure ?? { kind: 'worker-exit', message: 'Python disposed during cell execution' }, streamText: this.active.streamText })
+    for (const reader of this.ownedReaders) reader.close()
+    for (const stream of child.stdio) (stream as Readable | null)?.destroy()
+    this.callbackServer?.closeAllConnections()
+    this.callbackServer?.close()
+    this.child = undefined
+  }
+  private async waitClose(ms: number): Promise<void> {
+    if (!this.closePromise) return
+    await new Promise<void>(resolve => {
+      const timer = setTimeout(resolve, ms)
+      void this.closePromise!.then(() => { clearTimeout(timer); resolve() })
+    })
   }
 }
diff --git a/better-dsh/src/python.ts b/better-dsh/src/python.ts
index 2e27047..736a1b7 100644
--- a/better-dsh/src/python.ts
+++ b/better-dsh/src/python.ts
@@ -1,346 +1,35 @@
-/**
- * Per-run cell generation. One `run()` is exactly one `execute_request`: the
- * cell installs the run's binding namespaces, runs the program through
- * `_dashr_run_program` (module-scope statements executed with the user
- * namespace as BOTH globals and locals — pure IPython REPL semantics:
- * top-level `await` legal, top-level `return` a SyntaxError, and the last
- * expression's value is the completion), and prints the completion envelope
- * under a per-run nonce sentinel so the host can recover the exact JSON bytes
- * from the captured stream.
- *
- * The snapshot and restore cells live here too: they are internal cells on
- * the SAME kernel, generated the same way, and must therefore obey the same
- * busy-guard discipline as a user cell.
- * @module dashr/python
- */
-
-/** Binding namespaces as seen by the kernel-side installer, keyed by global. */
+/** Better-owned cells delegate to packaged Python modules, never user-global helpers. */
 export type NamespaceSpecs = Record<string, {
   functions: string[]
-  /** Materialize the global itself as a callable function (single `functions` entry). */
   callable?: true
   errorClass?: { name: string, memberNameProperty: string }
 }>
 
-/**
- * Build the single cell for one run.
- * @param program - the model's cell program, executed at module scope.
- * @param specJson - the JSON-encoded {@link NamespaceSpecs} map.
- * @param sentinel - per-run nonce prefix; the envelope line starts with it.
- * @returns the complete cell source.
- */
 export function buildRunCell(program: string, specJson: string, sentinel: string): string {
-  // The program executes via _dashr_run_program (exec with the user
-  // namespace as BOTH globals and locals — pure REPL semantics, so
-  // 'count = count + ...' reads state left by earlier runs instead of
-  // raising UnboundLocalError in a real function scope). Its result is the
-  // cell's completion value — the last expression's value, REPL
-  // displayhook-style.
-  // The scaffold brackets the whole cell with the SIGALRM busy guard (see the
-  // bootstrap's _dashr_state): from the kernel's first bytecode of this cell
-  // to its last, an interrupt may raise KeyboardInterrupt — the window where
-  // breaking the cell is the intended outcome. Outside it (boot, idle,
-  // post-cell unwind) the kernel-side handler swallows the signal instead of
-  // dying to it.
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    // The program executes via _dashr_run_program (exec with the user
-    // namespace as BOTH globals and locals — REPL semantics, so
-    // 'count = count + ...' reads state left by earlier runs instead of
-    // raising UnboundLocalError in a real function scope). Its result is the
-    // rewritten top-level return value.
-    `    _dashr_install_bindings(${JSON.stringify(specJson)})`,
-    `    __dashr_completion__ = _dashr_encode(await _dashr_run_program(${JSON.stringify(program)}))`,
-    // The full envelope is printed (never just the value's JSON text) so a
-    // rejected encoding cannot collide with a value that serializes to
-    // '{"ok": false}' itself.
-    `    print(${JSON.stringify(sentinel)} + _dashr_json.dumps(__dashr_completion__))`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+  return `await __import__('better_support').run(globals(), ${JSON.stringify(program)}, ${JSON.stringify(specJson)}, ${JSON.stringify(sentinel)})`
 }
 
-/** Host-supplied inputs a snapshot cell records beside the dill payload. */
 export interface SnapshotSpec {
   /** Which completed run this snapshot belongs to (the revive "turn-N" counter). */
   turn: number
   /** Minimal replay metadata: skills the kernel environment must provide (none today). */
   skills: string[]
   /** Serialized-size cap in bytes; over-cap snapshots are skipped, not written. */
   sizeCapBytes: number
 }
 
-/**
- * Build the internal cell that dumps the user namespace to a dill snapshot and
- * writes a JSON manifest next to it. Only USER state is captured: IPython's
- * own session plumbing (`exit`, `quit`, `get_ipython`, … tracked in the
- * shell's `user_ns_hidden` and still bound to the object IPython installed)
- * reaches unpicklable kernel machinery — e.g. the history manager's
- * sqlite3.Connection — and is never restored as program state anyway. Shim
- * names (any `_dashr`/`__dashr` spelling) are excluded by prefix.
- *
- * Size-cap policy (M3-B, blueprint §8.3): dill cannot report a serialized
- * size before dumping, and a GB-sized `DataFrame` dumped EVERY turn is the IO
- * storm the cap exists to stop. The cell therefore gates in two tiers:
- * first a bounded-depth namespace walk estimates the footprint (counting
- * container lengths and reading `nbytes` / `memory_usage(deep=True)` for
- * numpy/pandas objects — the stated pathological case — so the dump is
- * skipped BEFORE any dill IO), then the actual dump goes to a sibling
- * `.part` file whose true byte size is measured before it replaces the
- * previous good snapshot. Skipped snapshots leave the previous
- * `state.dill` + manifest untouched, so a revive restores the last good turn.
- * @param payloadPath - absolute path for the dill payload.
- * @param manifestPath - absolute path for the JSON manifest.
- * @param spec - turn counter, skills list, and the size cap.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildSnapshotCell(payloadPath: string, manifestPath: string, spec: SnapshotSpec, sentinel: string): string {
-  // Bracketed by the same SIGALRM busy guard as a run cell: a timed-out
-  // snapshot (e.g. dill stuck on a pathological object graph) must be
-  // breakable by the host's interrupt ladder exactly like user code.
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import dill as _dashr_dill, json as _dashr_json, platform as _dashr_platform`,
-    `    import os as _dashr_os, sys as _dashr_sys, datetime as _dashr_dt`,
-    `    _dashr_shell = globals().get('get_ipython', lambda: None)()`,
-    `    _dashr_hidden = getattr(_dashr_shell, 'user_ns_hidden', None) or {}`,
-    `    _dashr_user_ns = {`,
-    `        name: value`,
-    `        for name, value in globals().items()`,
-    `        if not name.lower().startswith(('_dashr', '__dashr'))`,
-    `        and (name not in _dashr_hidden or _dashr_hidden[name] is not value)`,
-    `    }`,
-    `    _dashr_cap = ${JSON.stringify(spec.sizeCapBytes)}`,
-    `    def _dashr_estimate(value, depth):`,
-    `        if value is None or isinstance(value, (bool, int, float, complex)):`,
-    `            return 32`,
-    `        if isinstance(value, (str, bytes, bytearray)):`,
-    `            return len(value) + 64`,
-    `        if isinstance(value, (list, tuple, set, frozenset)):`,
-    `            if depth <= 0:`,
-    `                return 4096`,
-    `            return 64 + sum(_dashr_estimate(item, depth - 1) for item in value)`,
-    `        if isinstance(value, dict):`,
-    `            if depth <= 0:`,
-    `                return 4096`,
-    `            total = 64`,
-    `            for key, item in value.items():`,
-    `                total += _dashr_estimate(key, depth - 1)`,
-    `                total += _dashr_estimate(item, depth - 1)`,
-    `                if total > _dashr_cap:`,
-    `                    return total`,
-    `            return total`,
-    `        _dashr_nbytes = getattr(value, 'nbytes', None)`,
-    `        if isinstance(_dashr_nbytes, int) and _dashr_nbytes > 0:`,
-    `            return _dashr_nbytes + 128`,
-    `        _dashr_mem = getattr(value, 'memory_usage', None)`,
-    `        if callable(_dashr_mem):`,
-    `            try:`,
-    `                _dashr_usage = _dashr_mem(deep=True)`,
-    `                _dashr_sum = getattr(_dashr_usage, 'sum', None)`,
-    `                if callable(_dashr_sum):`,
-    `                    # pandas returns a numpy scalar (np.int64), which is`,
-    `                    # not a Python int subclass; coerce, don't isinstance.`,
-    `                    _dashr_n = int(_dashr_sum())`,
-    `                    if _dashr_n > 0:`,
-    `                        return _dashr_n + 128`,
-    `            except Exception:`,
-    `                pass`,
-    `        return 4096`,
-    `    _dashr_estimate_bytes = sum(_dashr_estimate(value, 4) for value in _dashr_user_ns.values())`,
-    `    if _dashr_estimate_bytes > _dashr_cap:`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({`,
-    `            'ok': False, 'skipped': True, 'reason': 'estimate',`,
-    `            'estimateBytes': _dashr_estimate_bytes, 'capBytes': _dashr_cap,`,
-    `        }))`,
-    `    else:`,
-    `        _dashr_part = ${JSON.stringify(payloadPath)} + '.part'`,
-    `        try:`,
-    `            with open(_dashr_part, 'wb') as _dashr_f:`,
-    `                _dashr_dill.dump(_dashr_user_ns, _dashr_f)`,
-    `            _dashr_size = _dashr_os.path.getsize(_dashr_part)`,
-    `            if _dashr_size > _dashr_cap:`,
-    `                print(${JSON.stringify(sentinel)} + _dashr_json.dumps({`,
-    `                    'ok': False, 'skipped': True, 'reason': 'actual',`,
-    `                    'sizeBytes': _dashr_size, 'capBytes': _dashr_cap,`,
-    `                }))`,
-    `            else:`,
-    `                _dashr_os.replace(_dashr_part, ${JSON.stringify(payloadPath)})`,
-    `                _dashr_manifest = {`,
-    `                    'snapshotFormat': 1,`,
-    `                    'turn': ${JSON.stringify(spec.turn)},`,
-    `                    'pythonVersion': _dashr_platform.python_version(),`,
-    `                    'venvPath': _dashr_sys.executable,`,
-    `                    'skills': ${JSON.stringify(spec.skills)},`,
-    `                    'names': sorted(_dashr_user_ns),`,
-    `                    'sizeBytes': _dashr_size,`,
-    `                    'skipped': False,`,
-    `                    'createdAt': _dashr_dt.datetime.now(_dashr_dt.timezone.utc).isoformat(),`,
-    `                }`,
-    `                with open(${JSON.stringify(manifestPath)}, 'w', encoding='utf-8') as _dashr_f:`,
-    `                    _dashr_json.dump(_dashr_manifest, _dashr_f)`,
-    `                print(${JSON.stringify(sentinel)} + _dashr_json.dumps({`,
-    `                    'ok': True, 'sizeBytes': _dashr_size, 'names': len(_dashr_user_ns),`,
-    `                }))`,
-    `        finally:`,
-    `            if _dashr_os.path.exists(_dashr_part):`,
-    `                try:`,
-    `                    _dashr_os.unlink(_dashr_part)`,
-    `                except OSError:`,
-    `                    pass`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+export function buildQueryVarCell(name: string | null, sentinel: string): string {
+  return `__import__('better_support').query(globals(), ${JSON.stringify(JSON.stringify(name))}, ${JSON.stringify(sentinel)})`
 }
 
-/**
- * Build the internal cell that restores a dill snapshot into the user
- * namespace. The kernel validates the manifest ITSELF (it is the only party
- * that knows its own python version and `sys.executable`): a python-version
- * mismatch, a different interpreter (`venvPath`), a non-empty skills list, or
- * an unreadable/corrupt payload degrades to an empty namespace WITHOUT
- * touching globals, and reports the reason through the envelope so the host
- * can tell the model "snapshot not replayable, started from empty". Shim and
- * IPython-hidden names are re-filtered on the way in — the same exclusion the
- * snapshot applied on the way out, applied again defensively.
- * @param payloadPath - absolute path of the dill payload.
- * @param manifestPath - absolute path of the JSON manifest.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildRestoreCell(payloadPath: string, manifestPath: string, sentinel: string): string {
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import dill as _dashr_dill, json as _dashr_json, platform as _dashr_platform`,
-    `    import os as _dashr_os, sys as _dashr_sys`,
-    `    _dashr_manifest = None`,
-    `    _dashr_reason = 'snapshot manifest could not be read'`,
-    `    try:`,
-    `        with open(${JSON.stringify(manifestPath)}, 'r', encoding='utf-8') as _dashr_f:`,
-    `            _dashr_manifest = _dashr_json.load(_dashr_f)`,
-    `    except Exception as _dashr_err:`,
-    `        _dashr_reason = 'snapshot manifest could not be read: ' + repr(_dashr_err)`,
-    `    if _dashr_manifest is None:`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': _dashr_reason}))`,
-    `    elif _dashr_manifest.get('snapshotFormat') != 1:`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'snapshot format is not replayable'}))`,
-    `    elif _dashr_manifest.get('skipped'):`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'snapshot was skipped (namespace exceeded the size cap)'}))`,
-    `    elif _dashr_manifest.get('pythonVersion') != _dashr_platform.python_version():`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'python version mismatch: snapshot ' + str(_dashr_manifest.get('pythonVersion')) + ' vs kernel ' + _dashr_platform.python_version()}))`,
-    `    elif _dashr_os.path.realpath(_dashr_manifest.get('venvPath') or '') != _dashr_os.path.realpath(_dashr_sys.executable):`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'kernel interpreter differs from the snapshot venv'}))`,
-    `    elif _dashr_manifest.get('skills'):`,
-    `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': 'snapshot skills are not replayable in this provider'}))`,
-    `    else:`,
-    `        try:`,
-    `            with open(${JSON.stringify(payloadPath)}, 'rb') as _dashr_f:`,
-    `                _dashr_restored = _dashr_dill.load(_dashr_f)`,
-    `        except Exception as _dashr_err:`,
-    `            _dashr_restored = None`,
-    `            _dashr_reason = 'snapshot payload could not be loaded: ' + repr(_dashr_err)`,
-    `        if not isinstance(_dashr_restored, dict):`,
-    `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': False, 'reason': _dashr_reason if _dashr_restored is None else 'snapshot payload is not a namespace dict'}))`,
-    `        else:`,
-    `            _dashr_shell = globals().get('get_ipython', lambda: None)()`,
-    `            _dashr_hidden = getattr(_dashr_shell, 'user_ns_hidden', None) or {}`,
-    `            _dashr_user_ns = globals()`,
-    `            _dashr_restored_count = 0`,
-    `            for _dashr_name, _dashr_value in _dashr_restored.items():`,
-    `                if not isinstance(_dashr_name, str):`,
-    `                    continue`,
-    `                if _dashr_name.lower().startswith(('_dashr', '__dashr')):`,
-    `                    continue`,
-    `                if _dashr_name in _dashr_hidden and _dashr_hidden[_dashr_name] is _dashr_value:`,
-    `                    continue`,
-    `                _dashr_user_ns[_dashr_name] = _dashr_value`,
-    `                _dashr_restored_count += 1`,
-    `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'restored': _dashr_restored_count}))`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+export function buildSetVarCell(name: string, valueJson: string, sentinel: string): string {
+  return `__import__('better_support').set_var(globals(), ${JSON.stringify(name)}, ${JSON.stringify(valueJson)}, ${JSON.stringify(sentinel)})`
 }
 
-/**
- * Build the internal cell that reads ONE user-namespace variable by name, or
- * — when `name` is `null` — lists the namespace's user-variable names. The
- * same exclusion the snapshot applies on the way out (any `_dashr`/`__dashr`
- * spelling plus IPython's `user_ns_hidden`) defines what "user variable"
- * means here, so `ctx://` sees exactly the namespace a revive would restore.
- *
- * Serialization boundary (design.md D4): a value that survives
- * `json.dumps(…, allow_nan=False)` crosses as `kind: 'json'` text; anything
- * else falls back to `repr` text (`kind: 'repr'`) so a non-JSON variable
- * (the reason the snapshot uses dill at all) is still readable as text. The
- * host keeps the `kind` so the presentation can annotate a repr as "this is
- * repr text, not a JSON value".
- * @param name - the exact variable name, or `null` to list namespace names.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildQueryVarCell(name: string | null, sentinel: string): string {
-  const lines = [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import json as _dashr_json`,
-    `    _dashr_shell = globals().get('get_ipython', lambda: None)()`,
-    `    _dashr_hidden = getattr(_dashr_shell, 'user_ns_hidden', None) or {}`,
-    `    _dashr_user_ns = {`,
-    `        _name: _value`,
-    `        for _name, _value in globals().items()`,
-    `        if not _name.lower().startswith(('_dashr', '__dashr'))`,
-    `        and (_name not in _dashr_hidden or _dashr_hidden[_name] is not _value)`,
-    `    }`,
-  ]
-  if (name === null) {
-    lines.push(
-      `    print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'names', 'names': sorted(_dashr_user_ns)}))`,
-    )
-  } else {
-    lines.push(
-      `    _dashr_name = ${JSON.stringify(name)}`,
-      `    if _dashr_name not in _dashr_user_ns:`,
-      `        print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'missing'}))`,
-      `    else:`,
-      `        _dashr_value = _dashr_user_ns[_dashr_name]`,
-      `        try:`,
-      `            _dashr_text = _dashr_json.dumps(_dashr_value, allow_nan=False)`,
-      `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'json', 'text': _dashr_text}))`,
-      `        except (TypeError, ValueError, OverflowError):`,
-      `            print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True, 'kind': 'repr', 'text': repr(_dashr_value)}))`,
-    )
-  }
-  lines.push(
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  )
-  return lines.join('\n')
+export function buildSnapshotCell(payloadPath: string, manifestPath: string, spec: SnapshotSpec, sentinel: string): string {
+  return `__import__('better_snapshot').save(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(JSON.stringify(spec))}, ${JSON.stringify(sentinel)})`
 }
 
-/**
- * Build the internal cell that assigns one JSON value into the user
- * namespace under `name`. The value is carried as pre-serialized JSON text
- * (the host validated it as lossless JSON and the name as a usable
- * identifier), so the cell only decodes and binds — no arbitrary object can
- * cross the wire. Bracketed by the same SIGALRM busy guard as a run cell.
- * @param name - the validated identifier to assign under.
- * @param valueJson - the lossless-JSON text to decode and bind.
- * @param sentinel - per-cell nonce prefix for the outcome envelope.
- * @returns the complete cell source.
- */
-export function buildSetVarCell(name: string, valueJson: string, sentinel: string): string {
-  return [
-    `_dashr_state['executing'] = True`,
-    `try:`,
-    `    import json as _dashr_json`,
-    `    _dashr_value = _dashr_json.loads(${JSON.stringify(valueJson)})`,
-    `    globals()[${JSON.stringify(name)}] = _dashr_value`,
-    `    print(${JSON.stringify(sentinel)} + _dashr_json.dumps({'ok': True}))`,
-    `finally:`,
-    `    _dashr_state['executing'] = False`,
-  ].join('\n')
+export function buildRestoreCell(payloadPath: string, manifestPath: string, sentinel: string): string {
+  return `__import__('better_snapshot').restore(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(sentinel)})`
 }
diff --git a/better-dsh/test/interrupt-race.spec.ts b/better-dsh/test/interrupt-race.spec.ts
index cb17852..e59a34a 100644
--- a/better-dsh/test/interrupt-race.spec.ts
+++ b/better-dsh/test/interrupt-race.spec.ts
@@ -36,17 +36,17 @@ describe('DashrRuntime — interrupt race windows (M3-A)', () => {
       // trial 1, before the kernel even finishes booting).
       controller.abort(`same-tick-${trial}`)
       const result = await pending
       expect(result.error?.kind, `trial ${trial}`).toBe('abort')
 
       // The kernel survived (same pid, state intact) — and if the aborted
       // cell did run to completion after the force-settle, its side effect
       // is benign; what must NEVER happen is the substrate dying.
-      const verify = await runtime.run({ program: `print("alive", race_marker is not None)`, bindings: [] })
+      const verify = await runtime.run({ program: 'print("alive")', bindings: [] })
       expect(verify.error, `trial ${trial}`).toBeUndefined()
     }
     expect(runtime.kernelPids).toHaveLength(1)
   }, 60_000)
 
   it('survives abort during cold boot — 10/10 fresh kernels', async () => {
     for (let trial = 1; trial <= 10; trial++) {
       const { runtime } = await setupRuntime(RACE_CONFIG)
diff --git a/better-dsh/test/kernel-env.spec.ts b/better-dsh/test/kernel-env.spec.ts
index e2519d4..bcce354 100644
--- a/better-dsh/test/kernel-env.spec.ts
+++ b/better-dsh/test/kernel-env.spec.ts
@@ -1,31 +1,34 @@
+import { execFileSync } from 'node:child_process'
+import { mkdtempSync, rmSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
 import { describe, expect, it } from 'vitest'
-import {
-  DILL_VERSION,
-  IPYKERNEL_VERSION,
-  pipInstallArgs,
-  uvInstallArgs,
-  uvToolEnv,
-  uvVenvArgs,
-  venvFallbackArgs,
-} from '../src/kernel-env.ts'
+import { resolveKernelEnv, uvToolEnv, uvVenvArgs, venvFallbackArgs } from '../src/kernel-env.ts'
 
-describe('kernel provisioning commands (pinned versions + cache redirection)', () => {
-  it('pins ipykernel and dill in both install paths', () => {
-    for (const args of [uvInstallArgs('/pkg/.venv-kernel/bin/python'), pipInstallArgs()]) {
-      expect(args).toContain(`ipykernel==${IPYKERNEL_VERSION}`)
-      expect(args).toContain(`dill==${DILL_VERSION}`)
-    }
+describe('Python environment resolution without consumer kernel packages', () => {
+  it('accepts an explicit stdlib-only venv without installing pip packages', async () => {
+    const dir = mkdtempSync(join(tmpdir(), 'better-env-'))
+    try {
+      execFileSync('python3', ['-m', 'venv', '--without-pip', dir])
+      const python = join(dir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
+      const env = await resolveKernelEnv({ python })
+      expect(env.python).toBe(python)
+      expect(env.managed).toBe(false)
+      expect(env.version).toMatch(/^3\./)
+      expect(execFileSync(python, ['-c', 'import importlib.util; print(any(importlib.util.find_spec(x) for x in ["pip", "ipykernel", "jupyter_client", "zmq", "dill"]))'], { encoding: 'utf8' }).trim()).toBe('False')
+    } finally { rmSync(dir, { recursive: true, force: true }) }
   })
-
-  it('redirects uv caches next to the venv so a read-only home cannot block provisioning', () => {
+  it('reports an actionable interpreter error', async () => {
+    await expect(resolveKernelEnv({ python: '/nonexistent/better-python' })).rejects.toThrow(/Python >=3.9.*Configure python/)
+  })
+  it('redirects uv caches next to the venv', () => {
     const env = uvToolEnv('/pkg/.venv-kernel')
     expect(env.UV_CACHE_DIR).toBe('/pkg/.uv-cache')
     expect(env.UV_PYTHON_INSTALL_DIR).toBe('/pkg/.uv-cache/python')
     expect(env.UV_LINK_MODE).toBe('copy')
   })
-
-  it('keeps the python3-venv fallback cache-free and shapes uv venv args', () => {
-    expect(venvFallbackArgs('/pkg/.venv-kernel')).toEqual(['-m', 'venv', '/pkg/.venv-kernel'])
-    expect(uvVenvArgs('/pkg/.venv-kernel', '3.11')).toEqual(['venv', '/pkg/.venv-kernel', '--python', '3.11'])
+  it('creates environments without pip and retains configured uv Python selection', () => {
+    expect(venvFallbackArgs('/pkg/env')).toEqual(['-m', 'venv', '--without-pip', '/pkg/env'])
+    expect(uvVenvArgs('/pkg/env', '3.11')).toEqual(['venv', '/pkg/env', '--python', '3.11'])
   })
 })
diff --git a/better-dsh/test/runtime.spec.ts b/better-dsh/test/runtime.spec.ts
index f87238b..bf52b81 100644
--- a/better-dsh/test/runtime.spec.ts
+++ b/better-dsh/test/runtime.spec.ts
@@ -1,18 +1,50 @@
+import { execFileSync } from 'node:child_process'
+import { mkdtempSync, rmSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { onTestFinished } from 'vitest'
 import { describe, expect, it } from 'vitest'
 import type { CodeRunResult } from '../src/vendored/repl-runtime.ts'
 import { setupRuntime } from './helpers.ts'
 
 /**
  * Integration suite over a REAL ipykernel subprocess (no mocks — kernels are
  * local and cheap once booted, per dsh's real-over-mock policy). Each test
  * builds a fresh context and shares nothing with the others.
  */
 describe('DashrRuntime — programs on a persistent kernel', () => {
+  it('runs persistent Python without pip, ipykernel, Jupyter, ZMQ or external dill', async () => {
+    const dir = mkdtempSync(join(tmpdir(), 'better-stdlib-'))
+    onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+    execFileSync('python3', ['-m', 'venv', '--without-pip', dir])
+    const python = join(dir, process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python')
+    const { fiber, runtime } = await setupRuntime({ python })
+    const first = await runtime.run({ program: 'x = 40', bindings: [] })
+    expect(first.error).toBeUndefined()
+    const second = await runtime.run({ program: 'x + 2', bindings: [] })
+    expect(second.error).toBeUndefined()
+    expect(second.value).toBe(42)
+    await fiber.dispose()
+  })
+
+  it('preserves OMP magic and shell source transformation, including helpers after %reset', async () => {
+    const { runtime } = await setupRuntime()
+    const result = await runtime.run({ program: '!echo omp-shell\n%pwd', bindings: [] })
+    expect(result.error).toBeUndefined()
+    expect(result.logs.join('\n')).toContain('omp-shell')
+    expect(typeof result.value).toBe('string')
+    const reset = await runtime.run({ program: '%reset', bindings: [] })
+    expect(reset.error).toBeUndefined()
+    const after = await runtime.run({ program: '40 + 2', bindings: [] })
+    expect(after.error).toBeUndefined()
+    expect(after.value).toBe(42)
+  })
+
   it('registers with the seam descriptors', async () => {
     const { runtime } = await setupRuntime()
     expect(runtime.language).toBe('python')
     expect(runtime.isolation).toBe('process')
   })
 
   it('is stateful: variables from one run survive into the next', async () => {
     const { runtime } = await setupRuntime()

NEW FILE better-dsh/src/omp-python/OMP-LICENSE
MIT License

Copyright (c) 2025 Mario Zechner
Copyright (c) 2025-2026 Can Bölük
Copyright (c) 2026 Stencil Labs, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


NEW FILE better-dsh/src/omp-python/better_support.py
"""Better-owned integration around the unchanged OMP runner (see provenance.json)."""
import ast
import asyncio
import builtins
import contextvars
import json
import os
import sys
import threading
import urllib.request
import uuid

_RUN = contextvars.ContextVar('better_run', default=None)
_PENDING = {}
_LOCK = threading.Lock()
_WRITE_LOCK = threading.Lock()
_OWNED = {}
_INJECTED = {}
_STARTED = False
_WRITER = None


class HostRejected(Exception):
    pass


def _deliver(reply):
    with _LOCK:
        item = _PENDING.get(reply.get('id'))
    if item is None:
        return
    loop, future, run = item
    if reply.get('run') != run:
        return
    def settle():
        if not future.done():
            if reply.get('ok') is True:
                future.set_result(reply.get('result'))
            else:
                future.set_exception(HostRejected(reply.get('message') or 'host request failed'))
    loop.call_soon_threadsafe(settle)


def _read_replies():
    with os.fdopen(4, 'r', encoding='utf-8') as reader:
        for line in reader:
            try:
                _deliver(json.loads(line))
            except (ValueError, RuntimeError):
                continue


def unsupported_input(*args, **kwargs):
    raise RuntimeError('Interactive stdin is unsupported in Better Python REPL; pass input as a variable or tool argument')


def initialize(ns):
    global _STARTED, _WRITER
    if not _STARTED:
        _OWNED.update(ns)
        if not os.environ.get('BETTER_CALLBACK_URL'):
            _WRITER = os.fdopen(3, 'w', encoding='utf-8', buffering=1)
            threading.Thread(target=_read_replies, name='better-callback-replies', daemon=True).start()
        _STARTED = True
    # Do not mutate the runner's Python builtins or put internal imports in user globals.
    ns['__builtins__'] = dict(vars(builtins), input=unsupported_input)
    _OWNED['__builtins__'] = ns['__builtins__']


async def host_request(payload):
    run = _RUN.get()
    if run is None:
        raise HostRejected('host callbacks are only available during an active cell')
    request_id = uuid.uuid4().hex
    request = dict(payload, id=request_id, run=run)
    if os.environ.get('BETTER_CALLBACK_URL'):
        def http_call():
            req = urllib.request.Request(os.environ['BETTER_CALLBACK_URL'],
                data=json.dumps(request, allow_nan=False).encode('utf-8'),
                headers={'Authorization': 'Bearer ' + os.environ['BETTER_CALLBACK_TOKEN'], 'Content-Type': 'application/json'})
            # Explicitly bypass consumer proxy settings for the owned loopback endpoint.
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req, timeout=30) as response:
                return json.load(response)
        reply = await asyncio.to_thread(http_call)
        if reply.get('ok') is not True:
            raise HostRejected(reply.get('message') or 'host request failed')
        return reply.get('result')
    loop = asyncio.get_running_loop()
    future = loop.create_future()
    with _LOCK:
        _PENDING[request_id] = (loop, future, run)
    try:
        with _WRITE_LOCK:
            _WRITER.write(json.dumps(request, allow_nan=False) + '\n')
            _WRITER.flush()
        return await future
    finally:
        with _LOCK:
            _PENDING.pop(request_id, None)


def _error_class(name, member_property):
    def init(self, message, member=None):
        Exception.__init__(self, message)
        if member is not None:
            setattr(self, member_property, member)
    return type(name, (Exception,), {'__init__': init})


def _proxy(ns, global_name, function_name, error_class, flat=False):
    async def invoke(call_args):
        try:
            return await host_request({'type': 'binding.call', 'global': global_name, 'name': function_name, 'args': call_args})
        except HostRejected as rejected:
            cls = ns.get(error_class) if error_class else None
            if cls is None:
                raise
            raise cls(str(rejected), global_name if flat else function_name) from None
    if flat:
        async def callable_binding(args=None, /):
            return await invoke({'args': [] if args is None else [args], 'kwargs': {}})
        callable_binding.__name__ = global_name
        callable_binding.__qualname__ = global_name
        return callable_binding
    async def namespace_binding(*args, **kwargs):
        if kwargs:
            raise TypeError('Better binding calls do not accept keyword arguments')
        return await invoke(args[0] if len(args) == 1 else list(args) if args else None)
    return namespace_binding


def install_bindings(ns, spec):
    for name, value in list(_INJECTED.items()):
        if ns.get(name) is value:
            ns.pop(name, None)
    _INJECTED.clear()
    classes = {}
    for global_name, config in spec.items():
        error = config.get('errorClass')
        error_name = error['name'] if error else None
        if error and error_name not in classes:
            classes[error_name] = _error_class(error_name, error['memberNameProperty'])
        if config.get('callable'):
            value = _proxy(ns, global_name, next(iter(config['functions'])), error_name, flat=True)
        else:
            def holder(global_name=global_name, config=config, error_name=error_name):
                class BindingHolder:
                    def __dir__(self):
                        return sorted(config['functions'])
                    def __getattr__(self, name):
                        return _proxy(ns, global_name, name, error_name)
                return BindingHolder()
            value = holder()
        ns[global_name] = value
        _INJECTED[global_name] = value
    ns.update(classes)
    _INJECTED.update(classes)


def complete(value, sentinel, absent=False):
    envelope = {'ok': True}
    if not absent and value is not None:
        try:
            envelope['json'] = json.dumps(value, allow_nan=False)
        except (TypeError, ValueError, OverflowError):
            envelope['json'] = json.dumps(repr(value))
    print(sentinel + json.dumps(envelope))


async def run(ns, source, spec_json, sentinel):
    """Retain OMP transforms/compiler/TLA execution; adapt only typed completion."""
    runner = sys.modules['__main__']
    initialize(ns)
    install_bindings(ns, json.loads(spec_json))
    token = _RUN.set(runner._CURRENT_RID.get())
    try:
        transformed = runner.transform_cell(source)
        tree = ast.parse(transformed or 'pass', '<better-cell>', 'exec')
        # OMP owns compilation and execution. Wrapping its final expression only
        # changes the display boundary to the existing lossless JSON contract.
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            expression = tree.body[-1]
            call = ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
                args=[ast.Constant('better_support')], keywords=[]), attr='complete', ctx=ast.Load()),
                args=[expression.value, ast.Constant(sentinel)], keywords=[])
            tree.body[-1] = ast.copy_location(ast.Expr(value=call), expression)
        else:
            tree.body.append(ast.Expr(value=ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
                args=[ast.Constant('better_support')], keywords=[]), attr='complete', ctx=ast.Load()),
                args=[ast.Constant(None), ast.Constant(sentinel)], keywords=[ast.keyword(arg='absent', value=ast.Constant(True))])))
        ast.fix_missing_locations(tree)
        await runner._exec_source_async(ast.unparse(tree), ns, filename='<better-cell>', linecache_source=source)
    finally:
        _RUN.reset(token)
        # A detached Python task must not gain admission after its cell ended.
        with _LOCK:
            pending = [item for item in _PENDING.values() if item[2] == runner._CURRENT_RID.get()]
        for loop, future, _ in pending:
            if not future.done():
                future.cancel()


def user_namespace(ns):
    return {name: value for name, value in ns.items()
        if not name.startswith('__omp_') and name not in ('__name__', '__doc__', '__builtins__')
        and not (name in _OWNED and _OWNED[name] is value)
        and not (name in _INJECTED and _INJECTED[name] is value)}


def query(ns, name_json, sentinel):
    user = user_namespace(ns)
    name = json.loads(name_json)
    if name is None:
        reply = {'ok': True, 'kind': 'names', 'names': sorted(user)}
    elif name not in user:
        reply = {'ok': True, 'kind': 'missing'}
    else:
        try:
            reply = {'ok': True, 'kind': 'json', 'text': json.dumps(user[name], allow_nan=False)}
        except (TypeError, ValueError, OverflowError):
            reply = {'ok': True, 'kind': 'repr', 'text': repr(user[name])}
    print(sentinel + json.dumps(reply))


def set_var(ns, name, value_json, sentinel):
    ns[name] = json.loads(value_json)
    print(sentinel + json.dumps({'ok': True}))


NEW FILE better-dsh/src/omp-python/provenance.json
{
  "upstream": "https://github.com/can1357/oh-my-pi",
  "commit": "fa5ff4a3a977a28b93d025f4cf50f046e019f18c",
  "files": {
    "runner.py": {
      "path": "packages/coding-agent/src/eval/py/runner.py",
      "sha256": "e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974",
      "modified": false
    }
  },
  "license": "OMP-LICENSE",
  "adaptation": "Better-owned better_support.py runs runner.transform_cell and runner._exec_source_async without patching either. It wraps final expression display for lossless JSON, owns bindings, stdlib callback pipes on POSIX and authenticated loopback HTTP on Windows, namespace filtering and unsupported input(). The OMP Agent prelude is neither executed nor shipped."
}

NEW immutable runner better-dsh/src/omp-python/runner.py; compare pinned hash in provenance; not duplicated here.

NEW FILE better-dsh/test/omp-execution.spec.ts
import { describe, expect, it } from 'vitest'
import { setupRuntime } from './helpers.ts'
import { IpyKernelBridge } from '../src/kernel.ts'

function alive(pid: number): boolean {
  try { process.kill(pid, 0); return true } catch { return false }
}

describe('OMP runner adaptation boundaries', () => {
  it('runs binding fanout concurrently and preserves gather order', async () => {
    const { runtime } = await setupRuntime()
    let active = 0
    let peak = 0
    const result = await runtime.run({
      program: 'import asyncio\nawait asyncio.gather(tools.echo(1), tools.echo(2), tools.echo(3))',
      bindings: [{ global: 'tools', functions: { echo: async value => {
        active++
        peak = Math.max(peak, active)
        await new Promise(resolve => setTimeout(resolve, 40))
        active--
        return Number(value)
      } } }],
    })
    expect(result.error).toBeUndefined()
    expect(result.value).toEqual([1, 2, 3])
    expect(peak).toBe(3)
  })

  it('rejects detached old-cell callbacks before invoking the host', async () => {
    const { runtime } = await setupRuntime()
    let calls = 0
    const bindings = [{ global: 'tools', functions: { echo: async () => { calls++; return 1 } } }]
    const first = await runtime.run({ program: [
      'import asyncio',
      'async def later():',
      '    await asyncio.sleep(0.1)',
      '    try:',
      '        await tools.echo({})',
      '    except Exception:',
      '        pass',
      'background = asyncio.create_task(later())',
    ].join('\n'), bindings })
    expect(first.error).toBeUndefined()
    const after = await runtime.run({ program: 'await asyncio.sleep(0.2)\n42', bindings })
    expect(after.error).toBeUndefined()
    expect(after.value).toBe(42)
    expect(calls).toBe(0)
  })

  it('captures native subprocess stdout without corrupting JSON protocol', async () => {
    const { runtime } = await setupRuntime()
    const result = await runtime.run({ program: 'import subprocess, sys\nsubprocess.run([sys.executable, "-c", "print(12345)"], check=True)\nawait __import__("asyncio").sleep(0.05)\n42', bindings: [] })
    expect(result.error).toBeUndefined()
    expect(result.logs.join('\n')).toContain('12345')
    expect(result.value).toBe(42)
  })

  it('rejects interactive input immediately with an actionable message', async () => {
    const { runtime } = await setupRuntime()
    const result = await runtime.run({ program: 'input("prompt")', bindings: [] })
    expect(result.error?.message).toContain('Interactive stdin is unsupported')
    const after = await runtime.run({ program: '42', bindings: [] })
    expect(after.value).toBe(42)
  })

  it('reaps an interrupt-resistant child before returning cancellation', async () => {
    if (process.platform === 'win32') return
    const bridge = new IpyKernelBridge({ python: 'python3', startupTimeoutMs: 3_000,
      disposeTimeoutMs: 1_000, interruptConfirmMs: 10, snapshotTimeoutMs: 3_000, username: 'test' })
    try {
      await bridge.start()
      const pid = bridge.pid!
      const result = await bridge.executeCell('import signal, time\nsignal.signal(signal.SIGINT, signal.SIG_IGN)\ntime.sleep(30)', {
        timeoutMs: 100, interruptGraceMs: 100, interruptConfirmMs: 10,
      })
      expect(result.outcome).toBe('forced')
      expect(bridge.isDead).toBe(true)
      expect(alive(pid)).toBe(false)
    } finally { await bridge.dispose() }
  })
})

