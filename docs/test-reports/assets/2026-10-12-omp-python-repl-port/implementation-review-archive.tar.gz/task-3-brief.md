## Task 3: Consumer validation, Surface and review handoff

**Files:** update `better-dsh/eval-description.md`, relevant canonical docs and package-catalog as needed; update spec status with implementation evidence; write `docs/test-reports/2026-10-12-omp-python-repl-port.md`.

- [ ] Update runtime-visible tool guidance to explain OMP-backed Python, interpreter prerequisite, process-local state plus best-effort checkpoints, skipped resources and no automatic replay. Avoid claiming complete process restoration.
- [ ] Run full affected Better tests and both typecheck lanes. Run root packaging checks and `npm run version:release -- 0.3.0-s` before a clean dual pack.
- [ ] Inspect actual tarball resources/hashes/licenses and absence of obsolete ZMQ or consumer pip install, plus two independent bundles contract.
- [ ] Launch via `super-dsh/test/start-4999.sh` in retained `.tests/superd`; first-person model performs Python assignment, cross-cell lookup, native tool call, exception recovery, cancellation and reset. Inspect model-visible results.
- [ ] Transfer exact two tarballs and `pair.json` to retained dev3 test environment; use same launcher/prebuilt pair with independent host anchor. Run equivalent actual installed REPL/state/restore probes. Never touch production homes/ports/Caddy.
- [ ] Exercise installed checkpoint creation, fresh-child restore, partial restore/corruption and death side effects through actual consumer runtime; correlate files/manifests and model notices with results.
- [ ] Write exact artifact hashes, versions, checks/failures, session IDs, target services and review URL in report. Leave test web running for user review. No commit/publish; report any remaining externally blocked verification honestly.
