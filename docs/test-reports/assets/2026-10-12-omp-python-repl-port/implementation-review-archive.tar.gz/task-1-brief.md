## Task 1: Replace execution substrate and deliver resources

**Files:** create `better-dsh/src/omp-python/` for pinned runner, own support, provenance/notices; replace `src/kernel.ts`, `src/kernel-env.ts`, `src/bootstrap.ts` and `src/python.ts` as needed; remove retired `src/kernel-transport.ts`/`src/kernel-bridge.py`; update `scripts/copy-kernel-bridge.mjs`, `scripts/kernel-provision.mjs`, package scripts/notices and affected execution/env tests.

**Interfaces:** preserve bridge methods `start()`, `executeCell(code, opts)`, `queryVar(name)`, `setVar(name, valueJson)`, `snapshotState(payloadPath, manifestPath, spec)`, `restoreState(payloadPath, manifestPath)`, `dispose()`; preserve `pid`, `isRunning`, `isDead`. Add outcome fields only when Task2 consumes them. Host callback handler retains `{global, function, args}` request and `{ok,result|message}` reply.

- [ ] Read pinned source/protocol report `/tmp/omp-python-protocol-research.md` and actual existing runtime contracts. Record any deliberate adaptation in provenance.
- [ ] Add failing execution test using a temporary stdlib-only Python venv: `python3 -m venv --without-pip <dir>` and `setupRuntime({python:<dir>/bin/python})`; run `x=40`, then `x+2`, assert value42 and no Jupyter dependency. Add OMP magic/shell behavior test and binding gather/error/cancel tests where existing coverage is insufficient.
- [ ] Run `npm --prefix better-dsh test -- test/runtime.spec.ts test/kernel-env.spec.ts`, save expected missing-ipykernel failure as RED evidence.
- [ ] Copy runner unchanged; provide Better support module with per-child authenticated HTTP or dedicated inherited callback pipes (prefer pipes when portable). Route async tool calls concurrently within a serialized cell; correlate request/response and discard stale replies.
- [ ] Implement Node NDJSON transport/startup probe, actual OMP source transformation/execution, typed completion mapping, text output, error/abort/timeout mapping, no invisible truncation, and bounded termination/close. Separate internal output consumption from user results. Preserve None suppression, top-level await and return rejection.
- [ ] Resolve/probe >=3.9 interpreter without requiring ipykernel, jupyter_client, pyzmq or external dill. Preserve configured interpreter/managed venv compatibility without installing kernel packages; provide actionable interpreter errors.
- [ ] Copy all Python resources/licenses/provenance into `lib/` after build; remove obsolete bridge/provision mechanisms and update descriptions which claim IPython.
- [ ] Run execution/binding/output/cancel/lifecycle suites and host typecheck; verify no orphan children. Task reviewer checks protocol, state/cancellation ordering and packaged resource resolution before Task2.

