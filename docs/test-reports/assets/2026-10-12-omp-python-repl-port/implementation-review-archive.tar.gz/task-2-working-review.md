# Task2 working diff review package

No commits under root release gate. Diff compares saved reviewed Task1 working tree to current Task2 source. Original runner and dill runtime/license bytes excluded from text diff; hashes/provenance and guard logs verify unchanged originals. Root docs omitted from Task2 scope. Read task-2-brief.md/global-context.md and task-2-report.md.

Changed files:
- better-dsh/scripts/copy-kernel-bridge.mjs
- better-dsh/src/kernel.ts
- better-dsh/src/omp-python/better_snapshot.py
- better-dsh/src/omp-python/better_support.py
- better-dsh/src/omp-python/dill-provenance.json
- better-dsh/src/python.ts
- better-dsh/src/runtime.ts
- better-dsh/test/helpers.ts
- better-dsh/test/lifecycle.spec.ts
- better-dsh/test/omp-checkpoint-safety.spec.ts
- better-dsh/test/session-keys.spec.ts
- better-dsh/test/snapshot-restore.spec.ts
- better-dsh/test/snapshot-revive.spec.ts

```diff
--- task1/better-dsh/scripts/copy-kernel-bridge.mjs
+++ task2/better-dsh/scripts/copy-kernel-bridge.mjs
@@ -1,13 +1,19 @@
 #!/usr/bin/env node
 /** Verify and ship immutable runner plus Better resources after tsdown. */
 import { createHash } from 'node:crypto'
-import { cpSync, mkdirSync, readFileSync } from 'node:fs'
+import { cpSync, mkdirSync, readFileSync, rmSync } from 'node:fs'
 const source = new URL('../src/omp-python/', import.meta.url)
 const provenance = JSON.parse(readFileSync(new URL('provenance.json', source), 'utf8'))
 const expected = provenance.files['runner.py'].sha256
 const actual = createHash('sha256').update(readFileSync(new URL('runner.py', source))).digest('hex')
 if (actual !== expected) throw new Error(`Immutable OMP runner hash mismatch: expected ${expected}, found ${actual}`)
+const dillProvenance = JSON.parse(readFileSync(new URL('dill-provenance.json', source), 'utf8'))
+for (const [path, metadata] of Object.entries(dillProvenance.files)) {
+  const hash = createHash('sha256').update(readFileSync(new URL(path, source))).digest('hex')
+  if (hash !== metadata.sha256) throw new Error(`Immutable dill source hash mismatch: ${path}`)
+}
 const target = new URL('../lib/omp-python/', import.meta.url)
+rmSync(target, { recursive: true, force: true })
 mkdirSync(target, { recursive: true })
 cpSync(source, target, { recursive: true, filter: path => !path.includes('__pycache__') && !path.endsWith('.pyc') && !path.split(/[\\/]/).includes('tests') })
 console.log(`copy-kernel-bridge: verified runner ${actual}; packaged omp-python resources`)
--- task1/better-dsh/src/kernel.ts
+++ task2/better-dsh/src/kernel.ts
@@ -2,34 +2,36 @@
 import { spawn, type ChildProcess } from 'node:child_process'
 import { randomBytes, randomUUID } from 'node:crypto'
 import { createServer, type Server } from 'node:http'
 import { createInterface } from 'node:readline'
 import type { Readable, Writable } from 'node:stream'
 import { fileURLToPath } from 'node:url'
 import { KERNEL_BOOTSTRAP } from './bootstrap.ts'
-import { buildQueryVarCell, buildSetVarCell } from './python.ts'
+import { buildQueryVarCell, buildSetVarCell, buildSnapshotCell, buildRestoreCell } from './python.ts'
 import type { SnapshotSpec } from './python.ts'
 import { extractStream } from './output.ts'
 
 export interface KernelBridgeOptions {
   python: string
   cwd?: string
   startupTimeoutMs: number
   disposeTimeoutMs: number
   /** Retained configuration seam; OMP interrupts with SIGINT directly. */
   interruptConfirmMs: number
   snapshotTimeoutMs: number
   username: string
+  snapshotDirectory?: string
+  snapshotSizeCapBytes?: number
 }
 export type { SnapshotSpec }
 export type SnapshotOutcome =
-  | { kind: 'ok', sizeBytes: number, names: number }
+  | { kind: 'ok', sizeBytes: number, names: string[], omitted: Record<string, string>, turn: number }
   | { kind: 'skipped', reason: string, estimateBytes?: number, sizeBytes?: number, capBytes: number }
   | { kind: 'failed', reason: string }
-export type RestoreStateOutcome = { kind: 'restored', count: number } | { kind: 'degraded', reason: string }
+export type RestoreStateOutcome = { kind: 'restored', count: number, turn: number, omitted: Record<string, string> } | { kind: 'degraded', reason: string }
 export type QueryVarOutcome = { kind: 'json' | 'repr', text: string } | { kind: 'names', names: string[] } | { kind: 'missing' } | { kind: 'failed', reason: string }
 export type SetVarOutcome = { kind: 'ok' } | { kind: 'failed', reason: string }
 export type HostRequestOutcome = { ok: true, result: unknown } | { ok: false, message: string }
 export type HostRequestHandler = (data: Record<string, unknown>) => Promise<HostRequestOutcome>
 export interface ExecuteCellOptions {
   timeoutMs: number
   interruptGraceMs: number
@@ -145,15 +147,15 @@
           let data: unknown
           try { data = JSON.parse(line) } catch { return }
           void this.callback(data).then(reply => {
             if (!replies.destroyed && !replies.writableEnded) replies.write(JSON.stringify(reply) + '\n')
           })
         })
       }
-      const result = await this.perform(KERNEL_BOOTSTRAP, {
+      const result = await this.perform(KERNEL_BOOTSTRAP + `\n__import__('better_snapshot').configure(${JSON.stringify(this.options.snapshotDirectory ?? '')}, ${this.options.snapshotSizeCapBytes ?? 268435456}, ${this.options.snapshotTimeoutMs})`, {
         timeoutMs: this.options.startupTimeoutMs, interruptGraceMs: 1_000, interruptConfirmMs: this.options.interruptConfirmMs,
       })
       if (result.outcome !== 'completed' || result.status !== 'ok') {
         throw new Error(`OMP Python initialization failed: ${JSON.stringify(result)}`)
       }
       if (this.isDead) throw new Error('Python exited during initialization')
       this.state = 'running'
@@ -304,19 +306,30 @@
     return { kind: 'failed', reason: 'Python variable query failed' }
   }
   async setVar(name: string, valueJson: string): Promise<SetVarOutcome> {
     const sentinel = `__better_set_${randomBytes(12).toString('hex')}__`
     const reply = await this.internal(buildSetVarCell(name, valueJson, sentinel), sentinel)
     return reply?.ok === true ? { kind: 'ok' } : { kind: 'failed', reason: 'Python variable assignment failed' }
   }
-  async snapshotState(_payloadPath: string, _manifestPath: string, _spec: SnapshotSpec): Promise<SnapshotOutcome> {
-    return { kind: 'failed', reason: 'OMP checkpoint integration pending Task 2' }
-  }
-  async restoreState(_payloadPath: string, _manifestPath: string): Promise<RestoreStateOutcome> {
-    return { kind: 'degraded', reason: 'OMP checkpoint integration pending Task 2' }
+  async snapshotState(payloadPath: string, manifestPath: string, spec: SnapshotSpec): Promise<SnapshotOutcome> {
+    const sentinel = `__better_save_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildSnapshotCell(payloadPath, manifestPath, spec, sentinel), sentinel)
+    if (reply?.kind === 'ok' && Array.isArray(reply.names) && typeof reply.sizeBytes === 'number' && typeof reply.turn === 'number' && record(reply.omitted)) {
+      return { kind: 'ok', sizeBytes: reply.sizeBytes, names: reply.names as string[], omitted: reply.omitted as Record<string, string>, turn: reply.turn }
+    }
+    if (reply?.kind === 'skipped') return { kind: 'skipped', reason: String(reply.reason), capBytes: spec.sizeCapBytes }
+    return { kind: 'failed', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint helper timed out, failed, or exited; previous committed generation retained' }
+  }
+  async restoreState(payloadPath: string, manifestPath: string, bindings: string[] = []): Promise<RestoreStateOutcome> {
+    const sentinel = `__better_restore_${randomBytes(12).toString('hex')}__`
+    const reply = await this.internal(buildRestoreCell(payloadPath, manifestPath, sentinel, bindings), sentinel)
+    if (reply?.kind === 'restored' && typeof reply.count === 'number' && typeof reply.turn === 'number' && record(reply.omitted)) {
+      return { kind: 'restored', count: reply.count, turn: reply.turn, omitted: reply.omitted as Record<string, string> }
+    }
+    return { kind: 'degraded', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint restore helper failed or timed out' }
   }
 
   dispose(): Promise<void> {
     this.disposePromise ??= this.doDispose()
     return this.disposePromise
   }
   private async doDispose(): Promise<void> {
--- task1/better-dsh/src/omp-python/better_snapshot.py
+++ task2/better-dsh/src/omp-python/better_snapshot.py
@@ -0,0 +1,323 @@
+"""Best-effort checkpoints for the owned OMP namespace; dill 0.4.1 adapter.
+
+No cell history is stored/replayed. Pickling user objects is not a sandbox:
+reducers may execute arbitrary code. Host deadlines bound helper execution.
+"""
+import _thread
+import asyncio
+import dis
+import hashlib
+import io
+import json
+import os
+import platform
+import re
+import socket
+import sqlite3
+import subprocess
+import sys
+import threading
+import time
+import types
+import uuid
+
+# Select the unchanged packaged implementation before ANY user cell can import dill.
+_VENDOR = os.path.join(os.path.dirname(__file__), 'vendor')
+sys.path.insert(0, _VENDOR)
+import dill
+if dill.__version__ != '0.4.1' or os.path.realpath(dill.__file__) != os.path.realpath(os.path.join(_VENDOR, 'dill', '__init__.py')):
+    raise RuntimeError('Better requires its packaged dill 0.4.1')
+
+_DIRECTORY = None
+_CAP = None
+_TIMEOUT = 30.0
+_FORMAT = 2
+_RESOURCES = (io.IOBase, _thread.LockType, type(threading.RLock()), socket.socket,
+    subprocess.Popen, threading.Thread, sqlite3.Connection, sqlite3.Cursor,
+    asyncio.Future, asyncio.AbstractEventLoop, types.GeneratorType,
+    types.CoroutineType, types.AsyncGeneratorType)
+_PRIMITIVES = (str, bytes, int, float, bool, type(None))
+
+
+class UnsupportedResource(Exception):
+    pass
+
+
+class SizeCap(Exception):
+    pass
+
+
+class NamespaceProxy:
+    pass
+
+
+def _proxy(ns):
+    proxy = NamespaceProxy()
+    proxy.__dict__ = ns
+    return proxy
+
+
+def configure(directory, cap, timeout_ms):
+    global _DIRECTORY, _CAP, _TIMEOUT
+    _DIRECTORY = os.path.abspath(directory) if directory else None
+    _CAP = cap
+    _TIMEOUT = timeout_ms / 1000.0 * 0.9
+
+
+def clear():
+    """Delete only our fixed manifest and generation files, including orphans."""
+    if _DIRECTORY and os.path.islink(_DIRECTORY):
+        raise ValueError('checkpoint directory cannot be a symlink')
+    if not _DIRECTORY or not os.path.isdir(_DIRECTORY):
+        return
+    for name in os.listdir(_DIRECTORY):
+        if name == 'manifest.json' or re.fullmatch(r'(state-[0-9a-f]{32}\.dill|\.checkpoint-[0-9a-f]{32}\.tmp)', name):
+            os.unlink(os.path.join(_DIRECTORY, name))
+
+
+def _paths(payload_path, manifest_path):
+    if not _DIRECTORY or os.path.abspath(manifest_path) != os.path.join(_DIRECTORY, 'manifest.json') or os.path.abspath(payload_path) != os.path.join(_DIRECTORY, 'state.dill'):
+        raise ValueError('checkpoint paths are not the configured session directory')
+    os.makedirs(_DIRECTORY, mode=0o700, exist_ok=True)
+    if os.path.islink(_DIRECTORY):
+        raise ValueError('checkpoint directory cannot be a symlink')
+    if os.path.islink(manifest_path):
+        raise ValueError('checkpoint manifest cannot be a symlink')
+    os.chmod(_DIRECTORY, 0o700)
+
+
+def _environment():
+    return dict(pythonVersion=platform.python_version(), implementation=platform.python_implementation(),
+        interpreter=os.path.realpath(sys.executable), venvPath=sys.prefix,
+        environmentHash=hashlib.sha256(json.dumps([sys.prefix, sys.base_prefix, sys.path], sort_keys=True).encode()).hexdigest(),
+        dillVersion=dill.__version__, protocol=4, skills=[])
+
+
+def _guard(ns):
+    import better_support
+    owned = [sys.modules['__main__'], sys.modules['better_support'], sys.modules[__name__]]
+    owned.extend(better_support.owned_objects())
+    denied = {id(value) for value in owned if not isinstance(value, _PRIMITIVES)}
+    def guard(value):
+        if id(value) in denied or (isinstance(value, (types.FunctionType, type)) and getattr(value, '__module__', None) in ('better_support', 'better_snapshot')) or type(value).__module__ == 'better_support':
+            raise UnsupportedResource('captured Better/runner binding')
+        if isinstance(value, _RESOURCES):
+            raise UnsupportedResource('unsupported live resource ' + type(value).__name__)
+        return None
+    return guard
+
+
+class CappedBuffer(io.BytesIO):
+    def __init__(self, cap):
+        super().__init__()
+        self.cap = cap
+    def write(self, value):
+        if self.tell() + len(value) > self.cap:
+            raise SizeCap('serialized graph exceeds snapshotSizeCapBytes')
+        return super().write(value)
+
+
+def _encode(ns, values, cap, guard):
+    output = CappedBuffer(cap)
+    # Exact Pickler: subclassing disables pinned dill's main-module logic.
+    pickler = dill.Pickler(output, protocol=4, recurse=False, byref=False)
+    pickler._main = _proxy(ns)
+    pickler._original_main = pickler._main
+    pickler._main_modified = True
+    pickler.persistent_id = guard
+    pickler.dump(values)
+    return output.getvalue()
+
+
+def _decode(ns, payload):
+    unpickler = dill.Unpickler(io.BytesIO(payload))
+    unpickler._main = _proxy(ns)
+    unpickler._ignore = True
+    return unpickler.load()
+
+
+def _dependencies(root, ns):
+    """Bounded static global scan; dynamic eval/globals lookups remain best effort."""
+    found, seen = set(), set()
+    def walk(value):
+        if id(value) in seen or isinstance(value, _PRIMITIVES):
+            return
+        seen.add(id(value))
+        if len(seen) > 10000:
+            raise UnsupportedResource('dependency graph exceeds inspection budget')
+        if isinstance(value, types.FunctionType):
+            if value.__globals__ is ns:
+                def code_names(code):
+                    for op in dis.get_instructions(code):
+                        if op.opname in ('LOAD_GLOBAL', 'LOAD_NAME'):
+                            found.add(op.argval)
+                    for item in code.co_consts:
+                        if isinstance(item, types.CodeType): code_names(item)
+                code_names(value.__code__)
+            walk(value.__defaults__)
+            walk(value.__kwdefaults__)
+            for cell in value.__closure__ or ():
+                try: walk(cell.cell_contents)
+                except ValueError: pass
+        elif isinstance(value, (staticmethod, classmethod)):
+            walk(value.__func__)
+        elif isinstance(value, property):
+            walk(value.fget); walk(value.fset); walk(value.fdel)
+        elif isinstance(value, types.MethodType):
+            walk(value.__func__); walk(value.__self__)
+        elif isinstance(value, dict):
+            for key, item in value.items(): walk(key); walk(item)
+        elif isinstance(value, (tuple, list, set, frozenset)):
+            for item in value: walk(item)
+        elif isinstance(value, type):
+            if value.__module__ == ns.get('__name__'):
+                for item in vars(value).values(): walk(item)
+                for base in value.__bases__: walk(base)
+        elif not isinstance(value, types.ModuleType) and type(value).__module__ == ns.get('__name__'):
+            walk(type(value))
+            if hasattr(value, '__dict__'): walk(vars(value))
+    walk(root)
+    return found
+
+
+def _write_new(path, data):
+    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
+    with os.fdopen(fd, 'wb') as output:
+        output.write(data)
+        output.flush()
+        os.fsync(output.fileno())
+
+
+def _emit(sentinel, result):
+    print(sentinel + json.dumps(result, ensure_ascii=True))
+
+
+def save(ns, payload_path, manifest_path, spec_json, sentinel):
+    try:
+        _paths(payload_path, manifest_path)
+        deadline = time.monotonic() + _TIMEOUT
+        def check_deadline():
+            if time.monotonic() >= deadline:
+                raise TimeoutError('checkpoint deadline exceeded; previous generation retained')
+        spec = json.loads(spec_json)
+        cap = min(spec['sizeCapBytes'], _CAP)
+        import better_support
+        candidates = better_support.user_namespace(ns)
+        guard = _guard(ns)
+        kept, omitted, dependencies = {}, {}, {}
+        for name, value in candidates.items():
+            check_deadline()
+            try:
+                _encode(ns, {name: value}, cap, guard)
+                dependencies[name] = _dependencies(value, ns)
+                kept[name] = value
+            except SizeCap:
+                raise
+            except Exception as error:
+                omitted[name] = type(error).__name__ + ': ' + str(error)
+        changed = True
+        while changed:
+            changed = False
+            for name in list(kept):
+                missing = dependencies[name].intersection(omitted)
+                if missing:
+                    omitted[name] = 'depends on omitted globals: ' + ', '.join(sorted(missing))
+                    del kept[name]
+                    changed = True
+        check_deadline()
+        payload = _encode(ns, kept, cap, guard)
+        # Verify the FINAL shared graph, never independently reconstruct values.
+        trial_ns = dict(ns)
+        trial = _decode(trial_ns, payload)
+        if not isinstance(trial, dict) or set(trial) != set(kept):
+            raise ValueError('final graph round-trip changed admitted names')
+        trial_ns.update(trial)
+        groups = {}
+        for name, value in kept.items():
+            if id(value) in groups and trial[name] is not trial[groups[id(value)]]:
+                raise ValueError('final graph round-trip lost shared root identity')
+            groups[id(value)] = name
+        previous = None
+        try:
+            with open(manifest_path, encoding='utf-8') as old:
+                previous = json.load(old).get('payload')
+        except (OSError, ValueError, AttributeError):
+            pass
+        token = uuid.uuid4().hex
+        payload_name = 'state-' + token + '.dill'
+        manifest = dict(_environment(), snapshotFormat=_FORMAT, turn=spec['turn'],
+            payload=payload_name, sizeBytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
+            names=sorted(kept), dependencies={name: sorted(dependencies[name]) for name in kept},
+            bindingNames=sorted(better_support.injected_names()), omitted=omitted, coverage='partial' if omitted else 'best-effort',
+            skipped=False, limitations=['Dynamic globals/eval and arbitrary extension resources cannot be exhaustively inspected.'])
+        _write_new(os.path.join(_DIRECTORY, payload_name), payload)
+        temp = os.path.join(_DIRECTORY, '.checkpoint-' + token + '.tmp')
+        _write_new(temp, json.dumps(manifest, sort_keys=True).encode())
+        # Sole commit point: immutable payload exists before atomic pointer swap.
+        check_deadline()
+        os.replace(temp, manifest_path)
+        if os.name == 'posix':
+            fd = os.open(_DIRECTORY, os.O_RDONLY)
+            try: os.fsync(fd)
+            finally: os.close(fd)
+        # Retain committed + previous payload. Never prune on an unsuccessful save.
+        for old_name in os.listdir(_DIRECTORY):
+            if old_name not in (payload_name, previous) and re.fullmatch(r'(state-[0-9a-f]{32}\.dill|\.checkpoint-[0-9a-f]{32}\.tmp)', old_name):
+                try: os.unlink(os.path.join(_DIRECTORY, old_name))
+                except OSError: pass
+        _emit(sentinel, dict(kind='ok', sizeBytes=len(payload), names=manifest['names'], omitted=omitted, turn=spec['turn']))
+    except SizeCap as error:
+        _emit(sentinel, dict(kind='skipped', reason=str(error), capBytes=_CAP))
+    except Exception as error:
+        _emit(sentinel, dict(kind='failed', reason=type(error).__name__ + ': ' + str(error)))
+
+
+def restore(ns, payload_path, manifest_path, sentinel, bindings_json):
+    try:
+        _paths(payload_path, manifest_path)
+        if os.path.getsize(manifest_path) > 1048576:
+            raise ValueError('manifest exceeds metadata cap')
+        with open(manifest_path, encoding='utf-8') as source:
+            manifest = json.load(source)
+        if not isinstance(manifest, dict) or manifest.get('snapshotFormat') != _FORMAT:
+            raise ValueError('unsupported snapshot format')
+        for key, value in _environment().items():
+            if manifest.get(key) != value: raise ValueError('checkpoint environment mismatch: ' + key)
+        name = manifest.get('payload', '')
+        if not isinstance(name, str) or not re.fullmatch(r'state-[0-9a-f]{32}\.dill', name):
+            raise ValueError('invalid owned payload name')
+        names = manifest.get('names')
+        import better_support
+        if not isinstance(names, list) or any(not isinstance(n, str) or n.startswith('__omp_') or n in ('__name__', '__builtins__', '__doc__') or n in better_support.reserved_names() for n in names):
+            raise ValueError('invalid checkpoint namespace names')
+        turn = manifest.get('turn')
+        if not isinstance(turn, int) or isinstance(turn, bool) or turn < 0:
+            raise ValueError('invalid checkpoint turn')
+        path = os.path.join(_DIRECTORY, name)
+        size = os.path.getsize(path)
+        if os.path.islink(path) or size != manifest.get('sizeBytes') or size > _CAP:
+            raise ValueError('payload size/cap/path validation failed')
+        with open(path, 'rb') as source: payload = source.read(_CAP + 1)
+        if hashlib.sha256(payload).hexdigest() != manifest.get('sha256'):
+            raise ValueError('payload integrity hash mismatch')
+        values = _decode(ns, payload)
+        if not isinstance(values, dict) or sorted(values) != sorted(names):
+            raise ValueError('payload namespace differs from manifest')
+        omitted = dict(manifest.get('omitted', {}))
+        unavailable = set(manifest.get('bindingNames', [])) - set(json.loads(bindings_json))
+        dependencies = manifest.get('dependencies', {})
+        changed = True
+        while changed:
+            changed = False
+            for root in list(values):
+                missing_bindings = set(dependencies.get(root, [])).intersection(unavailable)
+                missing_state = set(dependencies.get(root, [])).intersection(omitted)
+                if missing_bindings or missing_state:
+                    omitted[root] = ('missing current host binding: ' + ', '.join(sorted(missing_bindings))) if missing_bindings else ('depends on omitted globals: ' + ', '.join(sorted(missing_state)))
+                    del values[root]
+                    changed = True
+        ns.update(values)
+        _emit(sentinel, dict(kind='restored', count=len(values), turn=turn, names=names,
+            omitted=omitted))
+    except Exception as error:
+        _emit(sentinel, dict(kind='degraded', reason=type(error).__name__ + ': ' + str(error)))
--- task1/better-dsh/src/omp-python/better_support.py
+++ task2/better-dsh/src/omp-python/better_support.py
@@ -57,14 +57,15 @@
 
 def unsupported_input(*args, **kwargs):
     raise RuntimeError('Interactive stdin is unsupported in Better Python REPL; pass input as a variable or tool argument')
 
 
 def initialize(ns):
     global _STARTED, _WRITER
+    __import__('better_snapshot')  # preload pinned dill before user imports
     if not _STARTED:
         _OWNED.update(ns)
         if not os.environ.get('BETTER_CALLBACK_URL'):
             _WRITER = os.fdopen(3, 'w', encoding='utf-8', buffering=1)
             threading.Thread(target=_read_replies, name='better-callback-replies', daemon=True).start()
         _STARTED = True
     # Do not mutate the runner's Python builtins or put internal imports in user globals.
@@ -77,14 +78,15 @@
     """Required runner compiler seam; Better has no speculative read cache."""
     result = action(args)
     return await result if inspect.isawaitable(result) else result
 
 
 def reset(ns, args):
     """Invoke the native magic, then immediately restore Better capabilities."""
+    __import__('better_snapshot').clear()
     sys.modules['__main__'].__dict__['__omp_magic']('reset', args)
     initialize(ns)
     install_bindings(ns, _SPECS.get())
 
 
 class ResetAdapter(ast.NodeTransformer):
     def visit_Call(self, node):
@@ -406,7 +408,18 @@
             reply = {'ok': True, 'kind': 'repr', 'text': repr(user[name])}
     print(sentinel + json.dumps(reply))
 
 
 def set_var(ns, name, value_json, sentinel):
     ns[name] = json.loads(value_json)
     print(sentinel + json.dumps({'ok': True}))
+
+
+def owned_objects():
+    return list(_OWNED.values()) + list(_INJECTED.values())
+
+def reserved_names():
+    return set(_OWNED) | set(_INJECTED)
+
+
+def injected_names():
+    return set(_INJECTED)
--- task1/better-dsh/src/omp-python/dill-provenance.json
+++ task2/better-dsh/src/omp-python/dill-provenance.json
@@ -0,0 +1,55 @@
+{
+  "version": "0.4.1",
+  "artifact": {
+    "url": "https://files.pythonhosted.org/packages/1e/77/dc8c558f7593132cf8fefec57c4f60c83b16941c574ac5f619abb3ae7933/dill-0.4.1-py3-none-any.whl",
+    "sha256": "1e1ce33e978ae97fcfcff5638477032b801c46c7c65cf717f95fbc2248f79a9d"
+  },
+  "adaptations": "None. Runtime Python sources and BSD-3-Clause license copied unchanged from wheel; tests excluded. Better adapter lives in better_snapshot.py.",
+  "files": {
+    "vendor/dill/__diff.py": {
+      "sha256": "ed70aa5887a54d648b8e278e22edd7b6bd6652e8bd6019a5b4fefeb6fb6b1be4"
+    },
+    "vendor/dill/__info__.py": {
+      "sha256": "106836361f383613e762ad49da3e8400f8b105bde9b15c58fb9ac05b3afca6b9"
+    },
+    "vendor/dill/__init__.py": {
+      "sha256": "63cbac9f3a5fb1c949c53e93bd16066ab117916117a6bbf8942d992746c63366"
+    },
+    "vendor/dill/_dill.py": {
+      "sha256": "35d695c86cce6f94b9eda6d83747855dca20a1c1d0ad306452bbbb72ac367f03"
+    },
+    "vendor/dill/_objects.py": {
+      "sha256": "fd773b3aa9d97ac0e62819ad91b92b041303cc7dd3205cbfbed311b5cee5b122"
+    },
+    "vendor/dill/_shims.py": {
+      "sha256": "92421aee6b961c7a7db88b6935f7ea99b8413b830428f21d7b21ce2b1c76545e"
+    },
+    "vendor/dill/detect.py": {
+      "sha256": "55b0b234c68856e762a8cd672e61b04bec975ba33d0a47696e455aac09a726a5"
+    },
+    "vendor/dill/logger.py": {
+      "sha256": "675c2053c05b48011604aa2e71844762b16154baaaa934e2f811dc7ec79b8bcf"
+    },
+    "vendor/dill/objtypes.py": {
+      "sha256": "de10c49d14b4e34995c80de7309a74b1e222030f5269fc5bbaf1b9b45bed85f1"
+    },
+    "vendor/dill/pointers.py": {
+      "sha256": "cde5fc5ea94b0485bdbcbf971ff7abf475169889e56df5a362dbdae7a7939b0c"
+    },
+    "vendor/dill/session.py": {
+      "sha256": "f3c0c914842b03cef7dcff952a46c2ab47759722737244180ab1b170f79229e1"
+    },
+    "vendor/dill/settings.py": {
+      "sha256": "0d1169d900bcc6ca4f67949bdde201e9a6cfa75c0db8136d0848d9f032d8fb1e"
+    },
+    "vendor/dill/source.py": {
+      "sha256": "1ac9987fa6c43cb33dae2bf3d4473b1b613eb44800a1723de428aca9d7101860"
+    },
+    "vendor/dill/temp.py": {
+      "sha256": "785c8c8192094545607518b66b8236b597798371d25059df9b92b72d5d99f779"
+    },
+    "DILL-LICENSE": {
+      "sha256": "f669d63bebf765baaa0b20d8b0c1193296a7e0ea0c22c50a308b74d76ab3939c"
+    }
+  }
+}
--- task1/better-dsh/src/python.ts
+++ task2/better-dsh/src/python.ts
@@ -26,10 +26,10 @@
   return `__import__('better_support').set_var(globals(), ${JSON.stringify(name)}, ${JSON.stringify(valueJson)}, ${JSON.stringify(sentinel)})`
 }
 
 export function buildSnapshotCell(payloadPath: string, manifestPath: string, spec: SnapshotSpec, sentinel: string): string {
   return `__import__('better_snapshot').save(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(JSON.stringify(spec))}, ${JSON.stringify(sentinel)})`
 }
 
-export function buildRestoreCell(payloadPath: string, manifestPath: string, sentinel: string): string {
-  return `__import__('better_snapshot').restore(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(sentinel)})`
+export function buildRestoreCell(payloadPath: string, manifestPath: string, sentinel: string, bindings: string[] = []): string {
+  return `__import__('better_snapshot').restore(globals(), ${JSON.stringify(payloadPath)}, ${JSON.stringify(manifestPath)}, ${JSON.stringify(sentinel)}, ${JSON.stringify(JSON.stringify(bindings))})`
 }
--- task1/better-dsh/src/runtime.ts
+++ task2/better-dsh/src/runtime.ts
@@ -1,42 +1,19 @@
 /**
- * `DashrRuntime`: DASHR's STATEFUL `ctx.replRuntime` backend (our vendored
- * Service Definition, blueprint v0.5 §7.6), the standing-mount layer of the
- * v0.1.5 architecture — between the profile-level DashrDaemon concept (a v0.1.5
- * empty shell: named, not yet built) and the session-level ipykernel
- * subprocess (a pure Python interpreter with no harness awareness). One
- * instance per standing mount owns a map of one persistent kernel subprocess
- * per SESSION (the run's `principal`) — the upstream "plugins key their
- * state by Session/Agent" model, which the roster's per-mount realm cannot
- * provide on its own (blueprint §7.4.1: an entry-local realm is one instance
- * per MOUNT, and every session joined to a standing mount shares it) — which
- * makes DashrRuntime the DE FACTO daemon today: it listens for `agent/disposed`,
- * keys kernels per session, snapshots them, and dispatches loopback host
- * requests. Each `run()` is exactly one cell on that session's kernel;
- * variables assigned in run N survive into run N+1 (blueprint §1.1 channel ②
- * — state codification, deliberately NOT the per-run isolation the
- * worker-thread backend provides), and two sessions never see each other's
- * variables. Kernels spawn lazily on a key's first run and die with their
- * session (the dsh `agent/disposed` event) or with the plugin. Binding
- * namespaces are materialized kernel-side as callable Python objects whose
- * calls travel back to the host over the `dashr.host` comm target (the PA
- * `host_request()` pattern). This is a capability seam, not a security
- * boundary.
- *
- * M3-B adds the namespace persistence half: turn-end snapshots (size-capped,
- * blueprint §8.3), restore-on-first-boot, and the death→revive chain (§8.3
- * "kernel death 行为链") that respawns onto the nearest replayable snapshot
- * instead of M3-A's fresh-empty respawn.
- * @module dashr-repl/runtime
+ * Stateful Python REPL backed by one owned OMP child per principal.
+ * Whole per-principal transactions serialize boot, restore, cells, queries,
+ * assignments and reset. Completed cells and assignments save best-effort
+ * object graphs; recovery never replays user code or external effects.
  */
 
-import { randomBytes } from 'node:crypto'
-import { existsSync, mkdirSync, readFileSync, rmSync } from 'node:fs'
+import { createHash, randomBytes } from 'node:crypto'
+import { existsSync, mkdirSync, rmSync } from 'node:fs'
 import { join } from 'node:path'
 import { Context } from '@deepseek-ai/cordis'
+import type { ProfileContext } from '@deepseek-ai/dsh-app-boot'
 import z from '#schemastery'
 import { snapshotJsonValue } from './snapshot-json.ts'
 import {
   DUNDER_MEMBER,
   PORTABLE_RESERVED_WORDS,
   RESERVED_BINDING_GLOBALS,
   RESERVED_ERROR_MEMBERS,
@@ -56,62 +33,53 @@
 import { MIN_OUTPUT_BYTES, extractStream, finalizeOutput, plainTraceback } from './output.ts'
 import { resolveKernelEnv } from './kernel-env.ts'
 import type { KernelEnv } from './kernel-env.ts'
 import type { ReplVarQuery } from './runtime-surface.ts'
 
 /** Plugin config: every tunable, changeable from `cordis.yml` (no hardcoded tunables). */
 export interface Config {
-  /** Python interpreter with `ipykernel` installed. The bare sentinel `python3` (or absent) selects a managed venv under {@link Config.kernelEnvDir}. */
+  /** Python >=3.9 interpreter. The bare sentinel `python3` (or absent) selects a managed venv under {@link Config.kernelEnvDir}. */
   python?: string
   /** Budget for kernel spawn → ready, in milliseconds. */
   startupTimeoutMs?: number
   /** Wall budget per run; expiry interrupts the kernel then force-settles. */
   runTimeoutMs?: number
   /** Grace between a timeout/abort interrupt and the force-settle, in milliseconds. */
   interruptGraceMs?: number
   /**
-   * Confirm window between the control-channel interrupt and the SIGALRM
-   * escalation, in milliseconds; must stay below {@link Config.interruptGraceMs}.
+   * Confirm window before repeating SIGINT, in milliseconds; must stay below {@link Config.interruptGraceMs}.
    * See the bridge's two-phase interrupt for why the escalation is deferred.
    */
   interruptConfirmMs?: number
   /** Budget for graceful kernel teardown (shutdown_request → SIGKILL), in milliseconds. */
   disposeTimeoutMs?: number
   /** Budget for internal snapshot/restore cells (dill dump/load), in milliseconds. */
   snapshotTimeoutMs?: number
   /** Hard cap for serialized log-array, completion-value, and failure-message payloads. */
   maxOutputBytes?: number
-  /** Directory for per-session namespace snapshots (`state.dill` + `manifest.json`); none when absent. */
+  /** Per-session immutable checkpoints. Defaults to the official profile home; empty string disables, standalone callers opt in. */
   snapshotDir?: string
-  /** Serialized-size cap for a turn-end snapshot, in bytes; over-cap snapshots are skipped with a one-time model warning. */
+  /** Serialized graph cap in bytes; each over-cap attempt reports the last successful checkpoint. */
   snapshotSizeCapBytes?: number
   /** Managed venv directory (used when `python` is absent/`python3`); defaults to `<package>/.venv-kernel`. */
   kernelEnvDir?: string
   /** Preferred CPython version for a managed venv. */
   kernelPythonVersion?: string
-  /** Provision the managed venv (ipykernel + dill) on first use; default true. */
+  /** Provision a stdlib-only managed venv on first use; default true. */
   kernelAutoInstall?: boolean
   username?: string
 }
 
 /** {@link Config} after schemastery fills the defaults. */
 type ResolvedConfig = Required<Omit<Config, 'snapshotDir' | 'kernelEnvDir' | 'kernelPythonVersion'>> & Pick<Config, 'snapshotDir' | 'kernelEnvDir' | 'kernelPythonVersion'>
 
 const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/
 
-/**
- * Names the kernel-side shim owns (`_dashr`/`__dashr` prefixed, any case —
- * bootstrap helpers plus the per-run `__dashr_completion__` and
- * `__dashr_injected__`), refused as binding globals on top of the seam's
- * shared set.
- */
-const KERNEL_OWNED_NAME = /^_+dashr/i
-
-/** Manifest format version; a snapshot written under a different version is not replayable. */
-const SNAPSHOT_FORMAT = 1
+/** Runner internals and legacy reserved shim prefix are never injectable variables. */
+const KERNEL_OWNED_NAME = /^(?:_+dashr|__omp_)/i
 
 function messageOf(error: unknown): string {
   return error instanceof Error ? error.message : String(error)
 }
 
 /** Key under which the per-session kernel map stores agentless runs. */
 const AGENTLESS_KEY = '(agentless)'
@@ -140,34 +108,25 @@
    * explicit namespace-lost error on respawn.
    */
   ranCells: boolean
   /** How many cells completed on this kernel — the snapshot "turn" counter. */
   turn: number
   /** Turn number of the last successfully written snapshot, when one exists. */
   lastSnapshotTurn?: number
-  /** Whether the one-time snapshot-size-cap warning has been delivered to the model. */
-  warnedSnapshotSkip?: boolean
   /** Whether restore-from-snapshot has been attempted for this entry (once per boot). */
   restoreAttempted?: boolean
   /** One-run notice (restore/degrade outcome) to surface on the next completed run. */
   pendingNotice?: string
 }
 
 /** What `restoreEntry` found and did, for the first-run notice and revive messaging. */
 type RestoreOutcome =
   | { kind: 'none' }
-  | { kind: 'restored', turn: number }
+  | { kind: 'restored', turn: number, omitted: Record<string, string> }
   | { kind: 'degraded', reason: string }
-
-/** Manifest fields the host reads before dispatching the restore cell. */
-interface SnapshotManifest {
-  snapshotFormat?: unknown
-  skipped?: unknown
-  turn?: unknown
-}
 
 /**
  * The {@link ReplRuntime} backend this package registers (`ctx.replRuntime`)
  * — the standing-mount layer of the v0.1.5 architecture, the de facto daemon
  * while the profile-level DashrDaemon stays an empty shell. One service
  * instance per mount holds one lazily-spawned kernel per session principal;
  * each kernel's lifecycle — snapshot and shutdown on session end, snapshot
@@ -195,31 +154,31 @@
   readonly isolation = 'process'
 
   private readonly config: ResolvedConfig
   private readonly logger: ReturnType<Context['logger']>
   /** One entry per session principal that has run code (lazy — never pre-seeded). */
   private readonly kernels = new Map<string, KeyedKernel>()
   private disposed = false
+  private readonly transactions = new Map<string, Promise<unknown>>()
   /** Lazily-resolved (and, when managed, provisioned) kernel interpreter. */
   private kernelEnvPromise: Promise<KernelEnv> | undefined
 
   constructor(ctx: Context, config: Config) {
     super(ctx)
-    this.config = config as ResolvedConfig
+    const profile: ProfileContext | undefined = ctx.get('profileContext')
+    this.config = { ...config, snapshotDir: config.snapshotDir ?? (profile ? join(profile.home, 'better-dsh', 'python-repl', createHash('sha256').update(profile.dir).digest('hex')) : undefined) } as ResolvedConfig
     // Schemastery filled the defaults; the cast records that. Positivity is a
     // semantic check the schema's plain number type does not carry.
     for (const key of ['startupTimeoutMs', 'runTimeoutMs', 'interruptGraceMs', 'disposeTimeoutMs', 'snapshotTimeoutMs'] as const) {
       const value = this.config[key]
       if (!(Number.isFinite(value) && value > 0)) {
         throw new Error(`dashr-repl: config.${key} must be a positive number, got ${String(value)}`)
       }
     }
-    // The SIGALRM escalation must fire strictly inside the force-settle grace,
-    // or it would never get its chance to break a busy cell before the run
-    // resolves.
+    // The repeat SIGINT must fire before the hard cancellation deadline.
     if (!(this.config.interruptConfirmMs > 0 && this.config.interruptConfirmMs < this.config.interruptGraceMs)) {
       throw new Error(`dashr-repl: config.interruptConfirmMs must be positive and below interruptGraceMs (${this.config.interruptGraceMs}), got ${String(this.config.interruptConfirmMs)}`)
     }
     if (!Number.isSafeInteger(this.config.maxOutputBytes) || this.config.maxOutputBytes < MIN_OUTPUT_BYTES) {
       throw new Error(`dashr-repl: config.maxOutputBytes must be a safe integer of at least ${MIN_OUTPUT_BYTES}, got ${String(this.config.maxOutputBytes)}`)
     }
     if (!Number.isSafeInteger(this.config.snapshotSizeCapBytes) || this.config.snapshotSizeCapBytes < 1) {
@@ -265,17 +224,29 @@
    * Execute one program as one cell on the persistent kernel. Program
    * outcomes — including kernel startup failure — resolve with
    * `result.error`; the method rejects only for Service Definition contract
    * misuse (a disposed runtime, an invalid binding namespace).
    * @param request - the program, its bindings, and the abort signal.
    * @returns the run's outcome per the seam contract.
    */
-  async run(request: CodeRunRequest): Promise<CodeRunResult> {
+  private transaction<T>(key: string, operation: () => Promise<T>): Promise<T> {
+    const result = (this.transactions.get(key) ?? Promise.resolve()).catch(() => undefined).then(operation)
+    this.transactions.set(key, result)
+    void result.finally(() => { if (this.transactions.get(key) === result) this.transactions.delete(key) }).catch(() => undefined)
+    return result
+  }
+
+  run(request: CodeRunRequest): Promise<CodeRunResult> {
+    return this.transaction(request.principal || AGENTLESS_KEY, () => this.runTransaction(request))
+  }
+
+  private async runTransaction(request: CodeRunRequest): Promise<CodeRunResult> {
     if (this.disposed) throw new Error('dashr-repl: run() after disposal')
     const bindings = this.validateBindings(request)
+    const bindingNames = request.bindings.flatMap(binding => [binding.global, ...binding.errorClass ? [binding.errorClass.name] : []])
     if (request.signal?.aborted) {
       return { logs: [], error: { kind: 'abort', message: String(request.signal.reason) } }
     }
     const key = request.principal && request.principal.length > 0 ? request.principal : AGENTLESS_KEY
     // reset=true abandons the persistent namespace: dispose the live kernel
     // and clear its on-disk snapshot BEFORE any dead-kernel or reuse logic,
     // so the next ensureKernel spawns a fresh, EMPTY kernel.
@@ -283,24 +254,24 @@
       await this.resetKey(key)
     }
 
     // A kernel that died since this key's last run is never silently reused:
     // its namespace is gone, and executing the program would surface a
     // misleading NameError instead of the substrate truth. The first run to
     // observe the death resolves with the explicit error (M3-B: after
-    // respawning onto the nearest replayable snapshot, so the message can
+    // respawning onto the nearest usable checkpoint, so the message can
     // name the turn) and the NEXT run continues on that restored kernel.
     // A kernel that died before ever completing a cell carried no user state
     // and is simply replaced (a prior SESSION's on-disk snapshot, if any, is
     // still restored by the normal first-boot path below).
     const dead = this.kernels.get(key)
     if (dead?.bridge.isDead) {
       this.kernels.delete(key)
       if (dead.ranCells) {
-        return await this.reviveAfterDeath(key, dead)
+        return await this.reviveAfterDeath(key, dead, false, bindingNames)
       }
     }
 
     let entry: KeyedKernel
     try {
       entry = await this.ensureKernel(key, request.cwd)
     } catch (error: unknown) {
@@ -308,17 +279,17 @@
     }
     // First boot of this entry (fresh session OR resume OR revive): restore
     // the on-disk snapshot before any user code, once per boot. The notice is
     // consumed by the next COMPLETED run's logs, so the model learns where its
     // namespace came from (turn-N restored, or degraded-empty).
     if (!entry.restoreAttempted) {
       entry.restoreAttempted = true
-      const restore = await this.restoreEntry(entry)
+      const restore = await this.restoreEntry(entry, bindingNames)
       if (restore.kind === 'restored') {
-        entry.pendingNotice = `namespace restored from the turn-${restore.turn} snapshot`
+        entry.pendingNotice = `namespace restored from the turn-${restore.turn} snapshot${this.omissionNotice(restore.omitted)}`
       } else if (restore.kind === 'degraded') {
         entry.pendingNotice = `snapshot not replayable (${restore.reason}); started from an EMPTY namespace — re-create any state you need`
       }
     }
     const kernel = entry.bridge
 
     const specs: NamespaceSpecs = Object.fromEntries([...bindings.entries()].map(([global, namespace]) => [global, {
@@ -342,35 +313,24 @@
     } else if (outcome.outcome === 'forced' && outcome.failure.kind === 'worker-exit' && kernel.isDead && !this.disposed) {
       // The substrate died under this run. M3-B unifies this path with the
       // post-death-arrival branch: a kernel that had completed cells revives
       // onto its nearest snapshot and this run reports the turn-N loss; a
       // first-cell death has no state to lose and the run's own worker-exit
       // failure is the whole story.
       if (this.kernels.get(key) === entry) this.kernels.delete(key)
-      if (entry.ranCells) {
-        return await this.reviveAfterDeath(key, entry)
-      }
+      const revived = await this.reviveAfterDeath(key, entry, true, bindingNames)
+      return finalizeOutput(extractStream(outcome.streamText, sentinel).logs, revived.value, revived.error, this.config.maxOutputBytes)
     }
     let result = this.assembleResult(outcome, sentinel)
 
     if (outcome.outcome === 'completed') {
-      // Turn-end snapshot (M3-B, blueprint §8.3): after every successful run,
-      // size-capped. The cap warning is delivered ONCE per kernel to the
-      // model through the run's own logs; the first-run restore notice rides
-      // the same channel. Both are re-finalized so the outer-output cap stays
-      // honest even with the notices appended.
+      // Save completed cells even after user exceptions. Recovery notices
+      // share the same output ledger as user output.
       const snapshot = await this.snapshotTurnEnd(entry)
-      const notices: string[] = []
-      if (snapshot.skipped && !entry.warnedSnapshotSkip) {
-        entry.warnedSnapshotSkip = true
-        const detail = snapshot.estimateBytes !== undefined
-          ? `estimated ${snapshot.estimateBytes} bytes`
-          : `${snapshot.sizeBytes ?? 'unknown'} bytes serialized`
-        notices.push(`[dashr] namespace snapshot skipped: ${detail} exceeds snapshotSizeCapBytes (${this.config.snapshotSizeCapBytes}) — later turn-end snapshots are skipped while the namespace stays this large`)
-      }
+      const notices: string[] = snapshot ? [snapshot] : []
       if (entry.pendingNotice) {
         notices.push(`[dashr] ${entry.pendingNotice}`)
         entry.pendingNotice = undefined
       }
       if (notices.length > 0) {
         result = finalizeOutput([...result.logs, ...notices], result.value, result.error, this.config.maxOutputBytes)
       }
@@ -385,15 +345,18 @@
    * `repr` text, and a missing name to `{ kind: 'missing' }`. When no live
    * kernel holds state for the key the namespace is empty (no spawn — this
    * channel never creates a kernel). Pure additive: the run/execute/snapshot
    * lifecycle is untouched.
    * @param name - the variable name, or empty to list namespace names.
    * @param principal - the session key (absent → the shared default).
    */
-  async queryVar(name: string, principal?: string): Promise<ReplVarQuery> {
+  queryVar(name: string, principal?: string): Promise<ReplVarQuery> {
+    return this.transaction(principal || AGENTLESS_KEY, () => this.queryTransaction(name, principal))
+  }
+  private async queryTransaction(name: string, principal?: string): Promise<ReplVarQuery> {
     if (this.disposed) throw new Error('dashr-repl: queryVar() after disposal')
     const key = principal && principal.length > 0 ? principal : AGENTLESS_KEY
     const bridge = this.kernels.get(key)?.bridge
     if (!bridge || !bridge.isRunning) {
       return name.trim().length === 0 ? { kind: 'names', names: [] } : { kind: 'missing' }
     }
     const outcome: QueryVarOutcome = await bridge.queryVar(name.trim().length === 0 ? null : name)
@@ -417,24 +380,27 @@
    * kernel-shim name); `value` must be lossless JSON. Requires a live kernel
    * for the key — the channel never spawns one, so a session that has not yet
    * run a cell must `run` first. Pure additive to the existing lifecycle.
    * @param name - the identifier to assign under.
    * @param value - the lossless-JSON value to bind.
    * @param principal - the session key (absent → the shared default).
    */
-  async setVar(name: string, value: unknown, principal?: string): Promise<void> {
+  setVar(name: string, value: unknown, principal?: string): Promise<void> {
+    return this.transaction(principal || AGENTLESS_KEY, () => this.setTransaction(name, value, principal))
+  }
+  private async setTransaction(name: string, value: unknown, principal?: string): Promise<void> {
     if (this.disposed) throw new Error('dashr-repl: setVar() after disposal')
     const trimmed = name.trim()
     if (trimmed.length === 0) {
       throw new Error('dashr-repl: setVar() requires a non-empty variable name')
     }
     if (!IDENTIFIER.test(trimmed)) {
       throw new Error(`dashr-repl: setVar() name ${JSON.stringify(trimmed)} is not a usable identifier`)
     }
-    if (KERNEL_OWNED_NAME.test(trimmed)) {
+    if (KERNEL_OWNED_NAME.test(trimmed) || RESERVED_BINDING_GLOBALS.has(trimmed) || trimmed === '__doc__') {
       throw new Error(`dashr-repl: setVar() name ${JSON.stringify(trimmed)} is reserved by the kernel`)
     }
     const jsonValue = snapshotJsonValue(value)
     if (jsonValue === undefined) {
       throw new Error('dashr-repl: setVar() value must be lossless JSON')
     }
     const key = principal && principal.length > 0 ? principal : AGENTLESS_KEY
@@ -442,14 +408,17 @@
     if (!bridge || !bridge.isRunning) {
       throw new Error('dashr-repl: setVar() requires a live kernel for this session — run a cell first')
     }
     const outcome: SetVarOutcome = await bridge.setVar(trimmed, JSON.stringify(jsonValue))
     if (outcome.kind === 'failed') {
       throw new Error(`dashr-repl: setVar(${JSON.stringify(trimmed)}) failed: ${outcome.reason}`)
     }
+    const entry = this.kernels.get(key)!
+    const notice = await this.snapshotTurnEnd(entry)
+    if (notice) entry.pendingNotice = [entry.pendingNotice, notice].filter(Boolean).join('; ')
   }
 
   /** Map one cell outcome onto the seam's result shape under the output ledger. */
   private assembleResult(outcome: CellOutcome, sentinel: string): CodeRunResult {
     const capture = extractStream(outcome.streamText, sentinel)
     const maxBytes = this.config.maxOutputBytes
 
@@ -612,187 +581,143 @@
           python: (await this.resolveKernelPython()).python,
           ...kernelCwd ? { cwd: kernelCwd } : {},
           startupTimeoutMs: this.config.startupTimeoutMs,
           disposeTimeoutMs: this.config.disposeTimeoutMs,
           interruptConfirmMs: this.config.interruptConfirmMs,
           snapshotTimeoutMs: this.config.snapshotTimeoutMs,
           username: this.config.username,
+          snapshotDirectory: this.config.snapshotDir ? join(this.config.snapshotDir, keyDirectoryName(key)) : undefined,
+          snapshotSizeCapBytes: this.config.snapshotSizeCapBytes,
         }),
         ranCells: false,
         turn: 0,
       }
       this.kernels.set(key, entry)
     }
+    if (this.disposed) { await entry.bridge.dispose(); throw new Error('runtime disposed during startup') }
     await entry.bridge.start()
     return entry
   }
 
-  /**
-   * Restore a key's on-disk snapshot into a freshly booted kernel, when one
-   * exists and its manifest is plausible. Called once per entry boot. The
-   * kernel-side restore cell performs the authoritative environment checks
-   * (python version, interpreter identity, skills); this method only gates on
-   * the manifest the host can read cheaply, then records the turn so the
-   * first-run notice and the revive chain can name it.
-   */
-  private async restoreEntry(entry: KeyedKernel): Promise<RestoreOutcome> {
+  /** Restore once before user admission; any degraded load retires that child. */
+  private async restoreEntry(entry: KeyedKernel, bindingNames: string[]): Promise<RestoreOutcome> {
     if (!this.config.snapshotDir) return { kind: 'none' }
     const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
-    const payloadPath = join(dir, 'state.dill')
     const manifestPath = join(dir, 'manifest.json')
-    const manifest = this.readSnapshotManifest(entry.key)
-    if (manifest === undefined) return { kind: 'none' }
-    if (manifest.snapshotFormat !== SNAPSHOT_FORMAT) {
-      return { kind: 'degraded', reason: `snapshot format ${String(manifest.snapshotFormat)} is not replayable` }
-    }
-    if (manifest.skipped === true) return { kind: 'none' }
-    if (!existsSync(payloadPath)) return { kind: 'degraded', reason: 'snapshot payload is missing' }
-    const restored = await entry.bridge.restoreState(payloadPath, manifestPath)
+    if (!existsSync(manifestPath)) return { kind: 'none' }
+    const restored = await entry.bridge.restoreState(join(dir, 'state.dill'), manifestPath, bindingNames)
     if (restored.kind === 'restored') {
-      entry.turn = typeof manifest.turn === 'number' && Number.isSafeInteger(manifest.turn) && manifest.turn >= 0 ? manifest.turn : 0
-      entry.lastSnapshotTurn = entry.turn
+      entry.turn = restored.turn
+      entry.lastSnapshotTurn = restored.turn
       entry.ranCells = true
-      return { kind: 'restored', turn: entry.turn }
-    }
+      return { kind: 'restored', turn: restored.turn, omitted: restored.omitted }
+    }
+    // A malicious/failed reducer can mutate globals before failing. Retire the
+    // whole attempted interpreter before admitting any user cell.
+    await entry.bridge.dispose()
+    this.kernels.delete(entry.key)
+    const fresh = await this.ensureKernel(entry.key, entry.cwd)
+    entry.bridge = fresh.bridge
+    this.kernels.set(entry.key, entry)
     return { kind: 'degraded', reason: restored.reason }
   }
 
-  /** Read the per-key manifest's host-relevant fields; absent when unreadable/missing. */
-  private readSnapshotManifest(key: string): SnapshotManifest | undefined {
-    if (!this.config.snapshotDir) return undefined
-    try {
-      const manifest = JSON.parse(readFileSync(join(this.config.snapshotDir, keyDirectoryName(key), 'manifest.json'), 'utf8')) as SnapshotManifest
-      return manifest
-    } catch {
-      return undefined
-    }
-  }
-
-  /**
-   * Revive one session's kernel after death: respawn a fresh kernel, restore
-   * the nearest replayable snapshot onto it (the normal restore path), and
-   * return the death-observing run's explicit error naming the turn. When no
-   * replayable snapshot exists the message falls back to M3-A's fresh-empty
-   * contract. The run itself does NOT execute — an error that lies about a
-   * NameError costs the model more than one dropped cell (blueprint §8.3).
-   * @param key - the run principal.
-   * @param dead - the entry that died (its `turn` is the last completed turn).
-   */
-  private async reviveAfterDeath(key: string, dead: KeyedKernel): Promise<CodeRunResult> {
+  private omissionNotice(omitted: Record<string, string>): string {
+    const entries = Object.entries(omitted)
+    return entries.length ? `; partial coverage, omitted ${entries.map(([name, reason]) => `${name} (${reason})`).join(', ')}` : ''
+  }
+
+  /** Restore a fresh child and report whether the observing call had started. */
+  private async reviveAfterDeath(key: string, dead: KeyedKernel, started: boolean, bindingNames: string[]): Promise<CodeRunResult> {
     let entry: KeyedKernel
     try {
       entry = await this.ensureKernel(key, dead.cwd)
     } catch (error: unknown) {
       return finalizeOutput([], undefined, {
         kind: 'worker-exit',
         message: `kernel died and respawn failed (${messageOf(error)}); the next run will retry a fresh kernel`,
       }, this.config.maxOutputBytes)
     }
     entry.restoreAttempted = true
-    const restore = await this.restoreEntry(entry)
-    const observingTurn = dead.turn + 1
+    const restore = await this.restoreEntry(entry, bindingNames)
+    entry.turn = Math.max(entry.turn, dead.turn)
+    const execution = started
+      ? 'This cell may have executed partially, including external side effects; inspect their state before choosing any retry. No user code was replayed.'
+      : 'This observing call did not execute. No user code was replayed.'
     if (restore.kind === 'restored') {
-      const lost = observingTurn - restore.turn
-      const rounds = lost === 1 ? 'round' : 'rounds'
       return finalizeOutput([], undefined, {
         kind: 'worker-exit',
-        message: `the kernel for this session died; its namespace was restored from the turn-${restore.turn} snapshot — the last ${lost} ${rounds} of variable operations must be replayed. This run did not execute.`,
+        message: `the kernel for this session died; its namespace was restored from the turn-${restore.turn} snapshot${this.omissionNotice(restore.omitted)}. Changes after that checkpoint may be lost. ${execution}`,
       }, this.config.maxOutputBytes)
     }
     const detail = restore.kind === 'degraded' ? ` (${restore.reason})` : ''
     return finalizeOutput([], undefined, {
       kind: 'worker-exit',
-      message: `the kernel for this session died and no replayable snapshot was available${detail}; the next run starts a fresh kernel with an EMPTY namespace — re-create any state you still need. This run did not execute.`,
+      message: `the kernel for this session died and no usable snapshot was available${detail}; the next run uses an EMPTY namespace. ${execution}`,
     }, this.config.maxOutputBytes)
   }
 
-  /**
-   * Write one key's turn-end snapshot, when a snapshot directory is
-   * configured. A size-cap skip is reported (so the run can warn the model
-   * once); other failures log without disturbing the run.
-   */
-  private async snapshotTurnEnd(entry: KeyedKernel): Promise<{ skipped: boolean, estimateBytes?: number, sizeBytes?: number }> {
-    if (!this.config.snapshotDir) return { skipped: false }
-    const kernel = entry.bridge
-    if (!kernel.isRunning) return { skipped: false }
+  /** Save completed mutations and expose partial/failed coverage within output limits. */
+  private async snapshotTurnEnd(entry: KeyedKernel): Promise<string | undefined> {
+    if (!this.config.snapshotDir || !entry.bridge.isRunning || this.disposed) return
     const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
-    mkdirSync(dir, { recursive: true })
+    mkdirSync(dir, { recursive: true, mode: 0o700 })
     const spec: SnapshotSpec = { turn: entry.turn, skills: [], sizeCapBytes: this.config.snapshotSizeCapBytes }
-    const outcome = await kernel.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
+    const outcome = await entry.bridge.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
     if (outcome.kind === 'ok') {
-      entry.lastSnapshotTurn = entry.turn
-      return { skipped: false }
-    }
-    if (outcome.kind === 'skipped') {
-      return { skipped: true, ...outcome.estimateBytes !== undefined ? { estimateBytes: outcome.estimateBytes } : {}, ...outcome.sizeBytes !== undefined ? { sizeBytes: outcome.sizeBytes } : {} }
-    }
-    this.logger.warn(`turn-end snapshot for ${JSON.stringify(entry.key)} failed: ${outcome.reason}`)
-    return { skipped: false }
-  }
-
-  /**
-   * Dispose to quiescence: snapshot every live key's namespace when a
-   * snapshot directory is configured (each under its own per-key
-   * subdirectory), then shut the subprocesses down. Registered as the
-   * plugin's `ctx.effect` disposer.
-   */
+      entry.lastSnapshotTurn = outcome.turn
+      const omission = this.omissionNotice(outcome.omitted)
+      return omission ? `[dashr] turn-${outcome.turn} checkpoint saved${omission}` : undefined
+    }
+    const latest = entry.lastSnapshotTurn === undefined ? 'no successful checkpoint available' : `latest successful checkpoint is turn-${entry.lastSnapshotTurn}`
+    return `[dashr] namespace snapshot ${outcome.kind === 'skipped' ? 'skipped' : 'failed'}: ${outcome.reason}; ${latest}`
+  }
+
+  /** Cancel active work, drain admitted transactions, and reap every owned child. */
   private async teardown(): Promise<void> {
     this.disposed = true
-    const entries = [...this.kernels.values()]
+    // Cancel active children before draining transactions, so disposal never
+    // waits for a user cell's full timeout. Completed mutations already save.
+    await Promise.all([...this.kernels.values()].map(entry => entry.bridge.dispose()))
+    await Promise.allSettled([...this.transactions.values()])
+    await Promise.all([...this.kernels.values()].map(entry => entry.bridge.dispose()))
     this.kernels.clear()
-    await Promise.all(entries.map(entry => this.teardownKernel(entry)))
   }
 
   /**
    * Tear one session's kernel down (session end via the `agent/disposed`
    * listener). A no-op for keys that never ran code through this instance —
    * which is what makes hearing every agent's disposal safe.
    */
   private async destroyKey(key: string): Promise<void> {
-    const entry = this.kernels.get(key)
-    if (!entry) return
-    this.kernels.delete(key)
-    await this.teardownKernel(entry)
-  }
+    await this.kernels.get(key)?.bridge.dispose()
+    await this.transaction(key, async () => {
+      const entry = this.kernels.get(key)
+      this.kernels.delete(key)
+      await entry?.bridge.dispose()
+    })
+  }
+
   /**
    * Reset one session's kernel to a fresh, empty namespace: dispose the live
    * subprocess WITHOUT a turn-end snapshot and clear its on-disk snapshot, so
-   * the next ensureKernel spawns empty (restore finds nothing to replay).
+   * the next ensureKernel spawns empty (restore finds no checkpoint).
    */
   private async resetKey(key: string): Promise<void> {
     const entry = this.kernels.get(key)
     if (entry) {
       this.kernels.delete(key)
       await entry.bridge.dispose()
     }
     if (this.config.snapshotDir) {
       rmSync(join(this.config.snapshotDir, keyDirectoryName(key)), { recursive: true, force: true })
     }
   }
 
-  /** Snapshot (when configured) then dispose one key's kernel; failures log, never throw into a listener. */
-  private async teardownKernel(entry: KeyedKernel): Promise<void> {
-    const kernel = entry.bridge
-    if (this.config.snapshotDir && kernel.isRunning) {
-      try {
-        // Per-key subdirectory: sessions sharing one snapshotDir must not
-        // overwrite each other's state.dill.
-        const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
-        mkdirSync(dir, { recursive: true })
-        const spec: SnapshotSpec = { turn: entry.turn, skills: [], sizeCapBytes: this.config.snapshotSizeCapBytes }
-        const saved = await kernel.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
-        if (saved.kind !== 'ok' && saved.kind !== 'skipped') {
-          this.logger.warn(`kernel namespace snapshot for ${JSON.stringify(entry.key)} failed: ${saved.reason}`)
-        }
-      } catch (error: unknown) {
-        this.logger.warn(`kernel namespace snapshot for ${JSON.stringify(entry.key)} failed: ${messageOf(error)}`)
-      }
-    }
-    await kernel.dispose()
-  }
+
 }
 
 export default DashrRuntime
 
 /**
  * The vendored Service Definition's public contract, re-exported from the
  * package root so consumers (the sibling presentation package, its drift
--- task1/better-dsh/test/helpers.ts
+++ task2/better-dsh/test/helpers.ts
@@ -1,7 +1,8 @@
+import assert from 'node:assert/strict'
 import { existsSync } from 'node:fs'
 import { fileURLToPath } from 'node:url'
 import { Context } from '@deepseek-ai/cordis'
 import { onTestFinished } from 'vitest'
 import { DashrRuntime } from '../src/index.ts'
 import type { Config } from '../src/index.ts'
 
@@ -12,18 +13,24 @@
 
 /** Boot a fresh context with the eval provider mounted, worker-thread test style. */
 export async function setupRuntime(config: Config = {}): Promise<{ fiber: Awaited<ReturnType<Context['plugin']>>, runtime: DashrRuntime }> {
   const ctx = new Context()
   const fiber = await ctx.plugin(DashrRuntime, { python: KERNEL_PYTHON, ...config })
   const runtime = ctx.replRuntime as DashrRuntime
   // Dispose even when a spec forgets to: kernel children are not killed with
-  // the worker process, so an undisposed fiber leaks an idle ipykernel
+  // the worker process, so an undisposed fiber leaks an idle OMP
   // subprocess forever (208 leaked orphans were found mid-project). Double
   // disposal is safe — the fiber disposer is single-shot.
-  onTestFinished(() => fiber.dispose())
+  onTestFinished(async () => {
+    const ownedPids = runtime.kernelPids
+    await fiber.dispose()
+    for (const pid of ownedPids) {
+      assert.throws(() => process.kill(pid, 0), { code: 'ESRCH' }, `owned OMP child ${pid} survived disposal`)
+    }
+  })
   return { fiber, runtime }
 }
 
 import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
 import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
 import type { ToolExecutionResult } from '@deepseek-ai/dsh-tools'
 import { toolCallId } from '../src/tool-call-id.ts'
@@ -83,15 +90,15 @@
   const ctx = new Context()
   await ctx.plugin(SystemPrompt, {})
   await ctx.plugin(ToolRuntime, {})
   if (runtime !== false) {
     const runtimeFiber = await runtime(ctx)
     // The runtime service (a real kernel provider owns a subprocess) must be
     // torn down with the test: its fiber disposer snapshots/shuts the kernel
-    // down, and skipping it leaks an ipykernel_launcher orphan (§10.9).
+    // down, and skipping it leaks an OMP runner orphan (§10.9).
     if (runtimeFiber && typeof (runtimeFiber as { dispose?: unknown }).dispose === 'function') {
       onTestFinished(async () => { await (runtimeFiber as { dispose(): Promise<void> }).dispose() })
     }
   }
 
   // A host fiber that injects the registry services, so contexts derived
   // from it may address `ctx.tools` / `ctx.systemPrompt` as properties (the
@@ -142,15 +149,15 @@
 }
 
 /**
  * Boot the same composition with the REAL kernel provider (M1's
  * `DashrRuntime` from `dashr-repl`). One kernel boots
  * per test; the fiber's registered disposer shuts it down
  * (`onTestFinished`), and the acceptance gate asserts no orphan
- * `ipykernel_launcher` processes remain (blueprint §10.9).
+ * `OMP runner` processes remain (blueprint §10.9).
  */
 export async function setupKernel(
   presentationConfig: Config = {},
   kernelConfig: import('../src/runtime.ts').Config = {},
 ): Promise<Harness> {
   const { DashrRuntime } = await import('../src/runtime.ts')
   return setupPresentation(async (ctx) => ctx.plugin(DashrRuntime, {
--- task1/better-dsh/test/lifecycle.spec.ts
+++ task2/better-dsh/test/lifecycle.spec.ts
@@ -60,15 +60,15 @@
     await runtime.run({ program: 'x = 40 + 2\npayload = {"kept": True}', bindings: [] })
     await fiber.dispose()
 
     // M3-A: snapshots are per-session — one subdirectory per kernel key
     // (this test's runs carry no principal, so the agentless default key).
     const keyDir = join(snapshotDir, '(agentless)')
     const manifestPath = join(keyDir, 'manifest.json')
-    expect(existsSync(join(keyDir, 'state.dill'))).toBe(true)
+    expect(existsSync(join(keyDir, JSON.parse(readFileSync(join(keyDir, 'manifest.json'), 'utf8')).payload))).toBe(true)
     expect(existsSync(manifestPath)).toBe(true)
     const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as { names: string[], pythonVersion: string }
     expect(manifest.names).toContain('x')
     expect(manifest.names).toContain('payload')
     expect(manifest.names).not.toContain('__dashr_program__')
     // IPython's own session plumbing (whose object graph is unpicklable) and
     // the shim names stay out of the snapshot — user state only.
--- task1/better-dsh/test/omp-checkpoint-safety.spec.ts
+++ task2/better-dsh/test/omp-checkpoint-safety.spec.ts
@@ -0,0 +1,205 @@
+import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, symlinkSync, writeFileSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { createHash } from 'node:crypto'
+import { Context } from '@deepseek-ai/cordis'
+import type { ProfileContext } from '@deepseek-ai/dsh-app-boot'
+import { describe, expect, it, onTestFinished } from 'vitest'
+import { DashrRuntime } from '../src/runtime.ts'
+import { KERNEL_PYTHON, setupRuntime } from './helpers.ts'
+
+function directory() {
+  const dir = mkdtempSync(join(tmpdir(), 'better-checkpoint-safety-'))
+  onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+  return dir
+}
+function manifest(dir: string) { return JSON.parse(readFileSync(join(dir, 's', 'manifest.json'), 'utf8')) }
+const request = (program: string) => ({ program, principal: 's', bindings: [] })
+
+describe('checkpoint safety and truthful outcomes', () => {
+  it('omits captured proxies and transitive missing globals but permits fresh global tools', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    const bindings = [{ global: 'tool', callable: true as const, functions: { call: async () => 'old' } }]
+    const save = await first.runtime.run({ ...request([
+      'good = [1]', 'alias = good', 'class Bad:', '    def __reduce__(self): raise TypeError("bad value")',
+      'bad = Bad()', 'dependent = lambda: bad', 'indirect = lambda: dependent()',
+      'class Getter:', '    def get(self): return bad', 'getter = Getter()',
+      'def capture(value): return lambda: value', 'captured = capture(tool)',
+      'fresh = lambda: tool({})', '_user_private = 7',
+    ].join('\n')), bindings })
+    expect(save.error).toBeUndefined()
+    expect(save.logs.join('\n')).toMatch(/partial.*bad/s)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run({ ...request('[good is alias, await fresh(), _user_private, "dependent" in globals(), "indirect" in globals(), "getter" in globals(), "captured" in globals()]'), bindings: [{ ...bindings[0]!, functions: { call: async () => 'fresh' } }] })
+    expect(result.error).toBeUndefined()
+    expect(result.value).toEqual([true, 'fresh', 7, false, false, false, false])
+    const names = await second.runtime.queryVar('', 's')
+    expect(names.kind).toBe('names')
+    if (names.kind === 'names') expect(names.names).not.toEqual(expect.arrayContaining(['tool', '__omp_with_call_site__']))
+  })
+
+  it.each(['manifest', 'payload', 'environment'])('rejects corrupt %s before restoring and stays usable', async mode => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 9'))
+    await first.fiber.dispose()
+    const m = manifest(snapshotDir)
+    if (mode === 'manifest') writeFileSync(join(snapshotDir, 's', 'manifest.json'), '{broken')
+    else if (mode === 'payload') writeFileSync(join(snapshotDir, 's', m.payload), 'broken')
+    else { m.pythonVersion = '0.0.0'; writeFileSync(join(snapshotDir, 's', 'manifest.json'), JSON.stringify(m)) }
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('"kept" in globals()'))
+    expect(result.error).toBeUndefined()
+    expect(result.value).toBe(false)
+    expect(result.logs.join('\n')).toMatch(/snapshot.*(failed|not replayable|unavailable)/i)
+  })
+
+  it('retains the previous generation on cap and serialization timeout', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir, snapshotSizeCapBytes: 5000, snapshotTimeoutMs: 300 })
+    await first.runtime.run(request('kept = 11'))
+    const committed = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const cap = await first.runtime.run(request('huge = "x" * 20000'))
+    expect(cap.logs.join('\n')).toMatch(/snapshot.*skipped/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(committed)
+    const slow = await first.runtime.run(request('del huge\nimport time\nclass Slow:\n    def __reduce__(self):\n        time.sleep(5)\n        return (int, (3,))\nslow = Slow()'))
+    expect(slow.logs.join('\n')).toMatch(/snapshot.*failed/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(committed)
+    expect((await first.runtime.queryVar('kept', 's')).kind).toBe('json')
+    process.kill(first.runtime.kernelPids[0]!, 'SIGKILL')
+    const second = await setupRuntime({ snapshotDir })
+    expect((await second.runtime.run(request('kept'))).value).toBe(11)
+  })
+
+  it('raw reset removes prior generations and preserves callable helpers', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('old = 1'))
+    const old = manifest(snapshotDir).payload
+    const result = await runtime.run(request('%reset\nnew = 2'))
+    expect(result.error).toBeUndefined()
+    expect(existsSync(join(snapshotDir, 's', old))).toBe(false)
+    expect((await runtime.queryVar('', 's'))).toEqual({ kind: 'names', names: ['new'] })
+    expect(manifest(snapshotDir).names).toEqual(['new'])
+    expect(statSync(join(snapshotDir, 's')).mode & 0o777).toBe(0o700)
+    for (const name of readdirSync(join(snapshotDir, 's'))) expect(statSync(join(snapshotDir, 's', name)).mode & 0o777).toBe(0o600)
+  })
+
+  it('does not replay or deny a side effect performed by the dying cell', async () => {
+    const snapshotDir = directory()
+    const marker = join(snapshotDir, 'side-effect.txt')
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('kept = 17'))
+    const died = await runtime.run(request(`import os\nwith open(${JSON.stringify(marker)}, "a") as output:\n    output.write("once")\nprint("side effect written", flush=True)\nos._exit(1)`))
+    expect(died.error?.kind).toBe('worker-exit')
+    expect(died.logs).toContain('side effect written')
+    expect(died.error?.message).toMatch(/may have executed|partially executed/)
+    expect(died.error?.message).not.toMatch(/must be replayed|did not execute/)
+    expect(readFileSync(marker, 'utf8')).toBe('once')
+    expect((await runtime.run(request('kept'))).value).toBe(17)
+    expect(readFileSync(marker, 'utf8')).toBe('once')
+  })
+
+  it('refuses an aggregate graph failure without replacing the checkpoint', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('kept = 23'))
+    const previous = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const result = await runtime.run(request('class Unstable:\n    calls = 0\n    def __reduce__(self):\n        type(self).calls += 1\n        if type(self).calls > 1: raise ValueError("aggregate failure")\n        return (int, (4,))\nunstable = Unstable()'))
+    expect(result.logs.join(' ')).toMatch(/snapshot failed.*aggregate failure/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(previous)
+  })
+
+  it('retains the checkpoint even when a reducer catches its timeout interrupt', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir, snapshotTimeoutMs: 300 })
+    await runtime.run(request('kept = 29'))
+    const previous = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const result = await runtime.run(request('import time\nclass Slow:\n    def __reduce__(self):\n        try: time.sleep(0.4)\n        except KeyboardInterrupt: pass\n        return (int, (4,))\nslow = Slow()'))
+    expect(result.logs.join(' ')).toMatch(/snapshot failed/)
+    expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(previous)
+  })
+
+  it('rejects internal setVar names while retaining genuine private user names', async () => {
+    const { runtime } = await setupRuntime()
+    await runtime.run(request('value = 1'))
+    for (const name of ['__name__', '__builtins__', '__omp_magic']) {
+      await expect(runtime.setVar(name, 7, 's')).rejects.toThrow(/reserved/)
+    }
+    await runtime.setVar('_private', 9, 's')
+    expect(await runtime.queryVar('', 's')).toEqual({ kind: 'names', names: ['_private', 'value'] })
+    expect((await runtime.run(request('value + _private'))).value).toBe(10)
+  })
+
+  it('retains at most two immutable generations after successful commits', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    for (let n = 0; n < 5; n++) await runtime.run(request(`kept = ${n}`))
+    const files = readdirSync(join(snapshotDir, 's')).filter(name => name.endsWith('.dill'))
+    expect(files).toHaveLength(2)
+    expect(files).toContain(manifest(snapshotDir).payload)
+  })
+
+  it('rejects a symlinked manifest instead of importing another session', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 1'))
+    await first.fiber.dispose()
+    const outside = join(snapshotDir, 'external.json')
+    const path = join(snapshotDir, 's', 'manifest.json')
+    writeFileSync(outside, readFileSync(path))
+    rmSync(path)
+    symlinkSync(outside, path)
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('"kept" in globals()'))
+    expect(result.value).toBe(false)
+    expect(result.logs.join(' ')).toMatch(/symlink/)
+  })
+
+  it('reports missing current host bindings when restoring dependent functions', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run({ ...request('fresh = lambda: tool({})'), bindings: [{ global: 'tool', callable: true, functions: { call: async () => 1 } }] })
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('"fresh" in globals()'))
+    expect(result.value).toBe(false)
+    expect(result.logs.join(' ')).toMatch(/missing.*binding.*tool/)
+  })
+
+  it('serializes queries, assignments and reset around an active cell', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    const running = runtime.run(request('import asyncio\nx = 1\nawait asyncio.sleep(0.05)\nx = 2'))
+    const queried = runtime.queryVar('x', 's')
+    const assigned = runtime.setVar('x', 3, 's')
+    const reset = runtime.run({ ...request('"x" in globals()'), reset: true })
+    expect((await running).error).toBeUndefined()
+    expect(await queried).toEqual({ kind: 'json', text: '2' })
+    await assigned
+    expect((await reset).value).toBe(false)
+    expect((await runtime.queryVar('x', 's')).kind).toBe('missing')
+  })
+
+  it('uses official profile home and respects explicit disable', async () => {
+    const home = directory()
+    const profileDir = join(home, 'profiles', 'work')
+    const root = join(home, 'better-dsh', 'python-repl', createHash('sha256').update(profileDir).digest('hex'))
+    const ctx = new Context()
+    const profile = { home, dir: profileDir, name: 'work', patchPath: join(profileDir, 'cordis.patch.yml'), installAnchor: profileDir, cwd: home, startedBundles: [], overlays: [], telemetryDisabledEnv: '1' } satisfies ProfileContext
+    ctx.provide('profileContext', profile)
+    const fiber = await ctx.plugin(DashrRuntime, { python: KERNEL_PYTHON })
+    onTestFinished(() => fiber.dispose())
+    await ctx.replRuntime.run(request('kept = 1'))
+    expect(existsSync(join(root, 's', 'manifest.json'))).toBe(true)
+    await fiber.dispose()
+    const disabled = new Context()
+    disabled.provide('profileContext', profile)
+    const other = await disabled.plugin(DashrRuntime, { python: KERNEL_PYTHON, snapshotDir: '' })
+    onTestFinished(() => other.dispose())
+    const result = await disabled.replRuntime.run(request('"kept" in globals()'))
+    expect(result.value).toBe(false)
+  })
+})
--- task1/better-dsh/test/session-keys.spec.ts
+++ task2/better-dsh/test/session-keys.spec.ts
@@ -169,15 +169,15 @@
     await runtime.run({ program: 'y = "b"', bindings: [], principal: 'sess-snap-b' })
     // Dispose deterministically (the onTestFinished disposer is idempotent)
     // so the per-key artifacts exist when this test reads them.
     await fiber.dispose()
 
     for (const [key, marker] of [['sess-snap-a', 'x'], ['sess-snap-b', 'y']] as const) {
       const dir = join(snapshotDir, key)
-      expect(existsSync(join(dir, 'state.dill'))).toBe(true)
+      expect(existsSync(join(dir, JSON.parse(readFileSync(join(dir, 'manifest.json'), 'utf8')).payload))).toBe(true)
       const manifest = JSON.parse(readFileSync(join(dir, 'manifest.json'), 'utf8')) as { names: string[] }
       expect(manifest.names).toContain(marker)
     }
   }, 30_000)
 })
 
 describe('DashrRuntime — per-session kernel cwd', () => {
--- task1/better-dsh/test/snapshot-restore.spec.ts
+++ task2/better-dsh/test/snapshot-restore.spec.ts
@@ -59,17 +59,16 @@
     const manifestPath = join(snapshotDir, 'dashr-agent', 'manifest.json')
     expect(existsSync(manifestPath)).toBe(true)
     const manifest = JSON.parse(readFileSync(manifestPath, 'utf8')) as ManifestShape
     expect(manifest.skipped).toBe(false)
     expect(manifest.turn).toBe(1)
     // USER state is captured...
     for (const name of ['kept', 'math', 'handle']) expect(manifest.names).toContain(name)
-    // ...alongside the flat binding surface itself (dill captures the
-    // callable proxies and the error class — plain non-shim globals).
-    for (const name of ['tool', 'ToolCallError']) expect(manifest.names).toContain(name)
+    // Host proxies are recreated on the fresh runtime, never persisted.
+    for (const name of ['tool', 'ToolCallError']) expect(manifest.names).not.toContain(name)
     // The pre-0.1.5 holder name and the deleted rlm_await are gone.
     for (const name of ['tools', 'rlm_await']) expect(manifest.names).not.toContain(name)
     // No flat tool global ever leaks: every tool (native or bridged) is a
     // member of the `tool` object, never a top-level namespace name.
     for (const name of ['subagent', 'send_message', 'workflow']) expect(manifest.names).not.toContain(name)
     // The exclusion semantics still hold around them: no dashr shim name
     // (the `_dashr`/`__dashr` prefix rule, any case) and none of IPython's
--- task1/better-dsh/test/snapshot-revive.spec.ts
+++ task2/better-dsh/test/snapshot-revive.spec.ts
@@ -5,15 +5,15 @@
 import { setupRuntime } from './helpers.ts'
 
 /**
  * M3-B namespace persistence (blueprint §8): turn-end size-capped snapshots,
  * restore-on-first-boot, and the death→revive chain that respawns onto the
  * nearest replayable snapshot. Real kernels throughout; every provider is
  * disposed through the helper's onTestFinished hook, and the orphan gate
- * (`pgrep ipykernel_launcher`) runs after the suite.
+ * verifies only owned OMP runner PIDs; production processes are untouched.
  */
 
 const snapshotDirs: string[] = []
 
 afterEach(() => {
   for (const dir of snapshotDirs.splice(0)) {
     rmSync(dir, { recursive: true, force: true })
@@ -102,35 +102,36 @@
     expect(await waitFor(() => !isAlive(deadPid), 5_000)).toBe(true)
 
     // The death-observing run does NOT execute: it respawns onto the turn-2
     // snapshot and reports the one lost round (turn 3 - turn 2).
     const observed = await runtime.run({ program: 'print("never")', bindings: [], principal: 'sess-revive' })
     expect(observed.error?.kind).toBe('worker-exit')
     expect(observed.error?.message).toContain('restored from the turn-2 snapshot')
-    expect(observed.error?.message).toContain('1 round')
+    expect(observed.error?.message).toContain('This observing call did not execute')
+    expect(observed.error?.message).not.toContain('must be replayed')
 
     // The next run executes on the restored namespace: both a and b survive.
     const revived = await runtime.run({ program: 'print(a + b)', bindings: [], principal: 'sess-revive' })
     expect(revived.error).toBeUndefined()
     expect(revived.logs).toContain('3')
     expect(runtime.kernelPids[0]).not.toBe(deadPid)
   }, 30_000)
 
-  it('skips an over-cap turn-end snapshot and warns the model exactly once', async () => {
+  it('skips an over-cap turn-end snapshot and reports each over-cap attempt and keeps the previous generation', async () => {
     const snapshotDir = mkdtempSync(join(tmpdir(), 'dashr-snapshot-'))
     snapshotDirs.push(snapshotDir)
     const { runtime } = await setupRuntime({ snapshotDir, snapshotSizeCapBytes: 10_000 })
 
     // ~50KB of string is estimated over the 10KB cap before any dill IO.
     const first = await runtime.run({ program: 'big = "x" * 50000', bindings: [] })
     expect(first.error).toBeUndefined()
     expect(first.logs.some(line => line.includes('namespace snapshot skipped'))).toBe(true)
     // Skipped snapshots never replace a previous good one — there was none.
     expect(existsSync(join(snapshotDir, '(agentless)', 'manifest.json'))).toBe(false)
     expect(existsSync(join(snapshotDir, '(agentless)', 'state.dill'))).toBe(false)
 
-    // The warning is one-time: a second over-cap run skips silently.
+    // Every failed attempt exposes current recovery coverage.
     const second = await runtime.run({ program: 'big2 = "y" * 50000', bindings: [] })
     expect(second.error).toBeUndefined()
-    expect(second.logs.some(line => line.includes('namespace snapshot skipped'))).toBe(false)
+    expect(second.logs.some(line => line.includes('namespace snapshot skipped'))).toBe(true)
   }, 30_000)
 })

```
