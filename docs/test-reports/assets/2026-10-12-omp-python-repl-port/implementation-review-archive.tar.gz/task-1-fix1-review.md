# Task 1 fix round 1 — scoped re-review

Date: 2026-10-12. Scope: original findings R1–R4 and new breakage in their fixes only. Read the prior review, fix review package, current support/copier/tests, implementation-report appendices, and the named focused validation logs. The final caught-interrupt correction was inspected directly in current source after the initial package was prepared.

**Spec verdict: PASS for this Task 1 fix round.**

**Code-quality verdict: PASS for this Task 1 fix round.**

All four findings are **ADDRESSED**. No new actionable blocker was identified in the fixes. These verdicts permit the Task 2 handoff; they are not final product/delivery acceptance or release authorization.

## Per-finding disposition

| Finding | Status | Implementation and evidence |
| --- | --- | --- |
| R1 — missing compiler-required helper | **ADDRESSED** | `better-dsh/src/omp-python/better_support.py:73` installs `__omp_with_call_site__`; the helper at line 76 forwards the exact callable/argument and awaits an awaitable result. The original runner compiler remains active and unchanged. The native `tool.read` regression verifies successful value, typed `ToolCallError` rejection/member, and exactly the two expected host calls. Same-cell reset followed by `tool.read` is separately covered. |
| R2 — live subprocess work after cancellation | **ADDRESSED within the root's ruled scope** | The support module captures descendant PID/birth identities at cell entry, excludes the prior baseline, and cleans only newly discovered descendants on cancellation. TERM is followed by KILL, direct children are reaped, and previously recorded identities remain tracked across reparenting during cleanup. Failed inspection/cleanup exits the runner, allowing existing Node group teardown before queue admission. Tests cover the original foreground `!echo $$; sleep 20` case, a new child ignoring SIGINT/SIGTERM, preservation of a prior persistent child, and stable runner PID. The final temporary SIGINT wrapper also records a signal when user code catches `KeyboardInterrupt`, so `finally` cleanup still runs. Its regression passed after first reproducing the leak. |
| R3 — same-cell reset bypasses input guard | **ADDRESSED** | `ResetAdapter` at line 89 adapts the transformed reset call into Better's module-qualified `reset` function. That calls the original native magic, then reinstalls the input guard, compiler helper, and current bindings immediately. It does not modify the immutable runner or globally replace its magic implementation. Regression asserts `%reset\ninput("question")` returns an immediate actionable exception and a subsequent `42` succeeds. Reset followed by a host read in the same cell also succeeds. |
| R4 — synthetic `__file__` exposed as user state | **ADDRESSED** | The call to `_exec_source_async` now uses its default cell filename and no longer triggers `_prepare_file_source` for the adapter's synthetic filename. The empty-namespace regression executes `42` and asserts an empty names result. This remedy avoids adding a blanket filter that would hide a real user-defined `__file__`. |

## R2 final correction and ownership review

The initial exception-only cleanup did miss code that caught `KeyboardInterrupt`. The final version records SIGINT in a Better-owned per-run closure, delegates to the previous runner handler, and performs cleanup in `finally` whenever interruption was observed. During cleanup it ignores the host's confirm SIGINT, then restores the saved handler on surviving paths. Cleanup failure calls `os._exit(130)` so the runner is not falsely reused; the existing Node death/disposal path supplies the outer group cleanup and retains timeout/abort classification. The handler and implementation are outside the immutable runner.

The reviewed scope is **new descendants of the current cancelled cell**, preserving earlier persistent children and ordinary interrupted runner PID. It is not a sandbox or proof about deliberately escaped/double-forked work. The implementation report explicitly documents that boundary. Windows leader-only cleanup remains the previously accepted scoped limitation; the POSIX `ps` fallback is source-reviewed, not runtime-verified by this review.

## Validation evidence considered

- `/tmp/omp-task1-fix1-final.log`: OMP execution and interrupt-race suites **15/15 passed** before the final caught-interrupt addition.
- `/tmp/omp-task1-caught-red.log`: caught-KeyboardInterrupt regression initially failed because the child remained alive.
- `/tmp/omp-task1-caught-green.log`: final OMP execution and interrupt-race suites **16/16 passed**, including the added caught-interrupt regression and prior PID-survival cases.
- `/tmp/omp-task1-resource-guard.log`: throwaway mismatched runner rejected before copying; real original runner copied successfully. The copier hashes bytes against provenance before creating/copying the destination and excludes bytecode/test resources.
- Independently recomputed source runner SHA-256: `e0e660ca44193735a2de467254b050109bb23028aca71af01b9365b9ab88e974`, unchanged from the pinned provenance.
- Parent reports actual Python 3.9 focused execution **11/11 passed** at the stable source before the final signal-wrapper edit (`/tmp/omp-task1-python39.log`). This is independent parent evidence, not a claim that this reviewer reran that interpreter or validated the later edit on 3.9.

No broad tests or duplicate runtime probes were run in this fix round. Inspection and existing focused RED/GREEN evidence resolved the original defects without further test expansion. The earlier report checkpoint describing R2 as pending and caught-interrupt handling as proposed is superseded by the current source and final 16-test log above; implementation-report chronology should be read accordingly.

## Out of scope / unchanged gates

Task 2 snapshots/dill, whole-runtime transaction serialization and cold-start races, checkpoint clearing on reset, final rebuild, tarball installation, PC4999/dev3 behavioral acceptance, and model-visible delivery checks remain the parent/Task 2 responsibilities. No Git commit/tag/push/publish or production action was performed. Only this requested review report was written.
