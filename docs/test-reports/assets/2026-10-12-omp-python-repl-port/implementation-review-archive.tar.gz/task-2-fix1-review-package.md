# Task2 fix round1 working-tree review

No commits per repository release gate; compared exact pre-fix backup to current files. Root-owned runtime/presentation test corrections excluded; they are Task3 final review scope.

- better-dsh/src/kernel.ts: 19195 → 19283 bytes
- better-dsh/src/omp-python/better_snapshot.py: 14326 → 17470 bytes
- better-dsh/src/runtime.ts: 36881 → 36984 bytes
- better-dsh/test/omp-checkpoint-review.spec.ts: 0 → 8563 bytes

```diff
--- pre-fix/better-dsh/src/kernel.ts
+++ current/better-dsh/src/kernel.ts
@@ -17,21 +17,21 @@
   disposeTimeoutMs: number
   /** Retained configuration seam; OMP interrupts with SIGINT directly. */
   interruptConfirmMs: number
   snapshotTimeoutMs: number
   username: string
   snapshotDirectory?: string
   snapshotSizeCapBytes?: number
 }
 export type { SnapshotSpec }
 export type SnapshotOutcome =
-  | { kind: 'ok', sizeBytes: number, names: string[], omitted: Record<string, string>, turn: number }
+  | { kind: 'ok', sizeBytes: number, names: string[], omitted: Record<string, string>, turn: number, warning?: string }
   | { kind: 'skipped', reason: string, estimateBytes?: number, sizeBytes?: number, capBytes: number }
   | { kind: 'failed', reason: string }
 export type RestoreStateOutcome = { kind: 'restored', count: number, turn: number, omitted: Record<string, string> } | { kind: 'degraded', reason: string }
 export type QueryVarOutcome = { kind: 'json' | 'repr', text: string } | { kind: 'names', names: string[] } | { kind: 'missing' } | { kind: 'failed', reason: string }
 export type SetVarOutcome = { kind: 'ok' } | { kind: 'failed', reason: string }
 export type HostRequestOutcome = { ok: true, result: unknown } | { ok: false, message: string }
 export type HostRequestHandler = (data: Record<string, unknown>) => Promise<HostRequestOutcome>
 export interface ExecuteCellOptions {
   timeoutMs: number
   interruptGraceMs: number
@@ -307,24 +307,24 @@
   }
   async setVar(name: string, valueJson: string): Promise<SetVarOutcome> {
     const sentinel = `__better_set_${randomBytes(12).toString('hex')}__`
     const reply = await this.internal(buildSetVarCell(name, valueJson, sentinel), sentinel)
     return reply?.ok === true ? { kind: 'ok' } : { kind: 'failed', reason: 'Python variable assignment failed' }
   }
   async snapshotState(payloadPath: string, manifestPath: string, spec: SnapshotSpec): Promise<SnapshotOutcome> {
     const sentinel = `__better_save_${randomBytes(12).toString('hex')}__`
     const reply = await this.internal(buildSnapshotCell(payloadPath, manifestPath, spec, sentinel), sentinel)
     if (reply?.kind === 'ok' && Array.isArray(reply.names) && typeof reply.sizeBytes === 'number' && typeof reply.turn === 'number' && record(reply.omitted)) {
-      return { kind: 'ok', sizeBytes: reply.sizeBytes, names: reply.names as string[], omitted: reply.omitted as Record<string, string>, turn: reply.turn }
+      return { kind: 'ok', sizeBytes: reply.sizeBytes, names: reply.names as string[], omitted: reply.omitted as Record<string, string>, turn: reply.turn, ...typeof reply.warning === 'string' ? { warning: reply.warning } : {} }
     }
     if (reply?.kind === 'skipped') return { kind: 'skipped', reason: String(reply.reason), capBytes: spec.sizeCapBytes }
-    return { kind: 'failed', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint helper timed out, failed, or exited; previous committed generation retained' }
+    return { kind: 'failed', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint helper timed out, failed, or exited; commit status could not be confirmed' }
   }
   async restoreState(payloadPath: string, manifestPath: string, bindings: string[] = []): Promise<RestoreStateOutcome> {
     const sentinel = `__better_restore_${randomBytes(12).toString('hex')}__`
     const reply = await this.internal(buildRestoreCell(payloadPath, manifestPath, sentinel, bindings), sentinel)
     if (reply?.kind === 'restored' && typeof reply.count === 'number' && typeof reply.turn === 'number' && record(reply.omitted)) {
       return { kind: 'restored', count: reply.count, turn: reply.turn, omitted: reply.omitted as Record<string, string> }
     }
     return { kind: 'degraded', reason: typeof reply?.reason === 'string' ? reply.reason : 'checkpoint restore helper failed or timed out' }
   }
 
```

```diff
--- pre-fix/better-dsh/src/omp-python/better_snapshot.py
+++ current/better-dsh/src/omp-python/better_snapshot.py
@@ -1,18 +1,19 @@
 """Best-effort checkpoints for the owned OMP namespace; dill 0.4.1 adapter.
 
 No cell history is stored/replayed. Pickling user objects is not a sandbox:
 reducers may execute arbitrary code. Host deadlines bound helper execution.
 """
 import _thread
 import asyncio
 import dis
+import functools
 import hashlib
 import io
 import json
 import os
 import platform
 import re
 import socket
 import sqlite3
 import subprocess
 import sys
@@ -152,56 +153,88 @@
                         if op.opname in ('LOAD_GLOBAL', 'LOAD_NAME'):
                             found.add(op.argval)
                     for item in code.co_consts:
                         if isinstance(item, types.CodeType): code_names(item)
                 code_names(value.__code__)
             walk(value.__defaults__)
             walk(value.__kwdefaults__)
             for cell in value.__closure__ or ():
                 try: walk(cell.cell_contents)
                 except ValueError: pass
+        elif isinstance(value, functools.partial):
+            walk(value.func); walk(value.args); walk(value.keywords); walk(vars(value))
         elif isinstance(value, (staticmethod, classmethod)):
             walk(value.__func__)
         elif isinstance(value, property):
             walk(value.fget); walk(value.fset); walk(value.fdel)
         elif isinstance(value, types.MethodType):
             walk(value.__func__); walk(value.__self__)
         elif isinstance(value, dict):
             for key, item in value.items(): walk(key); walk(item)
         elif isinstance(value, (tuple, list, set, frozenset)):
             for item in value: walk(item)
         elif isinstance(value, type):
             if value.__module__ == ns.get('__name__'):
                 for item in vars(value).values(): walk(item)
                 for base in value.__bases__: walk(base)
         elif not isinstance(value, types.ModuleType) and type(value).__module__ == ns.get('__name__'):
             walk(type(value))
             if hasattr(value, '__dict__'): walk(vars(value))
+            # Scan descriptors across the MRO, including inherited/mangled slots.
+            for owner in type(value).__mro__:
+                for descriptor in vars(owner).values():
+                    if isinstance(descriptor, types.MemberDescriptorType):
+                        try: walk(descriptor.__get__(value, type(value)))
+                        except AttributeError: pass  # uninitialized slot
     walk(root)
     return found
 
 
 def _write_new(path, data):
     fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
     with os.fdopen(fd, 'wb') as output:
         output.write(data)
         output.flush()
         os.fsync(output.fileno())
 
 
 def _emit(sentinel, result):
     print(sentinel + json.dumps(result, ensure_ascii=True))
 
 
+def _retained_payloads(manifest_path):
+    try:
+        with open(manifest_path, encoding='utf-8') as source:
+            manifest = json.load(source)
+    except (FileNotFoundError, ValueError):
+        return set(), None
+    if not isinstance(manifest, dict):
+        return set(), None
+    current = manifest.get('payload')
+    names = (current, manifest.get('previousPayload'))
+    retained = {name for name in names if isinstance(name, str) and re.fullmatch(r'state-[0-9a-f]{32}\.dill', name)}
+    return retained, current if isinstance(current, str) and current in retained else None
+
+
+def _scavenge(retained):
+    for name in os.listdir(_DIRECTORY):
+        if name not in retained and re.fullmatch(r'(state-[0-9a-f]{32}\.dill|\.checkpoint-[0-9a-f]{32}\.tmp)', name):
+            os.unlink(os.path.join(_DIRECTORY, name))
+
+
 def save(ns, payload_path, manifest_path, spec_json, sentinel):
+    attempt_paths, committed, result = [], False, None
+    payload_name, manifest, retained = None, None, set()
     try:
         _paths(payload_path, manifest_path)
+        retained, previous = _retained_payloads(manifest_path)
+        _scavenge(retained)  # collect killed-writer artifacts even if this attempt fails
         deadline = time.monotonic() + _TIMEOUT
         def check_deadline():
             if time.monotonic() >= deadline:
                 raise TimeoutError('checkpoint deadline exceeded; previous generation retained')
         spec = json.loads(spec_json)
         cap = min(spec['sizeCapBytes'], _CAP)
         import better_support
         candidates = better_support.user_namespace(ns)
         guard = _guard(ns)
         kept, omitted, dependencies = {}, {}, {}
@@ -230,72 +263,107 @@
         trial_ns = dict(ns)
         trial = _decode(trial_ns, payload)
         if not isinstance(trial, dict) or set(trial) != set(kept):
             raise ValueError('final graph round-trip changed admitted names')
         trial_ns.update(trial)
         groups = {}
         for name, value in kept.items():
             if id(value) in groups and trial[name] is not trial[groups[id(value)]]:
                 raise ValueError('final graph round-trip lost shared root identity')
             groups[id(value)] = name
-        previous = None
-        try:
-            with open(manifest_path, encoding='utf-8') as old:
-                previous = json.load(old).get('payload')
-        except (OSError, ValueError, AttributeError):
-            pass
         token = uuid.uuid4().hex
         payload_name = 'state-' + token + '.dill'
         manifest = dict(_environment(), snapshotFormat=_FORMAT, turn=spec['turn'],
-            payload=payload_name, sizeBytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
+            payload=payload_name, previousPayload=previous, sizeBytes=len(payload), sha256=hashlib.sha256(payload).hexdigest(),
             names=sorted(kept), dependencies={name: sorted(dependencies[name]) for name in kept},
             bindingNames=sorted(better_support.injected_names()), omitted=omitted, coverage='partial' if omitted else 'best-effort',
             skipped=False, limitations=['Dynamic globals/eval and arbitrary extension resources cannot be exhaustively inspected.'])
-        _write_new(os.path.join(_DIRECTORY, payload_name), payload)
+        payload_file = os.path.join(_DIRECTORY, payload_name)
+        attempt_paths.append(payload_file)
+        _write_new(payload_file, payload)
         temp = os.path.join(_DIRECTORY, '.checkpoint-' + token + '.tmp')
+        attempt_paths.append(temp)
         _write_new(temp, json.dumps(manifest, sort_keys=True).encode())
-        # Sole commit point: immutable payload exists before atomic pointer swap.
+        # Sole commit point. Cleanup must never remove this payload afterwards.
         check_deadline()
         os.replace(temp, manifest_path)
+        committed = True
+        result = dict(kind='ok', sizeBytes=len(payload), names=manifest['names'], omitted=omitted, turn=spec['turn'])
+        warnings = []
         if os.name == 'posix':
-            fd = os.open(_DIRECTORY, os.O_RDONLY)
-            try: os.fsync(fd)
-            finally: os.close(fd)
-        # Retain committed + previous payload. Never prune on an unsuccessful save.
-        for old_name in os.listdir(_DIRECTORY):
-            if old_name not in (payload_name, previous) and re.fullmatch(r'(state-[0-9a-f]{32}\.dill|\.checkpoint-[0-9a-f]{32}\.tmp)', old_name):
-                try: os.unlink(os.path.join(_DIRECTORY, old_name))
-                except OSError: pass
-        _emit(sentinel, dict(kind='ok', sizeBytes=len(payload), names=manifest['names'], omitted=omitted, turn=spec['turn']))
+            try:
+                fd = os.open(_DIRECTORY, os.O_RDONLY)
+                try: os.fsync(fd)
+                finally: os.close(fd)
+            except OSError as error:
+                warnings.append('directory fsync failed: ' + str(error))
+        try:
+            _scavenge({payload_name, previous})
+        except OSError as error:
+            warnings.append('stale artifact cleanup failed: ' + str(error))
+        if warnings:
+            result['warning'] = 'checkpoint committed; ' + '; '.join(warnings)
     except SizeCap as error:
-        _emit(sentinel, dict(kind='skipped', reason=str(error), capBytes=_CAP))
+        result = dict(kind='skipped', reason=str(error), capBytes=_CAP)
     except Exception as error:
-        _emit(sentinel, dict(kind='failed', reason=type(error).__name__ + ': ' + str(error)))
+        reason = type(error).__name__ + ': ' + str(error)
+        if payload_name is not None and not committed:
+            try:
+                _, pointed = _retained_payloads(manifest_path)
+                committed = pointed == payload_name
+            except OSError:
+                pass
+        if committed:
+            result = dict(kind='ok', sizeBytes=len(payload), names=manifest['names'], omitted=omitted, turn=spec['turn'])
+            result['warning'] = 'checkpoint committed; postcommit finalization failed: ' + reason
+        else:
+            result = dict(kind='failed', reason=reason)
+    finally:
+        if not committed and attempt_paths:
+            # A signal/error can arrive immediately after replace, before the
+            # local flag changes. The pointer is authoritative for deletion.
+            try:
+                latest, _ = _retained_payloads(manifest_path)
+                retained.update(latest)
+            except OSError:
+                # Cannot prove non-commit: leave recognized artifacts for the
+                # next save's pre-write scavenger rather than risk data loss.
+                retained.update(os.path.basename(path) for path in attempt_paths)
+            for path in attempt_paths:
+                if os.path.basename(path) in retained:
+                    continue
+                try: os.unlink(path)
+                except FileNotFoundError: pass
+                except OSError as error:
+                    if result is not None:
+                        result['reason'] += '; uncommitted artifact cleanup failed: ' + str(error)
+    if result is not None:
+        _emit(sentinel, result)
 
 
 def restore(ns, payload_path, manifest_path, sentinel, bindings_json):
     try:
         _paths(payload_path, manifest_path)
         if os.path.getsize(manifest_path) > 1048576:
             raise ValueError('manifest exceeds metadata cap')
         with open(manifest_path, encoding='utf-8') as source:
             manifest = json.load(source)
         if not isinstance(manifest, dict) or manifest.get('snapshotFormat') != _FORMAT:
             raise ValueError('unsupported snapshot format')
         for key, value in _environment().items():
             if manifest.get(key) != value: raise ValueError('checkpoint environment mismatch: ' + key)
         name = manifest.get('payload', '')
         if not isinstance(name, str) or not re.fullmatch(r'state-[0-9a-f]{32}\.dill', name):
             raise ValueError('invalid owned payload name')
         names = manifest.get('names')
         import better_support
-        if not isinstance(names, list) or any(not isinstance(n, str) or n.startswith('__omp_') or n in ('__name__', '__builtins__', '__doc__') or n in better_support.reserved_names() for n in names):
+        if not isinstance(names, list) or any(not isinstance(n, str) or n.startswith('__omp_') or n in ('__name__', '__builtins__', '__doc__') for n in names):
             raise ValueError('invalid checkpoint namespace names')
         turn = manifest.get('turn')
         if not isinstance(turn, int) or isinstance(turn, bool) or turn < 0:
             raise ValueError('invalid checkpoint turn')
         path = os.path.join(_DIRECTORY, name)
         size = os.path.getsize(path)
         if os.path.islink(path) or size != manifest.get('sizeBytes') or size > _CAP:
             raise ValueError('payload size/cap/path validation failed')
         with open(path, 'rb') as source: payload = source.read(_CAP + 1)
         if hashlib.sha256(payload).hexdigest() != manifest.get('sha256'):
```

```diff
--- pre-fix/better-dsh/src/runtime.ts
+++ current/better-dsh/src/runtime.ts
@@ -621,35 +621,35 @@
     return { kind: 'degraded', reason: restored.reason }
   }
 
   private omissionNotice(omitted: Record<string, string>): string {
     const entries = Object.entries(omitted)
     return entries.length ? `; partial coverage, omitted ${entries.map(([name, reason]) => `${name} (${reason})`).join(', ')}` : ''
   }
 
   /** Restore a fresh child and report whether the observing call had started. */
   private async reviveAfterDeath(key: string, dead: KeyedKernel, started: boolean, bindingNames: string[]): Promise<CodeRunResult> {
+    const execution = started
+      ? 'This cell may have executed partially, including external side effects; inspect their state before choosing any retry. No user code was replayed.'
+      : 'This observing call did not execute. No user code was replayed.'
     let entry: KeyedKernel
     try {
       entry = await this.ensureKernel(key, dead.cwd)
     } catch (error: unknown) {
       return finalizeOutput([], undefined, {
         kind: 'worker-exit',
-        message: `kernel died and respawn failed (${messageOf(error)}); the next run will retry a fresh kernel`,
+        message: `kernel died and respawn failed (${messageOf(error)}); the next run will retry a fresh kernel. ${execution}`,
       }, this.config.maxOutputBytes)
     }
     entry.restoreAttempted = true
     const restore = await this.restoreEntry(entry, bindingNames)
     entry.turn = Math.max(entry.turn, dead.turn)
-    const execution = started
-      ? 'This cell may have executed partially, including external side effects; inspect their state before choosing any retry. No user code was replayed.'
-      : 'This observing call did not execute. No user code was replayed.'
     if (restore.kind === 'restored') {
       return finalizeOutput([], undefined, {
         kind: 'worker-exit',
         message: `the kernel for this session died; its namespace was restored from the turn-${restore.turn} snapshot${this.omissionNotice(restore.omitted)}. Changes after that checkpoint may be lost. ${execution}`,
       }, this.config.maxOutputBytes)
     }
     const detail = restore.kind === 'degraded' ? ` (${restore.reason})` : ''
     return finalizeOutput([], undefined, {
       kind: 'worker-exit',
       message: `the kernel for this session died and no usable snapshot was available${detail}; the next run uses an EMPTY namespace. ${execution}`,
@@ -659,21 +659,22 @@
   /** Save completed mutations and expose partial/failed coverage within output limits. */
   private async snapshotTurnEnd(entry: KeyedKernel): Promise<string | undefined> {
     if (!this.config.snapshotDir || !entry.bridge.isRunning || this.disposed) return
     const dir = join(this.config.snapshotDir, keyDirectoryName(entry.key))
     mkdirSync(dir, { recursive: true, mode: 0o700 })
     const spec: SnapshotSpec = { turn: entry.turn, skills: [], sizeCapBytes: this.config.snapshotSizeCapBytes }
     const outcome = await entry.bridge.snapshotState(join(dir, 'state.dill'), join(dir, 'manifest.json'), spec)
     if (outcome.kind === 'ok') {
       entry.lastSnapshotTurn = outcome.turn
       const omission = this.omissionNotice(outcome.omitted)
-      return omission ? `[dashr] turn-${outcome.turn} checkpoint saved${omission}` : undefined
+      const warning = outcome.warning ? `; ${outcome.warning}` : ''
+      return omission || warning ? `[dashr] turn-${outcome.turn} checkpoint saved${omission}${warning}` : undefined
     }
     const latest = entry.lastSnapshotTurn === undefined ? 'no successful checkpoint available' : `latest successful checkpoint is turn-${entry.lastSnapshotTurn}`
     return `[dashr] namespace snapshot ${outcome.kind === 'skipped' ? 'skipped' : 'failed'}: ${outcome.reason}; ${latest}`
   }
 
   /** Cancel active work, drain admitted transactions, and reap every owned child. */
   private async teardown(): Promise<void> {
     this.disposed = true
     // Cancel active children before draining transactions, so disposal never
     // waits for a user cell's full timeout. Completed mutations already save.
```

```diff
--- pre-fix/better-dsh/test/omp-checkpoint-review.spec.ts
+++ current/better-dsh/test/omp-checkpoint-review.spec.ts
@@ -0,0 +1,157 @@
+import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
+import { tmpdir } from 'node:os'
+import { join } from 'node:path'
+import { describe, expect, it, onTestFinished } from 'vitest'
+import { KERNEL_PYTHON, setupRuntime } from './helpers.ts'
+
+function directory() {
+  const dir = mkdtempSync(join(tmpdir(), 'better-checkpoint-review-'))
+  onTestFinished(() => rmSync(dir, { recursive: true, force: true }))
+  return dir
+}
+const request = (program: string) => ({ program, principal: 's', bindings: [] })
+const files = (dir: string) => readdirSync(join(dir, 's')).sort()
+const manifest = (dir: string) => JSON.parse(readFileSync(join(dir, 's', 'manifest.json'), 'utf8'))
+// Fault injection stays inside the owned child/helper module, out of user globals.
+function moduleCode(code: string) { return `exec(${JSON.stringify(code)}, __import__('better_snapshot').__dict__)` }
+
+describe('checkpoint review regressions', () => {
+  it('restores legal startup binding replacements alongside valuable state', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    expect((await first.runtime.run(request('display = 42\nvaluable = [1, 2]\nvalue = lambda: display'))).error).toBeUndefined()
+    expect(manifest(snapshotDir).names).toContain('display')
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const result = await second.runtime.run(request('[display, valuable, value()]'))
+    expect(result.error).toBeUndefined()
+    expect(result.value).toEqual([42, [1, 2], 42])
+  })
+
+  it('prunes partial and inherited slot callbacks with missing globals transitively', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    const result = await first.runtime.run(request([
+      'import functools', 'good = [7]',
+      'class Bad:', '    def __reduce__(self): raise TypeError("bad value")', 'bad = Bad()',
+      'class Base:', '    __slots__ = ("callback",)',
+      'class Child(Base):', '    __slots__ = ()',
+      'slot = Child()', 'slot.callback = lambda: bad',
+      'wrapped = functools.partial(lambda: bad)',
+      'indirect = lambda: wrapped()', 'via_slot = lambda: slot.callback()',
+      'safe_slot = Child()', 'safe_slot.callback = lambda: good[0]',
+      'safe_partial = functools.partial(lambda n: good[0] + n, 2)',
+    ].join('\n')))
+    expect(result.error).toBeUndefined()
+    for (const name of ['bad', 'slot', 'wrapped', 'indirect', 'via_slot']) expect(manifest(snapshotDir).omitted).toHaveProperty(name)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    const restored = await second.runtime.run(request('good = [9]\n[safe_slot.callback(), safe_partial(), "slot" in globals(), "wrapped" in globals(), "indirect" in globals(), "via_slot" in globals()]'))
+    expect(restored.error).toBeUndefined()
+    expect(restored.value).toEqual([9, 11, false, false, false, false])
+  })
+
+  it('cleans every uncommitted pointer-failure attempt while preserving current and previous payloads', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir })
+    await runtime.run(request('kept = 1'))
+    await runtime.run(request('kept = 2'))
+    const before = files(snapshotDir)
+    const pointer = readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')
+    const setup = moduleCode('def _test_replace(*args):\n    raise OSError("injected pointer failure")\nos.replace = _test_replace')
+    for (let n = 0; n < 3; n++) {
+      const result = await runtime.run(request(n === 0 ? setup : 'kept += 1'))
+      expect(result.logs.join(' ')).toMatch(/snapshot failed.*injected pointer failure/)
+      expect(files(snapshotDir)).toEqual(before)
+      expect(readFileSync(join(snapshotDir, 's', 'manifest.json'), 'utf8')).toBe(pointer)
+    }
+  })
+
+  it('cleans files written by an attempt whose deadline expires before commit', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir, snapshotTimeoutMs: 300 })
+    await runtime.run(request('kept = 1'))
+    const before = files(snapshotDir)
+    const result = await runtime.run(request(moduleCode([
+      '_test_original_write = _write_new',
+      'def _test_slow_write(path, data):',
+      '    _test_original_write(path, data)',
+      '    if path.endswith(".tmp"):',
+      '        try: time.sleep(0.5)',
+      '        except KeyboardInterrupt: pass',
+      '_write_new = _test_slow_write',
+    ].join('\n'))))
+    expect(result.logs.join(' ')).toMatch(/snapshot failed/)
+    expect(files(snapshotDir)).toEqual(before)
+    expect(manifest(snapshotDir).turn).toBe(1)
+  })
+
+  it('scavenges recognized crash orphans before a subsequent capped attempt', async () => {
+    const snapshotDir = directory()
+    const { runtime } = await setupRuntime({ snapshotDir, snapshotSizeCapBytes: 5000 })
+    await runtime.run(request('kept = 1'))
+    await runtime.run(request('kept = 2'))
+    const before = files(snapshotDir)
+    writeFileSync(join(snapshotDir, 's', `state-${'a'.repeat(32)}.dill`), 'abandoned payload')
+    writeFileSync(join(snapshotDir, 's', `.checkpoint-${'b'.repeat(32)}.tmp`), 'abandoned manifest')
+    writeFileSync(join(snapshotDir, 's', 'unrelated.txt'), 'leave this')
+    const result = await runtime.run(request('huge = "x" * 20000'))
+    expect(result.logs.join(' ')).toMatch(/snapshot skipped/)
+    expect(files(snapshotDir)).toEqual([...before, 'unrelated.txt'].sort())
+    expect(manifest(snapshotDir).turn).toBe(2)
+  })
+
+  it('keeps a committed payload and reports a postcommit directory fsync failure truthfully', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 1'))
+    const result = await first.runtime.run(request(moduleCode([
+      'import stat as _test_stat', '_test_original_fsync = os.fsync',
+      'def _test_fsync(fd):',
+      '    if _test_stat.S_ISDIR(os.fstat(fd).st_mode): raise OSError("injected directory fsync failure")',
+      '    return _test_original_fsync(fd)', 'os.fsync = _test_fsync',
+    ].join('\n')) + '\nkept = 2'))
+    expect(result.logs.join(' ')).toMatch(/committed.*fsync/)
+    const saved = manifest(snapshotDir)
+    expect(saved.turn).toBe(2)
+    expect(existsSync(join(snapshotDir, 's', saved.payload))).toBe(true)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    expect((await second.runtime.run(request('kept'))).value).toBe(2)
+  })
+
+  it('keeps the pointed-to payload when replacement succeeds and its wrapper then throws', async () => {
+    const snapshotDir = directory()
+    const first = await setupRuntime({ snapshotDir })
+    await first.runtime.run(request('kept = 1'))
+    const result = await first.runtime.run(request(moduleCode([
+      '_test_original_replace = os.replace',
+      'def _test_replace_after(source, target):',
+      '    _test_original_replace(source, target)',
+      '    raise OSError("injected after pointer commit")',
+      'os.replace = _test_replace_after',
+    ].join('\n')) + '\nkept = 3'))
+    expect(result.logs.join(' ')).toMatch(/committed.*after pointer commit/)
+    const saved = manifest(snapshotDir)
+    expect(saved.turn).toBe(2)
+    expect(existsSync(join(snapshotDir, 's', saved.payload))).toBe(true)
+    await first.fiber.dispose()
+    const second = await setupRuntime({ snapshotDir })
+    expect((await second.runtime.run(request('kept'))).value).toBe(3)
+  })
+
+  it('retains partial-execution wording when a side-effecting cell cannot respawn', async () => {
+    const dir = directory()
+    const marker = join(dir, 'side-effect')
+    const python = join(dir, 'python-wrapper')
+    const quote = (value: string) => "'" + value.replaceAll("'", "'\\''") + "'"
+    writeFileSync(python, `#!/bin/sh\nif [ -f ${quote(marker)} ]; then exit 7; fi\nexec ${quote(KERNEL_PYTHON)} "$@"\n`, { mode: 0o700 })
+    const { runtime } = await setupRuntime({ python, snapshotDir: join(dir, 'snapshots') })
+    await runtime.run(request('kept = 1'))
+    const result = await runtime.run(request(`import os\nwith open(${JSON.stringify(marker)}, "w") as f:\n    f.write("once")\nos._exit(1)`))
+    expect(result.error?.message).toMatch(/respawn failed/)
+    expect(result.error?.message).toMatch(/may have executed partially/)
+    expect(result.error?.message).toMatch(/No user code was replayed/)
+    expect(readFileSync(marker, 'utf8')).toBe('once')
+  })
+})
```
