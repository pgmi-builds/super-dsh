# Task1 fix round1 review

Scope: findings R1-R4 in task-1-review.md and new breakage in fixes only. No commits per root release gate. Previous review package contains prior file versions. Current fixed files below. Original runner unchanged; snapshot/runtime Task2 still deferred. Root-owned patch comment/docs excluded.

## better-dsh/src/omp-python/better_support.py

```
"""Better-owned integration around the unchanged OMP runner (see provenance.json)."""
import ast
import asyncio
import builtins
import contextvars
import json
import inspect
import os
import signal
import subprocess
import time
import sys
import threading
import urllib.request
import uuid

_RUN = contextvars.ContextVar('better_run', default=None)
_SPECS = contextvars.ContextVar('better_specs', default={})
_PENDING = {}
_LOCK = threading.Lock()
_WRITE_LOCK = threading.Lock()
_OWNED = {}
_INJECTED = {}
_STARTED = False
_WRITER = None


class HostRejected(Exception):
    pass


def _deliver(reply):
    with _LOCK:
        item = _PENDING.get(reply.get('id'))
    if item is None:
        return
    loop, future, run = item
    if reply.get('run') != run:
        return
    def settle():
        if not future.done():
            if reply.get('ok') is True:
                future.set_result(reply.get('result'))
            else:
                future.set_exception(HostRejected(reply.get('message') or 'host request failed'))
    loop.call_soon_threadsafe(settle)


def _read_replies():
    with os.fdopen(4, 'r', encoding='utf-8') as reader:
        for line in reader:
            try:
                _deliver(json.loads(line))
            except (ValueError, RuntimeError):
                continue


def unsupported_input(*args, **kwargs):
    raise RuntimeError('Interactive stdin is unsupported in Better Python REPL; pass input as a variable or tool argument')


def initialize(ns):
    global _STARTED, _WRITER
    if not _STARTED:
        _OWNED.update(ns)
        if not os.environ.get('BETTER_CALLBACK_URL'):
            _WRITER = os.fdopen(3, 'w', encoding='utf-8', buffering=1)
            threading.Thread(target=_read_replies, name='better-callback-replies', daemon=True).start()
        _STARTED = True
    # Do not mutate the runner's Python builtins or put internal imports in user globals.
    ns['__builtins__'] = dict(vars(builtins), input=unsupported_input)
    _OWNED['__builtins__'] = ns['__builtins__']
    ns['__omp_with_call_site__'] = with_call_site


async def with_call_site(site_id, action, args):
    """Required runner compiler seam; Better has no speculative read cache."""
    result = action(args)
    return await result if inspect.isawaitable(result) else result


def reset(ns, args):
    """Invoke the native magic, then immediately restore Better capabilities."""
    sys.modules['__main__'].__dict__['__omp_magic']('reset', args)
    initialize(ns)
    install_bindings(ns, _SPECS.get())


class ResetAdapter(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if (isinstance(node.func, ast.Name) and node.func.id == '__omp_magic'
                and len(node.args) == 2 and isinstance(node.args[0], ast.Constant)
                and node.args[0].value == 'reset'):
            module = ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
                args=[ast.Constant('better_support')], keywords=[])
            adapted = ast.Call(func=ast.Attribute(value=module, attr='reset', ctx=ast.Load()),
                args=[ast.Call(func=ast.Name(id='globals', ctx=ast.Load()), args=[], keywords=[]), node.args[1]], keywords=[])
            return ast.copy_location(adapted, node)
        return node


async def host_request(payload):
    run = _RUN.get()
    if run is None:
        raise HostRejected('host callbacks are only available during an active cell')
    request_id = uuid.uuid4().hex
    request = dict(payload, id=request_id, run=run)
    if os.environ.get('BETTER_CALLBACK_URL'):
        def http_call():
            req = urllib.request.Request(os.environ['BETTER_CALLBACK_URL'],
                data=json.dumps(request, allow_nan=False).encode('utf-8'),
                headers={'Authorization': 'Bearer ' + os.environ['BETTER_CALLBACK_TOKEN'], 'Content-Type': 'application/json'})
            # Explicitly bypass consumer proxy settings for the owned loopback endpoint.
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(req, timeout=30) as response:
                return json.load(response)
        reply = await asyncio.to_thread(http_call)
        if reply.get('ok') is not True:
            raise HostRejected(reply.get('message') or 'host request failed')
        return reply.get('result')
    loop = asyncio.get_running_loop()
    future = loop.create_future()
    with _LOCK:
        _PENDING[request_id] = (loop, future, run)
    try:
        with _WRITE_LOCK:
            _WRITER.write(json.dumps(request, allow_nan=False) + '\n')
            _WRITER.flush()
        return await future
    finally:
        with _LOCK:
            _PENDING.pop(request_id, None)


def _error_class(name, member_property):
    def init(self, message, member=None):
        Exception.__init__(self, message)
        if member is not None:
            setattr(self, member_property, member)
    return type(name, (Exception,), {'__init__': init})


def _proxy(ns, global_name, function_name, error_class, flat=False):
    async def invoke(call_args):
        try:
            return await host_request({'type': 'binding.call', 'global': global_name, 'name': function_name, 'args': call_args})
        except HostRejected as rejected:
            cls = ns.get(error_class) if error_class else None
            if cls is None:
                raise
            raise cls(str(rejected), global_name if flat else function_name) from None
    if flat:
        async def callable_binding(args=None, /):
            return await invoke({'args': [] if args is None else [args], 'kwargs': {}})
        callable_binding.__name__ = global_name
        callable_binding.__qualname__ = global_name
        return callable_binding
    async def namespace_binding(*args, **kwargs):
        if kwargs:
            raise TypeError('Better binding calls do not accept keyword arguments')
        return await invoke(args[0] if len(args) == 1 else list(args) if args else None)
    return namespace_binding


def install_bindings(ns, spec):
    for name, value in list(_INJECTED.items()):
        if ns.get(name) is value:
            ns.pop(name, None)
    _INJECTED.clear()
    classes = {}
    for global_name, config in spec.items():
        error = config.get('errorClass')
        error_name = error['name'] if error else None
        if error and error_name not in classes:
            classes[error_name] = _error_class(error_name, error['memberNameProperty'])
        if config.get('callable'):
            value = _proxy(ns, global_name, next(iter(config['functions'])), error_name, flat=True)
        else:
            def holder(global_name=global_name, config=config, error_name=error_name):
                class BindingHolder:
                    def __dir__(self):
                        return sorted(config['functions'])
                    def __getattr__(self, name):
                        return _proxy(ns, global_name, name, error_name)
                return BindingHolder()
            value = holder()
        ns[global_name] = value
        _INJECTED[global_name] = value
    ns.update(classes)
    _INJECTED.update(classes)


def complete(value, sentinel, absent=False):
    envelope = {'ok': True}
    if not absent and value is not None:
        try:
            envelope['json'] = json.dumps(value, allow_nan=False)
        except (TypeError, ValueError, OverflowError):
            envelope['json'] = json.dumps(repr(value))
    print(sentinel + json.dumps(envelope))


def _process_tree():
    """Return descendants and birth identities; no subprocess monkeypatching."""
    if os.name != 'posix':
        return {}  # Windows limitation is explicit in the delivery report.
    root = os.getpid()
    if os.path.isdir('/proc/self/task'):
        tree = {}
        visited = {root}
        pending = [root]
        while pending:
            parent = pending.pop()
            try:
                tasks = os.listdir('/proc/%d/task' % parent)
            except FileNotFoundError:
                continue
            for task in tasks:
                try:
                    with open('/proc/%d/task/%s/children' % (parent, task)) as stream:
                        children = stream.read().split()
                except FileNotFoundError:
                    continue
                for child in children:
                    pid = int(child)
                    if pid in visited:
                        continue
                    visited.add(pid)
                    identity = _process_identity(pid)
                    if identity is not None:
                        tree[pid] = identity[0]
                        pending.append(pid)
        return tree
    result = subprocess.run(['ps', '-axo', 'pid=,ppid=,stat=,lstart='],
        capture_output=True, text=True, check=True, timeout=0.03)
    rows = {}
    for line in result.stdout.splitlines():
        parts = line.split(None, 3)
        if len(parts) == 4:
            rows[int(parts[0])] = (int(parts[1]), parts[3])
    if root not in rows:
        raise RuntimeError('cannot inspect Python process tree')
    found = {root}
    changed = True
    while changed:
        changed = False
        for pid, (parent, _) in rows.items():
            if parent in found and pid not in found:
                found.add(pid)
                changed = True
    return {pid: rows[pid][1] for pid in found if pid != root}


def _process_identity(pid):
    if os.path.isdir('/proc/self/task'):
        try:
            with open('/proc/%d/stat' % pid) as stream:
                text = stream.read()
            fields = text[text.rfind(')') + 2:].split()
            return fields[19], fields[0]
        except FileNotFoundError:
            return None
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'stat=,lstart='],
        capture_output=True, text=True, timeout=0.02)
    parts = result.stdout.strip().split(None, 1)
    return (parts[1], parts[0]) if len(parts) == 2 else None


def _cancel_new_children(baseline):
    if baseline is None:
        raise RuntimeError('process tree baseline unavailable')
    # Capture identities before parents exit/reparent; never signal a reused PID.
    current = _process_tree()
    owned = {pid: birth for pid, birth in current.items() if baseline.get(pid) != birth}
    deadline = time.monotonic() + 0.10
    term_until = time.monotonic() + 0.025
    killed = set()
    for pid in reversed(list(owned)):
        identity = _process_identity(pid)
        if identity and identity[0] == owned[pid] and identity[1] != 'Z':
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
    while True:
        # Pick up children created by a terminating descendant while its
        # parent is still visible; retain identities after reparenting.
        for pid, birth in _process_tree().items():
            if baseline.get(pid) != birth and pid not in owned:
                owned[pid] = birth
                try:
                    os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        # Reap only this cell's direct children; earlier persistent children
        # are left to their owners. Grandchild zombies are no longer executing.
        survivors = []
        for pid, birth in owned.items():
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass
            identity = _process_identity(pid)
            if identity and identity[0] == birth and not identity[1].startswith('Z'):
                survivors.append(pid)
        if not survivors:
            return
        now = time.monotonic()
        if now >= deadline:
            raise RuntimeError('cancelled descendants did not terminate')
        if now >= term_until:
            for pid in survivors:
                if pid not in killed:
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    killed.add(pid)
        time.sleep(min(0.003, deadline - now))


async def run(ns, source, spec_json, sentinel):
    """Retain OMP transforms/compiler/TLA execution; adapt only typed completion."""
    runner = sys.modules['__main__']
    initialize(ns)
    spec = json.loads(spec_json)
    install_bindings(ns, spec)
    spec_token = _SPECS.set(spec)
    token = _RUN.set(runner._CURRENT_RID.get())
    baseline = None
    try:
        try:
            baseline = _process_tree()
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
        transformed = runner.transform_cell(source)
        tree = ResetAdapter().visit(ast.parse(transformed or 'pass', '<cell>', 'exec'))
        # OMP owns compilation and execution. Wrapping its final expression only
        # changes the display boundary to the existing lossless JSON contract.
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            expression = tree.body[-1]
            call = ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
                args=[ast.Constant('better_support')], keywords=[]), attr='complete', ctx=ast.Load()),
                args=[expression.value, ast.Constant(sentinel)], keywords=[])
            tree.body[-1] = ast.copy_location(ast.Expr(value=call), expression)
        else:
            tree.body.append(ast.Expr(value=ast.Call(func=ast.Attribute(value=ast.Call(func=ast.Name(id='__import__', ctx=ast.Load()),
                args=[ast.Constant('better_support')], keywords=[]), attr='complete', ctx=ast.Load()),
                args=[ast.Constant(None), ast.Constant(sentinel)], keywords=[ast.keyword(arg='absent', value=ast.Constant(True))])))
        ast.fix_missing_locations(tree)
        await runner._exec_source_async(ast.unparse(tree), ns)
    except KeyboardInterrupt:
        # The host's confirm SIGINT must not interrupt the cleanup itself.
        previous = signal.signal(signal.SIGINT, signal.SIG_IGN)
        try:
            _cancel_new_children(baseline)
        except BaseException:
            # Cannot honestly return a reusable runner. Host observes death,
            # sweeps the owned group, and preserves the original timeout/abort.
            os._exit(130)
        finally:
            signal.signal(signal.SIGINT, previous)
        raise
    finally:
        _RUN.reset(token)
        _SPECS.reset(spec_token)
        # A detached Python task must not gain admission after its cell ended.
        with _LOCK:
            pending = [item for item in _PENDING.values() if item[2] == runner._CURRENT_RID.get()]
        for loop, future, _ in pending:
            if not future.done():
                future.cancel()


def user_namespace(ns):
    return {name: value for name, value in ns.items()
        if not name.startswith('__omp_') and name not in ('__name__', '__doc__', '__builtins__')
        and not (name in _OWNED and _OWNED[name] is value)
        and not (name in _INJECTED and _INJECTED[name] is value)}


def query(ns, name_json, sentinel):
    user = user_namespace(ns)
    name = json.loads(name_json)
    if name is None:
        reply = {'ok': True, 'kind': 'names', 'names': sorted(user)}
    elif name not in user:
        reply = {'ok': True, 'kind': 'missing'}
    else:
        try:
            reply = {'ok': True, 'kind': 'json', 'text': json.dumps(user[name], allow_nan=False)}
        except (TypeError, ValueError, OverflowError):
            reply = {'ok': True, 'kind': 'repr', 'text': repr(user[name])}
    print(sentinel + json.dumps(reply))


def set_var(ns, name, value_json, sentinel):
    ns[name] = json.loads(value_json)
    print(sentinel + json.dumps({'ok': True}))

```

## better-dsh/scripts/copy-kernel-bridge.mjs

```
#!/usr/bin/env node
/** Verify and ship immutable runner plus Better resources after tsdown. */
import { createHash } from 'node:crypto'
import { cpSync, mkdirSync, readFileSync } from 'node:fs'
const source = new URL('../src/omp-python/', import.meta.url)
const provenance = JSON.parse(readFileSync(new URL('provenance.json', source), 'utf8'))
const expected = provenance.files['runner.py'].sha256
const actual = createHash('sha256').update(readFileSync(new URL('runner.py', source))).digest('hex')
if (actual !== expected) throw new Error(`Immutable OMP runner hash mismatch: expected ${expected}, found ${actual}`)
const target = new URL('../lib/omp-python/', import.meta.url)
mkdirSync(target, { recursive: true })
cpSync(source, target, { recursive: true, filter: path => !path.includes('__pycache__') && !path.endsWith('.pyc') && !path.split(/[\\/]/).includes('tests') })
console.log(`copy-kernel-bridge: verified runner ${actual}; packaged omp-python resources`)

```

## better-dsh/test/omp-execution.spec.ts

```
import { describe, expect, it } from 'vitest'
import { setupRuntime } from './helpers.ts'
import { IpyKernelBridge } from '../src/kernel.ts'

function alive(pid: number): boolean {
  try { process.kill(pid, 0); return true } catch { return false }
}

describe('OMP runner adaptation boundaries', () => {
  it('stops native foreground shell descendants before returning timeout and retains the runner', async () => {
    if (process.platform !== 'linux') return
    const { runtime } = await setupRuntime({ runTimeoutMs: 250, interruptGraceMs: 800, interruptConfirmMs: 20 })
    await runtime.run({ program: '42', bindings: [] })
    const runnerPid = runtime.kernelPid
    const result = await runtime.run({ program: '!echo $$; sleep 20', bindings: [] })
    expect(result.error?.kind).toBe('timeout')
    const shellPid = Number(result.logs.find(line => /^\d+$/.test(line.trim())))
    expect(shellPid).toBeGreaterThan(0)
    expect(alive(shellPid)).toBe(false)
    const after = await runtime.run({ program: '42', bindings: [] })
    expect(after.error).toBeUndefined()
    expect(after.value).toBe(42)
    expect(runtime.kernelPid).toBe(runnerPid)
  })

  it('kills new Popen descendants ignoring SIGINT and SIGTERM before returning timeout', async () => {
    if (process.platform !== 'linux') return
    const { runtime } = await setupRuntime({ runTimeoutMs: 300, interruptGraceMs: 800, interruptConfirmMs: 20 })
    const persistent = await runtime.run({ program: 'import subprocess,sys\nprior = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(20)"])\nprior.pid', bindings: [] })
    const priorPid = Number(persistent.value)
    expect(priorPid).toBeGreaterThan(0)
    const runnerPid = runtime.kernelPid
    const childCode = 'import signal,time; signal.signal(signal.SIGINT,signal.SIG_IGN); signal.signal(signal.SIGTERM,signal.SIG_IGN); time.sleep(20)'
    const result = await runtime.run({ program: [
      'import subprocess,sys,time',
      `p = subprocess.Popen([sys.executable, "-c", ${JSON.stringify(childCode)}])`,
      'print(p.pid, flush=True)',
      'time.sleep(20)',
    ].join('\n'), bindings: [] })
    expect(result.error?.kind).toBe('timeout')
    const childPid = Number(result.logs.find(line => /^\d+$/.test(line.trim())))
    expect(childPid).toBeGreaterThan(0)
    expect(alive(childPid)).toBe(false)
    expect(alive(priorPid)).toBe(true)
    const after = await runtime.run({ program: 'prior.terminate()\nprior.wait()\n42', bindings: [] })
    expect(after.error).toBeUndefined()
    expect(after.value).toBe(42)
    expect(runtime.kernelPid).toBe(runnerPid)
  })

  it('runs native tool.read through the runner call-site helper and preserves typed rejection', async () => {
    const { runtime } = await setupRuntime()
    const calls: unknown[] = []
    const bindings = [{ global: 'tool', functions: { read: async (args: unknown) => {
      calls.push(args)
      if ((args as { path?: string }).path === 'bad') throw new Error('read rejected')
      return { content: 'read-ok' }
    } }, errorClass: { name: 'ToolCallError', memberNameProperty: 'toolName' } }]
    const result = await runtime.run({ program: 'await tool.read({"path": "ok"})', bindings })
    expect(result.error).toBeUndefined()
    expect(result.value).toEqual({ content: 'read-ok' })
    const rejected = await runtime.run({ program: [
      'try:',
      '    await tool.read({"path": "bad"})',
      'except ToolCallError as error:',
      '    caught = {"name": error.toolName, "message": str(error)}',
      'caught',
    ].join('\n'), bindings })
    expect(rejected.error).toBeUndefined()
    expect(rejected.value).toEqual({ name: 'read', message: 'read rejected' })
    expect(calls).toEqual([{ path: 'ok' }, { path: 'bad' }])
  })

  it('reinstalls the input guard immediately after native %reset in the same cell', async () => {
    const { runtime } = await setupRuntime({ runTimeoutMs: 150, interruptGraceMs: 150, interruptConfirmMs: 20 })
    const result = await runtime.run({ program: '%reset\ninput("question")', bindings: [] })
    expect(result.error?.kind).toBe('exception')
    expect(result.error?.message).toContain('Interactive stdin is unsupported')
    const after = await runtime.run({ program: '42', bindings: [] })
    expect(after.error).toBeUndefined()
    expect(after.value).toBe(42)
  })

  it('reinstalls current tool bindings immediately after native %reset', async () => {
    const { runtime } = await setupRuntime()
    const result = await runtime.run({ program: '%reset\nawait tool.read({"path": "ok"})',
      bindings: [{ global: 'tool', functions: { read: async () => 'ok' } }] })
    expect(result.error).toBeUndefined()
    expect(result.value).toBe('ok')
  })

  it('keeps synthetic execution file metadata out of the user namespace', async () => {
    const { runtime } = await setupRuntime()
    await runtime.run({ program: '42', bindings: [] })
    const names = await runtime.queryVar('')
    expect(names).toEqual({ kind: 'names', names: [] })
  })

  it('runs binding fanout concurrently and preserves gather order', async () => {
    const { runtime } = await setupRuntime()
    let active = 0
    let peak = 0
    const result = await runtime.run({
      program: 'import asyncio\nawait asyncio.gather(tools.echo(1), tools.echo(2), tools.echo(3))',
      bindings: [{ global: 'tools', functions: { echo: async value => {
        active++
        peak = Math.max(peak, active)
        await new Promise(resolve => setTimeout(resolve, 40))
        active--
        return Number(value)
      } } }],
    })
    expect(result.error).toBeUndefined()
    expect(result.value).toEqual([1, 2, 3])
    expect(peak).toBe(3)
  })

  it('rejects detached old-cell callbacks before invoking the host', async () => {
    const { runtime } = await setupRuntime()
    let calls = 0
    const bindings = [{ global: 'tools', functions: { echo: async () => { calls++; return 1 } } }]
    const first = await runtime.run({ program: [
      'import asyncio',
      'async def later():',
      '    await asyncio.sleep(0.1)',
      '    try:',
      '        await tools.echo({})',
      '    except Exception:',
      '        pass',
      'background = asyncio.create_task(later())',
    ].join('\n'), bindings })
    expect(first.error).toBeUndefined()
    const after = await runtime.run({ program: 'await asyncio.sleep(0.2)\n42', bindings })
    expect(after.error).toBeUndefined()
    expect(after.value).toBe(42)
    expect(calls).toBe(0)
  })

  it('captures native subprocess stdout without corrupting JSON protocol', async () => {
    const { runtime } = await setupRuntime()
    const result = await runtime.run({ program: 'import subprocess, sys\nsubprocess.run([sys.executable, "-c", "print(12345)"], check=True)\nawait __import__("asyncio").sleep(0.05)\n42', bindings: [] })
    expect(result.error).toBeUndefined()
    expect(result.logs.join('\n')).toContain('12345')
    expect(result.value).toBe(42)
  })

  it('rejects interactive input immediately with an actionable message', async () => {
    const { runtime } = await setupRuntime()
    const result = await runtime.run({ program: 'input("prompt")', bindings: [] })
    expect(result.error?.message).toContain('Interactive stdin is unsupported')
    const after = await runtime.run({ program: '42', bindings: [] })
    expect(after.value).toBe(42)
  })

  it('reaps an interrupt-resistant child before returning cancellation', async () => {
    if (process.platform === 'win32') return
    const bridge = new IpyKernelBridge({ python: 'python3', startupTimeoutMs: 3_000,
      disposeTimeoutMs: 1_000, interruptConfirmMs: 10, snapshotTimeoutMs: 3_000, username: 'test' })
    try {
      await bridge.start()
      const pid = bridge.pid!
      const result = await bridge.executeCell('import signal, time\nsignal.signal(signal.SIGINT, signal.SIG_IGN)\ntime.sleep(30)', {
        timeoutMs: 100, interruptGraceMs: 100, interruptConfirmMs: 10,
      })
      expect(result.outcome).toBe('forced')
      expect(bridge.isDead).toBe(true)
      expect(alive(pid)).toBe(false)
    } finally { await bridge.dispose() }
  })
})

```

